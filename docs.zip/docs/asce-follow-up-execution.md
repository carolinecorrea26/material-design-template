# ASCE follow-up execution

October 5, 2026. This register supplements [the backlog](asce-follow-up-backlog.md). Approved business decisions and Portal Library presentation remain the acceptance baseline. Real PRASE remains excluded. Completion requires evidence against each item's criteria.

## Implementation in this pass

- The aggregate Library component reads the persisted catalog through a captured immutable repository, instead of compiling source migration fixtures in the browser. Tests cover changed stored limits and read failures without generated fallback. Table structure is unchanged. Its production chunk fell from 16,363.04 KB to 7.81 KB; the remaining application/catalog chunks still need attention.
- Ordinary Vitest runs use one worker and a 15-second default test budget, matching the documented handoff invocation. Tests with explicit longer budgets retain them.
- Mock quotes capture the current Site Library revision. Payment sends its captured revision and applicant. Changed Library data rejects new authorization against an old quote. New submissions require the current revision, matching quote revision/applicant and an unexpired quote. Successful submissions reserve their payment IDs against use by another submission; exact submission replay remains durable across restart.
- The mock server caches each immutable payload's revision and the seed's base hash. Saving replaces the payload and invalidates that cache entry by identity, avoiding repeated hashing of the large catalog for every quote/authorization while retaining changed-Site revision checks.

## Current status and completion requirements

| ID | Status | Next work and required evidence |
|---|---|---|
| ASCE-01 | Needs approved sources | Supply versioned member/spouse/child Life and DI application forms, state variants, beneficiary rules and consents. Map every screen input/consent to a source location and compare rendered documents. Required acknowledgements must block advancement. |
| ASCE-02 | Needs approved sources | Supply effective-dated offline rates, age basis, class/plan mapping, modal factors, credits/fees and independently approved premium examples. Replay those examples through the persisted adapter. Synthetic rates remain test fixtures. |
| ASCE-03 | Needs business decision | Supply an approved CIR crosswalk: identifiers, applicants, ages/amounts/terms, base-policy dependency, new-base/in-force/rider-only rules and documents. Resolve brochure/application disagreement before implementing these branches. |
| ASCE-04 | Needs business decision | Resolve 20-Year code 121 versus 102 with source/version and explicit authority. Update configuration, document references and offline rate mappings together. Existing provisional 121 is not approval of the disputed code. |
| ASCE-05 | Needs approved sources; engineering open | Supply QD/FUW questionnaires and answer-to-pathway decisions. Implement deterministic mock decisions and member/spouse boundary cases, retaining the six approved ASCE decisions. Label outcomes simulated. |
| ASCE-06 | Needs sources and integration contract | Define approved document templates and signature adapter lifecycle, consent evidence, payment ordering, declined/expired signature and final submission. Verify assembled documents before enabling downloads. Actual integration needs provider access; mock acceptance is a separate milestone. |
| ASCE-07 | Engineering open; real delivery needs provider configuration | Replace same-tab storage/fixed 123456 with durable mock saves and expiring single-use links/codes. Match application, Site and recipient. Test wrong recipient, expiry, revocation/replay, household isolation, restart and recovery in a fresh browser session. Local outbox previews establish mock delivery only. |
| ASCE-08 | Domain mock contracts exist; browser work open | Expose explicit mock policy lookup, references and permitted increase/rider-only modes. Use service verification, not a form checkbox. Browser cases must cover active/missing/lapsed/expired/wrong-owner policies and recompute benefits, aggregates and billing. CIR-specific rules await ASCE-03. |
| ASCE-09 | Needs approved child semantics; browser work open | Confirm per-child versus family elections/pricing, age/student/gender bands and the maximum-one-child-Life-plan rule. Then collect each child separately; test siblings, add/change/remove, aggregates, Review and pricing. Unsupported bands stay unavailable. |
| ASCE-10 | Live demonstration deferred | The prior instruction to skip live sign-in remains in effect. When resumed, use the existing account/TOTP. Verify ASCE label/required, estimate visibility and Bill me fee through UI save/reload and restore baseline. Isolated API persistence is already tested. |
| ASCE-11 | Compiler issue and suite reliability verified; additional splitting open | Persisted reads replace browser fixture generation; committed worker/time budgets are in place. Full ordinary suite passes. Remaining application/catalog chunks still produce a warning. Further splitting must preserve Library acceptance criteria. |
| ASCE-12 | Mock hardening implemented; production gate open | Revision, expiry, applicant binding and payment reuse checks added. Still required: independent browser regression, full server-side rules/answers/consents validation, complete quote-dimension binding, approved signature/submission order, production adapters/security and release approval. Minimal mock records do not meet this production contract. |

## Verification

Build and repository lint pass; final mock-server/test lint passes after the revision-cache change. The aggregate chunk is 7.81 KB; shared application/catalog chunks remain 1,495.91 KB and 685.11 KB, so the ordinary large-chunk warning remains.

Final complete run with approved loopback access: **958 passed, 4 PostgreSQL-only skipped, zero failures**, across 89 passing files and one skipped file (446.85 seconds). This includes the latest revision-cache and reauthorization checks. Focused mock-service/persisted-cutover tests: 12/12 pass, using isolated temporary stores and loopback ports. Aggregate tests: 4/4 pass, including stored-policy edits and read failures. Earlier full sandbox run: 947 passed, 11 failed because localhost ports were denied, 4 skipped; the complete rerun supersedes that environment-limited result.

## Source intake and engineering order

For each source/decision, record the item ID, product/applicant/state scope, title/version/effective date, exact section/table/cell, accepted rule/value, authority, superseded conflict and expected examples. Do not replace historical evidence or close a source-dependent item using a guessed value.

After reliability: ASCE-07 durable mock resume; ASCE-08 existing-policy browser journeys; ASCE-09 separate-child journeys when semantics are confirmed; ASCE-05/06 when approved questionnaires/documents arrive. ASCE-12 remains a release gate throughout.

## ASCE-07 implementation boundary

Current code reads one unscoped `applicationFormValues` session-storage key (`ApplicationFormContext.tsx`), accepts the fixed demonstration code (`ResumeCode.tsx`), and substitutes a returning-applicant fixture when that session is empty. Generated resume email links use the support website rather than a persisted application/token (`mockEmail.ts`). These behaviors must be replaced together before durable resume is accepted.

The mock implementation should use a separate applicant save store, not Library drafts or administrator credentials. Save records need an opaque application ID, Site, immutable recipient, current Library revision, expiry, values and a write capability. Resume requests must select that application/recipient/Site, issue a hashed expiring link token, and use an independently expiring challenge. Resend revokes previous tokens/challenges; successful recovery consumes them and replaces the current household state rather than merging it. A changed Library revision requires explicit revalidation before submission. The local outbox must identify simulation and preserve the Site in links. No route may silently load an unrelated demonstration household.

Required acceptance cases: save then restart; recovery in a fresh tab/session; unrelated recipient/Site/application; same recipient with two households; expired/revoked/replayed link; wrong/expired code and attempt limits; a new request invalidating the old one; stale Library revision; failed storage writes; and restoration of the correct household, coverage and billing choices. Real notification delivery remains a provider-dependent follow-up.
