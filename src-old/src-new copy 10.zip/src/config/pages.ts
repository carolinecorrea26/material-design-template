
export const pages = [
  { id: "home", path: "/", type: "home", title: "Home" },
  {
    id: "membership",
    path: "/membership",
    type: "form",
    title: "Membership",
    groupId: "get-started",
  },
  {
    id: "eligibility",
    path: "/eligibility",
    type: "form",
    title: "Eligibility",
    groupId: "get-started",
  },
  {
    id: "coverage",
    path: "/coverage",
    type: "form",
    title: "Coverage",
    groupId: "coverage",
  },
  {
    id: "coverage-questions",
    path: "/coverage-questions",
    type: "form",
    title: "Coverage Questions",
    groupId: "coverage",
  },
  {
    id: "coverage-options",
    path: "/coverage-options",
    type: "form",
    title: "Coverage Options",
    groupId: "coverage",
  },
  {
    id: "beneficiary",
    path: "/beneficiary",
    type: "form",
    title: "Beneficiary",
    groupId: "coverage",
  },
  {
    id: "contact",
    path: "/contact",
    type: "form",
    title: "Contact",
    groupId: "profile",
  },
  {
    id: "personal",
    path: "/personal",
    type: "form",
    title: "Personal",
    groupId: "profile",
  },
  {
    id: "financial",
    path: "/financial",
    type: "form",
    title: "Financial",
    groupId: "profile",
  },
  {
    id: "review",
    path: "/review",
    type: "form",
    title: "Review",
    groupId: "review",
  },
  {
    id: "docusign",
    path: "/docusign",
    type: "form",
    title: "DocuSign",
    groupId: "review",
  },
  {
    id: "health-si",
    path: "/health-si",
    type: "form",
    title: "Health SI",
    groupId: "health",
  },
  {
    id: "health-qd",
    path: "/health-qd",
    type: "form",
    title: "Health QD",
    groupId: "health",
  },
  {
    id: "health-di",
    path: "/health-di",
    type: "form",
    title: "Health DI",
    groupId: "health",
  },
  {
    id: "health-cir",
    path: "/health-cir",
    type: "form",
    title: "Health CIR",
    groupId: "health",
  },
  {
    id: "decision",
    path: "/decision",
    type: "form",
    title: "Decision",
    groupId: "review",
  },
  {
    id: "payment",
    path: "/payment",
    type: "form",
    title: "Payment",
    groupId: "payment",
  },
  { id: "receipt", path: "/receipt", type: "receipt", title: "Receipt" },
  { id: "resume", path: "/resume", type: "resume", title: "Resume" },
] as const;

export type PageType = "home" | "form" | "receipt" | "resume";

export function getPagePath(id: (typeof pages)[number]["id"]) {
  const page = pages.find((page) => page.id === id);

  if (!page) {
    throw new Error(`Missing page path for page id: ${id}`);
  }

  return page.path;
}
