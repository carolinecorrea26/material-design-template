import { useState } from "react";
import {
  Button,
  Card,
  CardContent,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  FormLabel,
  MenuItem,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import { useFieldArray, type Control } from "react-hook-form";

type Child = {
  firstName: string;
  lastName: string;
  birthDate: string;
  gender: string;
};

type FormValues = Record<string, any>;

type ChildrenListProps = {
  control: Control<FormValues>;
};

const genderOptions = [
  { value: "male", label: "Male" },
  { value: "female", label: "Female" },
  { value: "other", label: "Other" },
];

export default function ChildrenList({ control }: ChildrenListProps) {
  const { fields, append, remove, update } = useFieldArray({
    control,
    name: "children",
  });

  const [showForm, setShowForm] = useState(false);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [formData, setFormData] = useState<Child>({
    firstName: "",
    lastName: "",
    birthDate: "",
    gender: "",
  });

  const handleAdd = () => {
    setFormData({ firstName: "", lastName: "", birthDate: "", gender: "" });
    setEditingIndex(null);
    setShowForm(true);
  };

  const handleEdit = (index: number) => {
    setFormData(fields[index] as unknown as Child);
    setEditingIndex(index);
    setShowForm(true);
  };

  const handleSave = () => {
    if (editingIndex !== null) {
      update(editingIndex, formData);
    } else {
      append(formData);
    }
    setShowForm(false);
  };

  const handleCancel = () => {
    setShowForm(false);
  };

  return (
    <div>
      {fields.map((field, index) => {
        const child = field as unknown as Child;
        return (
          <Card key={field.id} sx={{ mb: 2 }}>
            <CardContent>
              <Typography variant="h6">
                {child.firstName} {child.lastName}
              </Typography>
              <Typography>Birth Date: {child.birthDate}</Typography>
              <Typography>Gender: {child.gender}</Typography>
              <Button onClick={() => handleEdit(index)}>Edit</Button>
              <Button onClick={() => remove(index)} color="error">
                Remove
              </Button>
            </CardContent>
          </Card>
        );
      })}

      <Button onClick={handleAdd} variant="outlined">
        Add Child
      </Button>

      <Dialog open={showForm} onClose={handleCancel} maxWidth="sm" fullWidth>
        <DialogTitle>
          {editingIndex !== null ? "Edit Child" : "Add Child"}
        </DialogTitle>
        <DialogContent>
          <TextField
            label="First Name"
            value={formData.firstName}
            onChange={(e) =>
              setFormData({ ...formData, firstName: e.target.value })
            }
            fullWidth
            margin="normal"
            required
          />
          <TextField
            label="Last Name"
            value={formData.lastName}
            onChange={(e) =>
              setFormData({ ...formData, lastName: e.target.value })
            }
            fullWidth
            margin="normal"
            required
          />
          <TextField
            label="Date of Birth"
            type="date"
            value={formData.birthDate}
            onChange={(e) =>
              setFormData({ ...formData, birthDate: e.target.value })
            }
            fullWidth
            margin="normal"
            InputLabelProps={{ shrink: true }}
            required
          />
          <FormControl fullWidth margin="normal">
            <FormLabel>Gender</FormLabel>
            <Select
              value={formData.gender}
              onChange={(e) =>
                setFormData({ ...formData, gender: e.target.value })
              }
            >
              {genderOptions.map((option) => (
                <MenuItem key={option.value} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCancel}>Cancel</Button>
          <Button onClick={handleSave} variant="contained">
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
