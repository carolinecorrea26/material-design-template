import { Box, Stack, Typography } from "@mui/material";
import type { ClientConfig } from "../../config/clients/types";

type AppFooterProps = {
  client: ClientConfig;
};

export default function AppFooter({ client }: AppFooterProps) {
  return (
    <Box
      component="footer"
      sx={{
        mt: 4,
        py: 4,
        px: { xs: 2, sm: 3, md: 4 },
        backgroundColor: "#f2f4f8",
        color: "#798293",
      }}
    >
      <Box
        sx={{
          width: "100%",
          maxWidth: 1400,
          marginLeft: "auto",
          marginRight: "auto",
          display: "grid",
          gridTemplateColumns: { xs: "1fr", md: "repeat(3, minmax(0, 1fr))" },
          gap: 3,
        }}
      >
        <Stack spacing={0.5}>
          <Typography
            variant="body2"
            sx={{ fontWeight: 600, color: "inherit" }}
          >
            {client.branding.name}
          </Typography>
          <Typography sx={{ fontSize: "0.75rem", color: "inherit" }}>
            Insurance application portal
          </Typography>
        </Stack>

        <Stack spacing={0.5}>
          <Typography
            variant="body2"
            sx={{ fontWeight: 600, color: "inherit" }}
          >
            Contact
          </Typography>
          {(client.support.phoneDisplay ?? client.support.phone) ? (
            <Typography sx={{ fontSize: "0.75rem", color: "inherit" }}>
              {client.support.phoneDisplay ?? client.support.phone}
            </Typography>
          ) : null}
          {client.support.email ? (
            <Typography sx={{ fontSize: "0.75rem", color: "inherit" }}>
              {client.support.email}
            </Typography>
          ) : null}
        </Stack>

        <Stack spacing={0.5}>
          <Typography
            variant="body2"
            sx={{ fontWeight: 600, color: "inherit" }}
          >
            Website
          </Typography>
          {client.support.website ? (
            <Typography sx={{ fontSize: "0.75rem", color: "inherit" }}>
              {client.support.website}
            </Typography>
          ) : (
            <Typography sx={{ fontSize: "0.75rem", color: "inherit" }}>
              Not available
            </Typography>
          )}
        </Stack>
      </Box>
    </Box>
  );
}
