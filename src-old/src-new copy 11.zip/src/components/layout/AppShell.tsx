import type { ReactNode } from "react";
import { getActiveClient } from "../../client/getActiveClient";
import DevTools from "../../dev/DevTools";
import AppHeader from "./AppHeader";
import AppBody from "./AppBody";
import AppFooter from "./AppFooter";

type AppShellProps = {
  children: ReactNode;
};

export default function AppShell({ children }: AppShellProps) {
  const client = getActiveClient();

  return (
    <div>
      <AppHeader client={client} />
      <AppBody>{children}</AppBody>
      <AppFooter client={client} />
      <DevTools />
    </div>
  );
}
