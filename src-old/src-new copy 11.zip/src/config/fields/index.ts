import type { FieldDefinition, FieldId } from "./types";

export const fieldCatalog: Record<FieldId, FieldDefinition> = {
  membership: {
    id: "membership",
    label: "Are you currently a member?",
    inputType: "radio",
    required: true,
    options: [
      { value: "yes", label: "Yes" },
      { value: "no", label: "No" },
    ],
  },

  title: {
    id: "title",
    label: "Title",
    inputType: "dropdown",
    placeholder: "Select",
    options: [
      { value: "mr", label: "Mr." },
      { value: "mrs", label: "Mrs." },
      { value: "ms", label: "Ms." },
      { value: "dr", label: "Dr." },
    ],
  },

  "first-name": {
    id: "first-name",
    label: "First name",
    inputType: "text",
    required: true,
    autoComplete: "given-name",
  },

  "last-name": {
    id: "last-name",
    label: "Last name",
    inputType: "text",
    required: true,
    autoComplete: "family-name",
  },

  email: {
    id: "email",
    label: "Email address",
    inputType: "text",
    required: true,
    format: "email",
    autoComplete: "email",
    inputMode: "email",
  },

  phone: {
    id: "phone",
    label: "Phone number",
    inputType: "text",
    required: true,
    format: "phone",
    autoComplete: "tel",
    inputMode: "tel",
  },

  "zip-postal-code": {
    id: "zip-postal-code",
    label: "Zip / Postal Code",
    inputType: "text",
    required: true,
    autoComplete: "postal-code",
    inputMode: "numeric",
  },

  "state-province": {
    id: "state-province",
    label: "State / Province",
    inputType: "dropdown",
    required: true,
    placeholder: "Select",
    options: [
      { value: "AL", label: "Alabama" },
      { value: "AK", label: "Alaska" },
      { value: "AZ", label: "Arizona" },
      { value: "AR", label: "Arkansas" },
      { value: "CA", label: "California" },
      { value: "CO", label: "Colorado" },
      { value: "CT", label: "Connecticut" },
      { value: "DE", label: "Delaware" },
      { value: "DC", label: "District of Columbia" },
      { value: "FL", label: "Florida" },
      { value: "GA", label: "Georgia" },
      { value: "HI", label: "Hawaii" },
      { value: "ID", label: "Idaho" },
      { value: "IL", label: "Illinois" },
      { value: "IN", label: "Indiana" },
      { value: "IA", label: "Iowa" },
      { value: "KS", label: "Kansas" },
      { value: "KY", label: "Kentucky" },
      { value: "LA", label: "Louisiana" },
      { value: "ME", label: "Maine" },
      { value: "MD", label: "Maryland" },
      { value: "MA", label: "Massachusetts" },
      { value: "MI", label: "Michigan" },
      { value: "MN", label: "Minnesota" },
      { value: "MS", label: "Mississippi" },
      { value: "MO", label: "Missouri" },
      { value: "MT", label: "Montana" },
      { value: "NE", label: "Nebraska" },
      { value: "NV", label: "Nevada" },
      { value: "NH", label: "New Hampshire" },
      { value: "NJ", label: "New Jersey" },
      { value: "NM", label: "New Mexico" },
      { value: "NY", label: "New York" },
      { value: "NC", label: "North Carolina" },
      { value: "ND", label: "North Dakota" },
      { value: "OH", label: "Ohio" },
      { value: "OK", label: "Oklahoma" },
      { value: "OR", label: "Oregon" },
      { value: "PA", label: "Pennsylvania" },
      { value: "RI", label: "Rhode Island" },
      { value: "SC", label: "South Carolina" },
      { value: "SD", label: "South Dakota" },
      { value: "TN", label: "Tennessee" },
      { value: "TX", label: "Texas" },
      { value: "UT", label: "Utah" },
      { value: "VT", label: "Vermont" },
      { value: "VA", label: "Virginia" },
      { value: "WA", label: "Washington" },
      { value: "WV", label: "West Virginia" },
      { value: "WI", label: "Wisconsin" },
      { value: "WY", label: "Wyoming" },
    ],
  },

  "birth-date": {
    id: "birth-date",
    label: "Date of Birth",
    inputType: "date",
    required: true,
  },

  dependents: {
    id: "dependents",
    label: "Would you like to add dependent coverage?",
    inputType: "checkbox-group",
    options: [
      { value: "spouse", label: "Spouse" },
      { value: "child", label: "Child" },
    ],
  },

  "spouse-first-name": {
    id: "spouse-first-name",
    label: "Spouse first name",
    inputType: "text",
    required: true,
    autoComplete: "given-name",
  },

  "spouse-last-name": {
    id: "spouse-last-name",
    label: "Spouse last name",
    inputType: "text",
    required: true,
    autoComplete: "family-name",
  },

  "spouse-birth-date": {
    id: "spouse-birth-date",
    label: "Spouse date of birth",
    inputType: "date",
    required: true,
  },

  "child-first-name": {
    id: "child-first-name",
    label: "Child first name",
    inputType: "text",
    required: true,
    autoComplete: "given-name",
  },

  "child-last-name": {
    id: "child-last-name",
    label: "Child last name",
    inputType: "text",
    required: true,
    autoComplete: "family-name",
  },

  "child-birth-date": {
    id: "child-birth-date",
    label: "Child date of birth",
    inputType: "date",
    required: true,
  },
};
