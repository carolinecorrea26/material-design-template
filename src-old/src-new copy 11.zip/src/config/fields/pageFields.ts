import type { PageId } from "../../types/page";
import type { FieldId } from "./types";

export const pageFields: Partial<Record<PageId, FieldId[]>> = {
  membership: [
    "membership",
    "title",
    "first-name",
    "last-name",
    "email",
    "phone",
  ],
  eligibility: [
    "zip-postal-code",
    "state-province",
    "birth-date",
    "dependents",
    "spouse-first-name",
    "spouse-last-name",
    "spouse-birth-date",
  ],
};
