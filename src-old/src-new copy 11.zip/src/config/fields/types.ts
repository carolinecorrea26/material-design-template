export type FieldOption = {
  value: string;
  label: string;
};

export type FieldInputType =
  | "text"
  | "radio"
  | "dropdown"
  | "checkbox"
  | "checkbox-group"
  | "date";

export type FieldId =
  | "membership"
  | "title"
  | "first-name"
  | "last-name"
  | "email"
  | "phone"
  | "zip-postal-code"
  | "state-province"
  | "birth-date"
  | "dependents"
  | "spouse-first-name"
  | "spouse-last-name"
  | "spouse-birth-date"
  | "child-first-name"
  | "child-last-name"
  | "child-birth-date";

export type FieldDefinition = {
  id: string;
  label: string;
  inputType: FieldInputType;
  required?: boolean;
  placeholder?: string;
  options?: FieldOption[];
  autoComplete?: string;
  inputMode?: "text" | "email" | "tel" | "numeric";
  format?: "email" | "phone";
  labelVariant?: "floating" | "standard";
};

export type ClientPageFieldConfig = {
  overrides?: Partial<
    Record<string, Partial<FieldDefinition> & { hidden?: boolean }>
  >;
  extraFields?: FieldDefinition[];
};
