import type { PageId } from "../../types/page";
import type { PageSectionConfig } from "./types";

export const pageSections: Partial<Record<PageId, PageSectionConfig[]>> = {
  membership: [
    {
      id: "default",
      pageId: "membership",
      fieldIds: [
        "membership",
        "title",
        "first-name",
        "last-name",
        "email",
        "phone",
      ],
    },
  ],

  eligibility: [
    {
      id: "selfEligibility",
      pageId: "eligibility",
      title: "Eligibility",
      fieldIds: ["zip-postal-code", "state-province", "birth-date"],
    },
    {
      id: "dependentSelection",
      pageId: "eligibility",
      // title: "Would you like to add dependent coverage?",
      fieldIds: ["dependents"],
    },
    {
      id: "spouseSection",
      pageId: "eligibility",
      title: "Spouse information",
      fieldIds: ["spouse-first-name", "spouse-last-name", "spouse-birth-date"],
      visibleWhen: [{ fieldId: "dependents", includes: "spouse" }],
    },
    {
      id: "childSection",
      pageId: "eligibility",
      title: "Children",
      fieldIds: [],
      visibleWhen: [{ fieldId: "dependents", includes: "child" }],
    },
  ],
};
