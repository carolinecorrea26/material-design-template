export const pages = [
  { id: "home", path: "/", type: "home", title: "Home" },
  {
    id: "membership",
    path: "/membership",
    type: "form",
    title: "Start your insurance application below.",
    groupId: "get-started",
  },
  {
    id: "eligibility",
    path: "/eligibility",
    type: "form",
    title: "Check your eligibility for coverage.",
    groupId: "get-started",
  },
  {
    id: "coverage",
    path: "/coverage",
    type: "form",
    title: "Add the coverage you want to apply for.",
    groupId: "coverage",
  },
  {
    id: "coverage-questions",
    path: "/coverage-questions",
    type: "form",
    title: "We need some more information to calculate coverage options.",
    groupId: "coverage",
  },
  {
    id: "coverage-options",
    path: "/coverage-options",
    type: "form",
    title: "Choose from your available coverage options below.",
    groupId: "coverage",
  },
  {
    id: "beneficiary",
    path: "/beneficiary",
    type: "form",
    title: "Add your beneficiary information.",
    groupId: "coverage",
  },
  {
    id: "contact",
    path: "/contact",
    type: "form",
    title:
      "Enter your contact details so we can reach you about your application.",
    groupId: "profile",
  },
  {
    id: "personal",
    path: "/personal",
    type: "form",
    title: "Tell us about yourself so we can continue your application.",
    groupId: "profile",
  },
  {
    id: "financial",
    path: "/financial",
    type: "form",
    title: "Share your financial and existing coverage details.",
    groupId: "profile",
  },
  {
    id: "review",
    path: "/review",
    type: "form",
    title:
      "Review your application and complete your authorizations before signing.",
    groupId: "review",
  },
  {
    id: "docusign",
    path: "/docusign",
    type: "form",
    title: "Sign Your Application",
    groupId: "review",
  },
  {
    id: "decision",
    path: "/decision",
    type: "form",
    title: "Review the decision details for your requested coverage.",
    groupId: "review",
  },
  {
    id: "payment",
    path: "/payment",
    type: "form",
    title: "Choose how you would like to pay for your coverage.",
    groupId: "payment",
  },
  {
    id: "receipt",
    path: "/receipt",
    type: "receipt",
    title: "Thank you! Your application has been submitted.",
  },
  {
    id: "resume",
    path: "/resume",
    type: "resume",
    title: "Resume Application",
  },
] as const;

export type PageType = "home" | "form" | "receipt" | "resume";

export function getPagePath(id: (typeof pages)[number]["id"]) {
  const page = pages.find((page) => page.id === id);

  if (!page) {
    throw new Error(`Missing page path for page id: ${id}`);
  }

  return page.path;
}
