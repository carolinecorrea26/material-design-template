import FormRoutePage from "../components/form/FormRoutePage";

export default function Beneficiary() {
  return <FormRoutePage pageId="beneficiary" title="Beneficiary" />;
}
