import FormRoutePage from "../components/form/FormRoutePage";

export default function Contact() {
  return <FormRoutePage pageId="contact" title="Contact" />;
}
