import FormRoutePage from "../components/form/FormRoutePage";

export default function DocuSign() {
  return <FormRoutePage pageId="docusign" title="DocuSign" />;
}
