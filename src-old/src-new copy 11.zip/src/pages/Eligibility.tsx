import FormRoutePage from "../components/form/FormRoutePage";

export default function Eligibility() {
  return <FormRoutePage pageId="eligibility" title="Eligibility" />;
}
