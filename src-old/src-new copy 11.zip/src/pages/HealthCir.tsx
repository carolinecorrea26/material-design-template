import FormRoutePage from "../components/form/FormRoutePage";

export default function HealthCir() {
  return <FormRoutePage pageId="health-cir" title="Health CIR" />;
}
