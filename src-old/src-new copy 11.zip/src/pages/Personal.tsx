import FormRoutePage from "../components/form/FormRoutePage";

export default function Personal() {
  return <FormRoutePage pageId="personal" title="Personal" />;
}
