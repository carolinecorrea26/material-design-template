import FormRoutePage from "../components/form/FormRoutePage";

export default function Review() {
  return <FormRoutePage pageId="review" title="Review" />;
}
