import FormRoutePage from "../components/form/FormRoutePage";

export default function CoverageOptions() {
  return <FormRoutePage pageId="coverage-options" />;
}
