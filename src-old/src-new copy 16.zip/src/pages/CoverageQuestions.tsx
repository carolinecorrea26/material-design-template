import FormRoutePage from "../components/form/FormRoutePage";

export default function CoverageQuestions() {
  return <FormRoutePage pageId="coverage-questions" />;
}
