import FormRoutePage from "../components/form/FormRoutePage";

export default function Decision() {
  return <FormRoutePage pageId="decision" />;
}
