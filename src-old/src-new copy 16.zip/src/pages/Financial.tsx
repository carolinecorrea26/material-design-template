import FormRoutePage from "../components/form/FormRoutePage";

export default function Financial() {
  return <FormRoutePage pageId="financial" />;
}
