import FormRoutePage from "../components/form/FormRoutePage";

export default function HealthDi() {
  return <FormRoutePage pageId="health-di" />;
}
