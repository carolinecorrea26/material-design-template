import FormRoutePage from "../components/form/FormRoutePage";

export default function HealthQd() {
  return <FormRoutePage pageId="health-qd" />;
}
