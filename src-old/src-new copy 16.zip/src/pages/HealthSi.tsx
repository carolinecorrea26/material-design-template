import FormRoutePage from "../components/form/FormRoutePage";

export default function HealthSi() {
  return <FormRoutePage pageId="health-si" />;
}
