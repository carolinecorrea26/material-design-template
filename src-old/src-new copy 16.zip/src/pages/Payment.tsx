import FormRoutePage from "../components/form/FormRoutePage";

export default function Payment() {
  return <FormRoutePage pageId="payment" />;
}
