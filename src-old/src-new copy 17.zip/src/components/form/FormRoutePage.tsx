import { useEffect } from "react";
import { Button, Typography } from "@mui/material";
import {
  useForm,
  type Control,
  type FieldErrors,
  type UseFormSetValue,
} from "react-hook-form";
import { useNavigate } from "react-router-dom";
import type { PageId } from "../../types/page";
import { getClientPageFields } from "../../config/clientFields/getClientPageFields";
import {
  getNextFormPageId,
  getPreviousFormPageId,
} from "../../config/formFlow";
import { getPageTitle } from "../../config/pages";
import { getPageSections } from "../../config/pageSections";
import type { PageSectionConfig } from "../../config/pageSections/types";
import type { FieldDefinition } from "../../config/fields/types";
import { useApplicationForm } from "../../state/ApplicationFormContext";
import FormPage from "./FormPage";
import FieldRenderer from "./FieldRenderer";
import ChildrenList from "./ChildrenList";

export type FormRoutePageValues = Record<string, any>;

export type FormRouteRenderProps = {
  control: Control<FormRoutePageValues>;
  errors: FieldErrors<FormRoutePageValues>;
  watchedValues: FormRoutePageValues;
  allFields: FieldDefinition[];
  pageSections: PageSectionConfig[];
  setValue: UseFormSetValue<FormRoutePageValues>;
};

type FormRoutePageProps = {
  pageId: PageId;
  title?: string;
  children?: (props: FormRouteRenderProps) => React.ReactNode;
};

export function isSectionVisible(
  section: PageSectionConfig,
  values: FormRoutePageValues,
): boolean {
  if (!section.visibleWhen) return true;

  return section.visibleWhen.every((rule) => {
    const value = values[rule.fieldId];

    if ("equals" in rule) return value === rule.equals;
    if ("notEquals" in rule) return value !== rule.notEquals;
    if ("includes" in rule) {
      return Array.isArray(value) && value.includes(rule.includes);
    }

    return true;
  });
}

function getDevValue(field: {
  id: string;
  inputType: string;
  options?: { value: string }[];
}) {
  if (field.id === "dependents") return ["spouse"];
  if (field.inputType === "checkbox") return true;
  if (field.inputType === "checkbox-group") {
    return field.options?.[0]?.value ? [field.options[0].value] : [];
  }
  if (field.inputType === "radio" || field.inputType === "dropdown") {
    return field.options?.[0]?.value ?? "";
  }
  if (field.inputType === "date") return "1990-01-01";
  if (field.id.toLowerCase().includes("email")) return "test@example.com";
  if (field.id.toLowerCase().includes("phone")) return "(555) 123-4567";
  if (field.id.toLowerCase().includes("zip")) return "10001";
  if (field.id.toLowerCase().includes("state")) return "NY";
  return "Test";
}

export default function FormRoutePage({
  pageId,
  title,
  children,
}: FormRoutePageProps) {
  const navigate = useNavigate();
  const { values, setPageValues } = useApplicationForm();

  const initialFields = getClientPageFields(pageId, values);
  const defaultValues = initialFields.reduce<FormRoutePageValues>(
    (acc, field) => {
      acc[field.id] =
        values[field.id] ??
        (field.inputType === "checkbox"
          ? false
          : field.inputType === "checkbox-group"
            ? []
            : "");
      return acc;
    },
    {},
  );

  const {
    control,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<FormRoutePageValues>({
    defaultValues,
  });

  const watchedValues = watch();
  const allFields = getClientPageFields(pageId, watchedValues);
  const pageSections = getPageSections(pageId);

  useEffect(() => {
    function handleDevFillForm() {
      const currentValues = watch();
      const currentFields = getClientPageFields(pageId, currentValues);

      currentFields.forEach((field) => {
        setValue(field.id, getDevValue(field), {
          shouldDirty: true,
          shouldTouch: true,
          shouldValidate: false,
        });
      });
    }

    window.addEventListener("devtools:fillform", handleDevFillForm);
    return () =>
      window.removeEventListener("devtools:fillform", handleDevFillForm);
  }, [pageId, setValue, watch]);

  function onSubmit(formValues: FormRoutePageValues) {
    setPageValues(formValues);

    const nextPageId = getNextFormPageId(pageId);

    if (nextPageId) {
      navigate(`/${nextPageId}`);
      return;
    }

    if (pageId === "payment") {
      navigate("/receipt");
    }
  }

  function handleBack() {
    const previousPageId = getPreviousFormPageId(pageId);

    if (previousPageId) {
      navigate(`/${previousPageId}`);
    }
  }

  return (
    <FormPage
      title={title ?? getPageTitle(pageId)}
      actions={
        <>
          <Button
            type="button"
            onClick={handleBack}
            disabled={!getPreviousFormPageId(pageId)}
          >
            Back
          </Button>
          <Button type="submit" form={`${pageId}-form`} variant="contained">
            Next
          </Button>
        </>
      }
    >
      <form id={`${pageId}-form`} onSubmit={handleSubmit(onSubmit)}>
        {children
          ? children({
              control,
              errors,
              watchedValues,
              allFields,
              pageSections,
              setValue,
            })
          : pageSections.map((section) => {
              if (!isSectionVisible(section, watchedValues)) return null;

              return (
                <div key={section.id}>
                  {section.title && (
                    <Typography variant="h6" sx={{ mt: 2, mb: 1 }}>
                      {section.title}
                    </Typography>
                  )}
                  {section.id === "childSection" ? (
                    <ChildrenList control={control} />
                  ) : (
                    section.fieldIds.map((fieldId) => {
                      const field = allFields.find((f) => f.id === fieldId);
                      if (!field) return null;

                      return (
                        <FieldRenderer
                          key={field.id}
                          field={field}
                          control={control}
                          errors={errors}
                        />
                      );
                    })
                  )}
                </div>
              );
            })}
      </form>
    </FormPage>
  );
}
