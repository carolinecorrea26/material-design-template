import type { PageId } from "../../types/page";
import type { PageSectionConfig } from "./types";
import { applicantSectionTitles } from "../applicantLabels";

export const pageSections: Partial<Record<PageId, PageSectionConfig[]>> = {
  membership: [
    {
      id: "default",
      pageId: "membership",
      fieldIds: [
        "membership",
        "title",
        "first-name",
        "last-name",
        "email",
        "phone",
      ],
    },
  ],

  eligibility: [
    {
      id: "selfEligibility",
      pageId: "eligibility",
      title: applicantSectionTitles.self,
      fieldIds: ["zip-postal-code", "state-province", "birth-date"],
    },
    {
      id: "dependentSelection",
      pageId: "eligibility",
      fieldIds: ["dependents"],
    },
    {
      id: "spouseSection",
      pageId: "eligibility",
      title: applicantSectionTitles.spouse,
      fieldIds: ["spouse-first-name", "spouse-last-name", "spouse-birth-date"],
      visibleWhen: [{ fieldId: "dependents", includes: "spouse" }],
    },
    {
      id: "childSection",
      pageId: "eligibility",
      title: applicantSectionTitles.child,
      fieldIds: [],
      visibleWhen: [{ fieldId: "dependents", includes: "child" }],
    },
  ],
};
