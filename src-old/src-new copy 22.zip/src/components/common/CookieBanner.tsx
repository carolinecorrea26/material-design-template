import { Alert, Box, Button, Typography } from "@mui/material";

type CookieBannerProps = {
  onClose: () => void;
};

export default function CookieBanner({ onClose }: CookieBannerProps) {
  return (
    <Alert
      severity="info"
      icon={false}
      sx={{
        borderRadius: 0,
        bgcolor: "rgba(0, 0, 0, 0.9)",
        color: "common.white",
        position: "fixed",
        bottom: 0,
        left: 0,
        right: 0,
        zIndex: 1200,
        py: 2,
        px: 3,
        display: "flex",
        alignItems: "flex-start",
        "& .MuiAlert-message": {
          width: "100%",
          fontSize: "0.875rem",
          display: "block",
        },
      }}
    >
      <Box
        sx={{
          display: "flex",
          flexDirection: { xs: "column", md: "row" },
          alignItems: { xs: "stretch", md: "center" },
          gap: { xs: 3, md: 3 },
          width: "100%",
          maxWidth: 1400,
          mx: "auto",
        }}
      >
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 2,
            flex: 1,
          }}
        >
          <Box
            component="img"
            src="/logo.svg"
            alt="New York Life Logo"
            sx={{ height: "50px", width: "auto" }}
          />
          <Typography
            variant="body2"
            sx={{
              textAlign: "justify",
              color: "common.white",
            }}
          >
            New York Life uses cookies to enhance your experience and analyze
            site performance and traffic. By continuing to use this site, you
            agree to our use of cookies.
          </Typography>
        </Box>

        <Box
          sx={{
            display: "flex",
            justifyContent: { xs: "flex-end", sm: "flex-end" },
            alignItems: "center",
            gap: 1,
            flexWrap: "wrap",
          }}
        >
          <Button
            size="small"
            variant="outlined"
            href="https://www.newyorklife.com/privacy"
            target="_blank"
            rel="noreferrer"
            sx={{
              color: "common.white",
              borderColor: "rgba(255, 255, 255, 0.7)",
              fontWeight: 600,
              "&:hover": {
                borderColor: "common.white",
                bgcolor: "rgba(255, 255, 255, 0.1)",
              },
            }}
          >
            Privacy Notice
          </Button>
          <Button
            size="small"
            variant="contained"
            color="primary"
            onClick={onClose}
            sx={{
              fontWeight: 600,
            }}
          >
            Close
          </Button>
        </Box>
      </Box>
    </Alert>
  );
}
