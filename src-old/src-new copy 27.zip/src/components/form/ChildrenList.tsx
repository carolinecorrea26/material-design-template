import { useState } from "react";
import {
  Box,
  Button,
  Card,
  CardContent,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Typography,
} from "@mui/material";
import {
  useFieldArray,
  useForm,
  type Control,
  type FieldErrors,
} from "react-hook-form";
import FieldRenderer from "./FieldRenderer";
import type { FieldDefinition } from "../../config/fields/types";

type ChildFormValues = {
  firstName: string;
  lastName: string;
  birthDate: string;
  gender: string;
};

type ParentFormValues = Record<string, any>;

type ChildrenListProps = {
  control: Control<ParentFormValues>;
};

const childFields: FieldDefinition[] = [
  {
    id: "firstName",
    label: "First Name",
    inputType: "text",
    required: true,
    autoComplete: "given-name",
  },
  {
    id: "lastName",
    label: "Last Name",
    inputType: "text",
    required: true,
    autoComplete: "family-name",
  },
  {
    id: "birthDate",
    label: "Date of Birth",
    inputType: "date",
    required: true,
  },
  {
    id: "gender",
    label: "Gender",
    inputType: "dropdown",
    required: true,
    placeholder: "Select",
    options: [
      { value: "male", label: "Male" },
      { value: "female", label: "Female" },
      { value: "other", label: "Other" },
    ],
  },
];

export default function ChildrenList({ control }: ChildrenListProps) {
  const { fields, append, remove, update } = useFieldArray({
    control,
    name: "children",
  });

  const [showForm, setShowForm] = useState(false);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);

  const {
    control: childControl,
    handleSubmit,
    reset,
    formState: { errors: childErrors },
  } = useForm<ChildFormValues>({
    defaultValues: {
      firstName: "",
      lastName: "",
      birthDate: "",
      gender: "",
    },
  });

  const handleAdd = () => {
    reset({
      firstName: "",
      lastName: "",
      birthDate: "",
      gender: "",
    });
    setEditingIndex(null);
    setShowForm(true);
  };

  const handleEdit = (index: number) => {
    const child = fields[index] as unknown as ChildFormValues;

    reset({
      firstName: child.firstName ?? "",
      lastName: child.lastName ?? "",
      birthDate: child.birthDate ?? "",
      gender: child.gender ?? "",
    });

    setEditingIndex(index);
    setShowForm(true);
  };

  const handleSave = (data: ChildFormValues) => {
    if (editingIndex !== null) {
      update(editingIndex, data);
    } else {
      append(data);
    }

    setShowForm(false);
    reset({
      firstName: "",
      lastName: "",
      birthDate: "",
      gender: "",
    });
    setEditingIndex(null);
  };

  const handleCancel = () => {
    setShowForm(false);
    reset({
      firstName: "",
      lastName: "",
      birthDate: "",
      gender: "",
    });
    setEditingIndex(null);
  };

  return (
    <div>
      {fields.map((field, index) => {
        const child = field as unknown as ChildFormValues;
        return (
          <Card key={field.id} sx={{ mb: 2 }}>
            <CardContent>
              <Typography variant="h6">
                {child.firstName} {child.lastName}
              </Typography>
              <Typography>Birth Date: {child.birthDate}</Typography>
              <Typography>Gender: {child.gender}</Typography>
              <Button onClick={() => handleEdit(index)}>Edit</Button>
              <Button onClick={() => remove(index)} color="error">
                Remove
              </Button>
            </CardContent>
          </Card>
        );
      })}

      <Button onClick={handleAdd} variant="outlined">
        Add Child
      </Button>

      <Dialog open={showForm} onClose={handleCancel} maxWidth="sm" fullWidth>
        <DialogTitle>
          {editingIndex !== null ? "Edit Child" : "Add Child"}
        </DialogTitle>
        <DialogContent>
          <Box
            component="form"
            id="child-form"
            onSubmit={handleSubmit(handleSave)}
          >
            <Box
              sx={{
                display: "grid",
                gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
                gap: { xs: 0, sm: 2 },
              }}
            >
              {childFields.slice(0, 2).map((field) => (
                <FieldRenderer
                  key={field.id}
                  field={field}
                  control={
                    childControl as Control<
                      Record<string, string | boolean | string[]>
                    >
                  }
                  errors={
                    childErrors as FieldErrors<
                      Record<string, string | boolean | string[]>
                    >
                  }
                />
              ))}
            </Box>

            {childFields.slice(2).map((field) => (
              <FieldRenderer
                key={field.id}
                field={field}
                control={
                  childControl as Control<
                    Record<string, string | boolean | string[]>
                  >
                }
                errors={
                  childErrors as FieldErrors<
                    Record<string, string | boolean | string[]>
                  >
                }
              />
            ))}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCancel}>Cancel</Button>
          <Button type="submit" form="child-form" variant="contained">
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
