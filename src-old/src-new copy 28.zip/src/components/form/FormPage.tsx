import type { ReactNode } from "react";
import { Box, Stack } from "@mui/material";
import FormPageActions from "./FormPageActions";
import FormPageContent from "./FormPageContent";
import FormPageTitle from "./FormPageTitle";
import FormProgress from "./FormProgress";
import FormShell from "../layout/FormShell";

type FormPageProps = {
  title: string;
  children?: ReactNode;
  help?: ReactNode;
  actions?: ReactNode;
};

export default function FormPage({
  title,
  children,
  help,
  actions,
}: FormPageProps) {
  return (
    <FormShell
      header={
        <Stack spacing={2}>
          <Box>
            <FormProgress />
          </Box>
          <Stack spacing={1}>
            <FormPageTitle title={title} />
            {help}
          </Stack>
        </Stack>
      }
      body={<FormPageContent>{children}</FormPageContent>}
      footer={<FormPageActions>{actions}</FormPageActions>}
    />
  );
}
