import type { ReactNode } from "react";
import { Box, Stack } from "@mui/material";
import FormHeader from "./FormHeader";
import FormBody from "./FormBody";
import FormFooter from "./FormFooter";

type FormShellProps = {
  header?: ReactNode;
  body?: ReactNode;
  footer?: ReactNode;
  children?: ReactNode;
};

export default function FormShell({
  header,
  body,
  footer,
  children,
}: FormShellProps) {
  return (
    <Box
      sx={{
        width: "100%",
        maxWidth: 750,
        marginLeft: "auto",
        marginRight: "auto",
        px: { xs: 2, sm: 3, md: 4 },
      }}
    >
      <Stack spacing={2}>
        <FormHeader>{header}</FormHeader>
        <FormBody>{body ?? children}</FormBody>
        <FormFooter>{footer}</FormFooter>
      </Stack>
    </Box>
  );
}
