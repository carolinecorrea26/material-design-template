import type { PageId } from "../types/page";

export const formFlow: PageId[] = [
  "membership",
  "eligibility",
  "coverage",
  "coverage-questions",
  "coverage-options",
  "beneficiary",
  "contact",
  "personal",
  "financial",
  "review",
  "docusign",
  "health-si",
  "health-qd",
  "health-di",
  "health-cir",
  "decision",
  "payment",
];

export function isFormPage(pageId: PageId) {
  return formFlow.includes(pageId);
}

export function getNextFormPageId(pageId: PageId) {
  const currentIndex = formFlow.indexOf(pageId);

  if (currentIndex === -1 || currentIndex === formFlow.length - 1) {
    return null;
  }

  return formFlow[currentIndex + 1];
}

export function getPreviousFormPageId(pageId: PageId) {
  const currentIndex = formFlow.indexOf(pageId);

  if (currentIndex <= 0) {
    return null;
  }

  return formFlow[currentIndex - 1];
}
