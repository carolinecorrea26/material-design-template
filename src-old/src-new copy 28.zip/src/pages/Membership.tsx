import { useEffect } from "react";
import { Alert, Box, Button } from "@mui/material";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { getActiveClient } from "../client/getActiveClient";
import { getClientPageFields } from "../config/clientFields/getClientPageFields";
import { getNextFormPageId, getPreviousFormPageId } from "../config/formFlow";
import { getPageTitle } from "../config/pages";
import { useApplicationForm } from "../state/ApplicationFormContext";
import FormPage from "../components/form/FormPage";
import FieldRenderer from "../components/form/FieldRenderer";

type FormValues = Record<string, string | boolean | string[]>;

function getDevValue(field: {
  id: string;
  inputType: string;
  options?: { value: string }[];
}) {
  if (field.inputType === "checkbox") return true;
  if (field.inputType === "checkbox-group") {
    return field.options?.[0]?.value ? [field.options[0].value] : [];
  }
  if (field.inputType === "radio" || field.inputType === "dropdown") {
    return field.options?.[0]?.value ?? "";
  }
  if (field.inputType === "date") return "1990-01-01";
  if (field.id.toLowerCase().includes("email")) return "test@example.com";
  if (field.id.toLowerCase().includes("phone")) return "(555) 123-4567";
  if (field.id.toLowerCase().includes("zip")) return "10001";
  if (field.id.toLowerCase().includes("state")) return "NY";
  return "Test";
}

export default function Membership() {
  const navigate = useNavigate();
  const client = getActiveClient();
  const { values, setPageValues } = useApplicationForm();

  const pageId = "membership";
  const initialFields = getClientPageFields(pageId, values);
  const defaultValues = initialFields.reduce<FormValues>((acc, field) => {
    acc[field.id] =
      values[field.id] ?? (field.inputType === "checkbox" ? false : "");
    return acc;
  }, {});

  const {
    control,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<FormValues>({
    defaultValues,
  });

  const watchedValues = watch();
  const allFields = getClientPageFields(pageId, watchedValues);

  const membershipField = allFields.find((field) => field.id === "membership");
  const remainingFields = allFields.filter(
    (field) => field.id !== "membership",
  );

  const membershipValue = watchedValues.membership;

  useEffect(() => {
    function handleDevFillForm() {
      const currentValues = watch();
      const currentFields = getClientPageFields(pageId, currentValues);

      currentFields.forEach((field) => {
        setValue(field.id, getDevValue(field), {
          shouldDirty: true,
          shouldTouch: true,
          shouldValidate: false,
        });
      });
    }

    window.addEventListener("devtools:fillform", handleDevFillForm);
    return () =>
      window.removeEventListener("devtools:fillform", handleDevFillForm);
  }, [pageId, setValue, watch]);
  const showMembershipIneligibleAlert =
    client.id !== "ama" && client.id !== "waepa" && membershipValue === "no";

  const showMembershipFollowUpFields =
    client.id === "ama"
      ? Boolean(membershipValue)
      : client.id === "waepa"
        ? membershipValue === "current" || membershipValue === "new"
        : membershipValue === "yes";

  function onSubmit(formValues: FormValues) {
    setPageValues(formValues);

    const nextPageId = getNextFormPageId(pageId);

    if (nextPageId) {
      navigate(`/${nextPageId}`);
    }
  }

  function handleBack() {
    const previousPageId = getPreviousFormPageId(pageId);

    if (previousPageId) {
      navigate(`/${previousPageId}`);
    }
  }
  const hasTitleField = remainingFields.some((field) => field.id === "title");

  return (
    <FormPage
      title={getPageTitle(pageId)}
      actions={
        <>
          <Button
            type="button"
            onClick={handleBack}
            disabled={!getPreviousFormPageId(pageId)}
          >
            Back
          </Button>
          <Button type="submit" form={`${pageId}-form`} variant="contained">
            Next
          </Button>
        </>
      }
    >
      <form id={`${pageId}-form`} onSubmit={handleSubmit(onSubmit)}>
        {membershipField && (
          <FieldRenderer
            key={membershipField.id}
            field={membershipField}
            control={control}
            errors={errors}
          />
        )}

        {showMembershipIneligibleAlert && (
          <Alert severity="warning" sx={{ mt: 2 }}>
            You must be an active member to continue with this application.
          </Alert>
        )}

        {showMembershipFollowUpFields && (
          <>
            <Box
              sx={{
                display: "grid",
                gridTemplateColumns: {
                  xs: "1fr",
                  sm: hasTitleField ? "120px 1fr 1fr" : "1fr 1fr",
                },
                gap: { xs: 0, sm: 2 },
              }}
            >
              {remainingFields
                .filter((field) =>
                  ["title", "first-name", "last-name"].includes(field.id),
                )
                .map((field) => (
                  <FieldRenderer
                    key={field.id}
                    field={field}
                    control={control}
                    errors={errors}
                  />
                ))}
            </Box>

            {remainingFields
              .filter(
                (field) =>
                  !["title", "first-name", "last-name"].includes(field.id),
              )
              .map((field) => (
                <FieldRenderer
                  key={field.id}
                  field={field}
                  control={control}
                  errors={errors}
                />
              ))}
          </>
        )}
      </form>
    </FormPage>
  );
}
