import {
  Box,
  LinearProgress,
  Stack,
  Step,
  StepLabel,
  Stepper,
  Typography,
} from "@mui/material";
import { useLocation } from "react-router-dom";
import { pages } from "../../config/pages";
import type { PageId } from "../../types/page";
import { getFormProgressPercent, isFormPage } from "../../config/formFlow";
import {
  getProgressStepIndex,
  progressSteps,
} from "../../config/progressSteps";
import { useEffect, useState } from "react";
import type { ProgressVariant } from "../../types/progress";

function getCurrentPageId(pathname: string): PageId | null {
  const match = pages.find((page) => page.path === pathname);
  return match?.id ?? null;
}

export default function FormProgress() {
  const location = useLocation();
  const pageId = getCurrentPageId(location.pathname);

  if (!pageId || !isFormPage(pageId)) {
    return null;
  }

  const percent = getFormProgressPercent(pageId);
  const activeStep = getProgressStepIndex(pageId);

  // temporary until dev tools is wired
  const progressVariant = "bar";

  if (progressVariant === "stepper") {
    return (
      <Box>
        <Stepper activeStep={activeStep} alternativeLabel>
          {progressSteps.map((step) => (
            <Step key={step.id}>
              <StepLabel>{step.label}</StepLabel>
            </Step>
          ))}
        </Stepper>
      </Box>
    );
  }

  return (
    <Stack spacing={0.75}>
      <Stack direction="row" justifyContent="space-between" alignItems="center">
        <Typography variant="body2">Progress</Typography>
        <Typography variant="body2" fontWeight={600}>
          {Math.round(percent)}% done
        </Typography>
      </Stack>

      <LinearProgress
        variant="determinate"
        value={percent}
        sx={{
          height: 8,
          borderRadius: 999,
        }}
      />
    </Stack>
  );
}
