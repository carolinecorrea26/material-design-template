import type { PageId } from "../types/page";

export type ProgressStep = {
  id: string;
  label: string;
  pageIds: PageId[];
};

export const progressSteps: ProgressStep[] = [
  {
    id: "getting-started",
    label: "Getting started",
    pageIds: ["membership", "eligibility"],
  },
  {
    id: "coverage-options",
    label: "Coverage options",
    pageIds: ["coverage", "coverage-questions", "coverage-options"],
  },
  {
    id: "about-applicant",
    label: "About applicant",
    pageIds: ["beneficiary", "contact", "personal", "financial"],
  },
  {
    id: "application-review",
    label: "Application review",
    pageIds: [
      "review",
      "health-si",
      "health-qd",
      "health-di",
      "health-cir",
      "payment",
    ],
  },
  {
    id: "esign-submit",
    label: "E-sign and submit",
    pageIds: ["docusign"],
  },
];

export function getProgressStepIndex(pageId: PageId) {
  return progressSteps.findIndex((step) => step.pageIds.includes(pageId));
}
