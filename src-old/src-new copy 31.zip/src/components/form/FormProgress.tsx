import { useEffect, useState } from "react";
import {
  Box,
  LinearProgress,
  Stack,
  Step,
  StepLabel,
  Stepper,
  Typography,
} from "@mui/material";
import { useLocation } from "react-router-dom";
import { pages } from "../../config/pages";
import type { PageId } from "../../types/page";
import { getFormProgressPercent, isFormPage } from "../../config/formFlow";
import {
  getProgressStepIndex,
  progressSteps,
} from "../../config/progressSteps";
import type { ProgressVariant } from "../../types/progress";

const PROGRESS_VARIANT_STORAGE_KEY = "devtools:progressVariant";

function getCurrentPageId(pathname: string): PageId | null {
  const match = pages.find((page) => page.path === pathname);
  return match?.id ?? null;
}

function readProgressVariant(): ProgressVariant {
  const stored = window.sessionStorage.getItem(PROGRESS_VARIANT_STORAGE_KEY);
  return stored === "stepper" ? "stepper" : "bar";
}

export default function FormProgress() {
  const location = useLocation();
  const pageId = getCurrentPageId(location.pathname);

  const [progressVariant, setProgressVariant] = useState<ProgressVariant>(
    readProgressVariant(),
  );

  useEffect(() => {
    function handleVariantChange(event: Event) {
      const customEvent = event as CustomEvent<ProgressVariant>;
      setProgressVariant(customEvent.detail ?? readProgressVariant());
    }

    window.addEventListener(
      "devtools:progressvariantchange",
      handleVariantChange,
    );

    return () => {
      window.removeEventListener(
        "devtools:progressvariantchange",
        handleVariantChange,
      );
    };
  }, []);

  if (!pageId || !isFormPage(pageId)) {
    return null;
  }

  const percent = getFormProgressPercent(pageId);
  const activeStep = getProgressStepIndex(pageId);

  if (progressVariant === "stepper") {
    return (
      <Box>
        <Stepper activeStep={activeStep} alternativeLabel>
          {progressSteps.map((step) => (
            <Step key={step.id}>
              <StepLabel>{step.label}</StepLabel>
            </Step>
          ))}
        </Stepper>
      </Box>
    );
  }

  return (
    <Stack spacing={0.75}>
      <Stack direction="row" justifyContent="space-between" alignItems="center">
        <Typography variant="body2">Progress</Typography>
        <Typography variant="body2" fontWeight={600}>
          {Math.round(percent)}% done
        </Typography>
      </Stack>

      <LinearProgress
        variant="determinate"
        value={percent}
        sx={{
          height: 8,
          borderRadius: 999,
        }}
      />
    </Stack>
  );
}
