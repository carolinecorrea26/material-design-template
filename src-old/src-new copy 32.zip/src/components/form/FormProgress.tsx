import { useEffect, useState } from "react";
import { Box, LinearProgress, Stack, Typography } from "@mui/material";
import { useLocation } from "react-router-dom";
import { pages } from "../../config/pages";
import type { PageId } from "../../types/page";
import { getFormProgressPercent, isFormPage } from "../../config/formFlow";
import {
  getProgressStepIndex,
  progressSteps,
} from "../../config/progressSteps";
import type { ProgressVariant } from "../../types/progress";

const PROGRESS_VARIANT_STORAGE_KEY = "devtools:progressVariant";

function getCurrentPageId(pathname: string): PageId | null {
  const match = pages.find((page) => page.path === pathname);
  return match?.id ?? null;
}

function readProgressVariant(): ProgressVariant {
  const stored = window.sessionStorage.getItem(PROGRESS_VARIANT_STORAGE_KEY);
  return stored === "stepper" ? "stepper" : "bar";
}

export default function FormProgress() {
  const location = useLocation();
  const pageId = getCurrentPageId(location.pathname);

  const [progressVariant, setProgressVariant] = useState<ProgressVariant>(
    readProgressVariant(),
  );

  useEffect(() => {
    function handleVariantChange(event: Event) {
      const customEvent = event as CustomEvent<ProgressVariant>;
      setProgressVariant(customEvent.detail ?? readProgressVariant());
    }

    window.addEventListener(
      "devtools:progressvariantchange",
      handleVariantChange,
    );

    return () => {
      window.removeEventListener(
        "devtools:progressvariantchange",
        handleVariantChange,
      );
    };
  }, []);

  if (!pageId || !isFormPage(pageId)) {
    return null;
  }

  const percent = getFormProgressPercent(pageId);
  const activeStep = getProgressStepIndex(pageId);

  if (progressVariant === "stepper") {
    return (
      <Stack spacing={1}>
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            width: "100%",
          }}
        >
          {progressSteps.map((step, index) => {
            const Icon = step.icon;
            const isActive = index === activeStep;
            const isComplete = index < activeStep;
            const isLast = index === progressSteps.length - 1;

            return (
              <Box
                key={step.id}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  flex: 1,
                  minWidth: 0,
                }}
              >
                <Box
                  sx={{
                    width: 36,
                    height: 36,
                    borderRadius: "50%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    border: "1px solid",
                    borderColor:
                      isActive || isComplete ? "primary.main" : "divider",
                    backgroundColor:
                      isActive || isComplete
                        ? "primary.main"
                        : "background.paper",
                    color:
                      isActive || isComplete
                        ? "primary.contrastText"
                        : "text.secondary",
                    flexShrink: 0,
                  }}
                >
                  <Icon sx={{ fontSize: 18 }} />
                </Box>

                {!isLast && (
                  <Box
                    sx={{
                      height: 2,
                      flex: 1,
                      mx: 1,
                      borderRadius: 999,
                      backgroundColor: isComplete ? "primary.main" : "divider",
                    }}
                  />
                )}
              </Box>
            );
          })}
        </Box>

        <Box sx={{ minHeight: 20 }}>
          <Typography variant="body2" fontWeight={600}>
            {progressSteps[activeStep]?.label}
          </Typography>
        </Box>
      </Stack>
    );
  }

  return (
    <Stack spacing={0.75}>
      <Stack direction="row" justifyContent="space-between" alignItems="center">
        <Typography variant="body2">Progress</Typography>
        <Typography variant="body2" fontWeight={600}>
          {Math.round(percent)}% done
        </Typography>
      </Stack>

      <LinearProgress
        variant="determinate"
        value={percent}
        sx={{
          height: 8,
          borderRadius: 999,
        }}
      />
    </Stack>
  );
}
