import { Alert, Box, IconButton, Link, Typography } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";

type CookieBannerProps = {
  onClose: () => void;
};

export default function CookieBanner({ onClose }: CookieBannerProps) {
  return (
    <Alert
      severity="info"
      icon={false}
      sx={{
        borderRadius: 3,
        bgcolor: "rgba(0, 0, 0, 0.92)",
        color: "common.white",
        position: "fixed",
        bottom: { xs: 16, sm: 16 },
        left: { xs: 16, sm: "auto" },
        right: { xs: 16, sm: 16 },
        zIndex: 1200,
        py: 2,
        px: 2,
        width: { xs: "auto", sm: "100%" },
        maxWidth: 510,
        boxShadow: 6,
        display: "flex",
        alignItems: "flex-start",
        "& .MuiAlert-message": {
          width: "100%",
          p: 0,
          fontSize: "0.875rem",
          display: "block",
        },
      }}
    >
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          gap: 1.5,
          width: "100%",
          position: "relative",
        }}
      >
        <IconButton
          onClick={onClose}
          aria-label="Close cookie banner"
          size="small"
          sx={{
            position: "absolute",
            top: -4,
            right: -4,
            color: "common.white",
            p: 0.5,
          }}
        >
          <CloseIcon fontSize="small" />
        </IconButton>

        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 1.5,
            pr: 3,
          }}
        >
          <Box
            component="img"
            src="/logo.svg"
            alt="New York Life Logo"
            sx={{
              height: 48,
              width: "auto",
              flexShrink: 0,
              alignSelf: "flex-start",
              mt: 0.25,
            }}
          />

          <Typography
            variant="body2"
            sx={{
              color: "common.white",
              lineHeight: 1.5,
            }}
          >
            New York Life uses cookies to enhance your experience and analyze
            site performance and traffic. By continuing to use this site, you
            agree to our use of cookies.{" "}
            <Link
              href="https://www.newyorklife.com/privacy"
              target="_blank"
              rel="noreferrer"
              underline="always"
              color="inherit"
              sx={{ fontWeight: 500 }}
            >
              Privacy Notice
            </Link>
          </Typography>
        </Box>
      </Box>
    </Alert>
  );
}
