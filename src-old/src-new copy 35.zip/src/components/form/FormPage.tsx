import type { ReactNode } from "react";
import { Box, Stack } from "@mui/material";
import FormPageActions from "./FormPageActions";
import FormPageContent from "./FormPageContent";
import FormPageTitle from "./FormPageTitle";
import FormProgress from "./FormProgress";
import FormShell from "../layout/FormShell";

type FormPageProps = {
  title: string;
  children?: ReactNode;
  help?: ReactNode;
  actions?: ReactNode;
};

export default function FormPage({
  title,
  children,
  help,
  actions,
}: FormPageProps) {
  return (
    <Stack
      spacing={2}
      sx={{ flex: 1, alignItems: "center", justifyContent: "flex-start" }}
    >
      <Box sx={{ width: "100%", maxWidth: 1400 }}>
        <FormProgress />
      </Box>

      <Box sx={{ width: "100%", maxWidth: 700 }}>
        <FormShell
          header={
            <Stack spacing={1}>
              <FormPageTitle title={title} />
              {help}
            </Stack>
          }
          body={<FormPageContent>{children}</FormPageContent>}
          footer={<FormPageActions>{actions}</FormPageActions>}
        />
      </Box>
    </Stack>
  );
}
