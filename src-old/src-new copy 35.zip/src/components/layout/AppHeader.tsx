import { useState } from "react";
import { AppBar, Box, Toolbar, Typography } from "@mui/material";
import type { ClientConfig } from "../../config/clients/types";

type AppHeaderProps = {
  client: ClientConfig;
};

export default function AppHeader({ client }: AppHeaderProps) {
  const [imageError, setImageError] = useState(false);

  return (
    <AppBar position="static" color="default">
      <Toolbar
        sx={{
          width: "100%",
          maxWidth: 1400,
          marginLeft: "auto",
          marginRight: "auto",
          minHeight: 72,
          px: { xs: 2, sm: 3, md: 4 },
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", minWidth: 0 }}>
          {imageError ? (
            <Typography variant="h6" noWrap>
              {client.branding.name}
            </Typography>
          ) : (
            <Box
              component="img"
              src={client.branding.logo}
              alt={client.branding.logoAlt}
              onError={() => setImageError(true)}
              sx={{ height: 32, width: "auto", display: "block" }}
            />
          )}
        </Box>
        <Box
          sx={{ marginLeft: "auto", display: "flex", alignItems: "center" }}
        />
      </Toolbar>
    </AppBar>
  );
}
