import type { CoverageApplicantId } from "./coverages/types";

export const applicantLabels: Record<CoverageApplicantId, string> = {
  member: "Self",
  spouse: "Spouse",
  child: "Child",
};

export const applicantSectionTitles = {
  self: "Self",
  spouse: "Spouse",
  child: "Child",
} as const;
