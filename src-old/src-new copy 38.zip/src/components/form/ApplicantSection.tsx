import type { ReactNode } from "react";
import { Box, Stack, Typography } from "@mui/material";
import {
  applicantIcons,
  applicantSectionTitles,
  type ApplicantSectionId,
} from "../../config/applicantLabels";

type ApplicantSectionProps = {
  applicant: ApplicantSectionId;
  children: ReactNode;
};

export default function ApplicantSection({
  applicant,
  children,
}: ApplicantSectionProps) {
  const Icon = applicantIcons[applicant];
  const title = applicantSectionTitles[applicant];

  return (
    <Box sx={{ mt: 2 }}>
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1.5 }}>
        <Box
          sx={{
            color: "primary.main",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexShrink: 0,
            "& svg": {
              width: "0.875em",
              height: "0.875em",
            },
          }}
        >
          <Icon />
        </Box>

        <Typography
          sx={{
            lineHeight: 2.66,
            textTransform: "uppercase",
            color: "#4a6081",
            display: "block",
            fontWeight: 700,
            fontSize: "0.75rem",
            letterSpacing: "1px",
          }}
        >
          {title}
        </Typography>
      </Stack>

      <Box
        sx={{
          backgroundColor: "rgba(7, 104, 255, 0.04)",
          borderRadius: 1.5,
          px: { xs: 2, sm: 2.5 },
          py: 2,
        }}
      >
        {children}
      </Box>
    </Box>
  );
}
