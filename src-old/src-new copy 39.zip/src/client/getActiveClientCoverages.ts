import { coverages } from "../config/coverages";
import { getActiveClient } from "./getActiveClient";

export function getActiveClientCoverages() {
  const client = getActiveClient();
  const enabledCoverageIds = new Set(client.coverages.enabled ?? []);
  const ranges = client.coverages.ranges ?? {};
  const descriptions = client.coverages.descriptions ?? {};

  return coverages
    .filter((coverage) => enabledCoverageIds.has(coverage.id))
    .map((coverage) => {
      const range = ranges[coverage.id];
      const description = descriptions[coverage.id];

      return {
        ...coverage,
        minAmount: range?.min ?? coverage.minAmount,
        maxAmount: range?.max ?? coverage.maxAmount,
        description: description ?? coverage.description,
      };
    });
}
