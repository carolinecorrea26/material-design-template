import { Checkbox, Chip, Stack, Typography } from "@mui/material";
import { coverageCategories } from "../../config/coverageCategories";
import type { CoverageDefinition } from "../../config/coverages/types";
import SelectableOptionCard from "../form/SelectableOptionCard";
import { applicantLabels } from "../../config/applicantLabels";

type CoverageCatalogProps = {
  coverages: CoverageDefinition[];
  selectedCoverageIds: string[];
  onChangeSelectedCoverageIds: (nextIds: string[]) => void;
};

function formatCoverageAmount(amount?: number) {
  if (amount == null) return null;

  if (amount >= 1000000) {
    const millions = amount / 1000000;
    return `$${Number.isInteger(millions) ? millions : millions.toFixed(1)}M`;
  }

  if (amount >= 1000) {
    const thousands = amount / 1000;
    return `$${Number.isInteger(thousands) ? thousands : thousands.toFixed(1)}K`;
  }

  return `$${amount}`;
}

export default function CoverageCatalog({
  coverages,
  selectedCoverageIds,
  onChangeSelectedCoverageIds,
}: CoverageCatalogProps) {
  const groupedCategories = coverageCategories
    .map((category) => ({
      category,
      items: coverages.filter(
        (coverage) => coverage.categoryId === category.id,
      ),
    }))
    .filter((group) => group.items.length > 0);

  function toggleCoverage(coverageId: string) {
    const nextIds = selectedCoverageIds.includes(coverageId)
      ? selectedCoverageIds.filter((id) => id !== coverageId)
      : [...selectedCoverageIds, coverageId];

    onChangeSelectedCoverageIds(nextIds);
  }

  return (
    <Stack spacing={3}>
      {groupedCategories.map(({ category, items }) => (
        <Stack key={category.id} spacing={1.5}>
          <Typography variant="h6">{category.label}</Typography>

          <Stack spacing={1.5}>
            {items.map((coverage) => {
              const checked = selectedCoverageIds.includes(coverage.id);
              const minAmount = formatCoverageAmount(coverage.minAmount);
              const maxAmount = formatCoverageAmount(coverage.maxAmount);
              const coverageText =
                minAmount && maxAmount ? `${minAmount} - ${maxAmount}` : null;

              return (
                <SelectableOptionCard
                  key={coverage.id}
                  onClick={() => toggleCoverage(coverage.id)}
                >
                  <Checkbox
                    checked={checked}
                    onChange={() => toggleCoverage(coverage.id)}
                    onClick={(event) => event.stopPropagation()}
                    inputProps={{ "aria-label": `${coverage.name} selection` }}
                    sx={{
                      mt: 0.25,
                      color: "text.primary",
                      "&.Mui-checked": {
                        color: "primary.main",
                      },
                    }}
                  />

                  <Stack spacing={1} sx={{ flex: 1, minWidth: 0 }}>
                    <Stack
                      direction="row"
                      spacing={1}
                      alignItems="center"
                      flexWrap="wrap"
                    >
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {coverage.name}
                      </Typography>

                      <Chip
                        label={coverage.underwritingType}
                        size="small"
                        variant="outlined"
                      />
                    </Stack>

                    <Typography variant="body2" color="text.secondary">
                      {coverage.description ?? coverage.definition}
                    </Typography>

                    <Stack
                      direction="row"
                      alignItems="flex-start"
                      sx={{
                        columnGap: "32px",
                        rowGap: 1,
                        flexWrap: "wrap",
                        justifyContent: {
                          xs: "space-between",
                          sm: "flex-start",
                        },
                      }}
                    >
                      {coverageText ? (
                        <Stack spacing={0.5}>
                          <Typography
                            component="p"
                            sx={{
                              fontSize: "0.75rem",
                              m: 0,
                              color: "text.secondary",
                            }}
                          >
                            Coverage:
                          </Typography>
                          <Typography
                            variant="body2"
                            sx={{ color: "success.main", fontWeight: 600 }}
                          >
                            {coverageText}
                          </Typography>
                        </Stack>
                      ) : null}

                      {coverage.applicants.length ? (
                        <Stack spacing={0.5}>
                          <Typography
                            component="p"
                            sx={{
                              fontSize: "0.75rem",
                              m: 0,
                              color: "text.secondary",
                            }}
                          >
                            Available for:
                          </Typography>
                          <Stack direction="row" spacing={1.5} flexWrap="wrap">
                            {coverage.applicants.map((applicant) => (
                              <Typography
                                key={applicant}
                                variant="caption"
                                sx={{
                                  color: "#4b6181",
                                  fontWeight: 600,
                                  fontSize: "0.675rem",
                                  textTransform: "uppercase",
                                }}
                              >
                                {applicantLabels[applicant]}
                              </Typography>
                            ))}
                          </Stack>
                        </Stack>
                      ) : null}
                    </Stack>
                  </Stack>
                </SelectableOptionCard>
              );
            })}
          </Stack>
        </Stack>
      ))}
    </Stack>
  );
}
