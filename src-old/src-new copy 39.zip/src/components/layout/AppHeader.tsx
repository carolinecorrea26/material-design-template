import { useState, useSyncExternalStore } from "react";
import {
  AppBar,
  Box,
  Slide,
  Toolbar,
  Typography,
  useScrollTrigger,
} from "@mui/material";
import { pages } from "../../config/pages";
import { isFormPage } from "../../config/formFlow";
import type { ClientConfig } from "../../config/clients/types";
import type { PageId } from "../../types/page";
import FormProgress from "../form/FormProgress";

type AppHeaderProps = {
  client: ClientConfig;
};

function patchHistoryForLocationChangeEvents() {
  if (typeof window === "undefined") return;
  if (
    (window as typeof window & { __historyPatched__?: boolean })
      .__historyPatched__
  ) {
    return;
  }

  const originalPushState = window.history.pushState;
  const originalReplaceState = window.history.replaceState;

  window.history.pushState = function (...args) {
    originalPushState.apply(this, args);
    window.dispatchEvent(new Event("locationchange"));
  };

  window.history.replaceState = function (...args) {
    originalReplaceState.apply(this, args);
    window.dispatchEvent(new Event("locationchange"));
  };

  (
    window as typeof window & { __historyPatched__?: boolean }
  ).__historyPatched__ = true;
}

function subscribeToPathname(callback: () => void) {
  if (typeof window === "undefined") return () => {};

  patchHistoryForLocationChangeEvents();

  window.addEventListener("popstate", callback);
  window.addEventListener("locationchange", callback);

  return () => {
    window.removeEventListener("popstate", callback);
    window.removeEventListener("locationchange", callback);
  };
}

function getPathnameSnapshot() {
  if (typeof window === "undefined") return "/";
  return window.location.pathname;
}

export default function AppHeader({ client }: AppHeaderProps) {
  const [imageError, setImageError] = useState(false);
  const pathname = useSyncExternalStore(
    subscribeToPathname,
    getPathnameSnapshot,
    () => "/",
  );
  const trigger = useScrollTrigger({ disableHysteresis: true, threshold: 8 });

  const normalizedPath =
    pathname.length > 1 && pathname.endsWith("/")
      ? pathname.slice(0, -1)
      : pathname;

  const currentPage = pages.find((page) => page.path === normalizedPath);
  const showProgress = !!currentPage && isFormPage(currentPage.id as PageId);

  return (
    <Slide appear={false} direction="down" in={!trigger}>
      <AppBar
        position="sticky"
        color="default"
        elevation={0}
        sx={{
          backgroundColor: "#fff",
          borderBottom: "none",
          boxShadow: "none",
          // minHeight: "54px",
          pb: 1,
          pt: 2,
        }}
      >
        <Toolbar
          sx={{
            width: "100%",
            maxWidth: 1400,
            marginLeft: "auto",
            marginRight: "auto",
            minHeight: "40px !important",
            px: { xs: 2, sm: 3, md: 4 },
            gap: 1,
            alignItems: "flex-start",
            flexDirection: "column",
          }}
        >
          <Box sx={{ display: "flex", alignItems: "center" }}>
            {imageError ? (
              <Typography variant="h6" noWrap>
                {client.branding.name}
              </Typography>
            ) : (
              <Box
                component="img"
                src={client.branding.logo}
                alt={client.branding.logoAlt}
                onError={() => setImageError(true)}
                sx={{ height: 32, width: "auto", display: "block" }}
              />
            )}
          </Box>

          {showProgress && (
            <Box sx={{ width: "100%", minWidth: 0 }}>
              <FormProgress />
            </Box>
          )}
        </Toolbar>
      </AppBar>
    </Slide>
  );
}
