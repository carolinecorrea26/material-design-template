import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import FavoriteBorderIcon from "@mui/icons-material/FavoriteBorder";
import ChildCareIcon from "@mui/icons-material/ChildCare";
import type { CoverageApplicantId } from "./coverages/types";

export const applicantLabels: Record<CoverageApplicantId, string> = {
  member: "Self",
  spouse: "Spouse",
  child: "Child",
};

export type ApplicantSectionId = "self" | "spouse" | "child";

export const applicantSectionTitles: Record<ApplicantSectionId, string> = {
  self: "Self",
  spouse: "Spouse",
  child: "Child",
};

export const applicantIcons = {
  self: PersonOutlineIcon,
  spouse: FavoriteBorderIcon,
  child: ChildCareIcon,
} satisfies Record<ApplicantSectionId, typeof PersonOutlineIcon>;
