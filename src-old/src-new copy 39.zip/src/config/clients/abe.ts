import type { ClientConfig } from "./types";

export const abeClient: ClientConfig = {
  id: "abe",
  branding: {
    name: "American Bar Endowment",
    acronym: "ABE",
    logo: "/client/abe/logo.png",
    logoAlt: "ABE Logo",
  },
  support: {
    phone: "8006218981",
    phoneDisplay: "(800) 621-8981",
    email: "information@abendowment.org",
    website: "abendowment.org",
    address: {
      street: "321 North Clark Street, 14th Floor",
      city: "Chicago",
      state: "Illinois",
      zip: "60654-7648",
    },
  },
  pages: {
    excluded: [],
    optional: ["beneficiary", "payment"],
  },
  coverages: {
    categories: ["LI", "AD", "DI", "OO", "SH"],
    enabled: [
      "li-term",
      "li-10yr",
      "li-20yr",
      "li-50plus",
      "li-add",
      "di-ltd-plus",
      "di-ltd",
      "di-mtd",
      "oo-professional",
      "sh-critical-illness",
      "sh-hospital-money",
    ],
    ranges: {
      "li-term": { min: 50000, max: 500000 },
      "li-10yr": { min: 50000, max: 500000 },
      "li-20yr": { min: 50000, max: 1000000 },
      "li-50plus": { min: 50000, max: 500000 },
      "li-add": { min: 25000, max: 500000 },
      "di-ltd-plus": { min: 1000, max: 5000 },
      "di-ltd": { min: 1000, max: 5000 },
      "di-mtd": { min: 1000, max: 4000 },
      "oo-professional": { min: 500, max: 3000 },
      "sh-critical-illness": { min: 10000, max: 50000 },
      "sh-hospital-money": { min: 100, max: 500 },
    },
  },
  fields: {},
  content: {},
};
