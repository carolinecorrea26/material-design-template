export const coverageCategories = [
  { id: "LI", label: "Life" },
  { id: "AD", label: "Accidental Death and Dismemberment" },
  { id: "DI", label: "Disability" },
  { id: "OO", label: "Office Overhead" },
  { id: "SH", label: "Supplemental Health" },
] as const;

export type CoverageCategory = (typeof coverageCategories)[number];
export type CoverageCategoryId = CoverageCategory["id"];
