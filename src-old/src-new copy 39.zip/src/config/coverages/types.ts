export type CoverageCategoryId = "LI" | "AD" | "DI" | "OO" | "SH";

export type CoverageApplicantId = "member" | "spouse" | "child";

export type CoverageUnderwritingType = "FUW" | "GI" | "NA";

export type CoverageDefinition = {
  id: string;
  code: string;
  categoryId: CoverageCategoryId;
  name: string;
  underwritingType: CoverageUnderwritingType;
  definition: string;
  description?: string;
  applicants: CoverageApplicantId[];
  minAmount?: number;
  maxAmount?: number;
  options: {
    id: string;
    type: string;
    choices: unknown[];
  }[];
};
