import type { PageId } from "../../types/page";
import type { FieldId } from "./types";

export const pageFields: Partial<Record<PageId, FieldId[]>> = {
  membership: [
    "membership",
    "title",
    "first-name",
    "last-name",
    "email",
    "phone",
  ],
  eligibility: [
    "zip-postal-code",
    "state-province",
    "birth-date",
    "dependents",
    "spouse-first-name",
    "spouse-last-name",
    "spouse-birth-date",
  ],
  "coverage-questions": [
    "gender",
    "smoker",
    "tobacco-last-used",
    "tobacco-products",
    "average-monthly-income",
    "hours-worked-per-week",
    "monthly-business-expenses",
    "business-expense-responsibility",
    "spouse-gender",
    "spouse-smoker",
    "spouse-tobacco-last-used",
    "spouse-tobacco-products",
    "spouse-average-monthly-income",
    "spouse-hours-worked-per-week",
  ],
};
