export type FieldOption = {
  value: string;
  label: string;
};

export type FieldInputType =
  | "text"
  | "date"
  | "radio"
  | "dropdown"
  | "checkbox"
  | "checkbox-group"
  | "multi-select";

export type FieldId =
  | "membership"
  | "title"
  | "first-name"
  | "last-name"
  | "email"
  | "phone"
  | "zip-postal-code"
  | "state-province"
  | "birth-date"
  | "dependents"
  | "spouse-first-name"
  | "spouse-last-name"
  | "spouse-birth-date"
  | "child-first-name"
  | "child-last-name"
  | "child-birth-date"
  | "child-gender"
  | "gender"
  | "smoker"
  | "tobacco-last-used"
  | "tobacco-products"
  | "average-monthly-income"
  | "hours-worked-per-week"
  | "monthly-business-expenses"
  | "business-expense-responsibility"
  | "spouse-gender"
  | "spouse-smoker"
  | "spouse-tobacco-last-used"
  | "spouse-tobacco-products"
  | "spouse-average-monthly-income"
  | "spouse-hours-worked-per-week";

export type FieldDefinition = {
  id: string;
  label: string;
  inputType: FieldInputType;
  required?: boolean;
  placeholder?: string;
  options?: FieldOption[];
  autoComplete?: string;
  inputMode?: "text" | "email" | "tel" | "numeric";
  format?: "email" | "phone";
  labelVariant?: "floating" | "standard";
};

export type ClientPageFieldConfig = {
  overrides?: Partial<
    Record<string, Partial<FieldDefinition> & { hidden?: boolean }>
  >;
  extraFields?: FieldDefinition[];
};
