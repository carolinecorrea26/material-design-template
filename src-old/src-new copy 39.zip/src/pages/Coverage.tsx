import { useEffect, useMemo } from "react";
import { Button } from "@mui/material";
import { useNavigate } from "react-router-dom";
import CoverageCatalog from "../components/coverage/CoverageCatalog";
import FormPage from "../components/form/FormPage";
import { getActiveClientCoverages } from "../client/getActiveClientCoverages";
import { getNextFormPageId, getPreviousFormPageId } from "../config/formFlow";
import { getPageTitle } from "../config/pages";
import { useApplicationForm } from "../state/ApplicationFormContext";

export default function Coverage() {
  const navigate = useNavigate();
  const pageId = "coverage";
  const coverages = useMemo(() => getActiveClientCoverages(), []);
  const { values, setPageValues } = useApplicationForm();

  const selectedCoverageIds = Array.isArray(values.coverageSelections)
    ? values.coverageSelections
    : [];

  useEffect(() => {
    function handleDevFillForm() {
      const firstCoverageId = coverages[0]?.id;
      if (!firstCoverageId) return;

      setPageValues({
        coverageSelections: [firstCoverageId],
      });
    }

    window.addEventListener("devtools:fillform", handleDevFillForm);
    return () =>
      window.removeEventListener("devtools:fillform", handleDevFillForm);
  }, [coverages, setPageValues]);

  function handleBack() {
    const previousPageId = getPreviousFormPageId(pageId);

    if (previousPageId) {
      navigate(`/${previousPageId}`);
    }
  }

  function handleNext() {
    const nextPageId = getNextFormPageId(pageId);

    if (nextPageId) {
      navigate(`/${nextPageId}`);
    }
  }

  return (
    <FormPage
      title={getPageTitle(pageId)}
      actions={
        <>
          <Button type="button" onClick={handleBack}>
            Back
          </Button>
          <Button type="button" onClick={handleNext} variant="contained">
            Next
          </Button>
        </>
      }
    >
      <CoverageCatalog
        coverages={coverages}
        selectedCoverageIds={selectedCoverageIds}
        onChangeSelectedCoverageIds={(nextIds) =>
          setPageValues({ coverageSelections: nextIds })
        }
      />
    </FormPage>
  );
}
