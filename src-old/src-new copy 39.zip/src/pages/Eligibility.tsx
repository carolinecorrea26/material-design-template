import { Box, Typography } from "@mui/material";
import FormRoutePage, {
  isSectionVisible,
} from "../components/form/FormRoutePage";
import FieldRenderer from "../components/form/FieldRenderer";
import ChildrenList from "../components/form/ChildrenList";
import ApplicantSection from "../components/form/ApplicantSection";

export default function Eligibility() {
  return (
    <FormRoutePage pageId="eligibility">
      {({ control, errors, watchedValues, allFields, pageSections }) =>
        pageSections.map((section) => {
          if (!isSectionVisible(section, watchedValues)) return null;

          const content =
            section.id === "childSection" ? (
              <ChildrenList control={control} />
            ) : section.id === "spouseSection" ? (
              <>
                <Box
                  sx={{
                    display: "grid",
                    gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
                    gap: { xs: 0, sm: 2 },
                  }}
                >
                  {section.fieldIds
                    .filter((fieldId) =>
                      ["spouse-first-name", "spouse-last-name"].includes(
                        fieldId,
                      ),
                    )
                    .map((fieldId) => {
                      const field = allFields.find((f) => f.id === fieldId);
                      if (!field) return null;

                      return (
                        <FieldRenderer
                          key={field.id}
                          field={field}
                          control={control}
                          errors={errors}
                        />
                      );
                    })}
                </Box>

                {section.fieldIds
                  .filter(
                    (fieldId) =>
                      !["spouse-first-name", "spouse-last-name"].includes(
                        fieldId,
                      ),
                  )
                  .map((fieldId) => {
                    const field = allFields.find((f) => f.id === fieldId);
                    if (!field) return null;

                    return (
                      <FieldRenderer
                        key={field.id}
                        field={field}
                        control={control}
                        errors={errors}
                      />
                    );
                  })}
              </>
            ) : (
              <>
                {section.fieldIds.map((fieldId) => {
                  const field = allFields.find((f) => f.id === fieldId);
                  if (!field) return null;

                  return (
                    <FieldRenderer
                      key={field.id}
                      field={field}
                      control={control}
                      errors={errors}
                    />
                  );
                })}
              </>
            );

          return (
            <div key={section.id}>
              {section.applicant ? (
                <ApplicantSection applicant={section.applicant}>
                  {content}
                </ApplicantSection>
              ) : (
                <>
                  {section.title && (
                    <Typography variant="h6" sx={{ mt: 2, mb: 1 }}>
                      {section.title}
                    </Typography>
                  )}
                  {content}
                </>
              )}
            </div>
          );
        })
      }
    </FormRoutePage>
  );
}
