import { Typography } from "@mui/material";
import FormRoutePage, {
  isSectionVisible,
} from "../components/form/FormRoutePage";
import FieldRenderer from "../components/form/FieldRenderer";

export default function HealthQd() {
  return (
    <FormRoutePage pageId="health-qd">
      {({ control, errors, watchedValues, allFields, pageSections }) =>
        pageSections.map((section) => {
          if (!isSectionVisible(section, watchedValues)) return null;

          return (
            <div key={section.id}>
              {section.title && (
                <Typography variant="h6" sx={{ mt: 2, mb: 1 }}>
                  {section.title}
                </Typography>
              )}
              {section.fieldIds.map((fieldId) => {
                const field = allFields.find((f) => f.id === fieldId);
                if (!field) return null;

                return (
                  <FieldRenderer
                    key={field.id}
                    field={field}
                    control={control}
                    errors={errors}
                  />
                );
              })}
            </div>
          );
        })
      }
    </FormRoutePage>
  );
}
