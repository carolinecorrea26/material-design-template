import type { ReactNode } from "react";
import { Box } from "@mui/material";

type AppBodyProps = {
  children: ReactNode;
};

export default function AppBody({ children }: AppBodyProps) {
  return (
    <Box
      component="main"
      sx={{
        width: "100%",
        // maxWidth: 1400,
        marginLeft: "auto",
        marginRight: "auto",
        px: { xs: 2, sm: 3, md: 4 },
        pt: 1,
        pb: 4,
        flex: 1,
        display: "flex",
        flexDirection: "column",
        minHeight: 0,
        boxSizing: "border-box",
      }}
    >
      {children}
    </Box>
  );
}
