import type { PageId } from "../../types/page";
import type { PageSectionConfig } from "./types";
import { applicantSectionTitles } from "../formSectionTitle";

export const pageSections: Partial<Record<PageId, PageSectionConfig[]>> = {
  membership: [
    {
      id: "default",
      pageId: "membership",
      fieldIds: [
        "membership",
        "title",
        "first-name",
        "last-name",
        "email",
        "phone",
      ],
    },
  ],

  eligibility: [
    {
      id: "selfEligibility",
      pageId: "eligibility",
      title: applicantSectionTitles.self,
      applicant: "self",
      fieldIds: ["zip-postal-code", "state-province", "birth-date"],
    },
    {
      id: "dependentSelection",
      pageId: "eligibility",
      fieldIds: ["dependents"],
    },
    {
      id: "spouseSection",
      pageId: "eligibility",
      title: applicantSectionTitles.spouse,
      applicant: "spouse",
      fieldIds: ["spouse-first-name", "spouse-last-name", "spouse-birth-date"],
      visibleWhen: [{ fieldId: "dependents", includes: "spouse" }],
    },
    {
      id: "childSection",
      pageId: "eligibility",
      title: applicantSectionTitles.child,
      applicant: "child",
      fieldIds: [],
      visibleWhen: [{ fieldId: "dependents", includes: "child" }],
    },
  ],

  "coverage-questions": [
    {
      id: "selfCoverageQuestions",
      pageId: "coverage-questions",
      title: applicantSectionTitles.self,
      applicant: "self",
      fieldIds: [
        "gender",
        "smoker",
        "tobacco-last-used",
        "tobacco-products",
        "average-monthly-income",
        "hours-worked-per-week",
        "monthly-business-expenses",
        "business-expense-responsibility",
      ],
    },
    {
      id: "spouseCoverageQuestions",
      pageId: "coverage-questions",
      title: applicantSectionTitles.spouse,
      applicant: "spouse",
      fieldIds: [
        "spouse-gender",
        "spouse-smoker",
        "spouse-tobacco-last-used",
        "spouse-tobacco-products",
        "spouse-average-monthly-income",
        "spouse-hours-worked-per-week",
      ],
    },
  ],
};
