import { useMemo } from "react";
import { Button, Stack, Typography } from "@mui/material";
import { useNavigate } from "react-router-dom";
import FormPage from "../components/form/FormPage";
import { getActiveClientCoverages } from "../client/getActiveClientCoverages";
import { getNextFormPageId, getPreviousFormPageId } from "../config/formFlow";
import { getPageTitle } from "../config/pages";
import { useApplicationForm } from "../state/ApplicationFormContext";

export default function CoverageOptions() {
  const navigate = useNavigate();
  const pageId = "coverage-options";
  const coverages = useMemo(() => getActiveClientCoverages(), []);
  const { values } = useApplicationForm();

  const selectedCoverageIds = Array.isArray(values.coverageSelections)
    ? values.coverageSelections
    : [];

  const selectedCoverages = coverages.filter((c) =>
    selectedCoverageIds.includes(c.id),
  );

  function handleBack() {
    const previousPageId = getPreviousFormPageId(pageId);

    if (previousPageId) {
      navigate(`/${previousPageId}`);
    }
  }

  function handleNext() {
    const nextPageId = getNextFormPageId(pageId);

    if (nextPageId) {
      navigate(`/${nextPageId}`);
    }
  }

  return (
    <FormPage
      title={getPageTitle(pageId)}
      actions={
        <>
          <Button type="button" onClick={handleBack}>
            Back
          </Button>
          <Button type="button" onClick={handleNext} variant="contained">
            Next
          </Button>
        </>
      }
    >
      {selectedCoverages.length > 0 ? (
        <Stack spacing={1}>
          {selectedCoverages.map((coverage) => (
            <Typography key={coverage.id} variant="body2">
              {coverage.name}
            </Typography>
          ))}
        </Stack>
      ) : (
        <Typography color="text.secondary">No coverages selected.</Typography>
      )}
    </FormPage>
  );
}
