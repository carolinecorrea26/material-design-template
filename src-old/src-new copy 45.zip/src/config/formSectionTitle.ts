import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import FavoriteBorderIcon from "@mui/icons-material/FavoriteBorder";
import ChildCareIcon from "@mui/icons-material/ChildCare";
import type { SxProps, Theme } from "@mui/material";
import type { CoverageApplicantId } from "./coverages/types";

export const applicantLabels: Record<CoverageApplicantId, string> = {
  member: "Self",
  spouse: "Spouse",
  child: "Child",
};

export type ApplicantSectionId = "self" | "spouse" | "child";

export const applicantSectionTitles: Record<ApplicantSectionId, string> = {
  self: "Self",
  spouse: "Spouse",
  child: "Child",
};

export const applicantIcons = {
  self: PersonOutlineIcon,
  spouse: FavoriteBorderIcon,
  child: ChildCareIcon,
} satisfies Record<ApplicantSectionId, typeof PersonOutlineIcon>;

export const coverageApplicantToSection: Record<
  CoverageApplicantId,
  ApplicantSectionId
> = {
  member: "self",
  spouse: "spouse",
  child: "child",
};

export function getApplicantIcon(applicant: CoverageApplicantId) {
  return applicantIcons[coverageApplicantToSection[applicant]];
}

export const sectionTitleIconSx: SxProps<Theme> = {
  width: 28,
  height: 28,
  borderRadius: "50%",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  flexShrink: 0,
  backgroundColor: "rgba(7, 104, 255, 0.08)",
  color: "primary.main",
  "& svg": {
    width: "0.875em",
    height: "0.875em",
  },
};

export const inlineCoverageIconSx: SxProps<Theme> = {
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  flexShrink: 0,
  color: "primary.main",
  "& svg": {
    width: "0.875em",
    height: "0.875em",
  },
};
