import { useEffect, useMemo } from "react";
import CoverageCatalog from "../components/coverage/CoverageCatalog";
import FormRoutePage from "../components/form/FormRoutePage";
import { getActiveClientCoverages } from "../client/getActiveClientCoverages";
import { useApplicationForm } from "../state/ApplicationFormContext";

export default function Coverage() {
  const pageId = "coverage";
  const coverages = useMemo(() => getActiveClientCoverages(), []);
  const { values, setPageValues } = useApplicationForm();

  const selectedDependents = Array.isArray(values.dependents)
    ? values.dependents
    : [];

  const selectedCoverageIds = Array.isArray(values.coverageSelections)
    ? values.coverageSelections
    : [];

  useEffect(() => {
    function handleDevFillForm() {
      const firstCoverageId = coverages[0]?.id;
      if (!firstCoverageId) return;

      setPageValues({
        coverageSelections: [firstCoverageId],
      });
    }

    window.addEventListener("devtools:fillform", handleDevFillForm);
    return () =>
      window.removeEventListener("devtools:fillform", handleDevFillForm);
  }, [coverages, setPageValues]);

  function validate() {
    if (selectedCoverageIds.length === 0) {
      return "Please select at least one coverage to continue.";
    }
    return undefined;
  }

  return (
    <FormRoutePage pageId={pageId} validate={validate}>
      <CoverageCatalog
        coverages={coverages}
        selectedCoverageIds={selectedCoverageIds}
        selectedDependents={selectedDependents}
        onChangeSelectedCoverageIds={(nextIds) =>
          setPageValues({ coverageSelections: nextIds })
        }
      />
    </FormRoutePage>
  );
}
