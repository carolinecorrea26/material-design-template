export type FieldOption = {
  value: string;
  label: string;
};

export type FieldInputType =
  | "text"
  | "date"
  | "radio"
  | "dropdown"
  | "checkbox"
  | "checkbox-group"
  | "multi-select";

export type FieldId =
  | "membership"
  | "title"
  | "first-name"
  | "last-name"
  | "email"
  | "phone"
  | "phone-type"
  | "zip-postal-code"
  | "state-province"
  | "birth-date"
  | "dependents"
  | "spouse-first-name"
  | "spouse-last-name"
  | "spouse-birth-date"
  | "child-first-name"
  | "child-last-name"
  | "child-birth-date"
  | "child-gender"
  | "gender"
  | "smoker"
  | "tobacco-last-used"
  | "tobacco-products"
  | "average-monthly-income"
  | "hours-worked-per-week"
  | "monthly-business-expenses"
  | "business-expense-responsibility"
  | "spouse-gender"
  | "spouse-smoker"
  | "spouse-tobacco-last-used"
  | "spouse-tobacco-products"
  | "spouse-average-monthly-income"
  | "spouse-hours-worked-per-week"
  | "spouse-phone"
  | "spouse-phone-type"
  | "street-address"
  | "apt-suite"
  | "city"
  | "state"
  | "zip-code"
  | "correspondence-to"
  | "business-name"
  | "business-type"
  | "business-address-same-as-home"
  | "business-street-address"
  | "business-apt-suite"
  | "business-city"
  | "business-state"
  | "business-zip-code"
  | "business-phone"
  | "spouse-email";

export type FieldDefinition = {
  id: string;
  label: string;
  inputType: FieldInputType;
  required?: boolean;
  placeholder?: string;
  options?: FieldOption[];
  autoComplete?: string;
  inputMode?: "text" | "email" | "tel" | "numeric";
  format?: "email" | "phone";
  labelVariant?: "floating" | "standard";
  disabled?: boolean;
  /** Override the companion phone-type field name (default: "phone-type") */
  phoneTypeFieldId?: string;
};

export type ClientPageFieldConfig = {
  overrides?: Partial<
    Record<string, Partial<FieldDefinition> & { hidden?: boolean }>
  >;
  extraFields?: FieldDefinition[];
};
