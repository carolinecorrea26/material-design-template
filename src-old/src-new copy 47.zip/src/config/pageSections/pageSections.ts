import type { PageId } from "../../types/page";
import type { PageSectionConfig } from "./types";
import { applicantSectionTitles } from "../formSectionTitle";

export const pageSections: Partial<Record<PageId, PageSectionConfig[]>> = {
  membership: [
    {
      id: "default",
      pageId: "membership",
      fieldIds: [
        "membership",
        "title",
        "first-name",
        "last-name",
        "email",
        "phone",
      ],
    },
  ],

  eligibility: [
    {
      id: "selfEligibility",
      pageId: "eligibility",
      title: applicantSectionTitles.self,
      applicant: "self",
      fieldIds: ["zip-postal-code", "state-province", "birth-date"],
    },
    {
      id: "dependentSelection",
      pageId: "eligibility",
      fieldIds: ["dependents"],
    },
    {
      id: "spouseSection",
      pageId: "eligibility",
      title: applicantSectionTitles.spouse,
      applicant: "spouse",
      fieldIds: ["spouse-first-name", "spouse-last-name", "spouse-birth-date"],
      visibleWhen: [{ fieldId: "dependents", includes: "spouse" }],
    },
    {
      id: "childSection",
      pageId: "eligibility",
      title: applicantSectionTitles.child,
      applicant: "child",
      fieldIds: [],
      visibleWhen: [{ fieldId: "dependents", includes: "child" }],
    },
  ],

  "coverage-questions": [
    {
      id: "selfCoverageQuestions",
      pageId: "coverage-questions",
      title: applicantSectionTitles.self,
      applicant: "self",
      fieldIds: [
        "gender",
        "smoker",
        "tobacco-last-used",
        "tobacco-products",
        "average-monthly-income",
        "hours-worked-per-week",
        "monthly-business-expenses",
        "business-expense-responsibility",
      ],
    },
    {
      id: "spouseCoverageQuestions",
      pageId: "coverage-questions",
      title: applicantSectionTitles.spouse,
      applicant: "spouse",
      fieldIds: [
        "spouse-gender",
        "spouse-smoker",
        "spouse-tobacco-last-used",
        "spouse-tobacco-products",
        "spouse-average-monthly-income",
        "spouse-hours-worked-per-week",
      ],
      visibleWhen: [{ fieldId: "dependents", includes: "spouse" }],
    },
  ],

  contact: [
    {
      id: "contactResidentialAddress",
      pageId: "contact",
      title: applicantSectionTitles.self,
      applicant: "self",
      fieldIds: [
        "street-address",
        "apt-suite",
        "city",
        "state",
        "zip-code",
        "correspondence-to",
      ],
    },
    {
      id: "contactBusinessInfo",
      pageId: "contact",
      description: "Business / Employer Information",
      fieldIds: [
        "business-name",
        "business-type",
        "business-address-same-as-home",
        "business-street-address",
        "business-apt-suite",
        "business-city",
        "business-state",
        "business-zip-code",
        "business-phone",
      ],
    },
    {
      id: "contactSpouse",
      pageId: "contact",
      title: applicantSectionTitles.spouse,
      applicant: "spouse",
      fieldIds: ["spouse-phone", "spouse-email"],
      visibleWhen: [{ fieldId: "dependents", includes: "spouse" }],
    },
  ],
};
