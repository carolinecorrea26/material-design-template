export type FieldOption = {
  value: string;
  label: string;
};

export type FieldInputType =
  | "text"
  | "number"
  | "date"
  | "radio"
  | "dropdown"
  | "checkbox"
  | "checkbox-group"
  | "multi-select";

export type FieldId =
  | "membership"
  | "title"
  | "first-name"
  | "last-name"
  | "email"
  | "phone"
  | "phone-type"
  | "zip-postal-code"
  | "state-province"
  | "birth-date"
  | "dependents"
  | "spouse-first-name"
  | "spouse-last-name"
  | "spouse-birth-date"
  | "child-first-name"
  | "child-last-name"
  | "child-birth-date"
  | "child-gender"
  | "gender"
  | "smoker"
  | "tobacco-last-used"
  | "tobacco-products"
  | "average-monthly-income"
  | "hours-worked-per-week"
  | "monthly-business-expenses"
  | "business-expense-responsibility"
  | "spouse-gender"
  | "spouse-smoker"
  | "spouse-tobacco-last-used"
  | "spouse-tobacco-products"
  | "spouse-average-monthly-income"
  | "spouse-hours-worked-per-week"
  | "spouse-phone"
  | "spouse-phone-type"
  | "street-address"
  | "apt-suite"
  | "city"
  | "state"
  | "zip-code"
  | "correspondence-to"
  | "business-name"
  | "business-type"
  | "business-address-same-as-home"
  | "business-street-address"
  | "business-apt-suite"
  | "business-city"
  | "business-state"
  | "business-zip-code"
  | "business-phone"
  | "spouse-email"
  | "physician-first-name"
  | "physician-last-name"
  | "physician-phone"
  | "medical-facility-name"
  | "medical-facility-street-address"
  | "medical-facility-apt-suite"
  | "medical-city"
  | "medical-state"
  | "medical-zip-code"
  | "height-feet"
  | "height-inches"
  | "weight-lbs"
  | "weight-12-months-ago-lbs"
  | "social-security-number"
  | "marital-status"
  | "has-drivers-license"
  | "drivers-license-number"
  | "drivers-license-state"
  | "intend-live-outside-us"
  | "outside-us-months"
  | "outside-us-country"
  | "travel-outside-us-six-months"
  | "travel-outside-us-country"
  | "spouse-height"
  | "spouse-weight-lbs"
  | "spouse-weight-12-months-ago-lbs"
  | "spouse-social-security-number"
  | "spouse-has-drivers-license"
  | "spouse-drivers-license-number"
  | "spouse-drivers-license-state"
  | "spouse-intend-live-outside-us"
  | "spouse-outside-us-months"
  | "spouse-outside-us-country"
  | "spouse-travel-outside-us-six-months"
  | "spouse-travel-outside-us-country";

export type FieldDefinition = {
  id: string;
  label: string;
  inputType: FieldInputType;
  required?: boolean;
  placeholder?: string;
  options?: FieldOption[];
  autoComplete?: string;
  inputMode?: "text" | "email" | "tel" | "numeric";
  format?: "email" | "phone" | "ssn";
  labelVariant?: "floating" | "standard";
  disabled?: boolean;
  /** Override the companion phone-type field name (default: "phone-type") */
  phoneTypeFieldId?: string;
  /** Whether to show the companion phone type selector (default: true) */
  showPhoneTypeSelector?: boolean;
};

export type ClientPageFieldConfig = {
  overrides?: Partial<
    Record<string, Partial<FieldDefinition> & { hidden?: boolean }>
  >;
  extraFields?: FieldDefinition[];
};
