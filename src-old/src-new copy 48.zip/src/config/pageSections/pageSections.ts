import type { PageId } from "../../types/page";
import type { PageSectionConfig } from "./types";
import { applicantSectionTitles } from "../formSectionTitle";

export const pageSections: Partial<Record<PageId, PageSectionConfig[]>> = {
  membership: [
    {
      id: "default",
      pageId: "membership",
      fieldIds: [
        "membership",
        "title",
        "first-name",
        "last-name",
        "email",
        "phone",
      ],
    },
  ],

  eligibility: [
    {
      id: "selfEligibility",
      pageId: "eligibility",
      title: applicantSectionTitles.self,
      applicant: "self",
      fieldIds: ["zip-postal-code", "state-province", "birth-date"],
    },
    {
      id: "dependentSelection",
      pageId: "eligibility",
      fieldIds: ["dependents"],
    },
    {
      id: "spouseSection",
      pageId: "eligibility",
      title: applicantSectionTitles.spouse,
      applicant: "spouse",
      fieldIds: ["spouse-first-name", "spouse-last-name", "spouse-birth-date"],
      visibleWhen: [{ fieldId: "dependents", includes: "spouse" }],
    },
    {
      id: "childSection",
      pageId: "eligibility",
      title: applicantSectionTitles.child,
      applicant: "child",
      fieldIds: [],
      visibleWhen: [{ fieldId: "dependents", includes: "child" }],
    },
  ],

  "coverage-questions": [
    {
      id: "selfCoverageQuestions",
      pageId: "coverage-questions",
      title: applicantSectionTitles.self,
      applicant: "self",
      fieldIds: [
        "gender",
        "smoker",
        "tobacco-last-used",
        "tobacco-products",
        "average-monthly-income",
        "hours-worked-per-week",
        "monthly-business-expenses",
        "business-expense-responsibility",
      ],
    },
    {
      id: "spouseCoverageQuestions",
      pageId: "coverage-questions",
      title: applicantSectionTitles.spouse,
      applicant: "spouse",
      fieldIds: [
        "spouse-gender",
        "spouse-smoker",
        "spouse-tobacco-last-used",
        "spouse-tobacco-products",
        "spouse-average-monthly-income",
        "spouse-hours-worked-per-week",
      ],
      visibleWhen: [{ fieldId: "dependents", includes: "spouse" }],
    },
  ],

  contact: [
    {
      id: "contactResidentialAddress",
      pageId: "contact",
      title: applicantSectionTitles.self,
      applicant: "self",
      fieldIds: [
        "street-address",
        "apt-suite",
        "city",
        "state",
        "zip-code",
        "correspondence-to",
      ],
    },
    {
      id: "contactBusinessInfo",
      pageId: "contact",
      description: "Business / Employer Information",
      fieldIds: [
        "business-name",
        "business-type",
        "business-address-same-as-home",
        "business-street-address",
        "business-apt-suite",
        "business-city",
        "business-state",
        "business-zip-code",
        "business-phone",
      ],
    },
    {
      id: "contactSpouse",
      pageId: "contact",
      title: applicantSectionTitles.spouse,
      applicant: "spouse",
      fieldIds: ["spouse-phone", "spouse-email"],
      visibleWhen: [{ fieldId: "dependents", includes: "spouse" }],
    },
  ],

  personal: [
    {
      id: "personalSelf",
      pageId: "personal",
      title: applicantSectionTitles.self,
      applicant: "self",
      fieldIds: [
        "height-feet",
        "height-inches",
        "weight-lbs",
        "weight-12-months-ago-lbs",
        "social-security-number",
        "marital-status",
        "has-drivers-license",
        "intend-live-outside-us",
        "travel-outside-us-six-months",
      ],
    },
    {
      id: "personalSelfDriversLicense",
      pageId: "personal",
      applicant: "self",
      fieldIds: ["drivers-license-number", "drivers-license-state"],
      visibleWhen: [{ fieldId: "has-drivers-license", equals: "yes" }],
    },
    {
      id: "personalSelfOutsideUs",
      pageId: "personal",
      applicant: "self",
      fieldIds: ["outside-us-months", "outside-us-country"],
      visibleWhen: [{ fieldId: "intend-live-outside-us", equals: "yes" }],
    },
    {
      id: "personalSelfTravelOutsideUs",
      pageId: "personal",
      applicant: "self",
      fieldIds: ["travel-outside-us-country"],
      visibleWhen: [{ fieldId: "travel-outside-us-six-months", equals: "yes" }],
    },
    {
      id: "personalSelfPhysician",
      pageId: "personal",
      applicant: "self",
      fieldIds: [
        "physician-first-name",
        "physician-last-name",
        "physician-phone",
        "medical-facility-name",
        "medical-facility-street-address",
        "medical-facility-apt-suite",
        "medical-city",
        "medical-state",
        "medical-zip-code",
      ],
    },
    {
      id: "personalSpouse",
      pageId: "personal",
      title: applicantSectionTitles.spouse,
      applicant: "spouse",
      fieldIds: [
        "spouse-height",
        "spouse-weight-lbs",
        "spouse-weight-12-months-ago-lbs",
        "spouse-social-security-number",
        "spouse-has-drivers-license",
        "spouse-intend-live-outside-us",
        "spouse-travel-outside-us-six-months",
      ],
      visibleWhen: [{ fieldId: "dependents", includes: "spouse" }],
    },
    {
      id: "personalSpouseDriversLicense",
      pageId: "personal",
      applicant: "spouse",
      fieldIds: [
        "spouse-drivers-license-number",
        "spouse-drivers-license-state",
      ],
      visibleWhen: [
        { fieldId: "dependents", includes: "spouse" },
        { fieldId: "spouse-has-drivers-license", equals: "yes" },
      ],
    },
    {
      id: "personalSpouseOutsideUs",
      pageId: "personal",
      applicant: "spouse",
      fieldIds: ["spouse-outside-us-months", "spouse-outside-us-country"],
      visibleWhen: [
        { fieldId: "dependents", includes: "spouse" },
        { fieldId: "spouse-intend-live-outside-us", equals: "yes" },
      ],
    },
    {
      id: "personalSpouseTravelOutsideUs",
      pageId: "personal",
      applicant: "spouse",
      fieldIds: ["spouse-travel-outside-us-country"],
      visibleWhen: [
        { fieldId: "dependents", includes: "spouse" },
        { fieldId: "spouse-travel-outside-us-six-months", equals: "yes" },
      ],
    },
  ],
};
