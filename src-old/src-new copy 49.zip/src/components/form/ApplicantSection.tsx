import type { ReactNode } from "react";
import { Box, Stack, Typography } from "@mui/material";
import {
  applicantIcons,
  applicantSectionTitles,
  sectionTitleIconSx,
  type ApplicantSectionId,
} from "../../config/formSectionTitle";

type ApplicantSectionProps = {
  applicant: ApplicantSectionId;
  children: ReactNode;
  showLabel?: boolean;
};

export default function ApplicantSection({
  applicant,
  children,
  showLabel = true,
}: ApplicantSectionProps) {
  const Icon = applicantIcons[applicant];
  const title = applicantSectionTitles[applicant];

  if (!showLabel) {
    return <>{children}</>;
  }

  return (
    <Box sx={{ mt: 2 }}>
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1.5 }}>
        <Box sx={sectionTitleIconSx}>
          <Icon />
        </Box>

        <Typography
          sx={{
            lineHeight: 2.66,
            textTransform: "uppercase",
            color: "#4a6081",
            display: "block",
            fontWeight: 700,
            fontSize: "0.75rem",
            letterSpacing: "1px",
          }}
        >
          {title}
        </Typography>
      </Stack>

      <Box
        sx={{
          backgroundColor: "rgb(0 22 57 / 4%)",
          borderRadius: 1.5,
          px: { xs: 2, sm: 2.5 },
          py: 2,
        }}
      >
        {children}
      </Box>
    </Box>
  );
}
