import { useEffect, useState } from "react";
import {
  Box,
  IconButton,
  LinearProgress,
  Stack,
  Typography,
} from "@mui/material";
import { ChevronLeft, ChevronRight } from "@mui/icons-material";
import { pages } from "../../config/pages";
import type { PageId } from "../../types/page";
import {
  getFormProgressPercent,
  getNextFormPageId,
  getPreviousFormPageId,
  isFormPage,
} from "../../config/formFlow";
import {
  getProgressStepIndex,
  progressSteps,
} from "../../config/progressSteps";
import type { ProgressVariant } from "../../types/progress";
import { useApplicationForm } from "../../state/ApplicationFormContext";

const PROGRESS_VARIANT_STORAGE_KEY = "devtools:progressVariant";

function getCurrentPageId(pathname: string): PageId | null {
  const match = pages.find((page) => page.path === pathname);
  return match?.id ?? null;
}

function navigateTo(path: string) {
  if (typeof window === "undefined") return;
  if (window.location.pathname === path) return;

  window.history.pushState({}, "", path);
  window.dispatchEvent(new PopStateEvent("popstate"));
}

function readProgressVariant(): ProgressVariant {
  const stored = window.sessionStorage.getItem(PROGRESS_VARIANT_STORAGE_KEY);
  return stored === "stepper" ? "stepper" : "bar";
}

export default function FormProgress() {
  const pageId = getCurrentPageId(window.location.pathname);
  const { values } = useApplicationForm();

  const [progressVariant, setProgressVariant] = useState<ProgressVariant>(
    readProgressVariant(),
  );

  useEffect(() => {
    function handleVariantChange(event: Event) {
      const customEvent = event as CustomEvent<ProgressVariant>;
      setProgressVariant(customEvent.detail ?? readProgressVariant());
    }

    window.addEventListener(
      "devtools:progressvariantchange",
      handleVariantChange,
    );

    return () => {
      window.removeEventListener(
        "devtools:progressvariantchange",
        handleVariantChange,
      );
    };
  }, []);

  if (!pageId || !isFormPage(pageId)) {
    return null;
  }

  const percent = getFormProgressPercent(pageId, values);
  const activeStep = getProgressStepIndex(pageId);

  const content =
    progressVariant === "stepper" ? (
      <Stack spacing={1}>
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            width: "100%",
          }}
        >
          {progressSteps.map((step, index) => {
            const Icon = step.icon;
            const isActive = index === activeStep;
            const isComplete = index < activeStep;
            const isLast = index === progressSteps.length - 1;

            return (
              <Box
                key={step.id}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  flex: 1,
                  minWidth: 0,
                }}
              >
                <Box
                  sx={{
                    width: 36,
                    height: 36,
                    borderRadius: "50%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    border: "1px solid",
                    borderColor:
                      isActive || isComplete ? "primary.main" : "divider",
                    backgroundColor:
                      isActive || isComplete
                        ? "primary.main"
                        : "background.paper",
                    color:
                      isActive || isComplete
                        ? "primary.contrastText"
                        : "text.secondary",
                    flexShrink: 0,
                  }}
                >
                  <Icon sx={{ fontSize: 18 }} />
                </Box>

                {!isLast && (
                  <Box
                    sx={{
                      height: 2,
                      flex: 1,
                      mx: 1,
                      borderRadius: 999,
                      backgroundColor: isComplete ? "primary.main" : "divider",
                    }}
                  />
                )}
              </Box>
            );
          })}
        </Box>

        <Box sx={{ minHeight: 20 }}>
          <Typography variant="body2" fontWeight={600}>
            {progressSteps[activeStep]?.label}
          </Typography>
        </Box>
      </Stack>
    ) : (
      (() => {
        const previousPageId = getPreviousFormPageId(pageId, values);
        const nextPageId = getNextFormPageId(pageId, values);
        const hasNextAction = Boolean(nextPageId) || pageId === "payment";

        function handleBack() {
          const backButton = document.querySelector(
            `button[form="${pageId}-form"][type="button"]`,
          ) as HTMLButtonElement | null;

          if (backButton) {
            backButton.click();
            return;
          }

          if (previousPageId) {
            navigateTo(`/${previousPageId}`);
          }
        }

        function handleNext() {
          const submitButton = document.querySelector(
            `button[type="submit"][form="${pageId}-form"]`,
          ) as HTMLButtonElement | null;

          if (submitButton) {
            submitButton.click();
            return;
          }

          if (nextPageId) {
            navigateTo(`/${nextPageId}`);
          }
        }

        return (
          <Stack spacing={0}>
            {/* <Box
              sx={{
                fontWeight: 600,
                fontSize: "0.75rem",
                color: "text.secondary",
              }}
            >
              <Box
                component="span"
                sx={{
                  marginLeft: "2.5rem",
                  color: "primary.main",
                  fontWeight: 900,
                }}
              >
                {Math.round(percent)}%
              </Box>{" "}
              done
            </Box> */}

            <Box sx={{ display: "flex", alignItems: "center", gap: 0 }}>
              <IconButton
                onClick={handleBack}
                disabled={!previousPageId}
                size="small"
              >
                <ChevronLeft />
              </IconButton>

              <LinearProgress
                variant="determinate"
                value={percent}
                sx={{
                  flex: 1,
                  height: 12,
                  borderRadius: 999,
                  bgcolor: "rgb(0 0 0 / 4%)",
                  "& .MuiLinearProgress-bar": {
                    bgcolor: "primary.main",
                    borderRadius: 999,
                  },
                }}
              />

              <IconButton
                onClick={handleNext}
                size="small"
                disabled={!hasNextAction}
              >
                <ChevronRight />
              </IconButton>
            </Box>
          </Stack>
        );
      })()
    );

  return (
    <Box
      sx={{
        width: "100%",
        // px: { xs: 0, sm: 3, md: 4 },
      }}
    >
      <Box
        sx={{
          // maxWidth: 1400,
          mx: "auto",
          width: "100%",
        }}
      >
        {content}
      </Box>
    </Box>
  );
}
