import { Typography } from "@mui/material";
import FormRoutePage, {
  isSectionVisible,
} from "../components/form/FormRoutePage";
import FieldRenderer from "../components/form/FieldRenderer";
import ApplicantSection from "../components/form/ApplicantSection";
import { useApplicationForm } from "../state/ApplicationFormContext";
import {
  categoryQuestionFields,
  categoryQuestionFieldsSpouse,
  getSelectedCategoryIds,
} from "../config/formFlow";

export default function CoverageQuestions() {
  const { values } = useApplicationForm();
  const selectedCategories = getSelectedCategoryIds(values);
  const dependents = values["dependents"];
  const hasDependents = Array.isArray(dependents) && dependents.length > 0;

  const selfFieldIds = new Set(
    selectedCategories.flatMap((cat) => categoryQuestionFields[cat] ?? []),
  );

  const spouseFieldIds = new Set(
    selectedCategories.flatMap(
      (cat) => categoryQuestionFieldsSpouse[cat] ?? [],
    ),
  );

  return (
    <FormRoutePage pageId="coverage-questions">
      {({ control, errors, watchedValues, allFields, pageSections }) =>
        pageSections.map((section) => {
          if (!isSectionVisible(section, watchedValues)) return null;

          const activeFieldIds =
            section.applicant === "spouse" ? spouseFieldIds : selfFieldIds;

          const smokerFieldId =
            section.applicant === "spouse" ? "spouse-smoker" : "smoker";
          const isSmokerYes = watchedValues[smokerFieldId] === "yes";

          const tobaccoConditionalFields = new Set(
            section.applicant === "spouse"
              ? ["spouse-tobacco-last-used", "spouse-tobacco-products"]
              : ["tobacco-last-used", "tobacco-products"],
          );

          const visibleFieldIds = section.fieldIds.filter(
            (id) =>
              activeFieldIds.has(id) &&
              (!tobaccoConditionalFields.has(id) || isSmokerYes),
          );

          if (visibleFieldIds.length === 0) return null;

          const content = (
            <>
              {visibleFieldIds.map((fieldId) => {
                const field = allFields.find((f) => f.id === fieldId);
                if (!field) return null;

                return (
                  <FieldRenderer
                    key={field.id}
                    field={field}
                    control={control}
                    errors={errors}
                  />
                );
              })}
            </>
          );

          return (
            <div key={section.id}>
              {section.applicant ? (
                <ApplicantSection
                  applicant={section.applicant}
                  showLabel={section.applicant !== "self" || hasDependents}
                >
                  {content}
                </ApplicantSection>
              ) : (
                <>
                  {section.title && (
                    <Typography variant="h6" sx={{ mt: 2, mb: 1 }}>
                      {section.title}
                    </Typography>
                  )}
                  {content}
                </>
              )}
            </div>
          );
        })
      }
    </FormRoutePage>
  );
}
