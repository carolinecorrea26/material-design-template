import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { Button } from "@mui/material";
import { useForm, type FieldErrors } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import type { PageId } from "../../types/page";
import { getClientPageFields } from "../../config/clientFields/getClientPageFields";
import {
  getNextFormPageId,
  getPreviousFormPageId,
} from "../../config/formFlow";
import { getPageTitle } from "../../config/pages";
import { getPageSections } from "../../config/pageSections";
import type { PageSectionConfig } from "../../config/pageSections/types";
import type { FieldDefinition } from "../../config/fields/types";
import { useApplicationForm } from "../../state/ApplicationFormContext";
import FormPage from "./FormPage";

export type FormRoutePageValues = Record<string, any>;

export type FormRouteRenderProps = {
  control: ReturnType<typeof useForm<FormRoutePageValues>>["control"];
  errors: ReturnType<
    typeof useForm<FormRoutePageValues>
  >["formState"]["errors"];
  watchedValues: FormRoutePageValues;
  allFields: ReturnType<typeof getClientPageFields>;
  pageSections: ReturnType<typeof getPageSections>;
  setValue: ReturnType<typeof useForm<FormRoutePageValues>>["setValue"];
};

type DevFillContext = {
  currentValues: FormRoutePageValues;
  currentFields: FieldDefinition[];
  setValue: ReturnType<typeof useForm<FormRoutePageValues>>["setValue"];
  setPageValues: ReturnType<typeof useApplicationForm>["setPageValues"];
};

type FormRoutePageProps = {
  pageId: PageId;
  title?: string;
  children: ReactNode | ((props: FormRouteRenderProps) => ReactNode);
  validate?: () => string | undefined;
  defaultValueOverrides?: FormRoutePageValues;
  devFillFields?: (currentValues: FormRoutePageValues) => FieldDefinition[];
  onDevFill?: (context: DevFillContext) => void;
};

export function isSectionVisible(
  section: PageSectionConfig,
  values: FormRoutePageValues,
): boolean {
  if (!section.visibleWhen) return true;

  return section.visibleWhen.every((rule) => {
    const value = values[rule.fieldId];

    if ("equals" in rule) return value === rule.equals;
    if ("notEquals" in rule) return value !== rule.notEquals;
    if ("includes" in rule) {
      return Array.isArray(value) && value.includes(rule.includes);
    }

    return true;
  });
}

function getDevValue(field: {
  id: string;
  inputType: string;
  format?: string;
  options?: { value: string }[];
}) {
  if (field.id === "dependents") return ["spouse"];
  if (field.id.includes("-onset")) return "01/2020";
  if (field.inputType === "checkbox") return true;
  if (field.inputType === "checkbox-group") {
    return field.options?.[0]?.value ? [field.options[0].value] : [];
  }
  if (field.inputType === "multi-select") {
    return field.options?.[0]?.value ? [field.options[0].value] : [];
  }
  if (field.inputType === "radio" || field.inputType === "dropdown") {
    return field.options?.[0]?.value ?? "";
  }
  if (field.inputType === "date") return "1990-01-01";
  if (field.inputType === "number") return "100";
  if (field.format === "ssn") return "123-45-6789";
  if (field.format === "email" || field.id.toLowerCase().includes("email"))
    return "test@example.com";
  if (field.format === "phone" || field.id.toLowerCase().includes("phone"))
    return "(555) 123-4567";
  if (field.id.toLowerCase().includes("zip")) return "10001";
  if (field.id.toLowerCase().includes("state")) return "NY";
  return "Test";
}

export default function FormRoutePage({
  pageId,
  title,
  children,
  validate,
  defaultValueOverrides,
  devFillFields,
  onDevFill,
}: FormRoutePageProps) {
  const navigate = useNavigate();
  const { values, setPageValues } = useApplicationForm();

  const initialFields = getClientPageFields(pageId, values);
  const defaultValueOverridesRef = useRef(defaultValueOverrides);
  defaultValueOverridesRef.current = defaultValueOverrides;

  const defaultValues = initialFields.reduce<FormRoutePageValues>(
    (acc, field) => {
      acc[field.id] =
        defaultValueOverrides?.[field.id] ??
        values[field.id] ??
        (field.inputType === "checkbox"
          ? false
          : field.inputType === "checkbox-group"
            ? []
            : "");
      return acc;
    },
    {},
  );

  const {
    control,
    handleSubmit,
    watch,
    getValues,
    setValue,
    reset,
    formState: { errors },
  } = useForm<FormRoutePageValues>({
    defaultValues,
  });

  const watchedValues = { ...values, ...watch() };

  const watchRef = useRef(watch);
  watchRef.current = watch;
  const setPageValuesRef = useRef(setPageValues);
  setPageValuesRef.current = setPageValues;

  useEffect(() => {
    return () => {
      setPageValuesRef.current(watchRef.current());
    };
  }, []);
  const allFields = getClientPageFields(pageId, watchedValues);
  const pageSections = getPageSections(pageId);

  useEffect(() => {
    const fields = getClientPageFields(pageId, values);

    const restoredValues = fields.reduce<FormRoutePageValues>((acc, field) => {
      acc[field.id] =
        defaultValueOverridesRef.current?.[field.id] ??
        values[field.id] ??
        (field.inputType === "checkbox"
          ? false
          : field.inputType === "checkbox-group"
            ? []
            : "");
      return acc;
    }, {});

    reset(restoredValues);
  }, [pageId, values, reset]);

  useEffect(() => {
    function handleDevFillForm() {
      const currentValues = { ...values, ...getValues() };
      const currentFields = [
        ...getClientPageFields(pageId, currentValues),
        ...(devFillFields?.(currentValues) ?? []),
      ].filter(
        (field, index, fields) =>
          fields.findIndex((entry) => entry.id === field.id) === index,
      );

      currentFields.forEach((field) => {
        setValue(field.id, getDevValue(field), {
          shouldDirty: true,
          shouldTouch: true,
          shouldValidate: false,
        });
      });

      onDevFill?.({
        currentValues,
        currentFields,
        setValue,
        setPageValues: setPageValuesRef.current,
      });
    }

    window.addEventListener("devtools:fillform", handleDevFillForm);
    return () =>
      window.removeEventListener("devtools:fillform", handleDevFillForm);
  }, [devFillFields, getValues, onDevFill, pageId, setValue, values]);

  const [pageError, setPageError] = useState<string | undefined>();

  const scrollToFirstError = useCallback(() => {
    requestAnimationFrame(() => {
      const firstErrorField = document.querySelector(
        '[aria-invalid="true"], .Mui-error input, .Mui-error textarea, .Mui-error .MuiSelect-select',
      );
      if (firstErrorField) {
        firstErrorField.scrollIntoView({ behavior: "smooth", block: "center" });
      } else {
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
    });
  }, []);

  function onSubmit(formValues: FormRoutePageValues) {
    if (validate) {
      const validationError = validate();

      if (validationError) {
        setPageError(validationError);
        window.scrollTo({ top: 0, behavior: "smooth" });
        return;
      }
    }

    setPageError(undefined);
    setPageValues(formValues);

    const nextNavigationValues = {
      ...values,
      ...formValues,
    };
    const nextPageId = getNextFormPageId(pageId, nextNavigationValues);

    if (nextPageId) {
      navigate(`/${nextPageId}`);
      return;
    }

    if (pageId === "payment") {
      navigate("/receipt");
    }
  }

  function onFormError(fieldErrors: FieldErrors<FormRoutePageValues>) {
    setPageError("Please correct the errors below before continuing.");

    if (Object.keys(fieldErrors).length > 0) {
      scrollToFirstError();
    } else {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }

  function handleBack() {
    const previousPageId = getPreviousFormPageId(pageId, watchedValues);

    if (previousPageId) {
      setPageValues(getValues());
      navigate(`/${previousPageId}`);
    }
  }

  return (
    <FormPage
      title={title ?? getPageTitle(pageId)}
      error={pageError}
      actions={
        <>
          <Button
            type="button"
            onClick={handleBack}
            disabled={!getPreviousFormPageId(pageId, watchedValues)}
          >
            Back
          </Button>
          <Button type="submit" form={`${pageId}-form`} variant="contained">
            Next
          </Button>
        </>
      }
    >
      <form
        id={`${pageId}-form`}
        noValidate
        onSubmit={handleSubmit(onSubmit, onFormError)}
      >
        {typeof children === "function"
          ? children({
              control,
              errors,
              watchedValues,
              allFields,
              pageSections,
              setValue,
            })
          : children}
      </form>
    </FormPage>
  );
}
