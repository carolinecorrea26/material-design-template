import type { PageId } from "../types/page";
import type { ApplicationFormValues } from "../state/ApplicationFormContext";
import type { CoverageCategoryId } from "./coverages/types";
import { getActiveClientCoverages } from "../client/getActiveClientCoverages";

export const formFlow: PageId[] = [
  "membership",
  "eligibility",
  "coverage",
  "coverage-questions",
  "coverage-options",
  "beneficiary",
  "contact",
  "personal",
  "financial",
  "review",
  "health-si",
  "health-qd",
  "health-di",
  "health-cir",
  "payment",
  "docusign",
  "receipt",
];

/** Coverage-category IDs that require the coverage-questions page. */
export const categoriesRequiringQuestions: CoverageCategoryId[] = [
  "LI",
  "DI",
  "OO",
];

/**
 * Field IDs shown on coverage-questions keyed by the coverage category
 * that triggers them. Only categories that actually require questions are listed.
 */
export const categoryQuestionFields: Partial<
  Record<CoverageCategoryId, string[]>
> = {
  LI: ["smoker", "tobacco-last-used", "tobacco-products"],
  DI: ["average-monthly-income", "hours-worked-per-week"],
  OO: ["monthly-business-expenses", "business-expense-responsibility"],
};

export const categoryQuestionFieldsSpouse: Partial<
  Record<CoverageCategoryId, string[]>
> = {
  LI: ["spouse-smoker", "spouse-tobacco-last-used", "spouse-tobacco-products"],
  DI: ["spouse-average-monthly-income", "spouse-hours-worked-per-week"],
};

/** Resolve which coverage category IDs the user actually selected. */
export function getSelectedCategoryIds(
  values: ApplicationFormValues,
): CoverageCategoryId[] {
  const selectedIds = Array.isArray(values.coverageSelections)
    ? values.coverageSelections
    : [];

  if (selectedIds.length === 0) return [];

  const coverages = getActiveClientCoverages();
  const categories = new Set<CoverageCategoryId>();

  for (const coverage of coverages) {
    if (selectedIds.includes(coverage.id)) {
      categories.add(coverage.categoryId);
    }
  }

  return [...categories];
}

/** True when a page should be skipped given the current form values. */
export function shouldSkipPage(
  pageId: PageId,
  values: ApplicationFormValues,
): boolean {
  if (pageId === "coverage-questions") {
    const selectedCategories = getSelectedCategoryIds(values);
    return !selectedCategories.some((cat) =>
      categoriesRequiringQuestions.includes(cat),
    );
  }

  if (pageId === "beneficiary") {
    const selectedCategories = getSelectedCategoryIds(values);
    return !selectedCategories.some((cat) => cat === "LI" || cat === "AD");
  }

  return false;
}

export function isFormPage(pageId: PageId) {
  return formFlow.includes(pageId);
}

export function getNextFormPageId(
  pageId: PageId,
  values?: ApplicationFormValues,
) {
  const currentIndex = formFlow.indexOf(pageId);

  if (currentIndex === -1 || currentIndex === formFlow.length - 1) {
    return null;
  }

  let nextIndex = currentIndex + 1;

  while (
    values &&
    nextIndex < formFlow.length &&
    shouldSkipPage(formFlow[nextIndex], values)
  ) {
    nextIndex++;
  }

  return nextIndex < formFlow.length ? formFlow[nextIndex] : null;
}

export function getPreviousFormPageId(
  pageId: PageId,
  values?: ApplicationFormValues,
) {
  const currentIndex = formFlow.indexOf(pageId);

  if (currentIndex <= 0) {
    return null;
  }

  let prevIndex = currentIndex - 1;

  while (
    values &&
    prevIndex >= 0 &&
    shouldSkipPage(formFlow[prevIndex], values)
  ) {
    prevIndex--;
  }

  return prevIndex >= 0 ? formFlow[prevIndex] : null;
}

export function getFormPageIndex(pageId: PageId) {
  return formFlow.indexOf(pageId);
}

export function getActiveFormFlow(values?: ApplicationFormValues): PageId[] {
  if (!values) return formFlow;
  return formFlow.filter((id) => !shouldSkipPage(id, values));
}

export function getFormProgressPercent(
  pageId: PageId,
  values?: ApplicationFormValues,
) {
  const activeFlow = getActiveFormFlow(values);
  const currentIndex = activeFlow.indexOf(pageId);

  if (currentIndex === -1) {
    return 0;
  }

  return ((currentIndex + 1) / activeFlow.length) * 100;
}
