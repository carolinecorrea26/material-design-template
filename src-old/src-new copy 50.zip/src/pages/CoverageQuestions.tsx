import { Box, Typography } from "@mui/material";
import FormRoutePage, {
  isSectionVisible,
} from "../components/form/FormRoutePage";
import FieldRenderer from "../components/form/FieldRenderer";
import ApplicantSection from "../components/form/ApplicantSection";
import { useApplicationForm } from "../state/ApplicationFormContext";
import {
  categoryQuestionFields,
  categoryQuestionFieldsSpouse,
  getSelectedCategoryIds,
} from "../config/formFlow";

export default function CoverageQuestions() {
  const { values } = useApplicationForm();
  const selectedCategories = getSelectedCategoryIds(values);
  const dependents = values["dependents"];
  const hasDependents = Array.isArray(dependents) && dependents.length > 0;

  const selfFieldIds = new Set(
    selectedCategories.flatMap((cat) => categoryQuestionFields[cat] ?? []),
  );

  const spouseFieldIds = new Set(
    selectedCategories.flatMap(
      (cat) => categoryQuestionFieldsSpouse[cat] ?? [],
    ),
  );

  const tobaccoConditionalFieldIds = new Set([
    "tobacco-last-used",
    "tobacco-products",
  ]);
  const spouseTobaccoConditionalFieldIds = new Set([
    "spouse-tobacco-last-used",
    "spouse-tobacco-products",
  ]);

  return (
    <FormRoutePage pageId="coverage-questions">
      {({ control, errors, watchedValues, allFields, pageSections }) =>
        pageSections.map((section) => {
          if (!isSectionVisible(section, watchedValues)) return null;

          const activeFieldIds =
            section.applicant === "spouse" ? spouseFieldIds : selfFieldIds;

          const smokerFieldId =
            section.applicant === "spouse" ? "spouse-smoker" : "smoker";
          const isSmokerYes = watchedValues[smokerFieldId] === "yes";

          const conditionalFieldIds =
            section.applicant === "spouse"
              ? spouseTobaccoConditionalFieldIds
              : tobaccoConditionalFieldIds;

          const visibleFieldIds = section.fieldIds.filter(
            (id) =>
              activeFieldIds.has(id) &&
              (!conditionalFieldIds.has(id) || isSmokerYes),
          );

          if (visibleFieldIds.length === 0) return null;

          const content = (
            <>
              {visibleFieldIds.map((fieldId) => {
                const field = allFields.find((f) => f.id === fieldId);
                if (!field) return null;

                const conditionalFields = visibleFieldIds.filter((id) =>
                  conditionalFieldIds.has(id),
                );

                return (
                  <Box key={field.id}>
                    <FieldRenderer
                      field={field}
                      control={control}
                      errors={errors}
                    />

                    {fieldId === smokerFieldId &&
                      isSmokerYes &&
                      conditionalFields.length > 0 && (
                        <Box
                          sx={{
                            ml: 2,
                            pl: 2,
                            borderLeft: "4px solid",
                            borderLeftColor: "primary.main",
                            backgroundColor: "rgb(0 22 57 / 4%)",
                            borderRadius: 1,
                            p: 2,
                            mt: 2,
                          }}
                        >
                          {conditionalFields.map((conditionalFieldId) => {
                            const conditionalField = allFields.find(
                              (f) => f.id === conditionalFieldId,
                            );
                            if (!conditionalField) return null;

                            return (
                              <Box key={conditionalField.id} sx={{ mb: 2 }}>
                                <FieldRenderer
                                  field={conditionalField}
                                  control={control}
                                  errors={errors}
                                />
                              </Box>
                            );
                          })}
                        </Box>
                      )}
                  </Box>
                );
              })}
            </>
          );

          return (
            <div key={section.id}>
              {section.applicant ? (
                <ApplicantSection
                  applicant={section.applicant}
                  showLabel={section.applicant !== "self" || hasDependents}
                >
                  {content}
                </ApplicantSection>
              ) : (
                <>
                  {section.title && (
                    <Typography variant="h6" sx={{ mt: 2, mb: 1 }}>
                      {section.title}
                    </Typography>
                  )}
                  {content}
                </>
              )}
            </div>
          );
        })
      }
    </FormRoutePage>
  );
}
