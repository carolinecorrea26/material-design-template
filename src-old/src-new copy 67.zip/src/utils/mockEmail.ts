import emailjs from "@emailjs/browser";
import type { ApplicationFormValues } from "../state/ApplicationFormContext";
import { getActiveClient } from "../client/getActiveClient";

const EMAILJS_SERVICE_ID = "YOUR_SERVICE_ID";
const EMAILJS_PUBLIC_KEY = "YOUR_PUBLIC_KEY";

const AUTOSAVE_TEMPLATE_ID = "YOUR_AUTOSAVE_TEMPLATE_ID";
const RECEIPT_TEMPLATE_ID = "YOUR_RECEIPT_TEMPLATE_ID";

const AUTOSAVE_EMAIL_SENT_KEY = "mockEmail:autosaveSent";
const RECEIPT_EMAIL_SENT_KEY = "mockEmail:receiptSent";

function getStringValue(values: ApplicationFormValues, fieldId: string) {
  const value = values[fieldId];
  return typeof value === "string" ? value.trim() : "";
}

function getEmailPayload(values: ApplicationFormValues) {
  const client = getActiveClient();

  return {
    to_email: getStringValue(values, "email"),
    first_name: getStringValue(values, "first-name"),
    last_name: getStringValue(values, "last-name"),
    association_name: client.branding.name,
    tpa_name: client.branding.name,
    tpa_phone: client.support.phoneDisplay || client.support.phone || "",
    tpa_email: client.support.email || "",
    resume_url:
      "https://redesignv2--material-design-template.netlify.app/resume",
  };
}

function hasRecipientEmail(values: ApplicationFormValues) {
  return Boolean(getStringValue(values, "email"));
}

export async function sendAutosaveMockEmail(values: ApplicationFormValues) {
  if (!hasRecipientEmail(values)) return;

  const alreadySent = window.sessionStorage.getItem(AUTOSAVE_EMAIL_SENT_KEY);
  if (alreadySent) return;

  await emailjs.send(
    EMAILJS_SERVICE_ID,
    AUTOSAVE_TEMPLATE_ID,
    getEmailPayload(values),
    EMAILJS_PUBLIC_KEY,
  );

  window.sessionStorage.setItem(AUTOSAVE_EMAIL_SENT_KEY, "true");
}

export async function sendReceiptMockEmail(
  values: ApplicationFormValues,
  confirmationNumber: string,
) {
  if (!hasRecipientEmail(values)) return;

  const alreadySent = window.sessionStorage.getItem(RECEIPT_EMAIL_SENT_KEY);
  if (alreadySent) return;

  await emailjs.send(
    EMAILJS_SERVICE_ID,
    RECEIPT_TEMPLATE_ID,
    {
      ...getEmailPayload(values),
      confirmation_number: confirmationNumber,
    },
    EMAILJS_PUBLIC_KEY,
  );

  window.sessionStorage.setItem(RECEIPT_EMAIL_SENT_KEY, "true");
}
