import { Fragment, useMemo, useState } from "react";
import {
  Box,
  Button,
  Collapse,
  Divider,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import DeleteOutlineRoundedIcon from "@mui/icons-material/DeleteOutlineRounded";
import DraftsRoundedIcon from "@mui/icons-material/DraftsRounded";
import RefreshRoundedIcon from "@mui/icons-material/RefreshRounded";
import {
  clearMockEmailPreviews,
  readMockEmailPreviews,
  type MockEmailPreview,
} from "../utils/mockEmail";

function formatPreviewDate(value: string) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(new Date(value));
}

export default function MockEmailPreview() {
  const [expandedEmailId, setExpandedEmailId] = useState<string | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  const previews = useMemo(() => {
    refreshKey;
    return readMockEmailPreviews();
  }, [refreshKey]);

  function handleClearInbox() {
    clearMockEmailPreviews();
    setExpandedEmailId(null);
    setRefreshKey((currentValue) => currentValue + 1);
  }

  function handleRefreshInbox() {
    setRefreshKey((currentValue) => currentValue + 1);
  }

  return (
    <Box
      sx={{
        width: "100%",
        maxWidth: 1180,
        mx: "auto",
        py: { xs: 2, md: 4 },
      }}
    >
      <Stack spacing={3}>
        <Box>
          <Typography variant="h3" component="h1" sx={{ fontWeight: 800 }}>
            Your Email Inbox
          </Typography>
        </Box>

        <Stack
          direction={{ xs: "column", sm: "row" }}
          spacing={1.5}
          sx={{ alignItems: { xs: "stretch", sm: "center" } }}
        >
          <Button
            variant="outlined"
            startIcon={<RefreshRoundedIcon />}
            onClick={handleRefreshInbox}
          >
            Refresh inbox
          </Button>

          <Button
            color="error"
            variant="outlined"
            startIcon={<DeleteOutlineRoundedIcon />}
            onClick={handleClearInbox}
          >
            Clear generated emails
          </Button>
        </Stack>

        <TableContainer
          component={Paper}
          elevation={0}
          sx={{
            border: "1px solid",
            borderColor: "divider",
            borderRadius: 4,
            overflow: "hidden",
          }}
        >
          <Table aria-label="Mock email inbox">
            <TableHead>
              <TableRow sx={{ bgcolor: "#f5f5f5" }}>
                <TableCell sx={{ fontWeight: 800 }}>From</TableCell>
                <TableCell sx={{ fontWeight: 800 }}>Subject</TableCell>
                <TableCell sx={{ fontWeight: 800 }}>To</TableCell>
                <TableCell align="right" sx={{ fontWeight: 800 }}>
                  Date
                </TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {previews.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4}>
                    <Stack
                      spacing={1}
                      sx={{
                        alignItems: "center",
                        justifyContent: "center",
                        py: 8,
                        color: "text.secondary",
                      }}
                    >
                      <DraftsRoundedIcon fontSize="large" />

                      <Typography variant="h6" sx={{ fontWeight: 700 }}>
                        No mock emails yet
                      </Typography>

                      <Typography variant="body2">
                        Start the application flow to generate email previews.
                      </Typography>
                    </Stack>
                  </TableCell>
                </TableRow>
              ) : (
                previews.map((preview: MockEmailPreview) => {
                  const isExpanded = expandedEmailId === preview.id;

                  return (
                    <Fragment key={preview.id}>
                      <TableRow
                        hover
                        onClick={() =>
                          setExpandedEmailId(isExpanded ? null : preview.id)
                        }
                        sx={{
                          cursor: "pointer",
                          bgcolor: isExpanded ? "action.hover" : "inherit",
                        }}
                      >
                        <TableCell>
                          <Stack spacing={0.25}>
                            <Typography
                              variant="body2"
                              sx={{ fontWeight: 800 }}
                            >
                              {preview.fromName}
                            </Typography>

                            <Typography
                              variant="caption"
                              sx={{ color: "text.secondary" }}
                            >
                              {preview.fromEmail}
                            </Typography>
                          </Stack>
                        </TableCell>

                        <TableCell>
                          <Typography variant="body2" sx={{ fontWeight: 700 }}>
                            {preview.subject}
                          </Typography>
                        </TableCell>

                        <TableCell>
                          <Typography variant="body2">
                            {preview.toEmail}
                          </Typography>
                        </TableCell>

                        <TableCell align="right">
                          <Typography
                            variant="body2"
                            sx={{ color: "text.secondary" }}
                          >
                            {formatPreviewDate(preview.createdAt)}
                          </Typography>
                        </TableCell>
                      </TableRow>

                      <TableRow>
                        <TableCell
                          colSpan={4}
                          sx={{
                            p: 0,
                            borderBottom: isExpanded ? "1px solid" : 0,
                            borderColor: "divider",
                          }}
                        >
                          <Collapse
                            in={isExpanded}
                            timeout="auto"
                            unmountOnExit
                          >
                            <Box
                              sx={{
                                p: { xs: 2, md: 3 },
                                bgcolor: "#f4f7fb",
                              }}
                            >
                              <Paper
                                elevation={0}
                                sx={{
                                  border: "1px solid",
                                  borderColor: "divider",
                                  borderRadius: 3,
                                  overflow: "hidden",
                                  bgcolor: "background.paper",
                                }}
                              >
                                <Box sx={{ p: 2 }}>
                                  <Typography
                                    variant="h6"
                                    sx={{ fontWeight: 800 }}
                                  >
                                    {preview.subject}
                                  </Typography>

                                  <Typography
                                    variant="body2"
                                    sx={{ color: "text.secondary", mt: 0.5 }}
                                  >
                                    From: {preview.fromName} &lt;
                                    {preview.fromEmail}&gt;
                                  </Typography>

                                  <Typography
                                    variant="body2"
                                    sx={{ color: "text.secondary" }}
                                  >
                                    To: {preview.toEmail}
                                  </Typography>

                                  <Typography
                                    variant="body2"
                                    sx={{ color: "text.secondary" }}
                                  >
                                    Date: {formatPreviewDate(preview.createdAt)}
                                  </Typography>
                                </Box>

                                <Divider />

                                <Box
                                  component="iframe"
                                  title={`${preview.subject} email preview`}
                                  srcDoc={preview.html}
                                  sx={{
                                    display: "block",
                                    width: "100%",
                                    minHeight: { xs: 760, md: 900 },
                                    border: 0,
                                    bgcolor: "white",
                                  }}
                                />
                              </Paper>
                            </Box>
                          </Collapse>
                        </TableCell>
                      </TableRow>
                    </Fragment>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Stack>
    </Box>
  );
}
