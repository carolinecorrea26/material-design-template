import type { ApplicationFormValues } from "../state/ApplicationFormContext";
import { getActiveClient } from "../client/getActiveClient";

type MockEmailType =
  | "autosave"
  | "receipt"
  | "resume-magic-link"
  | "pending-reminder"
  | "purge-reminder"
  | "advisor-sent-for-signature"
  | "advisor-pending-reminder"
  | "advisor-edit-request"
  | "advisor-application-complete";

export type MockEmailPreview = {
  id: string;
  type: MockEmailType;
  fromName: string;
  fromEmail: string;
  toEmail: string;
  subject: string;
  createdAt: string;
  html: string;
};

export type MockEmailAudience = "applicant" | "advisor";

const MOCK_EMAIL_PREVIEWS_KEY = "mockEmail:previews";
const MOCK_EMAIL_PREVIEWS_CHANGED_EVENT = "mockEmail:previewsChanged";
const MOCK_APPLICANT_FIRST_NAME = "Taylor";
const MOCK_APPLICANT_LAST_NAME = "Morgan";
const MOCK_APPLICANT_EMAIL = "returning.user@example.com";
const MOCK_ADVISOR_EMAIL = "advisor@example.com";
const MOCK_FROM_EMAIL = "gmad_tpa_portal@ntlab.newyorklife.com";

function getStringValue(values: ApplicationFormValues, fieldId: string) {
  const value = values[fieldId];
  return typeof value === "string" ? value.trim() : "";
}

function escapeHtml(value: string) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function formatMockDate(date: Date) {
  return new Intl.DateTimeFormat("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  }).format(date);
}

function formatMockDateTime(date: Date) {
  return new Intl.DateTimeFormat("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

function addDays(date: Date, days: number) {
  const nextDate = new Date(date);
  nextDate.setDate(nextDate.getDate() + days);
  return nextDate;
}

function getDisplayName(firstName: string, lastName: string) {
  return [firstName, lastName].filter(Boolean).join(" ").trim() || "Applicant";
}

function getClientEmailPayload() {
  const client = getActiveClient();

  return {
    associationName: client.branding.name,
    tpaName: client.branding.name,
    tpaPhone: client.support.phoneDisplay || client.support.phone || "",
    tpaEmail: client.support.email || "",
    startUrl: `https://${
      client.support.website ||
      "redesignv2--material-design-template.netlify.app"
    }`,
    resumeUrl:
      "https://redesignv2--material-design-template.netlify.app/resume",
    resumeMagicLinkUrl:
      "https://redesignv2--material-design-template.netlify.app/resume?resumeFlow=code",
  };
}

function getApplicationEmailPayload(values: ApplicationFormValues) {
  return {
    ...getClientEmailPayload(),
    toEmail: getStringValue(values, "email"),
    firstName: getStringValue(values, "first-name"),
    lastName: getStringValue(values, "last-name"),
  };
}

function hasRecipientEmail(values: ApplicationFormValues) {
  return Boolean(getStringValue(values, "email"));
}

function getStoredMockEmails(): MockEmailPreview[] {
  try {
    const rawValue = window.localStorage.getItem(MOCK_EMAIL_PREVIEWS_KEY);
    if (!rawValue) return [];

    const parsedValue = JSON.parse(rawValue);
    return Array.isArray(parsedValue) ? parsedValue : [];
  } catch {
    return [];
  }
}

function notifyMockEmailPreviewsChanged() {
  window.dispatchEvent(new Event(MOCK_EMAIL_PREVIEWS_CHANGED_EVENT));
}

function saveMockEmailPreview(emailPreview: MockEmailPreview) {
  const existingPreviews = getStoredMockEmails();

  const nextPreviews = [
    emailPreview,
    ...existingPreviews.filter((preview) => preview.id !== emailPreview.id),
  ];

  window.localStorage.setItem(
    MOCK_EMAIL_PREVIEWS_KEY,
    JSON.stringify(nextPreviews),
  );

  notifyMockEmailPreviewsChanged();
}

function getBaseEmailHtml(options: { title: string; bodyHtml: string }) {
  const client = getActiveClient();

  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>${escapeHtml(options.title)}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
  </head>

  <body style="margin:0; padding:0; background-color:#eef2f7; font-family:Arial, Helvetica, sans-serif; color:#111827;">
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color:#eef2f7; margin:0; padding:28px 12px;">
      <tr>
        <td align="center">
          <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:600px; background-color:#ffffff; border-radius:28px; overflow:hidden;">
            <tr>
              <td style="padding:24px 24px 16px;">
                <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="left" style="vertical-align:top;">
                      <img src="/logo.svg" alt="New York Life" width="48" style="display:block; width:48px; max-width:48px; height:auto; border:0; outline:none; text-decoration:none; border-radius:2px;" />
                    </td>
                    <td align="right" style="vertical-align:top;">
                      <img src="${escapeHtml(client.branding.logo)}" alt="${escapeHtml(client.branding.logoAlt)}" width="170" style="display:block; width:170px; max-width:170px; height:auto; border:0; outline:none; text-decoration:none;" />
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <tr>
              <td style="padding:16px 24px 0; color:#111827; font-size:16px; line-height:1.55;">
                ${options.bodyHtml}
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>`;
}

function getButtonHtml(label: string, href: string) {
  return `<table role="presentation" cellspacing="0" cellpadding="0" style="margin:28px 0;">
    <tr>
      <td align="center" style="border-radius:999px; background-color:#006fff;">
        <a href="${escapeHtml(href)}" style="display:inline-block; padding:17px 28px; color:#ffffff; font-size:16px; line-height:1; font-weight:700; text-decoration:none; border-radius:999px;">
          ${escapeHtml(label)}
        </a>
      </td>
    </tr>
  </table>`;
}

function getTelHref(phone: string) {
  return phone.replace(/\D/g, "");
}

function getSupportHtml(tpaName: string, tpaPhone: string, tpaEmail: string) {
  const phoneHref = getTelHref(tpaPhone);

  return `<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:28px 0 0; background-color:#eef5ff; border:1px solid #006fff; border-radius:16px;">
    <tr>
      <td style="padding:22px 22px 20px; color:#12233d;">
        <p style="margin:0 0 18px; color:#071b3a; font-size:21px; line-height:1.25; font-weight:700;">
          Questions? We’re here to help.
        </p>

        <p style="margin:0 0 14px; color:#12233d; font-size:16px; line-height:1.45; font-weight:400;">
          ${escapeHtml(tpaName)} Insurance Administrator
        </p>

        <p style="margin:0 0 12px; color:#12233d; font-size:16px; line-height:1.45; font-weight:700;">
          Call:
          <a href="tel:${escapeHtml(phoneHref)}" style="color:#006fff; font-weight:700; text-decoration:none;">
            ${escapeHtml(tpaPhone)}
          </a>
        </p>

        <p style="margin:0; color:#12233d; font-size:16px; line-height:1.45; font-weight:700;">
          Email:
          <a href="mailto:${escapeHtml(tpaEmail)}" style="color:#006fff; font-weight:700; text-decoration:none;">
            ${escapeHtml(tpaEmail)}
          </a>
        </p>
      </td>
    </tr>
  </table>`;
}

function getNoticeHtml(title: string, body: string) {
  return `<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:20px 0 0; background-color:#fff7e8; border:1px solid #ff8a00; border-radius:16px;">
    <tr>
      <td style="padding:20px 20px 22px; color:#7a2e0c;">
        <p style="margin:0 0 12px; color:#7a2e0c; font-size:14px; line-height:1.3; font-weight:700; letter-spacing:0.04em; text-transform:uppercase;">
          Important Notice
        </p>
        <p style="margin:0 0 14px; color:#7a2e0c; font-size:21px; line-height:1.3; font-weight:700;">
          ${title}
        </p>
        <p style="margin:0; color:#7a2e0c; font-size:16px; line-height:1.55;">
          ${body}
        </p>
      </td>
    </tr>
  </table>`;
}

function getSuccessNoticeHtml(title: string, body: string) {
  return `<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:20px 0 0; background-color:#ecfdf5; border:1px solid #10b981; border-radius:16px;">
    <tr>
      <td style="padding:20px 20px 22px; color:#064e3b;">
        <p style="margin:0 0 12px; color:#065f46; font-size:14px; line-height:1.3; font-weight:700; letter-spacing:0.04em; text-transform:uppercase;">
          ${title}
        </p>
        <p style="margin:0; color:#064e3b; font-size:16px; line-height:1.55; font-weight:700;">
          ${body}
        </p>
      </td>
    </tr>
  </table>`;
}

function getNoReplyHtml() {
  return `<div style="margin:24px 0 0; border-top:1px solid #d1d5db; padding-top:18px;">
    <p style="margin:0; color:#111827; font-size:16px; line-height:1.45; font-weight:700;">
      Please note: This is an automated message. Replies to this email are not monitored and will not be read.
    </p>
  </div>`;
}

function getAdvisorStatusIconSvg(statusLabel: string) {
  const isComplete = statusLabel === "Submitted";
  const color = isComplete ? "#2e7d32" : "#0768ff";

  if (statusLabel === "Submitted") {
    return `<svg aria-hidden="true" viewBox="0 0 24 24" width="22" height="22" style="display:block; fill:${color}; flex:0 0 auto;">
      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1.41 14.59L6.35 12.35l1.41-1.41 2.83 2.83 5.66-5.66 1.41 1.41-7.07 7.07z"></path>
    </svg>`;
  }

  if (statusLabel === "Sent for signature") {
    return `<svg aria-hidden="true" viewBox="0 0 24 24" width="22" height="22" style="display:block; fill:${color}; flex:0 0 auto;">
      <path d="M14.06 9.02 15 9.96 6.92 18H6v-.92l8.06-8.06M17.66 3c-.26 0-.51.1-.71.29l-1.83 1.83 3.75 3.75 1.83-1.83c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.19-.19-.45-.29-.7-.29zm-3.6 3.19L4 16.25V20h3.75L17.81 9.94l-3.75-3.75zM20 20H4v2h16v-2z"></path>
    </svg>`;
  }

  if (statusLabel === "Edit requested") {
    return `<svg aria-hidden="true" viewBox="0 0 24 24" width="22" height="22" style="display:block; fill:${color}; flex:0 0 auto;">
      <path d="M14.06 9.02l.92.92L5.92 19H5v-.92l9.06-9.06M17.66 3c-.25 0-.51.1-.7.29l-1.83 1.83 3.75 3.75 1.83-1.83c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.2-.2-.45-.29-.71-.29zm-3.6 3.19L3 17.25V21h3.75L17.81 9.94l-3.75-3.75z"></path>
    </svg>`;
  }

  return `<svg aria-hidden="true" viewBox="0 0 24 24" width="22" height="22" style="display:block; fill:${color}; flex:0 0 auto;">
    <path d="M6 2v6h.01L6 8.01 10 12l-4 3.99.01.01H6v6h12v-5.99h-.01L18 16l-4-4 4-3.99-.01-.01H18V2H6zm10 18H8v-3.17l4-4 4 4V20zm-4-8.83l-4-4V4h8v3.17l-4 4z"></path>
  </svg>`;
}

function buildAutosaveEmailHtml(
  payload: ReturnType<typeof getApplicationEmailPayload>,
) {
  const fullName = escapeHtml(
    getDisplayName(payload.firstName, payload.lastName),
  );

  return getBaseEmailHtml({
    title: "Your application has been saved",
    bodyHtml: `
      <p style="margin:0 0 24px; font-size:16px; line-height:1.55;">
        Dear ${fullName},
      </p>

      <p style="margin:0 0 20px; font-size:16px; line-height:1.55;">
        Your insurance application through <strong>${escapeHtml(
          payload.associationName,
        )}</strong> has been automatically saved so you don’t lose your progress.
      </p>

      <p style="margin:0 0 28px; font-size:16px; line-height:1.55;">
        You can return to complete your application within the next <strong>10 calendar days.</strong>
      </p>

      ${getButtonHtml("Continue my application", payload.resumeUrl)}

      <p style="margin:0 0 10px; color:#374151; font-size:15px; line-height:1.5;">
        Or copy and paste the following link into your browser:
      </p>

      <p style="margin:0 0 28px; font-size:15px; line-height:1.5; color:#006fff; word-break:break-all;">
        <a href="${escapeHtml(payload.resumeUrl)}" style="color:#006fff; text-decoration:none;">
          ${escapeHtml(payload.resumeUrl)}
        </a>
      </p>

      <p style="margin:0; font-size:16px; line-height:1.55;">
        We look forward to serving your insurance needs.
      </p>

      ${getSupportHtml(payload.tpaName, payload.tpaPhone, payload.tpaEmail)}
      ${getNoticeHtml(
        "Your application will be saved for 10 days.",
        "If you do not complete within 10 calendar days, you will need to start a new application. This is for your security.",
      )}
      ${getNoReplyHtml()}
    `,
  });
}

function buildReceiptEmailHtml(
  payload: ReturnType<typeof getApplicationEmailPayload>,
  confirmationNumber: string,
) {
  const fullName = escapeHtml(
    getDisplayName(payload.firstName, payload.lastName),
  );

  return getBaseEmailHtml({
    title: "We received your application",
    bodyHtml: `
      <p style="margin:0 0 16px; font-size:15px; line-height:1.6;">
        Dear ${fullName},
      </p>

      <p style="margin:0 0 18px; font-size:15px; line-height:1.6;">
        Thank you. Your insurance application through <strong>${escapeHtml(
          payload.associationName,
        )}</strong> has been submitted.
      </p>

      <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:20px 0; background-color:#ecfdf5; border:2px solid #10b981; border-radius:14px;">
        <tr>
          <td style="padding:18px 20px;">
            <p style="margin:0 0 8px; color:#065f46; font-size:13px; font-weight:700; text-transform:uppercase; letter-spacing:0.04em;">
              Submitted Successfully
            </p>
            <p style="margin:0; color:#064e3b; font-size:16px; line-height:1.5; font-weight:700;">
              Confirmation number: ${escapeHtml(confirmationNumber)}
            </p>
          </td>
        </tr>
      </table>

      <h2 style="margin:24px 0 10px; font-size:18px; line-height:1.3; color:#111827;">
        What happens next
      </h2>

      <p style="margin:0 0 12px; font-size:15px; line-height:1.6;">
        New York Life will review your application and provide a decision after all required information has been received and reviewed.
      </p>

      <p style="margin:0 0 12px; font-size:15px; line-height:1.6;">
        If additional information is needed, a representative from New York Life, ${escapeHtml(
          payload.tpaName,
        )}, or a medical service provider may contact you.
      </p>

      <p style="margin:0 0 20px; font-size:15px; line-height:1.6;">
        If your application is approved, you will receive details about your new coverage.
      </p>

      ${getSupportHtml(payload.tpaName, payload.tpaPhone, payload.tpaEmail)}

      <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:24px 0 0; background-color:#fff4e5; border:1px solid #f59e0b; border-radius:14px;">
        <tr>
          <td style="padding:16px 20px;">
            <p style="margin:0; font-size:13px; line-height:1.6; color:#78350f;">
              <strong>Important:</strong> Do not reply to this email. This is an automated message, and replies are not monitored or read. For help, please call <strong>${escapeHtml(
                payload.tpaPhone,
              )}</strong> or email <strong>${escapeHtml(payload.tpaEmail)}</strong>.
            </p>
          </td>
        </tr>
      </table>

      <p style="margin:24px 0 0; font-size:15px; line-height:1.6;">
        We look forward to serving your insurance needs.
      </p>

      <p style="margin:18px 0 0; font-size:15px; line-height:1.5; font-weight:700;">
        ${escapeHtml(payload.tpaName)} Insurance Administrator
      </p>
    `,
  });
}

function buildResumeMagicLinkEmailHtml(emailAddress: string) {
  const payload = getClientEmailPayload();

  return getBaseEmailHtml({
    title: "Continue your saved application",
    bodyHtml: `
      <p style="margin:0 0 18px; font-size:15px; line-height:1.6;">
        A request has been made to return to an insurance application in progress through <strong>${escapeHtml(
          payload.associationName,
        )}</strong>.
      </p>

      ${getButtonHtml("Verify my email", payload.resumeMagicLinkUrl)}

      <p style="margin:0 0 8px; font-size:13px; line-height:1.6; color:#4b5563;">
        Or copy and paste this link into your browser:
      </p>

      <p style="margin:0 0 20px; font-size:13px; line-height:1.6; color:#0668ff; word-break:break-all;">
        ${escapeHtml(payload.resumeMagicLinkUrl)}
      </p>

      <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:20px 0; background-color:#fff4e5; border:2px solid #f59e0b; border-radius:14px;">
        <tr>
          <td style="padding:18px 20px;">
            <p style="margin:0 0 8px; color:#92400e; font-size:13px; font-weight:700; text-transform:uppercase; letter-spacing:0.04em;">
              Link expires in 10 minutes
            </p>
            <p style="margin:0; color:#78350f; font-size:15px; line-height:1.5;">
              For your security, this secure resume link will expire 10 minutes after it is sent.
            </p>
          </td>
        </tr>
      </table>

      <p style="margin:0 0 8px; font-size:15px; line-height:1.6; font-weight:700;">
        Didn’t request a link?
      </p>

      <p style="margin:0 0 20px; font-size:15px; line-height:1.6;">
        If you did not request a link, you may ignore this message. Access to application information will only be granted with verification.
      </p>

      <p style="margin:0; font-size:12px; line-height:1.6; color:#6b7280;">
        This mock email was generated for ${escapeHtml(emailAddress)}.
      </p>

      ${getNoReplyHtml()}
    `,
  });
}

function buildPendingReminderEmailHtml() {
  const payload = getClientEmailPayload();
  const startDate = new Date();
  const purgeDate = addDays(startDate, 9);

  return getBaseEmailHtml({
    title: "Your application is still pending",
    bodyHtml: `
      <p style="margin:0 0 16px; font-size:15px; line-height:1.6;">
        Dear ${escapeHtml(MOCK_APPLICANT_FIRST_NAME)},
      </p>

      <p style="margin:0 0 18px; font-size:15px; line-height:1.6;">
        We noticed you haven’t finished your <strong>${escapeHtml(
          payload.associationName,
        )}</strong> insurance application. Good news—your progress has been saved.
      </p>

      ${getButtonHtml("Complete my application", payload.resumeUrl)}

      <p style="margin:0 0 8px; font-size:13px; line-height:1.6; color:#4b5563;">
        Or copy and paste this website address into your browser:
      </p>

      <p style="margin:0 0 20px; font-size:13px; line-height:1.6; color:#0668ff; word-break:break-all;">
        ${escapeHtml(payload.startUrl)}
      </p>

      <p style="margin:0 0 18px; font-size:15px; line-height:1.6;">
        To access your application information, you will be asked to verify your identity using the email and phone number provided.
      </p>

      <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:20px 0; background-color:#fff4e5; border:2px solid #f59e0b; border-radius:14px;">
        <tr>
          <td style="padding:18px 20px;">
            <p style="margin:0 0 8px; color:#92400e; font-size:13px; font-weight:700; text-transform:uppercase; letter-spacing:0.04em;">
              Saved application deletion date
            </p>
            <p style="margin:0; color:#78350f; font-size:15px; line-height:1.5;">
              For your security, your saved application will be deleted on <strong>${formatMockDate(
                purgeDate,
              )}</strong> — 10 days from when you started. After that, you’ll need to begin a new application.
            </p>
          </td>
        </tr>
      </table>

      <p style="margin:0 0 24px; font-size:15px; line-height:1.6;">
        We look forward to serving your insurance needs.
      </p>

      <p style="margin:0 0 4px; font-size:15px; line-height:1.5; font-weight:700;">
        ${escapeHtml(payload.tpaName)} Insurance Administrator
      </p>

      ${getSupportHtml(payload.tpaName, payload.tpaPhone, payload.tpaEmail)}
      ${getNoReplyHtml()}
    `,
  });
}

function buildPurgeReminderEmailHtml() {
  const payload = getClientEmailPayload();

  return getBaseEmailHtml({
    title: "Your application request has expired",
    bodyHtml: `
      <p style="margin:0 0 16px; font-size:15px; line-height:1.6;">
        Dear ${escapeHtml(MOCK_APPLICANT_FIRST_NAME)},
      </p>

      <p style="margin:0 0 18px; font-size:15px; line-height:1.6;">
        Your insurance application through <strong>${escapeHtml(
          payload.associationName,
        )}</strong> has expired and has been securely deleted in accordance with our data retention policy. Application data is saved for you for 10 days to complete until it is deleted.
      </p>

      <p style="margin:0 0 18px; font-size:15px; line-height:1.6;">
        If you’d still like to apply, you can start a new application.
      </p>

      ${getButtonHtml("Start my application", payload.startUrl)}

      <p style="margin:0 0 8px; font-size:13px; line-height:1.6; color:#4b5563;">
        Or copy and paste this website address into your browser:
      </p>

      <p style="margin:0 0 20px; font-size:13px; line-height:1.6; color:#0668ff; word-break:break-all;">
        ${escapeHtml(payload.startUrl)}
      </p>

      <p style="margin:0 0 20px; font-size:15px; line-height:1.6;">
        If you have questions about your insurance options, we’re happy to help and provide additional information.
      </p>

      <p style="margin:0 0 24px; font-size:15px; line-height:1.6;">
        We look forward to serving your insurance needs.
      </p>

      <p style="margin:0 0 4px; font-size:15px; line-height:1.5; font-weight:700;">
        ${escapeHtml(payload.tpaName)} Insurance Administrator
      </p>

      ${getSupportHtml(payload.tpaName, payload.tpaPhone, payload.tpaEmail)}
      ${getNoReplyHtml()}
    `,
  });
}

function buildAdvisorEmailHtml(options: {
  title: string;
  message: string;
  statusLabel: string;
  includeEditRequested?: boolean;
  includeSubmissionDate?: boolean;
}) {
  const today = new Date();
  const sentDate = addDays(today, -3);
  const purgeDate = addDays(sentDate, 9);
  const editRequestDate = addDays(today, -1);

  const details = [
    [
      "Applicant name",
      `${MOCK_APPLICANT_FIRST_NAME} ${MOCK_APPLICANT_LAST_NAME}`,
    ],
    ["Applicant email", MOCK_APPLICANT_EMAIL],
    ["Sent for signature", formatMockDateTime(sentDate)],
    ...(options.includeSubmissionDate
      ? [["Submitted", formatMockDateTime(today)]]
      : [["Scheduled for deletion", formatMockDateTime(purgeDate)]]),
    ...(options.includeEditRequested
      ? [["Edit requested", formatMockDateTime(editRequestDate)]]
      : []),
  ];

  const detailRows = details
    .map(
      ([label, value]) => `<tr>
        <td style="padding:12px 14px; border-bottom:1px solid #e5e7eb; color:#4b5563; font-size:13px; font-weight:700; width:38%;">
          ${escapeHtml(label)}
        </td>
        <td style="padding:12px 14px; border-bottom:1px solid #e5e7eb; color:#111827; font-size:13px;">
          ${escapeHtml(value)}
        </td>
      </tr>`,
    )
    .join("");

  return getBaseEmailHtml({
    title: options.title,
    bodyHtml: `
      <p style="margin:0 0 18px; font-size:15px; line-height:1.6;">
        ${escapeHtml(options.message)}
      </p>

      <p style="margin:0 0 14px; font-size:15px; line-height:1.6;">
        See application details below:
      </p>

      <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="border:1px solid #d1d5db; border-radius:14px; overflow:hidden;">
        <tr>
          <td colspan="2" style="padding:12px 14px; background-color:#f5f5f5; color:#111827; font-size:14px; font-weight:700; border-bottom:1px solid #d1d5db;">
            <span style="display:inline-flex; align-items:center; gap:8px;">
              ${getAdvisorStatusIconSvg(options.statusLabel)}
              <span>${escapeHtml(options.statusLabel)}</span>
            </span>
          </td>
        </tr>
        ${detailRows}
      </table>

      ${getNoReplyHtml()}
    `,
  });
}

function getAlwaysVisibleMockEmails(): MockEmailPreview[] {
  const payload = getClientEmailPayload();
  const now = new Date().toISOString();

  return [
    {
      id: "pending-reminder",
      type: "pending-reminder",
      fromName: `${payload.tpaName} Insurance Administrator`,
      fromEmail: MOCK_FROM_EMAIL,
      toEmail: MOCK_APPLICANT_EMAIL,
      subject:
        "[DO NOT REPLY] Your insurance application request is still pending",
      createdAt: now,
      html: buildPendingReminderEmailHtml(),
    },
    {
      id: "purge-reminder",
      type: "purge-reminder",
      fromName: `${payload.tpaName} Insurance Administrator`,
      fromEmail: MOCK_FROM_EMAIL,
      toEmail: MOCK_APPLICANT_EMAIL,
      subject: "[DO NOT REPLY] Your insurance application request has expired",
      createdAt: now,
      html: buildPurgeReminderEmailHtml(),
    },
    {
      id: "advisor-sent-for-signature",
      type: "advisor-sent-for-signature",
      fromName: `${payload.tpaName} Advisor Notifications`,
      fromEmail: MOCK_FROM_EMAIL,
      toEmail: MOCK_ADVISOR_EMAIL,
      subject: "[DO NOT REPLY] Application sent for signature",
      createdAt: now,
      html: buildAdvisorEmailHtml({
        title: "Application sent for signature",
        message:
          "Application has been sent to applicant for review and signature.",
        statusLabel: "Sent for signature",
      }),
    },
    {
      id: "advisor-pending-reminder",
      type: "advisor-pending-reminder",
      fromName: `${payload.tpaName} Advisor Notifications`,
      fromEmail: MOCK_FROM_EMAIL,
      toEmail: MOCK_ADVISOR_EMAIL,
      subject: "[DO NOT REPLY] Application still waiting for signature",
      createdAt: now,
      html: buildAdvisorEmailHtml({
        title: "Application still waiting for signature",
        message: "This application is still waiting for signature.",
        statusLabel: "Waiting for signature",
      }),
    },
    {
      id: "advisor-edit-request",
      type: "advisor-edit-request",
      fromName: `${payload.tpaName} Advisor Notifications`,
      fromEmail: MOCK_FROM_EMAIL,
      toEmail: MOCK_ADVISOR_EMAIL,
      subject: "[DO NOT REPLY] Application edit request",
      createdAt: now,
      html: buildAdvisorEmailHtml({
        title: "Application edit request",
        message: "This application has an edit request.",
        statusLabel: "Edit requested",
        includeEditRequested: true,
      }),
    },
    {
      id: "advisor-application-complete",
      type: "advisor-application-complete",
      fromName: `${payload.tpaName} Advisor Notifications`,
      fromEmail: MOCK_FROM_EMAIL,
      toEmail: MOCK_ADVISOR_EMAIL,
      subject: "[DO NOT REPLY] Application has been signed",
      createdAt: now,
      html: buildAdvisorEmailHtml({
        title: "Application has been signed",
        message: "This application has been signed.",
        statusLabel: "Submitted",
        includeSubmissionDate: true,
      }),
    },
  ];
}

export function readMockEmailPreviews() {
  const storedPreviews = getStoredMockEmails();
  const alwaysVisiblePreviews = getAlwaysVisibleMockEmails();

  return [
    ...storedPreviews,
    ...alwaysVisiblePreviews.filter(
      (alwaysVisiblePreview) =>
        !storedPreviews.some(
          (storedPreview) => storedPreview.id === alwaysVisiblePreview.id,
        ),
    ),
  ];
}

export function getMockEmailAudience(
  preview: MockEmailPreview,
): MockEmailAudience {
  return preview.type.startsWith("advisor-") ? "advisor" : "applicant";
}

export function subscribeToMockEmailPreviews(onStoreChange: () => void) {
  function handleStorage(event: StorageEvent) {
    if (event.key === MOCK_EMAIL_PREVIEWS_KEY) {
      onStoreChange();
    }
  }

  window.addEventListener(MOCK_EMAIL_PREVIEWS_CHANGED_EVENT, onStoreChange);
  window.addEventListener("storage", handleStorage);

  return () => {
    window.removeEventListener(
      MOCK_EMAIL_PREVIEWS_CHANGED_EVENT,
      onStoreChange,
    );
    window.removeEventListener("storage", handleStorage);
  };
}

export function clearMockEmailPreviews() {
  window.localStorage.removeItem(MOCK_EMAIL_PREVIEWS_KEY);
  notifyMockEmailPreviewsChanged();
}

export async function sendAutosaveMockEmail(values: ApplicationFormValues) {
  if (!hasRecipientEmail(values)) return;

  const payload = getApplicationEmailPayload(values);

  saveMockEmailPreview({
    id: "autosave",
    type: "autosave",
    fromName: `${payload.tpaName} Insurance Administrator`,
    fromEmail: MOCK_FROM_EMAIL,
    toEmail: payload.toEmail,
    subject: "[DO NOT REPLY] Your saved application for insurance",
    createdAt: new Date().toISOString(),
    html: buildAutosaveEmailHtml(payload),
  });
}

export async function sendReceiptMockEmail(
  values: ApplicationFormValues,
  confirmationNumber: string,
) {
  if (!hasRecipientEmail(values)) return;

  const payload = getApplicationEmailPayload(values);

  saveMockEmailPreview({
    id: "receipt",
    type: "receipt",
    fromName: `${payload.tpaName} Insurance Administrator`,
    fromEmail: MOCK_FROM_EMAIL,
    toEmail: payload.toEmail,
    subject: "[DO NOT REPLY] Your insurance application has been submitted",
    createdAt: new Date().toISOString(),
    html: buildReceiptEmailHtml(payload, confirmationNumber),
  });
}

export async function sendResumeMagicLinkMockEmail(emailAddress: string) {
  const trimmedEmailAddress = emailAddress.trim();
  if (!trimmedEmailAddress) return;

  const payload = getClientEmailPayload();

  saveMockEmailPreview({
    id: "resume-magic-link",
    type: "resume-magic-link",
    fromName: `${payload.tpaName} Insurance Administrator`,
    fromEmail: MOCK_FROM_EMAIL,
    toEmail: trimmedEmailAddress,
    subject:
      "[DO NOT REPLY] Your secure link to continue your saved insurance application",
    createdAt: new Date().toISOString(),
    html: buildResumeMagicLinkEmailHtml(trimmedEmailAddress),
  });
}
