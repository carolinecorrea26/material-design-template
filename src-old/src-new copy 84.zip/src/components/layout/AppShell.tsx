import { useState, type ReactNode } from "react";
import { Box } from "@mui/material";
import { useLocation } from "react-router-dom";
import { getActiveClient } from "../../client/getActiveClient";
import CookieBanner from "../common/CookieBanner";
import DevTools from "../../dev/DevTools";
import AppHeader, { ApplicationIntro } from "./AppHeader";
import AppBody from "./AppBody";
import AppFooter from "./AppFooter";
import { pages } from "../../config/pages";
import type { PageId } from "../../types/page";

type AppShellProps = {
  children: ReactNode;
};

export default function AppShell({ children }: AppShellProps) {
  const client = getActiveClient();
  const location = useLocation();

  const [showCookieBanner, setShowCookieBanner] = useState(() => {
    return localStorage.getItem("cookieConsent") !== "accepted";
  });

  function handleCloseCookieBanner() {
    localStorage.setItem("cookieConsent", "accepted");
    setShowCookieBanner(false);
  }

  const normalizedPath =
    location.pathname.length > 1 && location.pathname.endsWith("/")
      ? location.pathname.slice(0, -1)
      : location.pathname;

  const currentPage = pages.find((page) => page.path === normalizedPath);
  const currentPageId = currentPage?.id as PageId | undefined;

  const showApplicationIntro = currentPageId === "membership";

  return (
    <Box
      sx={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        // backgroundColor: "#f9fafc",
        // pb: showCookieBanner ? "80px" : 0,
      }}
    >
      <AppHeader client={client} />

      {showApplicationIntro && (
        <Box sx={{ px: { xs: 2, sm: 3, md: 4 } }}>
          <ApplicationIntro client={client} />
        </Box>
      )}

      <AppBody>{children}</AppBody>
      <AppFooter client={client} />
      <DevTools />
      {showCookieBanner && <CookieBanner onClose={handleCloseCookieBanner} />}
    </Box>
  );
}
