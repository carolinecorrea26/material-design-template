// keep your existing page objects / ids / paths / groupIds exactly as they are

export const pages = [
  { id: "home", path: "/", type: "home", title: "Home", navTitle: "Home" },
  {
    id: "membership",
    path: "/membership",
    type: "form",
    title: "Let’s get started",
    subhead:
      "First, tell us how you are connected to the group so we can tailor the application to you.",
    navTitle: "Membership",
    groupId: "get-started",
  },
  {
    id: "eligibility",
    path: "/eligibility",
    type: "form",
    title: "Check your eligibility",
    subhead:
      "Answer a few questions so we can show the coverage options available for you and anyone applying with you.",
    navTitle: "Check eligibility",
    groupId: "get-started",
  },
  {
    id: "coverage",
    path: "/coverage",
    type: "form",
    title: "Choose coverage",
    subhead:
      "Review the available products and select the coverage amounts you want to include in your application.",
    navTitle: "Add coverage",
    groupId: "coverage",
  },
  {
    id: "coverage-questions",
    path: "/coverage-questions",
    type: "form",
    title: "Answer coverage questions",
    subhead:
      "These details help us calculate your personalized rate and confirm the options available to you.",
    navTitle: "Coverage questions",
    groupId: "coverage",
  },
  {
    id: "coverage-options",
    path: "/coverage-options",
    type: "form",
    title: "Review your coverage options",
    subhead:
      "Compare your personalized options, rates, and selections before moving forward.",
    navTitle: "Coverage options",
    groupId: "coverage",
  },
  {
    id: "beneficiary",
    path: "/beneficiary",
    type: "form",
    title: "Choose beneficiaries",
    subhead: "Tell us who should receive benefits if a claim is approved.",
    navTitle: "Beneficiary",
    groupId: "coverage",
  },
  {
    id: "contact",
    path: "/contact",
    type: "form",
    title: "Add contact details",
    subhead:
      "Provide the contact information we should use for updates about this application.",
    navTitle: "Contact",
    groupId: "profile",
  },
  {
    id: "personal",
    path: "/personal",
    type: "form",
    title: "Add personal information",
    subhead:
      "We need a few additional details to complete your application profile.",
    navTitle: "Personal information",
    groupId: "profile",
  },
  {
    id: "financial",
    path: "/financial",
    type: "form",
    title: "Add financial information",
    subhead:
      "Tell us about any existing coverage or financial details needed for review.",
    navTitle: "Financial information",
    groupId: "profile",
  },
  {
    id: "review",
    path: "/review",
    type: "form",
    title: "Review your application",
    subhead:
      "Check your information carefully before continuing to signature and submission.",
    navTitle: "Review",
    groupId: "review",
  },
  {
    id: "docusign",
    path: "/docusign",
    type: "form",
    title: "Review and sign",
    subhead:
      "Open your application documents, complete any required signatures, and continue when finished.",
    navTitle: "E-sign",
    groupId: "review",
  },
  {
    id: "health-si",
    path: "/health-si",
    type: "form",
    title: "Complete health questions",
    subhead:
      "Answer each question to the best of your ability so your application can be reviewed.",
    navTitle: "Health",
    groupId: "health",
  },
  {
    id: "health-qd",
    path: "/health-qd",
    type: "form",
    title: "Complete health questions",
    subhead:
      "Your answers may help determine whether a faster decision is available.",
    navTitle: "Health",
    groupId: "health",
  },
  {
    id: "health-di",
    path: "/health-di",
    type: "form",
    title: "Complete health questions",
    subhead:
      "Provide the health details needed to review your disability coverage application.",
    navTitle: "Health",
    groupId: "health",
  },
  {
    id: "health-cir",
    path: "/health-cir",
    type: "form",
    title: "Complete health questions",
    subhead:
      "Provide the health details needed to review your coverage application.",
    navTitle: "Health",
    groupId: "health",
  },
  {
    id: "payment",
    path: "/payment",
    type: "form",
    title: "Choose payment method",
    subhead:
      "Select how you would like to pay. You will not be billed until coverage is approved.",
    navTitle: "Payment",
    groupId: "payment",
  },
  {
    id: "receipt",
    path: "/receipt",
    type: "receipt",
    title: "Your application has been submitted.",
    subhead:
      "We’ll send confirmation and next steps to the contact information provided.",
    navTitle: "Receipt",
  },
  {
    id: "resume",
    path: "/resume",
    type: "resume",
    title: "Resume your application",
    subhead: "Enter your information to continue a saved application.",
    navTitle: "Resume application",
  },
  {
    id: "advisor-login",
    path: "/advisor-login",
    type: "form",
    title: "Advisor login",
    subhead:
      "Enter your advisor code to start or resume an application for a client.",
    navTitle: "Advisor login",
  },
  {
    id: "advisor-send-confirmation",
    path: "/advisor-send-confirmation",
    type: "form",
    title: "Application sent successfully",
    subhead:
      "The applicant can now review, sign, and submit their application.",
    navTitle: "Sent confirmation",
  },
  {
    id: "mock-email-preview",
    path: "/mock-email-preview",
    type: "receipt",
    title: "Mock Email Preview",
    navTitle: "Mock email preview",
  },
  {
    id: "information-architecture",
    path: "/information-architecture",
    type: "internal",
    title: "Information Architecture",
    navTitle: "Information architecture",
  },
] as const;

export type PageType = "home" | "form" | "receipt" | "resume" | "internal";

export function getPagePath(id: (typeof pages)[number]["id"]) {
  const page = pages.find((page) => page.id === id);

  if (!page) {
    throw new Error(`Missing page path for page id: ${id}`);
  }

  return page.path;
}

export function getPageTitle(id: (typeof pages)[number]["id"]) {
  const page = pages.find((page) => page.id === id);

  if (!page) {
    throw new Error(`Missing page title for page id: ${id}`);
  }

  return page.title;
}

export function getPageSubhead(id: (typeof pages)[number]["id"]) {
  const page = pages.find((page) => page.id === id);

  if (!page) {
    throw new Error(`Missing page subhead for page id: ${id}`);
  }

  return "subhead" in page ? page.subhead : undefined;
}

export function getPageNavTitle(id: (typeof pages)[number]["id"]) {
  const page = pages.find((page) => page.id === id);

  if (!page) {
    throw new Error(`Missing page nav title for page id: ${id}`);
  }

  return page.navTitle;
}
