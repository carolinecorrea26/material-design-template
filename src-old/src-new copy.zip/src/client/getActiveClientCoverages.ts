import { coverages } from "../config/coverages";
import { getActiveClient } from "./getActiveClient";

export function getActiveClientCoverages() {
  const client = getActiveClient();
  const enabledCoverageIds = new Set(client.coverages.enabled ?? []);
  const ranges = client.coverages.ranges ?? {};

  return coverages
    .filter((coverage) => enabledCoverageIds.has(coverage.id))
    .map((coverage) => {
      const range = ranges[coverage.id];

      if (!range) {
        return coverage;
      }

      return {
        ...coverage,
        minAmount: range.min,
        maxAmount: range.max,
      };
    });
}
