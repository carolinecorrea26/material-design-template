import {
  Controller,
  type Control,
  type FieldErrors,
  type UseFormRegister,
} from "react-hook-form";
import {
  Checkbox,
  FormControl,
  FormHelperText,
  FormLabel,
  MenuItem,
  Radio,
  Select,
  Stack,
  TextField,
  ToggleButton,
  ToggleButtonGroup,
  Typography,
} from "@mui/material";
import type { FieldDefinition } from "../../config/fields/types";
import SelectableOptionRow from "./SelectableOptionRow";

type FormValues = Record<string, string | boolean | string[]>;

type FieldRendererProps = {
  field: FieldDefinition;
  control: Control<FormValues>;
  register: UseFormRegister<FormValues>;
  errors: FieldErrors<FormValues>;
};

function getValidationRules(field: FieldDefinition) {
  const rules: {
    required?: string | { value: true; message: string };
    validate?: (value: unknown) => true | string;
  } = {};

  if (field.inputType === "checkbox") {
    if (field.required) {
      rules.validate = (value) => value === true || "This field is required.";
    }

    return rules;
  }

  if (field.inputType === "checkbox-group") {
    if (field.required) {
      rules.validate = (value) =>
        Array.isArray(value) && value.length > 0
          ? true
          : "Select at least one option.";
    }

    return rules;
  }

  if (field.required) {
    rules.required = "This field is required.";
  }

  if (field.format === "email") {
    rules.validate = (value) => {
      if (!value) return true;
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value))
        ? true
        : "Enter a valid email address.";
    };
  }

  if (field.format === "phone") {
    rules.validate = (value) => {
      if (!value) return true;
      const digits = String(value).replace(/\D/g, "");
      return digits.length === 10
        ? true
        : "Enter a valid 10-digit phone number.";
    };
  }

  return rules;
}

function formatPhone(value: string) {
  const digits = value.replace(/\D/g, "").slice(0, 10);

  if (digits.length <= 3) {
    return digits;
  }

  if (digits.length <= 6) {
    return `(${digits.slice(0, 3)}) ${digits.slice(3)}`;
  }

  return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6)}`;
}

const controlSx = {
  p: 0,
  color: "text.primary",
  "&.Mui-checked": {
    color: "primary.main",
  },
  "&:hover": {
    backgroundColor: "action.hover",
  },
  "&.Mui-checked:hover": {
    backgroundColor: "action.hover",
  },
};

export default function FieldRenderer({
  field,
  control,
  register,
  errors,
}: FieldRendererProps) {
  const validationRules = getValidationRules(field);

  if (field.inputType === "radio") {
    return (
      <Controller
        key={field.id}
        name={field.id}
        control={control}
        rules={validationRules}
        render={({ field: controllerField }) => (
          <FormControl
            fullWidth
            margin="normal"
            error={Boolean(errors[field.id])}
          >
            <FormLabel>{field.label}</FormLabel>

            <ToggleButtonGroup
              exclusive
              value={(controllerField.value as string) ?? ""}
              onChange={(_, value) => {
                if (value !== null) {
                  controllerField.onChange(value);
                }
              }}
              sx={{
                display: "flex",
                flexDirection: "column",
                gap: 1,
                mt: 1,
              }}
            >
              {(field.options ?? []).map((option) => (
                <ToggleButton
                  key={option.value}
                  value={option.value}
                  sx={{
                    width: "100%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "flex-start",
                    gap: 1.5,
                    py: 1.5,
                    textTransform: "none",
                  }}
                >
                  <Radio
                    checked={controllerField.value === option.value}
                    size="small"
                    sx={{ p: 0 }}
                  />
                  {option.label}
                </ToggleButton>
              ))}
            </ToggleButtonGroup>

            <FormHelperText>
              {errors[field.id]?.message as string}
            </FormHelperText>
          </FormControl>
        )}
      />
    );
  }

  if (field.inputType === "dropdown") {
    return (
      <Controller
        key={field.id}
        name={field.id}
        control={control}
        rules={validationRules}
        render={({ field: controllerField }) => (
          <FormControl
            fullWidth
            margin="normal"
            error={Boolean(errors[field.id])}
          >
            <FormLabel>{field.label}</FormLabel>
            <Select
              value={(controllerField.value as string) ?? ""}
              onChange={(event) => controllerField.onChange(event.target.value)}
              displayEmpty
            >
              <MenuItem value="">
                <em>{field.placeholder ?? "Select"}</em>
              </MenuItem>
              {(field.options ?? []).map((option) => (
                <MenuItem key={option.value} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </Select>
            <FormHelperText>
              {errors[field.id]?.message as string}
            </FormHelperText>
          </FormControl>
        )}
      />
    );
  }

  if (field.inputType === "checkbox") {
    return (
      <Controller
        key={field.id}
        name={field.id}
        control={control}
        rules={validationRules}
        render={({ field: controllerField }) => (
          <FormControl
            fullWidth
            margin="normal"
            error={Boolean(errors[field.id])}
          >
            <SelectableOptionRow>
              <Checkbox
                checked={Boolean(controllerField.value)}
                onChange={(event) =>
                  controllerField.onChange(event.target.checked)
                }
                sx={controlSx}
              />
              <Typography variant="body2">{field.label}</Typography>
            </SelectableOptionRow>

            <FormHelperText>
              {errors[field.id]?.message as string}
            </FormHelperText>
          </FormControl>
        )}
      />
    );
  }

  if (field.inputType === "checkbox-group") {
    return (
      <Controller
        key={field.id}
        name={field.id}
        control={control}
        rules={validationRules}
        render={({ field: controllerField }) => {
          const selectedValues = Array.isArray(controllerField.value)
            ? controllerField.value.map(String)
            : [];

          return (
            <FormControl
              fullWidth
              margin="normal"
              error={Boolean(errors[field.id])}
            >
              <FormLabel>{field.label}</FormLabel>

              <Stack spacing={1} sx={{ mt: 1 }}>
                {(field.options ?? []).map((option) => {
                  const checked = selectedValues.includes(option.value);

                  return (
                    <SelectableOptionRow key={option.value}>
                      <Checkbox
                        checked={checked}
                        onChange={(event) => {
                          const nextValues = event.target.checked
                            ? [...selectedValues, option.value]
                            : selectedValues.filter(
                                (value) => value !== option.value,
                              );

                          controllerField.onChange(nextValues);
                        }}
                        sx={controlSx}
                      />
                      <Typography variant="body2">{option.label}</Typography>
                    </SelectableOptionRow>
                  );
                })}
              </Stack>

              <FormHelperText>
                {errors[field.id]?.message as string}
              </FormHelperText>
            </FormControl>
          );
        }}
      />
    );
  }

  if (field.inputType === "date") {
    return (
      <TextField
        key={field.id}
        label={field.label}
        type="date"
        fullWidth
        margin="normal"
        placeholder={field.placeholder}
        autoComplete={field.autoComplete}
        InputLabelProps={{ shrink: true }}
        error={Boolean(errors[field.id])}
        helperText={errors[field.id]?.message as string}
        {...register(field.id, validationRules)}
      />
    );
  }

  const htmlInputType =
    field.format === "email"
      ? "email"
      : field.format === "phone"
        ? "tel"
        : "text";

  if (field.format === "phone") {
    return (
      <Controller
        key={field.id}
        name={field.id}
        control={control}
        rules={validationRules}
        render={({ field: controllerField }) => (
          <TextField
            label={field.label}
            type={htmlInputType}
            fullWidth
            margin="normal"
            placeholder={field.placeholder}
            autoComplete={field.autoComplete}
            inputProps={{ inputMode: field.inputMode }}
            value={(controllerField.value as string) ?? ""}
            onChange={(event) =>
              controllerField.onChange(formatPhone(event.target.value))
            }
            error={Boolean(errors[field.id])}
            helperText={errors[field.id]?.message as string}
          />
        )}
      />
    );
  }

  return (
    <TextField
      key={field.id}
      label={field.label}
      type={htmlInputType}
      fullWidth
      margin="normal"
      placeholder={field.placeholder}
      autoComplete={field.autoComplete}
      inputProps={{ inputMode: field.inputMode }}
      error={Boolean(errors[field.id])}
      helperText={errors[field.id]?.message as string}
      {...register(field.id, validationRules)}
    />
  );
}
