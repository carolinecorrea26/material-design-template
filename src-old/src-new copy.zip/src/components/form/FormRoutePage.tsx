import type { ReactNode } from "react";
import { Button, Typography } from "@mui/material";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import type { PageId } from "../../types/page";
import { getClientPageFields } from "../../config/clientFields/getClientPageFields";
import {
  getNextFormPageId,
  getPreviousFormPageId,
} from "../../config/formFlow";
import { getPageSections } from "../../config/pageSections";
import type { PageSectionConfig } from "../../config/pageSections/types";
import { useApplicationForm } from "../../state/ApplicationFormContext";
import FormPage from "./FormPage";
import FieldRenderer from "./FieldRenderer";
import ChildrenList from "./ChildrenList";

type FormRoutePageProps = {
  pageId: PageId;
  title: string;
  children?: ReactNode;
};

type FormRoutePageValues = Record<string, any>;

function isSectionVisible(
  section: PageSectionConfig,
  values: FormRoutePageValues,
): boolean {
  if (!section.visibleWhen) return true;

  return section.visibleWhen.every((rule) => {
    const value = values[rule.fieldId];
    if ("equals" in rule) return value === rule.equals;
    if ("notEquals" in rule) return value !== rule.notEquals;
    return true;
  });
}

export default function FormRoutePage({
  pageId,
  title,
  children,
}: FormRoutePageProps) {
  const navigate = useNavigate();
  const { values, setPageValues } = useApplicationForm();

  const initialFields = getClientPageFields(pageId, values);
  const defaultValues = initialFields.reduce<FormRoutePageValues>(
    (acc, field) => {
      acc[field.id] =
        values[field.id] ?? (field.inputType === "checkbox" ? false : "");
      return acc;
    },
    {},
  );

  const {
    control,
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<FormRoutePageValues>({
    defaultValues,
  });

  const watchedValues = watch();
  const allFields = getClientPageFields(pageId, watchedValues);
  const pageSections = getPageSections(pageId);

  function onSubmit(formValues: FormRoutePageValues) {
    setPageValues(formValues);

    const nextPageId = getNextFormPageId(pageId);

    if (nextPageId) {
      navigate(`/${nextPageId}`);
      return;
    }

    if (pageId === "payment") {
      navigate("/receipt");
    }
  }

  function handleBack() {
    const previousPageId = getPreviousFormPageId(pageId);

    if (previousPageId) {
      navigate(`/${previousPageId}`);
    }
  }

  return (
    <FormPage
      title={title}
      actions={
        <>
          <Button
            type="button"
            onClick={handleBack}
            disabled={!getPreviousFormPageId(pageId)}
          >
            Back
          </Button>
          <Button type="submit" form={`${pageId}-form`} variant="contained">
            Next
          </Button>
        </>
      }
    >
      <form id={`${pageId}-form`} onSubmit={handleSubmit(onSubmit)}>
        {pageSections.map((section) => {
          if (!isSectionVisible(section, watchedValues)) return null;

          return (
            <div key={section.id}>
              {section.title && (
                <Typography variant="h6" sx={{ mt: 2, mb: 1 }}>
                  {section.title}
                </Typography>
              )}
              {section.id === "childSection" ? (
                <ChildrenList control={control} />
              ) : (
                section.fieldIds.map((fieldId) => {
                  const field = allFields.find((f) => f.id === fieldId);
                  if (!field) return null;

                  return (
                    <FieldRenderer
                      key={field.id}
                      field={field}
                      control={control}
                      register={register}
                      errors={errors}
                    />
                  );
                })
              )}
            </div>
          );
        })}

        {children}
      </form>
    </FormPage>
  );
}
