import { useMemo, useState } from "react";
import { Button } from "@mui/material";
import { useNavigate } from "react-router-dom";
import CoverageCatalog from "../components/coverage/CoverageCatalog";
import FormPage from "../components/form/FormPage";
import { getActiveClientCoverages } from "../client/getActiveClientCoverages";
import { getNextFormPageId, getPreviousFormPageId } from "../config/formFlow";

export default function Coverage() {
  const navigate = useNavigate();
  const pageId = "coverage";
  const coverages = useMemo(() => getActiveClientCoverages(), []);
  const [selectedCoverageIds, setSelectedCoverageIds] = useState<string[]>([]);

  function handleBack() {
    const previousPageId = getPreviousFormPageId(pageId);

    if (previousPageId) {
      navigate(`/${previousPageId}`);
    }
  }

  function handleNext() {
    const nextPageId = getNextFormPageId(pageId);

    if (nextPageId) {
      navigate(`/${nextPageId}`);
    }
  }

  return (
    <FormPage
      title="Coverage"
      actions={
        <>
          <Button type="button" onClick={handleBack}>
            Back
          </Button>
          <Button type="button" onClick={handleNext} variant="contained">
            Next
          </Button>
        </>
      }
    >
      <CoverageCatalog
        coverages={coverages}
        selectedCoverageIds={selectedCoverageIds}
        onChangeSelectedCoverageIds={setSelectedCoverageIds}
      />
    </FormPage>
  );
}
