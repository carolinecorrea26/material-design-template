import { Alert, Button } from "@mui/material";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { getActiveClient } from "../client/getActiveClient";
import { getClientPageFields } from "../config/clientFields/getClientPageFields";
import { getNextFormPageId, getPreviousFormPageId } from "../config/formFlow";
import { useApplicationForm } from "../state/ApplicationFormContext";
import FormPage from "../components/form/FormPage";
import FieldRenderer from "../components/form/FieldRenderer";

type FormValues = Record<string, string | boolean | string[]>;
export default function Membership() {
  const navigate = useNavigate();
  const client = getActiveClient();
  const { values, setPageValues } = useApplicationForm();

  const pageId = "membership";
  const initialFields = getClientPageFields(pageId, values);
  const defaultValues = initialFields.reduce<FormValues>((acc, field) => {
    acc[field.id] =
      values[field.id] ?? (field.inputType === "checkbox" ? false : "");
    return acc;
  }, {});

  const {
    control,
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<FormValues>({
    defaultValues,
  });

  const watchedValues = watch();
  const allFields = getClientPageFields(pageId, watchedValues);

  const membershipField = allFields.find((field) => field.id === "membership");
  const remainingFields = allFields.filter(
    (field) => field.id !== "membership",
  );

  const membershipValue = watchedValues.membership;

  const showMembershipIneligibleAlert =
    client.id !== "ama" && client.id !== "waepa" && membershipValue === "no";

  const showMembershipFollowUpFields =
    client.id === "ama"
      ? Boolean(membershipValue)
      : client.id === "waepa"
        ? membershipValue === "current" || membershipValue === "new"
        : membershipValue === "yes";

  function onSubmit(formValues: FormValues) {
    setPageValues(formValues);

    const nextPageId = getNextFormPageId(pageId);

    if (nextPageId) {
      navigate(`/${nextPageId}`);
    }
  }

  function handleBack() {
    const previousPageId = getPreviousFormPageId(pageId);

    if (previousPageId) {
      navigate(`/${previousPageId}`);
    }
  }

  return (
    <FormPage
      title="Membership"
      actions={
        <>
          <Button
            type="button"
            onClick={handleBack}
            disabled={!getPreviousFormPageId(pageId)}
          >
            Back
          </Button>
          <Button type="submit" form={`${pageId}-form`} variant="contained">
            Next
          </Button>
        </>
      }
    >
      <form id={`${pageId}-form`} onSubmit={handleSubmit(onSubmit)}>
        {membershipField && (
          <FieldRenderer
            key={membershipField.id}
            field={membershipField}
            control={control}
            register={register}
            errors={errors}
          />
        )}

        {showMembershipIneligibleAlert && (
          <Alert severity="warning" sx={{ mt: 2 }}>
            You must be an active member to continue with this application.
          </Alert>
        )}

        {showMembershipFollowUpFields &&
          remainingFields.map((field) => (
            <FieldRenderer
              key={field.id}
              field={field}
              control={control}
              register={register}
              errors={errors}
            />
          ))}
      </form>
    </FormPage>
  );
}
