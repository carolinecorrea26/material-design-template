import type { PageId } from "../../types/page";
import type { FieldId } from "../fields/types";

export type PageSectionId =
  | "default"
  | "selfEligibility"
  | "dependentSelection"
  | "spouseSection"
  | "childSection"
  | "selfCoverageQuestions"
  | "spouseCoverageQuestions";

export type SectionVisibilityRule =
  | {
      fieldId: FieldId;
      equals: string | boolean | number;
    }
  | {
      fieldId: FieldId;
      notEquals: string | boolean | number;
    }
  | {
      fieldId: FieldId;
      includes: string;
    };

export type PageSectionConfig = {
  id: PageSectionId;
  pageId: PageId;
  title?: string;
  description?: string;
  fieldIds: FieldId[];
  visibleWhen?: SectionVisibilityRule[];
};
