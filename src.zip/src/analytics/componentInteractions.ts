import type { AnalyticsElementKind, AnalyticsEvent } from "../domain/analytics";

/** Source-reviewed controls; these specifications do not install vendor tags.
 * Repeated controls use one semantic definition, never applicant-derived IDs. */
export type ComponentInteraction = {
  page: string; kind: AnalyticsElementKind; key: string; label: string;
  events: AnalyticsEvent[]; sourceFile: string; condition: string;
};
const interaction = (page: string, kind: AnalyticsElementKind, key: string, label: string, sourceFile: string, condition: string, events: AnalyticsEvent[] = ["activate"]): ComponentInteraction => ({ page, kind, key, label, events, sourceFile, condition });
export const componentInteractions: ComponentInteraction[] = [
  interaction("coverage", "button", "category-selection", "Select coverage category", "src/components/forms/CoverageCategorySelector.tsx", "Configured coverage categories displayed"),
  interaction("coverage", "button", "see-coverage-options", "See my coverage options", "src/pages/Coverage.tsx", "Categories selected and additional questions required"),
  interaction("coverage", "button", "open-portfolio", "View coverage portfolio", "src/pages/Coverage.tsx", "Portfolio button displayed"),
  interaction("coverage", "drawer", "portfolio", "Coverage portfolio", "src/components/ui/CoveragePortfolioDrawer.tsx", "Portfolio opened", ["open", "close"]),
  interaction("coverage", "modal", "dependent-coverage", "Dependent-only coverage confirmation", "src/pages/Coverage.tsx", "Continue with dependent-only coverage", ["open", "close"]),
  interaction("coverage", "button", "dependent-continue", "Continue dependent-only coverage", "src/pages/Coverage.tsx", "Dependent-only confirmation open"),
  interaction("coverage", "button", "dependent-cancel", "Cancel dependent-only continuation", "src/pages/Coverage.tsx", "Dependent-only confirmation open"),
  interaction("coverage", "modal", "remove-coverage", "Remove coverage confirmation", "src/components/ui/CoverageCart.tsx", "Remove selected coverage requested", ["open", "close"]),
  interaction("coverage", "button", "confirm-remove-coverage", "Confirm remove coverage", "src/components/ui/CoverageCart.tsx", "Removal confirmation open"),
  interaction("coverage", "button", "cancel-remove-coverage", "Cancel remove coverage", "src/components/ui/CoverageCart.tsx", "Removal confirmation open"),
  interaction("beneficiary", "button", "add-beneficiary", "Add beneficiary", "src/pages/Beneficiary.tsx", "Eligible product with beneficiary slots available"),
  interaction("beneficiary", "button", "edit-beneficiary", "Edit beneficiary", "src/pages/Beneficiary.tsx", "Existing beneficiary displayed"),
  interaction("beneficiary", "button", "remove-beneficiary", "Remove beneficiary", "src/pages/Beneficiary.tsx", "Existing beneficiary displayed"),
  interaction("beneficiary", "modal", "beneficiary-editor", "Add / edit beneficiary modal", "src/pages/Beneficiary.tsx", "Add or edit selected", ["open", "close", "submit", "validation-failed"]),
  interaction("beneficiary", "button", "save-beneficiary", "Save beneficiary", "src/pages/Beneficiary.tsx", "Beneficiary editor open"),
  interaction("beneficiary", "button", "cancel-beneficiary", "Cancel beneficiary editing", "src/pages/Beneficiary.tsx", "Beneficiary editor open"),
  interaction("beneficiary", "button", "share-preset", "Beneficiary share shortcut", "src/pages/Beneficiary.tsx", "Individual beneficiary editor; share shortcuts enabled"),
  interaction("beneficiary", "modal", "apply-to-others", "Apply beneficiary to other coverages", "src/pages/Beneficiary.tsx", "Apply-to-other-coverages dialog open", ["open", "close"]),
  interaction("beneficiary", "button", "confirm-apply-to-others", "Apply beneficiary to selected coverages", "src/pages/Beneficiary.tsx", "Apply-to-other-coverages dialog open"),
  interaction("beneficiary", "button", "cancel-apply-to-others", "Cancel applying beneficiary", "src/pages/Beneficiary.tsx", "Apply-to-other-coverages dialog open"),
  interaction("review", "button", "print", "Print consent content", "src/pages/Review.tsx", "Read-and-sign or electronic-consent content displayed"),
  interaction("app-shell", "link", "terms-of-use", "Terms of use", "src/components/layout/AppFooter.tsx", "Footer displayed"),
  interaction("app-shell", "modal", "terms-of-use", "Terms of use modal", "src/components/layout/AppFooter.tsx", "Terms link activated", ["open", "close"]),
  interaction("app-shell", "button", "resume-application", "Continue saved application", "src/components/layout/AppMenu.tsx", "Application menu open"),
  ...([ ["membership", "Membership"], ["coverage", "Coverage"], ["beneficiary", "Beneficiary"], ["payment", "Payment"], ["health-si", "HealthSi"], ["health-di", "HealthDi"] ] as const).flatMap(([page, file]) => [
    interaction(page, "button", "open-help", "Open page help", `src/pages/${file}.tsx`, "Help chip displayed"),
    interaction(page, "drawer", "help", "Page help drawer", `src/pages/${file}.tsx`, "Help chip activated", ["open", "close"]),
  ]),
  ...([ ["resume", "Resume"], ["resume-method", "ResumeMethod"], ["resume-code", "ResumeCode"] ] as const).map(([page, file]) =>
    interaction(page, "button", "continue-resume", "Continue saved-application verification", `src/pages/${file}.tsx`, "Resume step displayed")),
  ...(["menu", "footer"] as const).flatMap(area => (["website", "email", "phone"] as const).map(channel =>
    interaction("app-shell", "link", `${area}-support-${channel}`, `${area} support ${channel}`, area === "menu" ? "src/components/layout/AppMenu.tsx" : "src/components/layout/AppFooter.tsx", `${area} displayed; configured support contact available`))),
  ...([ ["how-applying-works", "How applying works"], ["about-coverage", "About coverage"], ["quick-decision", "About QuickDecision"], ["coverage-needs", "Coverage needs calculator"] ] as const).flatMap(([key, label]) => [
    interaction("app-shell", "button", `open-${key}`, `Open ${label}`, "src/components/layout/AppMenu.tsx", "Application menu open"),
    interaction("app-shell", "drawer", key, label, "src/components/layout/AppMenu.tsx", "Tool opened from application menu", ["open", "close"]),
  ]),
];
export function quoteInteractions(page: string): ComponentInteraction[] {
  return [
    interaction(page, "button", "quote-get-estimates", "Get quote estimates", "src/components/forms/QuoteCalculator.tsx", "Quote input step displayed"),
    interaction(page, "button", "quote-apply", "Apply from quote", "src/components/forms/QuoteCalculator.tsx", "Quote results displayed"),
    interaction(page, "button", "quote-continue", "Continue quote step", "src/components/forms/QuoteCalculator.tsx", "Inline quote step displayed"),
  ];
}
