import { act } from 'react';
import { createRoot, type Root } from 'react-dom/client';
import { MemoryRouter } from 'react-router-dom';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import ApplicationSessionGuard from './ApplicationSessionGuard';
import { applicationTimeoutKey, readApplicationDeadline, resetApplicationTimeout, timeoutMilliseconds, warningMilliseconds } from './applicationTimeout';
import ApplicationErrorState from '../components/feedback/ApplicationErrorState';

vi.mock('../data/activeSite', async importOriginal => ({ ...await importOriginal<typeof import('../data/activeSite')>(), resolveSiteId: () => 'abe' }));
let root: Root, container: HTMLDivElement;
beforeEach(() => {
  vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true);
  vi.spyOn(window, 'scrollTo').mockImplementation(() => {});
  vi.useFakeTimers(); vi.setSystemTime(new Date('2026-10-26T12:00:00Z'));
  sessionStorage.clear();
  container = document.createElement('div'); document.body.append(container); root = createRoot(container);
});
afterEach(async () => { await act(async () => root.unmount()); container.remove(); sessionStorage.clear(); vi.useRealTimers(); vi.restoreAllMocks(); vi.unstubAllGlobals(); });
const mount = async (active = true, onExpire = vi.fn()) => {
  await act(async () => root.render(<MemoryRouter><ApplicationSessionGuard active={active} onExpire={onExpire}><input aria-label="Application field" /></ApplicationSessionGuard></MemoryRouter>));
  return onExpire;
};
it('shows the countdown at the warning threshold and reloads once on expiry', async () => {
  const onExpire = await mount();
  expect(container.querySelector('[role="alert"]')).toBeNull();
  await act(async () => vi.advanceTimersByTime(timeoutMilliseconds - warningMilliseconds));
  expect(container.querySelector('[role="timer"]')?.textContent).toBe('Time remaining: 2:00');
  await act(async () => vi.advanceTimersByTime(warningMilliseconds + 3000));
  expect(onExpire).toHaveBeenCalledTimes(1);
});
it('extends an active session on form activity but never revives an expired deadline', async () => {
  const onExpire = await mount();
  await act(async () => vi.advanceTimersByTime(timeoutMilliseconds - 30_000));
  await act(async () => window.dispatchEvent(new Event('input')));
  expect(container.querySelector('[role="alert"]')).toBeNull();
  expect(readApplicationDeadline('abe')).toBe(Date.now() + timeoutMilliseconds);
  sessionStorage.setItem(applicationTimeoutKey('abe'), String(Date.now() - 1));
  await act(async () => window.dispatchEvent(new Event('keydown')));
  expect(onExpire).toHaveBeenCalledTimes(1);
  expect(readApplicationDeadline('abe')).toBeLessThan(Date.now());
});
it('retains the original deadline across reloads and checks time after a background pause', async () => {
  const deadline = readApplicationDeadline('abe');
  await mount();
  vi.setSystemTime(deadline + 1000);
  await act(async () => document.dispatchEvent(new Event('visibilitychange')));
  expect(readApplicationDeadline('abe')).toBe(deadline);
  resetApplicationTimeout('abe');
  expect(readApplicationDeadline('abe')).toBe(Date.now() + timeoutMilliseconds);
});
it('leaves utility pages usable and directs service failures to the Site resume flow', async () => {
  const onExpire = await mount(false);
  expect(sessionStorage.getItem(applicationTimeoutKey('abe'))).toBeNull();
  await act(async () => window.dispatchEvent(new Event('application:session-expired')));
  expect(onExpire).not.toHaveBeenCalled();
  await mount(true, onExpire);
  await act(async () => window.dispatchEvent(new Event('application:technical-error')));
  expect(container.querySelector('[role="alert"]')?.textContent).toContain('There was a technical error');
  expect(container.querySelector('a')?.getAttribute('href')).toBe('/resume?site=abe');
  await act(async () => window.dispatchEvent(new Event('application:session-expired')));
  expect(onExpire).toHaveBeenCalledTimes(1);
});
it.each([404, 500, 'session-expired', 'technical-error'] as const)('offers the shared compact recovery actions for %s', async status => {
  const onStartNew = vi.fn();
  await act(async () => root.render(<MemoryRouter><ApplicationErrorState status={status} onStartNew={onStartNew} /></MemoryRouter>));
  const actions = [...container.querySelectorAll('a.MuiButton-root')];
  expect(actions.map(action => action.textContent)).toEqual(['Resume application', 'Start new application']);
  expect(actions.every(action => action.classList.contains('MuiButton-sizeSmall'))).toBe(true);
  await act(async () => (actions[1] as HTMLElement).click());
  expect(onStartNew).toHaveBeenCalledTimes(1);
});
