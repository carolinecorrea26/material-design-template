import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { Alert, Box } from "@mui/material";
import { useForm, type FieldErrors } from "react-hook-form";
import { useNavigate, useLocation } from "react-router-dom";
import type { PageId } from "../types";
import { getClientPageFields } from "../config/clientFields/getClientPageFields";
import {
  getResolvedFormFlow,
  getNextFormPageId,
  getPreviousFormPageId,
} from "../config/formFlow";
import { getPageInfoNote, getPageSubhead, getPageTitle } from "../config/pages";
import { getPageSections } from "../config/pageSections";
import type { PageSectionConfig } from "../config/pageSections/types";
import type { FieldDefinition } from "../config/fields/types";
import {
  type ApplicationFormValues,
  useApplicationForm,
} from "./ApplicationFormContext";
import { isApplicantApplying } from "../utils/applicantVisibility";
import PageShell from "../components/layout/PageShell";
import PageHeader from "../components/layout/PageHeader";
import FormShell from "../components/layout/FormShell";
import PageNav from "../components/navigation/PageNav";
import ProgressStep, {
  VerticalStepperBreadcrumbs,
} from "../components/navigation/ProgressStep";
import { getActiveProgressStepIndex } from "../config/progressSteps";
import { generateFormDataUpToPage } from "../dev/utils/generateFormData";
import {
  getForwardMessages,
  BACK_MESSAGE,
  MESSAGE_DURATION,
} from "../config/transitionMessages";
import { sendAutosaveMockEmail } from "../utils/mockEmail";

import PageTransitionSkeleton from "../components/feedback/PageTransitionSkeleton";
import ProgressSavedSnackbar from "../components/feedback/ProgressSavedSnackbar";
import PageAlert from "../components/feedback/PageAlert";

type FormRouteFieldValue = string | boolean | string[];
type FormRoutePageFormValues = Record<string, FormRouteFieldValue>;

export type FormRoutePageValues = ApplicationFormValues;

export type FormRouteRenderProps = {
  control: ReturnType<typeof useForm<FormRoutePageFormValues>>["control"];
  errors: ReturnType<
    typeof useForm<FormRoutePageFormValues>
  >["formState"]["errors"];
  watchedValues: FormRoutePageValues;
  allFields: ReturnType<typeof getClientPageFields>;
  pageSections: ReturnType<typeof getPageSections>;
  setValue: ReturnType<typeof useForm<FormRoutePageFormValues>>["setValue"];
  trigger: ReturnType<typeof useForm<FormRoutePageFormValues>>["trigger"];
};

export type BeforeNextContext = {
  values: FormRoutePageValues;
  continueNavigation: () => void;
};

type DevFillContext = {
  currentValues: FormRoutePageValues;
  currentFields: FieldDefinition[];
  setValue: ReturnType<typeof useForm<FormRoutePageFormValues>>["setValue"];
  setPageValues: ReturnType<typeof useApplicationForm>["setPageValues"];
};

type FormRoutePageProps = {
  pageId: PageId;
  title?: ReactNode;
  subhead?: ReactNode;
  formMaxWidth?: number | string;
  noTitle?: boolean;
  noContainer?: boolean;
  hideActions?: boolean;
  hideNextButton?: boolean | ((values: FormRoutePageValues) => boolean);
  disableNextButton?: boolean | ((values: FormRoutePageValues) => boolean);
  help?: ReactNode | ((props: FormRouteRenderProps) => ReactNode);
  children: ReactNode | ((props: FormRouteRenderProps) => ReactNode);
  validate?: (values: FormRoutePageValues) => string | undefined;
  defaultValueOverrides?: FormRoutePageFormValues;
  devFillFields?: (currentValues: FormRoutePageValues) => FieldDefinition[];
  onDevFill?: (context: DevFillContext) => void;
  onBeforeNext?: (context: BeforeNextContext) => boolean;
  resolveNextPageId?: (values: FormRoutePageValues) => PageId | null;
  initialTransitionMessage?: string;
};

function getDefaultValueForField(field: FieldDefinition): FormRouteFieldValue {
  if (field.inputType === "checkbox") {
    return false;
  }

  if (
    field.inputType === "checkbox-group" ||
    field.inputType === "multi-select"
  ) {
    return [];
  }

  return "";
}

function getStoredFieldValue(
  value: ApplicationFormValues[string] | undefined,
): FormRouteFieldValue | undefined {
  if (
    typeof value === "string" ||
    typeof value === "boolean" ||
    (Array.isArray(value) && value.every((entry) => typeof entry === "string"))
  ) {
    return value;
  }

  return undefined;
}

function getMergedPageFields(
  pageId: PageId,
  values: FormRoutePageValues,
  devFillFields?: (currentValues: FormRoutePageValues) => FieldDefinition[],
) {
  return [
    ...getClientPageFields(pageId, values),
    ...(devFillFields?.(values) ?? []),
  ].filter(
    (field, index, fields) =>
      fields.findIndex((entry) => entry.id === field.id) === index,
  );
}

export function isSectionVisible(
  section: PageSectionConfig,
  values: FormRoutePageValues,
): boolean {
  const resolvedFlow = getResolvedFormFlow();
  const coverageIndex = resolvedFlow.indexOf("coverage");
  const sectionPageIndex = resolvedFlow.indexOf(section.pageId);
  const useApplicantCoverageGate =
    sectionPageIndex >= coverageIndex && coverageIndex !== -1;

  if (
    useApplicantCoverageGate &&
    section.applicant &&
    !isApplicantApplying(section.applicant, values)
  ) {
    return false;
  }

  if (!section.visibleWhen) return true;

  return section.visibleWhen.every((rule) => {
    const value = values[rule.fieldId];

    if ("equals" in rule) return value === rule.equals;
    if ("notEquals" in rule) return value !== rule.notEquals;
    if ("includes" in rule) {
      return Array.isArray(value) && value.includes(rule.includes);
    }

    return true;
  });
}

function getDevValue(field: {
  id: string;
  inputType: string;
  format?: string;
  options?: { value: string }[];
}) {
  if (field.id === "dependents") return [];
  if (field.id.includes("-onset")) return "01/2020";
  if (field.id.startsWith("payment-method:")) return "bill-me";
  if (field.id.startsWith("payment-frequency:")) return "monthly";
  if (field.id === "payment-routing-number") return "021000021";
  if (field.id === "payment-account-number") return "123456789";
  if (field.id === "payment-account-type") return "checking";
  if (field.id === "bank-authorization") return true;
  if (field.format === "currency") return "$5,000";
  if (field.format === "percent") return "50";
  if (field.inputType === "checkbox") return true;
  if (field.inputType === "checkbox-group") {
    return field.options?.[0]?.value ? [field.options[0].value] : [];
  }
  if (field.inputType === "multi-select") {
    return field.options?.[0]?.value ? [field.options[0].value] : [];
  }
  if (
    field.inputType === "radio" ||
    field.inputType === "dropdown" ||
    field.inputType === "searchable-select"
  ) {
    return field.options?.[0]?.value ?? "";
  }
  if (field.inputType === "date") return "1990-01-01";
  if (field.inputType === "number") return "100";
  if (field.format === "ssn") return "123-45-6789";
  if (field.format === "email" || field.id.toLowerCase().includes("email"))
    return "test@example.com";
  if (field.format === "phone" || field.id.toLowerCase().includes("phone"))
    return "(555) 123-4567";
  if (field.id.toLowerCase().includes("zip")) return "10001";
  if (field.id.toLowerCase().includes("state")) return "NY";
  return "Test";
}

function emitProgressSnapshot(values: FormRoutePageValues) {
  window.dispatchEvent(
    new CustomEvent<FormRoutePageValues>("form:progresssnapshot", {
      detail: values,
    }),
  );
}

function emitPendingBreadcrumbCompletion(pageId: PageId | null) {
  window.dispatchEvent(
    new CustomEvent<PageId | null>("form:pendingbreadcrumbcompletion", {
      detail: pageId,
    }),
  );
}

export default function FormRoutePage({
  pageId,
  title,
  subhead,
  formMaxWidth,
  noTitle,
  noContainer,
  hideActions,
  hideNextButton,
  disableNextButton,
  help,
  children,
  validate,
  defaultValueOverrides,
  devFillFields,
  onDevFill,
  onBeforeNext,
  resolveNextPageId,
  initialTransitionMessage,
}: FormRoutePageProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const { values, setPageValues } = useApplicationForm();

  const [showProgressSaved, setShowProgressSaved] = useState(false);

  useEffect(() => {
    if ((location.state as Record<string, unknown>)?.showProgressSaved) {
      setShowProgressSaved(true);
      navigate(location.pathname, { replace: true, state: {} });
    }
  }, [location, navigate]);

  const initialFields = getMergedPageFields(pageId, values, devFillFields);
  const defaultValueOverridesRef = useRef(defaultValueOverrides);
  defaultValueOverridesRef.current = defaultValueOverrides;

  const defaultValues = initialFields.reduce<FormRoutePageFormValues>(
    (acc, field) => {
      acc[field.id] =
        defaultValueOverrides?.[field.id] ??
        getStoredFieldValue(values[field.id]) ??
        getDefaultValueForField(field);
      return acc;
    },
    {},
  );

  const {
    control,
    handleSubmit,
    watch,
    getValues,
    setValue,
    trigger,
    reset,
    formState: { errors },
  } = useForm<FormRoutePageFormValues>({
    defaultValues,
  });

  const watchedValues = { ...values, ...watch() };

  const watchRef = useRef(watch);
  watchRef.current = watch;
  const setPageValuesRef = useRef(setPageValues);
  setPageValuesRef.current = setPageValues;
  const hasExplicitlySavedRef = useRef(false);

  useEffect(() => {
    return () => {
      if (!hasExplicitlySavedRef.current) {
        setPageValuesRef.current(watchRef.current());
      }
    };
  }, []);

  const allFields = getMergedPageFields(pageId, watchedValues, devFillFields);
  const pageSections = getPageSections(pageId);

  useEffect(() => {
    const fields = getMergedPageFields(pageId, values, devFillFields);

    const restoredValues = fields.reduce<FormRoutePageFormValues>(
      (acc, field) => {
        acc[field.id] =
          defaultValueOverridesRef.current?.[field.id] ??
          getStoredFieldValue(values[field.id]) ??
          getDefaultValueForField(field);
        return acc;
      },
      {},
    );

    reset(restoredValues);
  }, [devFillFields, pageId, reset, values]);

  useEffect(() => {
    function handleDevFillForm() {
      const formDataUpToPage = generateFormDataUpToPage(pageId);

      const currentValues = {
        ...formDataUpToPage,
        ...getValues(),
      };

      const currentFields = getMergedPageFields(
        pageId,
        currentValues,
        devFillFields,
      );

      const devFilledValues = currentFields.reduce<FormRoutePageFormValues>(
        (acc, field) => {
          acc[field.id] = getDevValue(field);
          return acc;
        },
        {},
      );

      setPageValuesRef.current({
        ...formDataUpToPage,
        ...devFilledValues,
      });

      currentFields.forEach((field) => {
        setValue(field.id, devFilledValues[field.id], {
          shouldDirty: true,
          shouldTouch: true,
          shouldValidate: false,
        });
      });

      onDevFill?.({
        currentValues: {
          ...currentValues,
          ...devFilledValues,
        },
        currentFields,
        setValue,
        setPageValues: setPageValuesRef.current,
      });
    }

    window.addEventListener("devtools:fillform", handleDevFillForm);

    return () =>
      window.removeEventListener("devtools:fillform", handleDevFillForm);
  }, [devFillFields, getValues, onDevFill, pageId, setValue]);

  const [pageError, setPageError] = useState<string | undefined>();
  const [isTransitioning, setIsTransitioning] = useState(
    Boolean(initialTransitionMessage),
  );
  const [transitionMessage, setTransitionMessage] = useState(
    initialTransitionMessage ?? "",
  );
  const transitionTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (initialTransitionMessage) {
      transitionTimerRef.current = setTimeout(() => {
        setIsTransitioning(false);
        setTransitionMessage("");
      }, MESSAGE_DURATION);
    }
  }, [initialTransitionMessage]);

  useEffect(() => {
    return () => {
      if (transitionTimerRef.current) clearTimeout(transitionTimerRef.current);
    };
  }, []);

  const scrollToFirstError = useCallback(() => {
    requestAnimationFrame(() => {
      const firstErrorField = document.querySelector(
        '[aria-invalid="true"], .Mui-error input, .Mui-error textarea, .Mui-error .MuiSelect-select',
      );

      if (firstErrorField) {
        firstErrorField.scrollIntoView({ behavior: "smooth", block: "center" });
      } else {
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
    });
  }, []);

  const continueToNextPage = useCallback(
    (nextNavigationValues: FormRoutePageValues) => {
      const resolvedNextPageId = resolveNextPageId?.(nextNavigationValues);
      const nextPageId =
        resolvedNextPageId === undefined
          ? getNextFormPageId(pageId, nextNavigationValues)
          : resolvedNextPageId;

      const destination =
        nextPageId ?? (pageId === "payment" ? "receipt" : null);
      if (!destination) return;

      const [msg1, msg2] = getForwardMessages(pageId);

      emitPendingBreadcrumbCompletion(pageId);
      setTransitionMessage(msg1);
      setIsTransitioning(true);
      window.scrollTo({ top: 0 });

      transitionTimerRef.current = setTimeout(() => {
        setTransitionMessage(msg2);

        transitionTimerRef.current = setTimeout(() => {
          emitProgressSnapshot(nextNavigationValues);
          navigate(`/${destination}`, { state: { showProgressSaved: true } });
        }, MESSAGE_DURATION);
      }, MESSAGE_DURATION);
    },
    [navigate, pageId, resolveNextPageId],
  );

  function onSubmit(formValues: FormRoutePageValues) {
    const nextNavigationValues = {
      ...values,
      ...formValues,
    };

    const validationError = validate?.(nextNavigationValues);

    if (validationError) {
      setPageError(validationError);
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }

    setPageError(undefined);
    setPageValues(formValues);
    hasExplicitlySavedRef.current = true;

    if (pageId === "membership") {
      void sendAutosaveMockEmail(nextNavigationValues).catch((error) => {
        console.warn("Autosave mock email failed", error);
      });
    }

    if (pageId === "review") {
      window.sessionStorage.setItem("reviewSubmitted", "true");
      window.dispatchEvent(new Event("reviewsubmitted"));
    }

    const shouldContinue = onBeforeNext?.({
      values: nextNavigationValues,
      continueNavigation: () => continueToNextPage(nextNavigationValues),
    });

    if (shouldContinue === false) {
      return;
    }

    continueToNextPage(nextNavigationValues);
  }

  function onFormError(fieldErrors: FieldErrors<FormRoutePageValues>) {
    setPageError("Please correct the errors below before continuing.");

    if (Object.keys(fieldErrors).length > 0) {
      scrollToFirstError();
    } else {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }

  function handleBack() {
    const previousPageId = getPreviousFormPageId(pageId, watchedValues);

    if (previousPageId) {
      const previousNavigationValues = {
        ...values,
        ...getValues(),
      };

      setPageValues(previousNavigationValues);
      hasExplicitlySavedRef.current = true;

      emitPendingBreadcrumbCompletion(null);
      setTransitionMessage(BACK_MESSAGE);
      setIsTransitioning(true);
      window.scrollTo({ top: 0 });

      transitionTimerRef.current = setTimeout(() => {
        emitProgressSnapshot(previousNavigationValues);
        navigate(`/${previousPageId}`);
      }, MESSAGE_DURATION);
    }
  }

  const renderProps: FormRouteRenderProps = {
    control,
    errors,
    watchedValues,
    allFields,
    pageSections,
    setValue,
    trigger,
  };

  const renderedHelp = typeof help === "function" ? help(renderProps) : help;

  const activeProgressStepIndex = getActiveProgressStepIndex(pageId, values);
  const hasVerticalStepper = activeProgressStepIndex >= 0;

  const resolvedTitle = title ?? getPageTitle(pageId);
  const resolvedSubhead = subhead ?? getPageSubhead(pageId);
  const resolvedInfoNote = getPageInfoNote(pageId);

  // After review is submitted, disable back navigation on post-review pages
  const reviewSubmitted =
    window.sessionStorage.getItem("reviewSubmitted") === "true";
  const flow = getResolvedFormFlow();
  const reviewIndex = flow.indexOf("review");
  const currentIndex = flow.indexOf(pageId);
  const isAfterReview =
    reviewSubmitted && reviewIndex !== -1 && currentIndex > reviewIndex;

  const formPageElement = (
    <PageShell
      title={resolvedTitle}
      maxWidth={hasVerticalStepper ? "100%" : formMaxWidth}
      noTitle
      noContainer={noContainer || hasVerticalStepper}
      actions={undefined}
    >
      <Box>
        <FormShell
          sx={{
            px: { xs: 2, sm: "48px" },
            py: { xs: 2, sm: "32px" },
            mb: hasVerticalStepper ? 1 : 0,
          }}
        >
          {hasVerticalStepper && (
            <Box sx={{ mb: 1.5 }}>
              <VerticalStepperBreadcrumbs pageId={pageId} />
            </Box>
          )}
          {isTransitioning ? (
            <PageTransitionSkeleton message={transitionMessage} />
          ) : (
            <>
              {!noTitle && (
                <PageHeader
                  title={resolvedTitle}
                  subhead={resolvedSubhead}
                  onBack={
                    !isAfterReview &&
                    getPreviousFormPageId(pageId, watchedValues)
                      ? handleBack
                      : undefined
                  }
                  help={renderedHelp}
                />
              )}
              {resolvedInfoNote && (
                <Box sx={{ mb: 2 }}>
                  <Alert severity="info" sx={{ width: "100%" }}>
                    {resolvedInfoNote}
                  </Alert>
                </Box>
              )}
              <PageAlert severity="error" message={pageError} />
              <form
                id={`${pageId}-form`}
                noValidate
                onSubmit={handleSubmit(onSubmit, onFormError)}
              >
                {typeof children === "function"
                  ? children(renderProps)
                  : children}
              </form>
            </>
          )}
          {!hideActions &&
            !(typeof hideNextButton === "function"
              ? hideNextButton(watchedValues)
              : hideNextButton) && (
              <PageNav
                formId={`${pageId}-form`}
                isTransitioning={isTransitioning}
                disabled={
                  typeof disableNextButton === "function"
                    ? disableNextButton(watchedValues)
                    : Boolean(disableNextButton)
                }
              />
            )}
        </FormShell>
      </Box>
    </PageShell>
  );

  return (
    <>
      <ProgressSavedSnackbar
        open={showProgressSaved}
        onClose={() => setShowProgressSaved(false)}
      />

      {hasVerticalStepper ? (
        <ProgressStep pageId={pageId}>{formPageElement}</ProgressStep>
      ) : (
        formPageElement
      )}
    </>
  );
}
