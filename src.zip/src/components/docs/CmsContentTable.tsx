import { useMemo, useState } from "react";
import {
  Chip,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import type { CmsEntry } from "../../content/docs/cmsEntries";
import ResponsiveTableContainer from "./ResponsiveTableContainer";
import SearchField from "./SearchField";
import TruncatedString from "./TruncatedString";
import { CLIENT_HIGHLIGHT_BG } from "./ClientNote";

export type CmsTableRow = {
  entry: CmsEntry;
  value: string;
  overridden: boolean;
};

const ALL = "All";

export default function CmsContentTable({ rows }: { rows: CmsTableRow[] }) {
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>(ALL);
  const [pageFilter, setPageFilter] = useState<string>(ALL);
  const [statusFilter, setStatusFilter] = useState<string>(ALL);

  const typeOptions = useMemo(
    () => [ALL, ...Array.from(new Set(rows.map((r) => r.entry.type))).sort()],
    [rows],
  );
  const pageOptions = useMemo(
    () => [ALL, ...Array.from(new Set(rows.map((r) => r.entry.page))).sort()],
    [rows],
  );
  const statusOptions = useMemo(
    () => [ALL, ...Array.from(new Set(rows.map((r) => r.entry.status))).sort()],
    [rows],
  );

  const filteredRows = useMemo(() => {
    const lc = search.trim().toLowerCase();
    return rows.filter(({ entry, value }) => {
      if (typeFilter !== ALL && entry.type !== typeFilter) return false;
      if (pageFilter !== ALL && entry.page !== pageFilter) return false;
      if (statusFilter !== ALL && entry.status !== statusFilter) return false;
      if (lc && !`${value} ${entry.page}`.toLowerCase().includes(lc)) return false;
      return true;
    });
  }, [rows, search, typeFilter, pageFilter, statusFilter]);

  return (
    <Stack spacing={2}>
      <Stack direction={{ xs: "column", sm: "row" }} spacing={1.5} sx={{ flexWrap: "wrap" }}>
        <SearchField value={search} onChange={setSearch} placeholder="Search content…" />
        <FormControl size="small" sx={{ minWidth: 140 }}>
          <InputLabel>Type</InputLabel>
          <Select label="Type" value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}>
            {typeOptions.map((option) => (
              <MenuItem key={option} value={option}>
                {option}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <FormControl size="small" sx={{ minWidth: 220 }}>
          <InputLabel>Page / Location</InputLabel>
          <Select
            label="Page / Location"
            value={pageFilter}
            onChange={(e) => setPageFilter(e.target.value)}
          >
            {pageOptions.map((option) => (
              <MenuItem key={option} value={option}>
                {option}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <FormControl size="small" sx={{ minWidth: 140 }}>
          <InputLabel>Status</InputLabel>
          <Select
            label="Status"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            {statusOptions.map((option) => (
              <MenuItem key={option} value={option}>
                {option}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Stack>

      <ResponsiveTableContainer>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell sx={{ minWidth: 340, fontWeight: 600 }}>Content</TableCell>
              <TableCell sx={{ minWidth: 90, fontWeight: 600 }}>Type</TableCell>
              <TableCell sx={{ minWidth: 220, fontWeight: 600 }}>Page / Location</TableCell>
              <TableCell sx={{ minWidth: 110, fontWeight: 600 }}>Status</TableCell>
              <TableCell sx={{ minWidth: 120, fontWeight: 600 }}>Last Modified</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredRows.map(({ entry, value, overridden }) => (
              <TableRow key={entry.id} sx={overridden ? { bgcolor: CLIENT_HIGHLIGHT_BG } : undefined}>
                <TableCell sx={{ verticalAlign: "top", whiteSpace: "normal !important" }}>
                  <TruncatedString value={value} />
                </TableCell>
                <TableCell sx={{ verticalAlign: "top" }}>
                  <Chip label={entry.type} size="small" />
                </TableCell>
                <TableCell sx={{ verticalAlign: "top", whiteSpace: "normal !important" }}>
                  {entry.page}
                </TableCell>
                <TableCell sx={{ verticalAlign: "top" }}>
                  <Chip label={entry.status} size="small" color="success" variant="outlined" />
                </TableCell>
                <TableCell sx={{ verticalAlign: "top" }}>{entry.lastModified ?? "—"}</TableCell>
              </TableRow>
            ))}
            {filteredRows.length === 0 && (
              <TableRow>
                <TableCell colSpan={5}>
                  <Typography variant="body2" color="text.secondary" sx={{ py: 2 }}>
                    No content matches these filters.
                  </Typography>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </ResponsiveTableContainer>

      <Typography variant="caption" color="text.secondary">
        Showing {filteredRows.length} of {rows.length} content items.
      </Typography>
    </Stack>
  );
}
