import { useMemo, useState } from "react";
import { Box, Chip, Stack, Table, TableBody, TableCell, TableHead, TableRow, Typography } from "@mui/material";
import ResponsiveTableContainer from "./ResponsiveTableContainer";
import ResizableHeaderCell from "./ResizableHeaderCell";
import SearchField from "./SearchField";
import useResizableColumns from "./useResizableColumns";

import TruncatedString from "./TruncatedString";
import { getConfigurationGroupAnchor, type ConfigRow } from "../../content/docs/configurations";

/**
 * Renders the given configuration rows as a flat, searchable, resizable-
 * column table, grouped by `group`. Used by each of the six IA sections to
 * show "global vs. client configuration" for that section instead of a
 * standalone Configurations section — Configuration is a lens on every
 * section, not a section itself. The caller owns the section's title/count
 * header (e.g. via SubsectionHeader) — this component renders table content
 * only.
 *
 * If `groups` is omitted, every group present in `rows` is shown. If
 * `groupOrder` is provided, groups render in that order (any group not
 * listed renders after the ordered ones, in its natural — i.e. first
 * appearance in `rows` — order). Without `groupOrder`, groups render in
 * whatever order they naturally appear in `rows`.
 */
export default function ConfigReferenceList({
  rows: allRows,
  groups,
  groupOrder,
  compact = false,
}: {
  rows: ConfigRow[];
  groups?: string[];
  groupOrder?: string[];
  /** Render only Area / Configuration / Description columns (drops Source, Scope, and Used-in, and the code-style name line). */
  compact?: boolean;
}) {
  const [filter, setFilter] = useState("");
  const { widths, resize } = useResizableColumns({
    group: 160,
    configuration: 200,
    description: 300,
    source: 200,
    scope: 150,
    usedIn: 160,
  });

  const filteredRows = groups ? allRows.filter((c) => groups.includes(c.group)) : allRows;

  const naturalOrder: string[] = [];
  for (const r of filteredRows) {
    if (!naturalOrder.includes(r.group)) naturalOrder.push(r.group);
  }

  const finalGroupOrder = groupOrder
    ? [
        ...groupOrder.filter((g) => naturalOrder.includes(g)),
        ...naturalOrder.filter((g) => !groupOrder.includes(g)),
      ]
    : naturalOrder;

  const orderedRows = finalGroupOrder.flatMap((group) =>
    filteredRows.filter((r) => r.group === group),
  );

  const rows = useMemo(() => {
    if (!filter) return orderedRows;
    const lc = filter.toLowerCase();
    return orderedRows.filter((r) =>
      `${r.group} ${r.label} ${r.name} ${r.description} ${r.sourcePath} ${r.scope} ${r.usedIn}`
        .toLowerCase()
        .includes(lc),
    );
  }, [orderedRows, filter]);

  if (orderedRows.length === 0) return null;

  return (
    <Stack spacing={1.5}>
      {!compact && (
        <Typography variant="body2" color="text.secondary">
          Scope is standardized to two values: <strong>Global</strong> for template-wide settings and{" "}
          <strong>Client Configurable</strong> for settings that may vary by client.
        </Typography>
      )}
      <SearchField value={filter} onChange={setFilter} placeholder="Filter configuration…" />
      <ResponsiveTableContainer>
        <Table size="small" sx={{ tableLayout: "fixed", width: "max-content" }}>
          <colgroup>
            <col style={{ width: widths.group }} />
            <col style={{ width: widths.configuration }} />
            <col style={{ width: widths.description }} />
            {!compact && (
              <>
                <col style={{ width: widths.source }} />
                <col style={{ width: widths.scope }} />
                <col style={{ width: widths.usedIn }} />
              </>
            )}
          </colgroup>
          <TableHead>
            <TableRow>
              <ResizableHeaderCell width={widths.group} onResize={(w) => resize("group", w)}>
                Area
              </ResizableHeaderCell>
              <ResizableHeaderCell
                width={widths.configuration}
                onResize={(w) => resize("configuration", w)}
              >
                Configuration
              </ResizableHeaderCell>
              <ResizableHeaderCell
                width={widths.description}
                onResize={(w) => resize("description", w)}
              >
                Description
              </ResizableHeaderCell>
              {!compact && (
                <>
                  <ResizableHeaderCell width={widths.source} onResize={(w) => resize("source", w)}>
                    Source
                  </ResizableHeaderCell>
                  <ResizableHeaderCell
                    width={widths.scope}
                    onResize={(w) => resize("scope", w)}
                  >
                    Scope
                  </ResizableHeaderCell>
                  <ResizableHeaderCell width={widths.usedIn} onResize={(w) => resize("usedIn", w)}>
                    Used in
                  </ResizableHeaderCell>
                </>
              )}
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((config, i) => {
              const showGroup = i === 0 || rows[i - 1].group !== config.group;
              return (
                <TableRow
                  key={config.label + config.name}
                  id={showGroup ? getConfigurationGroupAnchor(config.group) : undefined}
                >
                  <TableCell
                    sx={{
                      verticalAlign: "top",
                      color: showGroup ? "text.primary" : "transparent",
                      fontWeight: 600,
                      fontSize: "0.8125rem",
                      whiteSpace: "normal !important",
                      borderTop: showGroup && i !== 0 ? "2px solid" : undefined,
                      borderTopColor: showGroup && i !== 0 ? "divider" : undefined,
                    }}
                  >
                    {config.group}
                  </TableCell>
                  <TableCell
                    sx={{
                      verticalAlign: "top",
                      whiteSpace: "normal !important",
                      borderTop: showGroup && i !== 0 ? "2px solid" : undefined,
                      borderTopColor: showGroup && i !== 0 ? "divider" : undefined,
                    }}
                  >
                    <Stack direction="row" spacing={0.75} alignItems="center" flexWrap="wrap" useFlexGap>
                      <Typography variant="body2" sx={{ fontWeight: 700, lineHeight: 1.4 }}>
                        {config.label}
                      </Typography>
                      {config.sourcePath.startsWith("Planned") && (
                        <Chip label="Planned" size="small" variant="outlined" />
                      )}
                    </Stack>
                    {!compact && (
                      <Typography
                        variant="caption"
                        color="text.disabled"
                        sx={{
                          fontFamily: "monospace",
                          display: "block",
                          mt: 0.25,
                          lineHeight: 1.4,
                          whiteSpace: "normal",
                        }}
                      >
                        {config.name}
                      </Typography>
                    )}
                  </TableCell>
                  <TableCell
                    sx={{
                      whiteSpace: "normal !important",
                      verticalAlign: "top",
                      borderTop: showGroup && i !== 0 ? "2px solid" : undefined,
                      borderTopColor: showGroup && i !== 0 ? "divider" : undefined,
                    }}
                  >
                    <TruncatedString value={config.description} threshold={160} />
                  </TableCell>
                  {!compact && (
                    <>
                      <TableCell
                        sx={{
                          verticalAlign: "top",
                          whiteSpace: "normal !important",
                          borderTop: showGroup && i !== 0 ? "2px solid" : undefined,
                          borderTopColor: showGroup && i !== 0 ? "divider" : undefined,
                        }}
                      >
                        <TruncatedString value={config.sourcePath} threshold={140} />
                      </TableCell>
                      <TableCell
                        sx={{
                          whiteSpace: "normal !important",
                          verticalAlign: "top",
                          borderTop: showGroup && i !== 0 ? "2px solid" : undefined,
                          borderTopColor: showGroup && i !== 0 ? "divider" : undefined,
                        }}
                      >
                        <Chip label={config.scope} size="small" variant="outlined" />
                      </TableCell>
                      <TableCell
                        sx={{
                          whiteSpace: "normal !important",
                          verticalAlign: "top",
                          borderTop: showGroup && i !== 0 ? "2px solid" : undefined,
                          borderTopColor: showGroup && i !== 0 ? "divider" : undefined,
                        }}
                      >
                        <TruncatedString value={config.usedIn} threshold={140} />
                      </TableCell>
                    </>
                  )}
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </ResponsiveTableContainer>
      {rows.length === 0 && (
        <Box sx={{ py: 2 }}>
          <Typography variant="body2" color="text.secondary">
            No configuration options match “{filter}”.
          </Typography>
        </Box>
      )}
    </Stack>
  );
}
