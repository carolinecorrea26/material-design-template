import { useEffect, useMemo, useState } from "react";
import {
  Box,
  Chip,
  Link,
  Stack,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Tabs,
  Typography,
} from "@mui/material";
import type { ClientId } from "../../types";
import AppModal from "../layout/AppModal";
import ClientNote, { CLIENT_HIGHLIGHT_BG } from "./ClientNote";
import ResponsiveTableContainer from "./ResponsiveTableContainer";
import {
  readMockEmailPreviews,
  subscribeToMockEmailPreviews,
  type MockEmailPreview as MockEmailPreviewData,
} from "../../utils/mockEmail";
import { emailTemplateRows, type EmailTemplateRow } from "./emailTemplateRows";

type ModalView = "mockup" | "html";

const FLOW_CHIP_COLOR = {
  Consumer: "primary",
  Advisor: "secondary",
  Resume: "success",
} as const;

/**
 * Flow / Email / Description / When sent / Notes table for the mock email
 * catalog, resolved against a given client (the "demo" placeholder client for
 * the Global tab, or a real client for the Client tab). The Email column
 * opens a modal with a mockup + raw HTML preview, shared by both panels.
 */
export default function EmailTemplatesTable({
  clientId,
  highlightedIds,
  overrideNote,
}: {
  clientId: ClientId;
  /** Row ids to render with the client-override yellow highlight. */
  highlightedIds?: Set<string>;
  /** Chip label shown under the email name for highlighted rows. */
  overrideNote?: string;
}) {
  const [openRow, setOpenRow] = useState<EmailTemplateRow | null>(null);
  const [modalView, setModalView] = useState<ModalView>("mockup");
  const [previews, setPreviews] = useState<MockEmailPreviewData[]>(() =>
    readMockEmailPreviews(clientId),
  );

  useEffect(() => {
    setPreviews(readMockEmailPreviews(clientId));
  }, [clientId]);

  useEffect(() => {
    return subscribeToMockEmailPreviews(() => {
      setPreviews(readMockEmailPreviews(clientId));
    });
  }, [clientId]);

  const openPreview = useMemo(
    () =>
      openRow
        ? previews.find((preview) => preview.type === openRow.type) ?? null
        : null,
    [openRow, previews],
  );

  function handleOpenRow(row: EmailTemplateRow) {
    setOpenRow(row);
    setModalView("mockup");
  }

  return (
    <>
      <ResponsiveTableContainer>
        <Table size="small" aria-label="Email templates">
          <TableHead>
            <TableRow>
              <TableCell sx={{ fontWeight: 800 }}>Flow</TableCell>
              <TableCell sx={{ fontWeight: 800 }}>Email</TableCell>
              <TableCell sx={{ fontWeight: 800 }}>Description</TableCell>
              <TableCell sx={{ fontWeight: 800 }}>When sent</TableCell>
              <TableCell sx={{ fontWeight: 800 }}>Notes</TableCell>
            </TableRow>
          </TableHead>

          <TableBody>
            {emailTemplateRows.map((row) => {
              const highlighted = highlightedIds?.has(row.id) ?? false;

              return (
                <TableRow
                  key={row.id}
                  hover
                  sx={highlighted ? { bgcolor: CLIENT_HIGHLIGHT_BG } : undefined}
                >
                  <TableCell sx={{ whiteSpace: "nowrap", verticalAlign: "top" }}>
                    <Chip
                      label={row.flow}
                      size="small"
                      color={FLOW_CHIP_COLOR[row.flow]}
                      variant="outlined"
                      sx={{ fontWeight: 700 }}
                    />
                  </TableCell>

                  <TableCell sx={{ whiteSpace: "nowrap", verticalAlign: "top" }}>
                    <Link
                      component="button"
                      type="button"
                      underline="hover"
                      onClick={() => handleOpenRow(row)}
                      sx={{ fontWeight: 700, textAlign: "left" }}
                    >
                      {row.title}
                    </Link>
                    {highlighted && overrideNote && (
                      <Box sx={{ mt: 0.5 }}>
                        <ClientNote label={overrideNote} />
                      </Box>
                    )}
                  </TableCell>

                  <TableCell sx={{ verticalAlign: "top" }}>
                    <Typography variant="body2" sx={{ color: "text.secondary" }}>
                      {row.description}
                    </Typography>
                  </TableCell>

                  <TableCell sx={{ verticalAlign: "top" }}>
                    <Typography variant="body2" sx={{ color: "text.secondary" }}>
                      {row.whenSent}
                    </Typography>
                  </TableCell>

                  <TableCell sx={{ verticalAlign: "top" }}>
                    <Typography variant="body2" sx={{ color: "text.secondary" }}>
                      {row.notes}
                    </Typography>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </ResponsiveTableContainer>

      <AppModal
        open={Boolean(openRow)}
        onClose={() => setOpenRow(null)}
        title={openRow?.title ?? ""}
        maxWidth={860}
      >
        {openPreview && (
          <Stack spacing={2}>
            <Tabs
              value={modalView}
              onChange={(_, value: ModalView) => setModalView(value)}
              sx={{ borderBottom: "1px solid", borderColor: "divider" }}
            >
              <Tab value="mockup" label="Mockup" />
              <Tab value="html" label="HTML" />
            </Tabs>

            {modalView === "mockup" ? (
              <Box
                component="iframe"
                title={`${openPreview.subject} email preview`}
                srcDoc={openPreview.html}
                sx={{
                  display: "block",
                  width: "100%",
                  minHeight: { xs: 640, md: 760 },
                  border: "1px solid",
                  borderColor: "divider",
                  borderRadius: 1,
                  bgcolor: "white",
                }}
              />
            ) : (
              <Box
                component="pre"
                sx={{
                  m: 0,
                  p: 2,
                  border: "1px solid",
                  borderColor: "divider",
                  borderRadius: 1,
                  bgcolor: "#f5f5f5",
                  color: "#111827",
                  fontFamily: "monospace",
                  fontSize: "0.75rem",
                  lineHeight: 1.6,
                  whiteSpace: "pre-wrap",
                  wordBreak: "break-word",
                  maxHeight: { xs: 640, md: 760 },
                  overflow: "auto",
                }}
              >
                {openPreview.html}
              </Box>
            )}
          </Stack>
        )}
      </AppModal>
    </>
  );
}
