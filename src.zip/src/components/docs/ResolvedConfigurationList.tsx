import { useMemo, useState } from "react";
import { Chip, Stack, Table, TableBody, TableCell, TableHead, TableRow, Typography } from "@mui/material";
import ResponsiveTableContainer from "./ResponsiveTableContainer";
import ResizableHeaderCell from "./ResizableHeaderCell";
import SearchField from "./SearchField";
import useResizableColumns from "./useResizableColumns";
import { CLIENT_HIGHLIGHT_BG, CLIENT_HIGHLIGHT_BORDER } from "./ClientNote";
import type { ResolvedConfiguration } from "../../config/resolvers";
import TruncatedString from "./TruncatedString";

/** Renders an unknown resolved config value (primitive/array/object) as a compact, readable string. */
function formatConfigValue(value: unknown): string {
  if (value === undefined || value === null) return "—";
  if (typeof value === "boolean") return value ? "Yes" : "No";
  if (typeof value === "number") return String(value);
  if (typeof value === "string") return value || "—";
  if (Array.isArray(value)) {
    if (value.length === 0) return "—";
    return value.map((v) => (typeof v === "object" ? JSON.stringify(v) : String(v))).join(", ");
  }
  if (typeof value === "object") {
    const entries = Object.entries(value as Record<string, unknown>).filter(
      ([, v]) => !(v === undefined || v === null || (Array.isArray(v) && v.length === 0)),
    );
    if (entries.length === 0) return "—";
    return entries
      .map(([key, v]) => `${key}: ${Array.isArray(v) ? v.join(", ") : typeof v === "object" ? JSON.stringify(v) : String(v)}`)
      .join("; ");
  }
  return String(value);
}

/**
 * Global → Client override → Effective → Status table for resolved
 * configuration settings (rows with a live ClientConfig accessor — see
 * resolveClientConfigurations). Overridden rows are highlighted; inherited
 * rows render in muted text so overrides read as the exception, not the norm.
 */
export default function ResolvedConfigurationList({
  rows,
  groupOrder,
}: {
  rows: ResolvedConfiguration[];
  groupOrder?: string[];
}) {
  const [filter, setFilter] = useState("");
  const { widths, resize } = useResizableColumns({
    group: 160,
    setting: 200,
    global: 260,
    override: 200,
    effective: 200,
    status: 110,
  });

  const naturalOrder: string[] = [];
  for (const row of rows) {
    if (!naturalOrder.includes(row.group)) naturalOrder.push(row.group);
  }
  const finalGroupOrder = groupOrder
    ? [
        ...groupOrder.filter((g) => naturalOrder.includes(g)),
        ...naturalOrder.filter((g) => !groupOrder.includes(g)),
      ]
    : naturalOrder;
  const orderedRows = finalGroupOrder.flatMap((group) => rows.filter((r) => r.group === group));

  const filteredRows = useMemo(() => {
    if (!filter) return orderedRows;
    const lc = filter.toLowerCase();
    return orderedRows.filter((r) =>
      `${r.group} ${r.label} ${r.key} ${r.global.description}`.toLowerCase().includes(lc),
    );
  }, [orderedRows, filter]);

  if (rows.length === 0) return null;

  return (
    <Stack spacing={1.5}>
      <SearchField value={filter} onChange={setFilter} placeholder="Filter configuration…" />
      <ResponsiveTableContainer>
        <Table size="small" sx={{ tableLayout: "fixed", width: "max-content" }}>
          <colgroup>
            <col style={{ width: widths.group }} />
            <col style={{ width: widths.setting }} />
            <col style={{ width: widths.global }} />
            <col style={{ width: widths.override }} />
            <col style={{ width: widths.effective }} />
            <col style={{ width: widths.status }} />
          </colgroup>
          <TableHead>
            <TableRow>
              <ResizableHeaderCell width={widths.group} onResize={(w) => resize("group", w)}>
                Area
              </ResizableHeaderCell>
              <ResizableHeaderCell width={widths.setting} onResize={(w) => resize("setting", w)}>
                Setting
              </ResizableHeaderCell>
              <ResizableHeaderCell width={widths.global} onResize={(w) => resize("global", w)}>
                Global
              </ResizableHeaderCell>
              <ResizableHeaderCell width={widths.override} onResize={(w) => resize("override", w)}>
                Client override
              </ResizableHeaderCell>
              <ResizableHeaderCell width={widths.effective} onResize={(w) => resize("effective", w)}>
                Effective
              </ResizableHeaderCell>
              <ResizableHeaderCell width={widths.status} onResize={(w) => resize("status", w)}>
                Status
              </ResizableHeaderCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredRows.map((row, i) => {
              const showGroup = i === 0 || filteredRows[i - 1].group !== row.group;
              const overridden = row.status === "overridden";
              return (
                <TableRow key={row.key} sx={overridden ? { bgcolor: CLIENT_HIGHLIGHT_BG } : undefined}>
                  <TableCell
                    sx={{
                      verticalAlign: "top",
                      fontWeight: 600,
                      fontSize: "0.8125rem",
                      whiteSpace: "normal !important",
                      color: showGroup ? "text.primary" : "transparent",
                      borderTop: showGroup && i !== 0 ? "2px solid" : undefined,
                      borderTopColor: showGroup && i !== 0 ? "divider" : undefined,
                    }}
                  >
                    {row.group}
                  </TableCell>
                  <TableCell
                    sx={{
                      verticalAlign: "top",
                      whiteSpace: "normal !important",
                      borderTop: showGroup && i !== 0 ? "2px solid" : undefined,
                      borderTopColor: showGroup && i !== 0 ? "divider" : undefined,
                    }}
                  >
                    <Typography variant="body2" sx={{ fontWeight: 700, lineHeight: 1.4 }}>
                      {row.label}
                    </Typography>
                    <Typography
                      variant="caption"
                      color="text.disabled"
                      sx={{ fontFamily: "monospace", display: "block", mt: 0.25 }}
                    >
                      {row.key}
                    </Typography>
                  </TableCell>
                  <TableCell
                    sx={{
                      verticalAlign: "top",
                      whiteSpace: "normal !important",
                      color: "text.secondary",
                      borderTop: showGroup && i !== 0 ? "2px solid" : undefined,
                      borderTopColor: showGroup && i !== 0 ? "divider" : undefined,
                    }}
                  >
                    <TruncatedString value={row.global.description} threshold={160} />
                  </TableCell>
                  <TableCell
                    sx={{
                      verticalAlign: "top",
                      whiteSpace: "normal !important",
                      borderTop: showGroup && i !== 0 ? "2px solid" : undefined,
                      borderTopColor: showGroup && i !== 0 ? "divider" : undefined,
                    }}
                  >
                    {overridden ? (
                      <TruncatedString value={formatConfigValue(row.override)} threshold={150} />
                    ) : (
                      <Typography variant="body2" color="text.disabled" sx={{ fontStyle: "italic" }}>
                        Inherited
                      </Typography>
                    )}
                  </TableCell>
                  <TableCell
                    sx={{
                      verticalAlign: "top",
                      whiteSpace: "normal !important",
                      fontWeight: overridden ? 700 : 400,
                      color: overridden ? "text.primary" : "text.secondary",
                      borderTop: showGroup && i !== 0 ? "2px solid" : undefined,
                      borderTopColor: showGroup && i !== 0 ? "divider" : undefined,
                    }}
                  >
                    <TruncatedString value={formatConfigValue(row.effective)} threshold={150} />
                  </TableCell>
                  <TableCell
                    sx={{
                      verticalAlign: "top",
                      borderTop: showGroup && i !== 0 ? "2px solid" : undefined,
                      borderTopColor: showGroup && i !== 0 ? "divider" : undefined,
                    }}
                  >
                    <Chip
                      label={overridden ? "Overridden" : "Inherited"}
                      size="small"
                      variant={overridden ? "filled" : "outlined"}
                      sx={
                        overridden
                          ? {
                              bgcolor: CLIENT_HIGHLIGHT_BG,
                              borderColor: CLIENT_HIGHLIGHT_BORDER,
                              color: "#5c4a00",
                              border: "1px solid",
                              fontWeight: 600,
                            }
                          : undefined
                      }
                    />
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </ResponsiveTableContainer>
      {filteredRows.length === 0 && (
        <Typography variant="body2" color="text.secondary">
          No configuration settings match “{filter}”.
        </Typography>
      )}
    </Stack>
  );
}
