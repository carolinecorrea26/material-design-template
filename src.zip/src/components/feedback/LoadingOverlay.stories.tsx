import type { Meta, StoryObj } from "@storybook/react-vite";
import { Alert, Box, Typography } from "@mui/material";
import LoadingOverlay from "./LoadingOverlay";

/**
 * LoadingOverlay has 4 size variants for 4 different contexts — sm (inline,
 * e.g. inside a button), md (section-level), lg (page-level), and
 * fullscreen (blocks the whole viewport for external-redirect/global-
 * submission flows). The fullscreen/lg variants are purpose-built for the
 * "processing/redirecting" screen currently hand-duplicated across
 * DocuSign.tsx, HealthQd.tsx, and Resume.tsx instead of using this
 * component (a Phase 1 audit finding, not fixed here).
 */
const meta = {
  title: "Feedback/LoadingOverlay",
  component: LoadingOverlay,
  parameters: { layout: "padded" },
} satisfies Meta<typeof LoadingOverlay>;

export default meta;

export const Small: StoryObj = {
  name: 'size="sm" (inline, e.g. inside a button)',
  render: () => <LoadingOverlay size="sm" />,
};

export const Medium: StoryObj = {
  name: 'size="md" (default — section-level)',
  render: () => <LoadingOverlay message="Loading your coverage options…" />,
};

export const Large: StoryObj = {
  name: 'size="lg" (page-level)',
  render: () => <LoadingOverlay size="lg" message="Loading…" />,
};

export const Fullscreen: StoryObj = {
  name: 'size="fullscreen" (blocks the viewport)',
  render: () => (
    <Box sx={{ position: "relative", height: 320, border: "1px dashed", borderColor: "divider" }}>
      <Typography variant="body2" sx={{ p: 2 }}>
        Page content behind the overlay (for demo purposes this story
        contains the overlay in a bounded box instead of a real{" "}
        <code>position: fixed</code> full-viewport takeover).
      </Typography>
      <Box sx={{ position: "absolute", inset: 0, overflow: "hidden" }}>
        <LoadingOverlay size="fullscreen" message="Redirecting to DocuSign…" />
      </Box>
    </Box>
  ),
};

export const NoMessage: StoryObj = {
  render: () => <LoadingOverlay />,
};

export const RecommendedExtraction: StoryObj = {
  name: "Recommended: ProcessingStatusPage",
  render: () => (
    <Alert severity="info" sx={{ maxWidth: 700 }}>
      DocuSign.tsx and HealthQd.tsx independently build the same full-page
      "redirecting…" screen (spinner + icon + heading + body) instead of
      using <code>LoadingOverlay size="fullscreen"</code>. Extracting a{" "}
      <code>ProcessingStatusPage</code> component was proposed in the Phase 1
      audit and remains deferred.
    </Alert>
  ),
};
