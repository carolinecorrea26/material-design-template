import { useEffect, useRef, useState, useSyncExternalStore } from "react";

import {
  AppBar,
  Badge,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Drawer,
  IconButton,
  LinearProgress,
  Link,
  Slide,
  Stack,
  Toolbar,
  Typography,
  useScrollTrigger,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import ChatIcon from "@mui/icons-material/Chat";
import CloseIcon from "@mui/icons-material/Close";
import PrivacyTipIcon from "@mui/icons-material/PrivacyTip";
import RequestQuoteRoundedIcon from "@mui/icons-material/RequestQuoteRounded";
import CalculateRoundedIcon from "@mui/icons-material/CalculateRounded";
import HelpRoundedIcon from "@mui/icons-material/HelpRounded";
import PhoneOutlinedIcon from "@mui/icons-material/PhoneOutlined";
import EmailOutlinedIcon from "@mui/icons-material/EmailOutlined";
import AccessTimeOutlinedIcon from "@mui/icons-material/AccessTimeOutlined";
import LanguageOutlinedIcon from "@mui/icons-material/LanguageOutlined";
import { CoverageOptionsDrawerContent } from "../../content/helpContent";
import CoverageNeedsCalculator from "../overlays/CoverageCalculator";
import CostEstimateDrawerContent from "../overlays/CostEstimate";
import FormHelpDrawer from "../help/Drawer";
import { pages } from "../../config/pages";
// import { getActiveClientCoverages } from "../../config/client/getActiveClientCoverages";
// import { coverageCategories } from "../../config/coverageCategories";
import type { CoverageDefinition } from "../../config/coverages/types";
import { getFormProgressPercent, isFormPage } from "../../config/formFlow";
import type { ClientConfig } from "../../config/clients/types";
import type { PageId } from "../../types";
import { useApplicationForm } from "../../app/ApplicationFormContext";
import { router } from "../../app/router";
import { APP_MENU_SECTION_TITLE_SX } from "../../app/theme";
import ApplicationSummaryDrawer, {
  useApplicationSummaryBadge,
} from "../overlays/ApplicationSummary";

type AppHeaderProps = {
  client: ClientConfig;
};

const currencyFormatter = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0,
});

function formatCoverageRange(coverage: CoverageDefinition) {
  if (coverage.minAmount == null && coverage.maxAmount == null) {
    return "Amount varies by selection.";
  }

  if (coverage.minAmount != null && coverage.maxAmount != null) {
    return `${currencyFormatter.format(coverage.minAmount)} - ${currencyFormatter.format(coverage.maxAmount)}`;
  }

  if (coverage.minAmount != null) {
    return `Starting at ${currencyFormatter.format(coverage.minAmount)}`;
  }

  return `Up to ${currencyFormatter.format(coverage.maxAmount ?? 0)}`;
}

function formatApplicants(applicants: CoverageDefinition["applicants"]) {
  const labels: Record<CoverageDefinition["applicants"][number], string> = {
    member: "Member",
    spouse: "Spouse",
    child: "Child",
  };

  return applicants.map((applicant) => labels[applicant]).join(", ");
}

function patchHistoryForLocationChangeEvents() {
  if (typeof window === "undefined") return;
  if (
    (window as typeof window & { __historyPatched__?: boolean })
      .__historyPatched__
  ) {
    return;
  }

  const originalPushState = window.history.pushState;
  const originalReplaceState = window.history.replaceState;

  window.history.pushState = function (...args) {
    originalPushState.apply(this, args);
    window.dispatchEvent(new Event("locationchange"));
  };

  window.history.replaceState = function (...args) {
    originalReplaceState.apply(this, args);
    window.dispatchEvent(new Event("locationchange"));
  };

  (
    window as typeof window & { __historyPatched__?: boolean }
  ).__historyPatched__ = true;
}

function subscribeToPathname(callback: () => void) {
  if (typeof window === "undefined") return () => {};

  patchHistoryForLocationChangeEvents();

  window.addEventListener("popstate", callback);
  window.addEventListener("locationchange", callback);

  return () => {
    window.removeEventListener("popstate", callback);
    window.removeEventListener("locationchange", callback);
  };
}

function getPathnameSnapshot() {
  if (typeof window === "undefined") return "/";
  return window.location.pathname;
}

export default function AppHeader({ client }: AppHeaderProps) {
  const [imageError, setImageError] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSummaryOpen, setIsSummaryOpen] = useState(false);
  const [summarySource, setSummarySource] = useState<
    "cart-icon" | "coverage-page"
  >("cart-icon");
  const [isCoverageDrawerOpen, setIsCoverageDrawerOpen] = useState(false);
  const [isNeedsCalcOpen, setIsNeedsCalcOpen] = useState(false);
  const [isQuoteDrawerOpen, setIsQuoteDrawerOpen] = useState(false);
  const [_addedSnackbarOpen, setAddedSnackbarOpen] = useState(false);
  const [activeCoverage, setActiveCoverage] =
    useState<CoverageDefinition | null>(null);
  const { values } = useApplicationForm();
  const summaryBadgeCount = useApplicationSummaryBadge();

  const pathname = useSyncExternalStore(
    subscribeToPathname,
    getPathnameSnapshot,
    () => "/",
  );

  const trigger = useScrollTrigger({
    // disableHysteresis: true,
    threshold: 8,
  });

  const normalizedPath =
    pathname.length > 1 && pathname.endsWith("/")
      ? pathname.slice(0, -1)
      : pathname;

  const currentPage = pages.find((page) => page.path === normalizedPath);

  const currentPageId = currentPage?.id as PageId | undefined;

  const showProgress =
    !!currentPage &&
    isFormPage(currentPage.id as PageId) &&
    currentPage.id !== "receipt";

  const overallProgressPercent =
    showProgress && currentPageId
      ? getFormProgressPercent(currentPageId, values)
      : 0;

  const showSummaryIcon =
    currentPageId !== undefined &&
    currentPageId !== "home" &&
    currentPageId !== "receipt";

  const prevCoverageCountRef = useRef<number>(
    Array.isArray(values.coverageSelections)
      ? values.coverageSelections.length
      : 0,
  );

  useEffect(() => {
    const currentCount = Array.isArray(values.coverageSelections)
      ? values.coverageSelections.length
      : 0;
    const prevCount = prevCoverageCountRef.current;
    prevCoverageCountRef.current = currentCount;

    if (
      currentPageId === "coverage" &&
      currentCount > prevCount &&
      prevCount >= 0
    ) {
      setAddedSnackbarOpen(true);
    }
  }, [values.coverageSelections, currentPageId]);

  const phone = client.support.phone;

  function handleNavigate(path: string) {
    setIsMenuOpen(false);
    void router.navigate(path);
  }

  return (
    <>
      <Slide appear={false} direction="down" in={!trigger}>
        <AppBar
          position="sticky"
          color="default"
          elevation={0}
          sx={{
            backgroundColor: "#fff",
            borderBottom: "none",
            boxShadow: "none",
            pt: 2,
            // pb: 2,
          }}
        >
          <Toolbar
            sx={{
              width: "100%",
              // maxWidth: 1400,
              marginLeft: "auto",
              marginRight: "auto",
              minHeight: "40px !important",
              px: { xs: 2, sm: 3, md: 4 },
              gap: 1,
              alignItems: "stretch",
              flexDirection: "column",
            }}
          >
            <Box
              sx={{
                width: "100%",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: 2,
              }}
            >
              <Box sx={{ display: "flex", alignItems: "center", minWidth: 0 }}>
                {imageError ? (
                  <Typography
                    variant="h6"
                    noWrap
                    sx={{ cursor: "pointer" }}
                    onClick={() => void router.navigate("/")}
                  >
                    {client.branding.name}
                  </Typography>
                ) : (
                  <Box
                    component="img"
                    src={client.branding.logo}
                    alt={client.branding.logoAlt}
                    onError={() => setImageError(true)}
                    onClick={() => void router.navigate("/")}
                    sx={{
                      height: "auto",
                      width: "auto",
                      maxWidth: { xs: 200, sm: 250 },
                      maxHeight: 35,
                      display: "block",
                      cursor: "pointer",
                    }}
                  />
                )}
              </Box>

              <Box
                sx={{
                  ml: "auto",
                  minWidth: 0,
                  textAlign: "right",
                }}
              >
                <Stack direction="row" spacing={0.75} alignItems="center">
                  {client.features?.chat && showSummaryIcon && (
                    <IconButton
                      aria-label="Open chat"
                      size="small"
                      sx={{ borderRadius: 1, gap: 0.5 }}
                    >
                      <ChatIcon sx={{ color: "primary.main" }} />
                      <Typography
                        variant="caption"
                        fontWeight="bold"
                        sx={{
                          color: "primary.main",
                          display: { xs: "none", sm: "block" },
                        }}
                      >
                        Chat
                      </Typography>
                    </IconButton>
                  )}

                  {showSummaryIcon && (
                    <IconButton
                      aria-label="Open coverage requested"
                      onClick={() => {
                        setSummarySource("cart-icon");
                        setIsSummaryOpen(true);
                      }}
                      size="small"
                      sx={{ borderRadius: 1, gap: 0.5 }}
                    >
                      <Badge
                        badgeContent={summaryBadgeCount}
                        color="error"
                        max={99}
                      >
                        <ShoppingCartIcon sx={{ color: "primary.main" }} />
                      </Badge>
                      {/* <Typography
                        variant="body2"
                        sx={{
                          color: "primary.main",
                          fontWeight: 700,
                          fontSize: "0.75rem",
                          display: { xs: "none", sm: "block" },
                        }}
                      >
                        Cart
                      </Typography> */}
                    </IconButton>
                  )}

                  <IconButton
                    aria-label="Open application navigation menu"
                    onClick={() => setIsMenuOpen(true)}
                    size="small"
                  >
                    <MenuIcon />
                  </IconButton>
                </Stack>
              </Box>
            </Box>

            {showProgress && (
              <Box sx={{ width: "100%", minWidth: 0 }}>
                <LinearProgress
                  variant="determinate"
                  value={overallProgressPercent}
                  aria-label="Overall application progress"
                  sx={{
                    width: {
                      xs: "calc(100% + 32px)",
                      sm: "calc(100% + 48px)",
                      md: "calc(100% + 64px)",
                    },
                    // height: 8,
                    mx: { xs: -2, sm: -3, md: -4 },
                    mt: 2,
                    // bgcolor: "rgb(0 0 0 / 6%)",
                    "& .MuiLinearProgress-bar": {
                      bgcolor: "primary.main",
                    },
                  }}
                />
              </Box>
            )}
          </Toolbar>
        </AppBar>
      </Slide>

      <Drawer
        anchor="right"
        open={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        sx={{
          "& .MuiDrawer-paper": {
            width: { xs: "80vw", sm: 420 },
            maxWidth: "100%",
            p: 2,
          },
        }}
      >
        <Stack spacing={2} sx={{ height: "100%" }}>
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 1,
            }}
          >
            <Typography variant="subtitle1" fontWeight="bold">
              Menu
            </Typography>

            <IconButton
              aria-label="Close application navigation menu"
              onClick={() => setIsMenuOpen(false)}
            >
              <CloseIcon />
            </IconButton>
          </Box>

          <Box
            sx={{
              p: 2,
              borderRadius: 1,

              bgcolor: "background.subtle",
            }}
          >
            <Stack spacing={1}>
              <Typography variant="subtitle1" sx={APP_MENU_SECTION_TITLE_SX}>
                Continue Saved Application
              </Typography>
              <Typography variant="body2" sx={{ color: "text.secondary" }}>
                You can continue your saved application below. Applications are
                only saved for 10 days from starting.
              </Typography>
            </Stack>
            <Button
              variant="contained"
              fullWidth
              onClick={() => handleNavigate("/resume")}
              sx={{ margin: "1.25rem 0" }}
            >
              Continue Application
            </Button>
          </Box>

          <Box
            sx={{
              p: 2,
              borderRadius: 1,

              bgcolor: "background.subtle",
            }}
          >
            <Stack spacing={2}>
              <Typography variant="subtitle1" sx={APP_MENU_SECTION_TITLE_SX}>
                Application Tools
              </Typography>
              <Box
                sx={{
                  display: "grid",
                  gridTemplateColumns: "1fr 1fr",
                  gap: 1.5,
                }}
              >
                <Button
                  variant="outlined"
                  onClick={() => {
                    setIsMenuOpen(false);
                    setIsCoverageDrawerOpen(true);
                  }}
                  sx={{
                    flexDirection: "column",
                    textTransform: "none",
                    py: 2,
                    px: 1,
                    gap: 0.5,
                    borderRadius: 2,
                    minHeight: 80,
                  }}
                >
                  <PrivacyTipIcon />
                  <Typography variant="caption" fontWeight={600}>
                    About Coverage
                  </Typography>
                </Button>
                <Button
                  variant="outlined"
                  onClick={() => {
                    setIsMenuOpen(false);
                    setIsQuoteDrawerOpen(true);
                  }}
                  sx={{
                    flexDirection: "column",
                    textTransform: "none",
                    py: 2,
                    px: 1,
                    gap: 0.5,
                    borderRadius: 2,
                    minHeight: 80,
                  }}
                >
                  <RequestQuoteRoundedIcon />
                  <Typography variant="caption" fontWeight={600}>
                    Get Quote
                  </Typography>
                </Button>
                <Button
                  variant="outlined"
                  onClick={() => {
                    setIsMenuOpen(false);
                    setIsNeedsCalcOpen(true);
                  }}
                  sx={{
                    flexDirection: "column",
                    textTransform: "none",
                    py: 2,
                    px: 1,
                    gap: 0.5,
                    borderRadius: 2,
                    minHeight: 80,
                  }}
                >
                  <CalculateRoundedIcon />
                  <Typography variant="caption" fontWeight={600}>
                    Needs Calculator
                  </Typography>
                </Button>
                <Button
                  variant="outlined"
                  onClick={() => {
                    setIsMenuOpen(false);
                  }}
                  sx={{
                    flexDirection: "column",
                    textTransform: "none",
                    py: 2,
                    px: 1,
                    gap: 0.5,
                    borderRadius: 2,
                    minHeight: 80,
                  }}
                >
                  <HelpRoundedIcon />
                  <Typography variant="caption" fontWeight={600}>
                    FAQ
                  </Typography>
                </Button>
              </Box>
            </Stack>
          </Box>

          <Box
            sx={{
              p: 2,
              borderRadius: 1,

              bgcolor: "background.subtle",
            }}
          >
            <Stack spacing={1.5}>
              <Typography variant="subtitle1" sx={APP_MENU_SECTION_TITLE_SX}>
                Contact Us
              </Typography>
              <Stack spacing={1}>
                <Typography variant="body2">{client.branding.name}</Typography>
                {client.support.website && (
                  <Stack direction="row" spacing={1} alignItems="center">
                    <LanguageOutlinedIcon
                      sx={{ fontSize: 18, color: "text.secondary" }}
                    />
                    <Link
                      href={`https://${client.support.website}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      underline="hover"
                      variant="body2"
                    >
                      {client.support.website}
                    </Link>
                  </Stack>
                )}
                {client.support.email && (
                  <Stack direction="row" spacing={1} alignItems="center">
                    <EmailOutlinedIcon
                      sx={{ fontSize: 18, color: "text.secondary" }}
                    />
                    <Link
                      href={`mailto:${client.support.email}`}
                      underline="hover"
                      variant="body2"
                    >
                      {client.support.email}
                    </Link>
                  </Stack>
                )}
                {phone && (
                  <Stack direction="row" spacing={1} alignItems="center">
                    <PhoneOutlinedIcon
                      sx={{ fontSize: 18, color: "text.secondary" }}
                    />
                    <Link
                      href={`tel:${phone}`}
                      underline="hover"
                      variant="body2"
                    >
                      {client.support.phoneDisplay ?? phone}
                    </Link>
                  </Stack>
                )}
                {client.support.phoneHours && (
                  <Stack direction="row" spacing={1} alignItems="center">
                    <AccessTimeOutlinedIcon
                      sx={{ fontSize: 18, color: "text.secondary" }}
                    />
                    <Typography variant="body2" color="text.secondary">
                      {client.support.phoneHours}
                    </Typography>
                  </Stack>
                )}
              </Stack>
            </Stack>
          </Box>

          <Box sx={{ mt: "auto" }} />
        </Stack>
      </Drawer>

      <FormHelpDrawer
        open={isCoverageDrawerOpen}
        title="What are my coverage options?"
        onClose={() => setIsCoverageDrawerOpen(false)}
      >
        <CoverageOptionsDrawerContent />
      </FormHelpDrawer>

      <FormHelpDrawer
        open={isNeedsCalcOpen}
        title="How much coverage do I need?"
        onClose={() => setIsNeedsCalcOpen(false)}
      >
        <CoverageNeedsCalculator />
      </FormHelpDrawer>

      <FormHelpDrawer
        open={isQuoteDrawerOpen}
        title="How much does it cost?"
        onClose={() => setIsQuoteDrawerOpen(false)}
      >
        <CostEstimateDrawerContent />
      </FormHelpDrawer>

      <Dialog
        open={Boolean(activeCoverage)}
        onClose={() => setActiveCoverage(null)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>{activeCoverage?.name ?? "Coverage Details"}</DialogTitle>

        <DialogContent dividers>
          <Stack spacing={1.5}>
            <Typography variant="body2" color="text.secondary">
              {activeCoverage?.description ?? activeCoverage?.definition}
            </Typography>

            <Typography variant="body2">
              <Box component="span" sx={{ fontWeight: 700 }}>
                Benefit amount:
              </Box>
              {activeCoverage ? formatCoverageRange(activeCoverage) : "-"}
            </Typography>

            {activeCoverage?.coverageNote ? (
              <Typography variant="body2">
                <Box component="span" sx={{ fontWeight: 700 }}>
                  Coverage note:
                </Box>
                {activeCoverage.coverageNote}
              </Typography>
            ) : null}

            {activeCoverage ? (
              <Typography variant="body2">
                <Box component="span" sx={{ fontWeight: 700 }}>
                  Eligible applicants:
                </Box>
                {formatApplicants(activeCoverage.applicants)}
              </Typography>
            ) : null}

            {activeCoverage?.waitingPeriodOptions?.length ? (
              <Typography variant="body2">
                <Box component="span" sx={{ fontWeight: 700 }}>
                  Waiting periods:
                </Box>
                {activeCoverage.waitingPeriodOptions
                  .map((option) => option.label)
                  .join(", ")}
              </Typography>
            ) : null}

            {activeCoverage?.maxBenefitPeriodOptions?.length ? (
              <Typography variant="body2">
                <Box component="span" sx={{ fontWeight: 700 }}>
                  Max benefit periods:
                </Box>
                {activeCoverage.maxBenefitPeriodOptions
                  .map((option) => option.label)
                  .join(", ")}
              </Typography>
            ) : null}

            {activeCoverage?.riders?.length ? (
              <Stack spacing={0.75}>
                <Typography variant="body2" sx={{ fontWeight: 700 }}>
                  Available riders
                </Typography>

                {activeCoverage.riders.map((rider) => (
                  <Typography
                    key={rider.id}
                    variant="body2"
                    color="text.secondary"
                  >
                    {rider.name}: {rider.description}
                  </Typography>
                ))}
              </Stack>
            ) : null}

            <Link
              component="button"
              type="button"
              underline="hover"
              color="primary"
              sx={{ alignSelf: "flex-start", fontWeight: 700 }}
            >
              View full coverage details
            </Link>
          </Stack>
        </DialogContent>

        <DialogActions>
          <Button onClick={() => setActiveCoverage(null)}>Close</Button>
        </DialogActions>
      </Dialog>

      <ApplicationSummaryDrawer
        open={isSummaryOpen}
        onClose={() => setIsSummaryOpen(false)}
        source={summarySource}
      />

      {/* <Snackbar
        open={addedSnackbarOpen}
        autoHideDuration={2000}
        onClose={() => setAddedSnackbarOpen(false)}
        message="Added!"
        anchorOrigin={{ vertical: "top", horizontal: "right" }}
        sx={{
          "& .MuiSnackbarContent-root": {
            minWidth: "auto",
            px: 2,
            py: 0.5,
            bgcolor: "success.main",
            fontWeight: 600,
          },
          top: { xs: "70px !important", sm: "70px !important" },
        }}
      /> */}
    </>
  );
}
