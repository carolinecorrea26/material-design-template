import { useState } from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { Stack, Typography } from "@mui/material";
import RateFrequencyToggle from "./RateFrequencyToggle";
import type { EstimatedRateFrequency } from "../../config/clients/types";

/**
 * RateFrequencyToggle is a styled MUI Switch with no props of its own beyond
 * Switch's — the monthly/annual meaning comes entirely from how a consumer
 * wires `checked`/`onChange`, which is why every story below builds that
 * wiring locally rather than the component providing it.
 *
 * The "Monthly [switch] Annual" label row around this switch is duplicated
 * verbatim in two real call sites — CoverageCart.tsx:713-746 and
 * QuoteCalculator.tsx:879-922 — a real, not-yet-fixed extraction candidate
 * (`RateFrequencyControl`) flagged in the Phase 1 audit and still open as of
 * this phase. The demo below reproduces that exact label-row shape so it's
 * visible here, but this story does not extract the shared component itself
 * — that's cleanup-phase scope, not documentation-phase scope.
 */
const meta = {
  title: "Coverage & Commerce/RateFrequencyToggle",
  component: RateFrequencyToggle,
  parameters: { layout: "centered" },
} satisfies Meta<typeof RateFrequencyToggle>;

export default meta;

function LabelRowDemo() {
  const [frequency, setFrequency] = useState<EstimatedRateFrequency>("monthly");
  return (
    <Stack direction="row" alignItems="center" spacing={1}>
      <Typography
        variant="body2"
        sx={{ fontWeight: frequency === "monthly" ? 700 : 400 }}
      >
        Monthly
      </Typography>
      <RateFrequencyToggle
        checked={frequency === "annual"}
        onChange={(e) => setFrequency(e.target.checked ? "annual" : "monthly")}
        inputProps={{ "aria-label": "Toggle between monthly and annual rate display" }}
      />
      <Typography
        variant="body2"
        sx={{ fontWeight: frequency === "annual" ? 700 : 400 }}
      >
        Annual
      </Typography>
    </Stack>
  );
}

export const MonthlyAnnualLabelRow: StoryObj = {
  name: '"Monthly [switch] Annual" label row (duplicated in 2 real files)',
  render: () => <LabelRowDemo />,
};

export const Unchecked: StoryObj = {
  render: () => <RateFrequencyToggle inputProps={{ "aria-label": "Rate frequency" }} />,
};

export const Checked: StoryObj = {
  render: () => <RateFrequencyToggle defaultChecked inputProps={{ "aria-label": "Rate frequency" }} />,
};
