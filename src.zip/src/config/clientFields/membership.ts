import type { ClientPageFieldConfig, ConditionalFieldDefinition } from "../fields/types";
import { fieldCatalog } from "../fields";
import type {
  ActiveAssociationResolution,
  AssociationSelectionMode,
  SiteId,
} from "../../data";
import type { ClientId } from "../../types";

export type MembershipClientFieldConfig = ClientPageFieldConfig;

export function shouldShowMembershipFollowUpFields({
  clientId,
  selectionMode,
  membershipValue,
  associationStatus,
}: {
  clientId: ClientId;
  selectionMode?: AssociationSelectionMode;
  membershipValue: unknown;
  associationStatus: ActiveAssociationResolution["status"];
}): boolean {
  if (selectionMode === "select") {
    return associationStatus === "resolved";
  }
  if (clientId === "ama") return Boolean(membershipValue);
  if (clientId === "waepa") {
    return membershipValue === "current" || membershipValue === "new";
  }
  return membershipValue === "yes";
}

const waepaExtraFields: ConditionalFieldDefinition[] = [
  fieldCatalog["waepa-declaration"],
  fieldCatalog["waepa-attestation"],
  fieldCatalog["waepa-employer"],
  fieldCatalog["waepa-start-date"],
  fieldCatalog["waepa-retired-employer"],
  fieldCatalog["waepa-retirement-date"],
  fieldCatalog["waepa-member-first-name"],
  fieldCatalog["waepa-member-last-name"],
  fieldCatalog["waepa-member-id"],
].map((field) => ({
  ...field,
  visibleWhen: [{ fieldId: "membership", equals: "new" }],
}));

const avmaExtraFields = [
  fieldCatalog["avma-vet-college"],
  fieldCatalog["avma-graduation-year"],
  fieldCatalog["avma-occupation"],
];

const asceExtraFields = [fieldCatalog["asce-member-id"]];

const cseaExtraFields = [
  fieldCatalog["csea-performing-duties"],
  fieldCatalog["csea-occupation-group"],
];

const amaExtraFields: ConditionalFieldDefinition[] = [
  fieldCatalog["ama-physician-type"],
  fieldCatalog["ama-physician-title"],
  fieldCatalog["ama-physician-first-name"],
  fieldCatalog["ama-physician-last-name"],
  fieldCatalog["ama-physician-birth-date"],
  fieldCatalog["ama-physician-email"],
].map((field) => ({
  ...field,
  visibleWhen: [{ fieldId: "membership", equals: "spouse" }],
}));

export const membershipClientFields: Partial<
  Record<SiteId, MembershipClientFieldConfig>
> = {
  "demo-default": {
    overrides: {
      title: { hidden: true },
      membership: {
        label: "Are you an active member of Demo Insurance?",
      },
    },
    extraFields: [],
  },
  "abe-default": {
    overrides: {
      title: { hidden: true },
      membership: {
        label:
          "Are you an active member of a State, Local, or Specialty Bar Association?",
      },
    },
    extraFields: [],
  },
  // ama is the one client that shows the "title" field — no title override needed.
  "ama-default": {
    overrides: {
      membership: {
        label: "I am a (select one)",
        inputType: "dropdown",
        labelVariant: "standard",
        placeholder: "Select one",
        options: [
          { label: "Physician", value: "physician" },
          { label: "Resident", value: "resident" },
          { label: "Student", value: "student" },
          { label: "Retired Physician", value: "retired" },
          { label: "Spouse of Physician", value: "spouse" },
        ],
      },
    },
    extraFields: amaExtraFields,
  },
  "asce-default": {
    overrides: {
      title: { hidden: true },
      membership: {
        label:
          "Are you a member of the American Society of Civil Engineers?",
      },
    },
    extraFields: asceExtraFields,
  },
  "avma-default": {
    overrides: {
      title: { hidden: true },
      membership: {
        label:
          "Are you a member of the American Veterinary Medical Association?",
      },
    },
    extraFields: avmaExtraFields,
  },
  "csea-default": {
    overrides: {
      title: { hidden: true },
      membership: {
        label: "Are you a member of the CSEA?",
      },
    },
    extraFields: cseaExtraFields,
  },
  "isitrust-default": {
    overrides: {
      title: { hidden: true },
      membership: {
        label: "I am a member of:",
        inputType: "searchable-select",
        labelVariant: "standard",
        placeholder: "Search or select association",
      },
    },
    extraFields: [],
  },
  "nso-default": {
    overrides: {
      title: { hidden: true },
      membership: {
        label: "Are you a nurse?",
      },
    },
    extraFields: [],
  },
  "waepa-standard": {
    overrides: {
      title: { hidden: true },
      membership: {
        label:
          "Are you a current WAEPA member, or are you becoming a new member?",
        inputType: "radio",

        options: [
          { label: "Current Member", value: "current" },
          { label: "New Member", value: "new" },
        ],
      },
    },
    extraFields: waepaExtraFields,
  },
  // No membership-specific label override for waepagi (uses the global default),
  // but it still hides "title" like every client except ama.
  "waepa-gi": {
    overrides: {
      title: { hidden: true },
    },
  },
};
