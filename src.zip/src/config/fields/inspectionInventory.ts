/** Inspection-only inventory: never feeds page rendering, validation, or persistence.
 * Includes conditional and repeated inputs in addition to the flat runtime registry.
 */
import { fieldCatalog } from ".";
import { getQuoteQuestionFieldIds, homeQuoteFieldIds } from "./homeQuoteFields";
import { needsCalculatorFields } from "./needsCalculatorFields";
import { getPageCategory } from "../resolvers/resolveClientPages";
import { childMapping } from "./eligibilityListFields";
import { SECURITY_QUESTIONS } from "./verificationFields";
import { resolveCoverageQuestionSections } from "../resolvers/resolveCoverageQuestionSections";
import { coverageFactFieldIds } from "./coverageFactFields";
import { pageFieldOrder } from "./pageFieldOrder";
import { getResolvedFieldResolutionsForSite } from "./resolvedFieldRegistry";
import { pages } from "../pages";
import { pageSections } from "../pageSections/pageSections";
import { siteEntities, getEffectiveSiteConfig } from "../../data/registry";
import { getClientCoverages } from "../client/getActiveClientCoverages";
import { getClientPageRequirement } from "../client/getClientPageRequirement";
import { coverageUnlocksPage, getFlowGateDefinition } from "../flowGates";
import { createAnswerFields as siAnswers, detailsFields as siDetails } from "./healthSiFields";
import { createQuestionFields as liAnswers, detailsFields as liDetails } from "./healthLiFields";
import { createAnswerFields as diAnswers, QUESTIONS as diQuestions } from "./healthDiFields";
import { disabilityCompanyMapping } from "./profileListFields";
import { BENEFICIARY_INDIVIDUAL_FIELDS, BENEFICIARY_TRUST_FIELDS, beneficiaryInfoOptInField } from "./beneficiaryFields";
import { paymentMethodOptions, paymentFrequencyOptions, paymentInfoOptInField } from "./paymentFields";
import type { FieldDefinition } from "./types";
import type { PageId } from "../../types";

export type FieldPlacement = {
  pageId: PageId;
  accessPath: string;
  presentation: "inline" | "drawer";
  condition: string;
};
export type FieldGroup = { id: string; label: string };
export type InspectedField = {
  field: FieldDefinition;
  pageId: PageId | null;
  group?: FieldGroup;
  placements?: FieldPlacement[];
  area: string;
  condition: string;
  storage: string;
  status: string;
  notes: string[];
  sites: string[];
};
const catalog = fieldCatalog as Record<string, FieldDefinition>;
const cache = new Map<string, InspectedField[]>();
export function getSiteFieldInventory(siteId: string): InspectedField[] {
  const cached = cache.get(siteId); if (cached) return cached;
  const client = getEffectiveSiteConfig(siteId);
  const products = getClientCoverages(client);
  const result: InspectedField[] = [];
  const coverageFields = new Set([
    ...resolveCoverageQuestionSections({sections:pageSections.coverage ?? [],selectedCategories:products.map(p=>p.categoryId),coverageQuestions:client.coverageQuestions}).flatMap(s=>s.fieldIds),
    ...coverageFactFieldIds(products),
  ]);
  const enabled = (page: PageId) => getClientPageRequirement(page, client) !== "none" && (!getFlowGateDefinition(page) || products.some(p => coverageUnlocksPage(page, p)));
  const add = (pageId: PageId, field: FieldDefinition, area: string, condition: string, storage = field.id, status = "page-defined", notes: string[] = []) => {
    if (enabled(pageId)) result.push({ field, pageId, area, condition, storage, status, notes, sites: [siteId] });
  };
  for (const page of pages) {
    if (page.type === "internal" || !enabled(page.id)) continue;
    for (const row of getResolvedFieldResolutionsForSite(page.id, siteId)) {
      if (!row.included) continue;
      if (page.id === "coverage" && !coverageFields.has(row.fieldId)) continue;
      const section = pageSections[page.id]?.find(s => s.fieldIds.includes(row.fieldId));
      if (page.id === "profile" && section?.id.startsWith("profileFinancial")) {
        const applicant = section.applicant === "spouse" ? "spouse" : "member";
        const category = section.id === "profileFinancialQuestionnaireSelf" || row.field.id.includes("disability") ? "DI" : "LI";
        if (!products.some(p=>p.categoryId===category && p.applicants.includes(applicant))) continue;
      }
      add(page.id, row.field, section?.id ?? "Page", [section?.visibilityConditionId, row.field.visibilityConditionId].filter(Boolean).join("; ") || "Page and field visibility rules apply", row.field.id, row.status, row.notes);
      if (row.field.format === "phone" && row.field.showPhoneTypeSelector !== false) {
        const id = row.field.phoneTypeFieldId ?? "phone-type";
        add(page.id, { id, label: "Phone Type", inputType: "dropdown", required: true, options: ["mobile", "home", "business"].map(value => ({value,label: value})) }, section?.id ?? "Page", `Shown with ${row.field.id}`, id, "component-defined");
      }
    }
  }
  const childKeys: Record<string,string> = {...childMapping.fieldToKey,"child-unmarried":"unmarried","child-full-time-student":"fullTimeStudent"};
  for (const [id,key] of Object.entries(childKeys)) {
    const registered = result.find(r => r.pageId === "eligibility" && r.field.id === id);
    if (id === "child-unmarried" || id === "child-full-time-student") {
      if (registered) Object.assign(registered, {area:"childSection",storage:`children[].${key}`,condition:"Child selected; repeated for each child"});
    } else add("eligibility", catalog[id], "childSection", "Child selected; repeated for each child", `children[].${key}`);
  }
  for (const applicant of ["self", "spouse"] as const) {
    const applicantType = applicant === "self" ? "member" : "spouse";
    for (const page of ["health-si","health-li","health-di"] as const) {
      if (!products.some(p => p.applicants.includes(applicantType) && (page === "health-si" || coverageUnlocksPage(page,p)))) continue;
      const answers = page === "health-si" ? siAnswers(applicant) : page === "health-li" ? liAnswers(applicant) : diAnswers(applicant);
      answers.forEach((field,index) => {
        add(page, field, applicant, "Applicant participating in this health page");
        const details = page === "health-si" ? siDetails : page === "health-li" ? liDetails : diQuestions[index].mapping.fields;
        for (const detail of details) {
          const storage = `${field.id}-details[].${detail.id}`;
          add(page, {...detail,id:storage}, `${applicant} / ${field.id} details`, `${field.id} = yes; repeated detail records`, storage);
        }
      });
    }
    for (const field of products.some(p=>p.categoryId === "DI" && p.applicants.includes(applicantType)) ? disabilityCompanyMapping.fields : []) {
      const key = disabilityCompanyMapping.fieldToKey[field.id as keyof typeof disabilityCompanyMapping.fieldToKey];
      const storage = `${applicant}DisabilityCompanies[].${key}`;
      add("profile", {...field,id:`${applicant}-${field.id}`}, `${applicant} / existing disability insurance`, "Applicant has existing disability insurance and applicable coverage", storage);
    }
    add("review", catalog[`review-${applicant}-consent`], applicant, applicant === "self" ? "Review page" : "Spouse applying");
  }
  if (getClientPageRequirement("beneficiary",client) === "optional") add("beneficiary",beneficiaryInfoOptInField,"Page","Optional beneficiary page");
  for (const field of [...BENEFICIARY_INDIVIDUAL_FIELDS,...BENEFICIARY_TRUST_FIELDS, {id:"beneficiaryType",label:"Beneficiary Type",inputType:"radio" as const,options:[{value:"individual",label:"Individual"},{value:"trust",label:"Trust"}]}]) {
    add("beneficiary", {...field,id:`beneficiary-${field.id}`}, "Beneficiary / per product and applicant", `${field.id.startsWith("trust") ? "Trust" : field.id === "beneficiaryType" ? "Individual or trust" : "Individual"}; primary or contingent; selected LI/AD coverage`, `beneficiaries[product:applicant][].${field.id}`);
  }
  if (getClientPageRequirement("payment",client) === "optional") add("payment",paymentInfoOptInField,"Page","Optional payment page");
  for (const product of products) {
    for (const [kind,label,inputType,options] of [["method","Payment Method","radio",paymentMethodOptions],["frequency","Payment Frequency","dropdown",paymentFrequencyOptions]] as const) {
      add("payment", {id:`payment-${kind}:${product.id}`,label,inputType,options:options.map(o=>({value:o.value,label:o.label}))},product.name,"Selected product with nonzero amount; payment information enabled");
    }
    for (const applicant of product.applicants) {
      const key = `${product.id}:${applicant}`;
      const area = `${product.name} / ${applicant}`;
      const control = (id:string,label:string,inputType:FieldDefinition["inputType"], storage:string, options?:FieldDefinition["options"]) => add("coverage",{id,label,inputType,options},area,"Product/applicant selected; eligibility and amount rules apply",storage,"component-defined");
      control(`coverage-applicant:${key}`,"Applicant selection","checkbox",`productApplicants[${product.id}]`);
      control(`coverage-amount:${key}`,"Coverage Amount","dropdown",`coverageAmounts[${key}]`);
      const waiting = product.waitingPeriodOptionsByApplicant?.[applicant] ?? product.waitingPeriodOptions;
      const benefit = product.maxBenefitPeriodOptionsByApplicant?.[applicant] ?? product.maxBenefitPeriodOptions;
      if (["DI","OO"].includes(product.categoryId)) {
        if (waiting) control(`coverage-waiting:${key}`,"Waiting Period","dropdown",`coverageWaitingPeriods[${key}]`,waiting);
        if (benefit) control(`coverage-benefit:${key}`,product.categoryId === "DI" ? "Benefit Option" : "Maximum Benefit Period","dropdown",`coverageMaxBenefitPeriods[${key}]`,benefit);
      }
      for (const rider of product.riders ?? []) if (!rider.applicants || rider.applicants.includes(applicant)) {
        const riderKey=`${product.id}:${rider.id}:${applicant}`;
        control(`coverage-rider:${riderKey}`,rider.name,"checkbox",`coverageRiders[${riderKey}]`);
        if (rider.hasAmount && rider.coverageAmounts) control(`coverage-rider-amount:${riderKey}`,`${rider.name} amount`,"dropdown",`coverageRiderAmounts[${riderKey}]`);
      }
    }
  }
  add("coverage",{id:"selectedCategoryChips",label:"Coverage categories",inputType:"checkbox-group"},"Coverage selection","Select coverage categories","selectedCategoryChips","component-defined");
  if (client.features?.memberVerificationMatchFacts) {
    add("eligibility",{id:"verification-method",label:"Verification Method",inputType:"radio",options:["text","voice","security-questions","skip"].map(value=>({value,label:value}))},"Member verification","Configured member match; verification dialog open","Local dialog state","component-defined");
    for (const question of SECURITY_QUESTIONS) add("eligibility",{id:question.id,label:question.question,inputType:"radio",options:question.options.map(value=>({value,label:value}))},"Member verification / sample security questions","Security questions verification method selected","Local dialog state","component-defined");
  }
  for (const block of client.reviewPolicy?.blocks ?? []) for (const id of block.fields) {
    if (client.fields.review?.hidden?.includes(id)) continue;
    add("review", { ...catalog[id], ...client.fields.review?.overrides?.[id] }, block.title, block.when?.applicant ? `${block.when.applicant} applying` : "Review page", id, "site-configured", block.sourceReferences);
  }
  const quoteGroup = { id: "quote-calculator", label: "Quote calculator" };
  const quotePlacements: FieldPlacement[] = [];
  if (enabled("membership")) quotePlacements.push({
    pageId: "membership", accessPath: 'Help chip → How much does it cost?',
    presentation: "drawer", condition: "Quote helper open",
  });
  const homeVariant = client.features?.homePageVariant ?? "default";
  const homeQuoteEnabled = enabled("home") && client.features?.defaultTemplate !== "single" && ["default", "quoteFirst"].includes(homeVariant);
  if (homeQuoteEnabled) quotePlacements.push({
    pageId: "home", accessPath: homeVariant === "quoteFirst" ? "Inline quote calculator" : "Eligibility card → See my quote",
    presentation: homeVariant === "quoteFirst" ? "inline" : "drawer",
    condition: homeVariant === "quoteFirst" ? "Quote step shown" : "Quote drawer open",
  });
  const addTool = (group: FieldGroup, placements: FieldPlacement[], field: FieldDefinition, condition: string, storage: string) => {
    if (placements.length) result.push({field, pageId: null, group, placements, area: group.label, condition, storage, status: "component-defined", notes: [], sites: [siteId]});
  };
  // Home's default card collects eligibility before opening the tool. Other
  // inputs belong to the calculator, including its inline Home placement.
  for (let index = result.length - 1; index >= 0; index--) {
    const row = result[index];
    if (row.pageId === "home" && homeQuoteFieldIds.some(id => id === row.field.id)) {
      if (homeVariant !== "default" || !homeQuoteFieldIds.slice(0, 3).some(id => id === row.field.id)) result.splice(index, 1);
    }
  }
  const quoteQuestions = new Set(getQuoteQuestionFieldIds(client, products.map(p => p.categoryId)));
  for (const [index, id] of homeQuoteFieldIds.entries()) {
    if (index >= 3 && !quoteQuestions.has(id)) continue;
    const placements = index < 3 ? quotePlacements.filter(p => p.pageId !== "home" || homeVariant === "quoteFirst") : quotePlacements;
    addTool(quoteGroup, placements, catalog[id], index < 3 ? "Eligibility collected in calculator" : "Relevant coverage category selected", "Local quote state; copied to application when applying");
  }
  for (const product of products.filter(p => p.applicants.includes("member"))) {
    addTool(quoteGroup, quotePlacements, {id:`quote-selection:${product.id}`,label:`${product.name} selection`,inputType:"checkbox"}, "Quote results shown", "Local quote state");
    addTool(quoteGroup, quotePlacements, {id:`quote-amount:${product.id}`,label:`${product.name} amount`,inputType:"dropdown"}, "Quote product selected", "Local quote state");
  }
  if (new Set(products.map(p => p.categoryId)).size > 1) addTool(quoteGroup, quotePlacements, {id:"quote-categories",label:"Coverage categories",inputType:"checkbox-group"}, "Multiple coverage categories available", "Local quote state");
  if (client.coverages.estimatedRateDisplay?.showFrequencyToggle) {
    add("coverage",{id:"coverage-rate-frequency",label:"Rate display frequency",inputType:"radio"},"Estimated rates","Frequency toggle enabled","Local display state","component-defined");
    addTool(quoteGroup, quotePlacements, {id:"quote-rate-frequency",label:"Rate display frequency",inputType:"radio"}, "Quote results shown; frequency toggle enabled", "Local display state");
  }
  const needsPlacements: FieldPlacement[] = pages
    .filter(page => (getPageCategory(page) === "application" || page.id === "home") && enabled(page.id))
    .map(page => ({pageId: page.id, accessPath: "Application menu → How much coverage do I need?", presentation: "drawer", condition: "Needs calculator drawer open"}));
  for (const field of needsCalculatorFields) addTool(
    {id: "needs-calculator", label: "Needs calculator"}, needsPlacements,
    field, "Needs calculator drawer open", "Local calculator state (not saved)",
  );
  // Bank fields are rendered only when a product uses a bank account.
  for (const row of result) if (row.pageId === "payment" && row.field.id.startsWith("bank-")) row.condition="At least one product uses Bank account; payment information enabled";
  const unique = [...new Map(result.map(row => [JSON.stringify([row.pageId,row.field,row.area,row.storage]),row])).values()];
  cache.set(siteId,unique); return unique;
}
let globalInventory: InspectedField[] | undefined;
export function getGlobalFieldInventory(): InspectedField[] {
  if (globalInventory) return globalInventory;
  const grouped = new Map<string,InspectedField>();
  for (const site of siteEntities) for (const row of getSiteFieldInventory(site.id)) {
    const key = JSON.stringify([row.field,row.pageId,row.area,row.storage,row.condition,row.group,row.placements]);
    const existing=grouped.get(key);
    if (existing) existing.sites.push(site.id);
    else grouped.set(key,{...row,sites:[site.id]});
  }
  // Retain baseline definitions even when all current Sites override or omit them.
  for (const field of Object.values(fieldCatalog)) {
    const placements=[...new Set([...Object.entries(pageFieldOrder).filter(([,ids])=>ids?.some(id => id === field.id)).map(([p])=>p as PageId), ...Object.entries(pageSections).filter(([,sections])=>sections?.some(section=>section.fieldIds.some(id => id === field.id))).map(([p])=>p as PageId), ...[...grouped.values()].filter(r=>r.field.id===field.id && r.pageId).map(r=>r.pageId!)])];
    for (const page of placements.length ? placements : [null]) {
      if ([...grouped.values()].some(row => row.pageId === page && JSON.stringify(row.field) === JSON.stringify(field))) continue;
      grouped.set(`baseline:${page}:${field.id}`,{field,pageId:page,area:page ? "Global baseline" : "Unplaced",condition:"Default placement; visibility rules apply",storage:field.id,status:"global",notes:[],sites:[]});
    }
  }
  globalInventory=[...grouped.values()]; return globalInventory;
}
export function getFieldInventory(scope: "global" | "effective", siteId: string) { return scope === "global" ? getGlobalFieldInventory() : getSiteFieldInventory(siteId).filter(row => row.pageId === null || !["internal", "advisor"].includes(getPageCategory(pages.find(page => page.id === row.pageId)!))); }

/** Project ownership separately from access: inline tools are direct page content. */
export function getFieldPlacements(row: InspectedField): FieldPlacement[] {
  return row.placements ?? (row.pageId ? [{
    pageId: row.pageId, accessPath: row.area, presentation: "inline", condition: row.condition,
  }] : []);
}
export function selectFieldInventory(rows: InspectedField[], view: "all" | "pages" | "tools" | "unplaced", pageId?: string, includeLinkedTools = false): InspectedField[] {
  return rows.flatMap(row => {
    if (view === "all") {
      const placements = getFieldPlacements(row).filter(placement => !pageId || placement.pageId === pageId);
      return pageId && !placements.length ? [] : [{ ...row, placements }];
    }
    if (view === "unplaced") return !row.pageId && !row.group ? [row] : [];
    if (view === "tools" && !row.group) return [];
    const placements = getFieldPlacements(row).filter(placement =>
      (!pageId || placement.pageId === pageId) &&
      (view === "tools" || includeLinkedTools || placement.presentation === "inline"));
    return placements.length ? [{...row, placements}] : [];
  });
}
