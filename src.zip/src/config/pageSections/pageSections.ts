import type { PageId } from "../../types";
import type { PageSectionConfig } from "./types";
import { applicantSectionTitles } from "../formSectionTitle";

/**
 * Canonical section header labels — import these instead of hardcoding strings.
 */
export const sectionLabels = {
  personalDetails: "Personal Details",
  workAndIncome: "Work & Income",
  businessDetails: "Business Details",
  businessEmployerInfo: "Business / Employer Information",
  personalInfo: "Personal information",
  financialInfo: "Financial information",
} as const;

export const pageSections: Partial<Record<PageId, PageSectionConfig[]>> = {
  coverage: [
    {
      id: "selfCoverageQuestions",
      pageId: "coverage",
      description: sectionLabels.personalDetails,
      applicant: "self",
      fieldIds: ["gender", "smoker"],
    },
    {
      id: "selfCoverageTobacco",
      pageId: "coverage",
      applicant: "self",
      fieldIds: ["tobacco-last-used", "tobacco-products"],
      visibleWhen: [{ fieldId: "smoker", equals: "yes" }],
    },
    {
      id: "selfCoverageWorkIncome",
      pageId: "coverage",
      description: sectionLabels.workAndIncome,
      applicant: "self",
      fieldIds: ["hours-worked-per-week", "average-monthly-income"],
    },
    {
      id: "selfCoverageBusinessExpenses",
      pageId: "coverage",
      description: sectionLabels.businessDetails,
      applicant: "self",
      fieldIds: [
        "monthly-business-expenses",
        "business-expense-responsibility",
        "average-employees-6-months",
      ],
    },
    {
      id: "spouseCoverageQuestions",
      pageId: "coverage",
      description: sectionLabels.personalDetails,
      applicant: "spouse",
      fieldIds: ["spouse-gender", "spouse-smoker"],
      visibleWhen: [{ fieldId: "dependents", includes: "spouse" }],
    },
    {
      id: "spouseCoverageTobacco",
      pageId: "coverage",
      applicant: "spouse",
      fieldIds: ["spouse-tobacco-last-used", "spouse-tobacco-products"],
      visibleWhen: [
        { fieldId: "dependents", includes: "spouse" },
        { fieldId: "spouse-smoker", equals: "yes" },
      ],
    },
    {
      id: "spouseCoverageWorkIncome",
      pageId: "coverage",
      description: sectionLabels.workAndIncome,
      applicant: "spouse",
      fieldIds: [
        "spouse-hours-worked-per-week",
        "spouse-average-monthly-income",
      ],
      visibleWhen: [{ fieldId: "dependents", includes: "spouse" }],
    },
  ],

  membership: [
    {
      id: "default",
      pageId: "membership",
      fieldIds: [
        "membership",
        "title",
        "first-name",
        "last-name",
        "email",
        "phone",
      ],
    },
  ],

  eligibility: [
    {
      id: "selfEligibility",
      pageId: "eligibility",
      title: applicantSectionTitles.self,
      applicant: "self",
      fieldIds: ["zip-postal-code", "state-province", "birth-date"],
    },
    {
      id: "dependentSelection",
      pageId: "eligibility",
      fieldIds: ["dependents"],
    },
    {
      id: "spouseSection",
      pageId: "eligibility",
      title: applicantSectionTitles.spouse,
      applicant: "spouse",
      fieldIds: [
        "spouse-membership",
        "spouse-first-name",
        "spouse-last-name",
        "spouse-birth-date",
      ],
      visibleWhen: [{ fieldId: "dependents", includes: "spouse" }],
    },
    {
      id: "childSection",
      pageId: "eligibility",
      title: applicantSectionTitles.child,
      applicant: "child",
      fieldIds: [],
      visibleWhen: [{ fieldId: "dependents", includes: "child" }],
    },
  ],

  contact: [
    {
      id: "contactResidentialAddress",
      pageId: "contact",
      title: applicantSectionTitles.self,
      applicant: "self",
      fieldIds: [
        "street-address",
        "apt-suite",
        "city",
        "state",
        "zip-code",
        "correspondence-to",
      ],
    },
    {
      id: "contactBusinessInfo",
      pageId: "contact",
      description: sectionLabels.businessEmployerInfo,
      fieldIds: [
        "business-name",
        "business-type",
        "business-address-same-as-home",
        "business-street-address",
        "business-apt-suite",
        "business-city",
        "business-state",
        "business-zip-code",
        "business-phone",
      ],
    },
    {
      id: "contactSpouse",
      pageId: "contact",
      title: applicantSectionTitles.spouse,
      applicant: "spouse",
      fieldIds: ["spouse-phone", "spouse-email"],
      visibleWhen: [{ fieldId: "dependents", includes: "spouse" }],
    },
  ],

  profile: [
    {
      id: "profilePersonalSelf",
      pageId: "profile",
      description: sectionLabels.personalInfo,
      applicant: "self",
      fieldIds: [
        "height-feet",
        "height-inches",
        "weight-lbs",
        "weight-12-months-ago-lbs",
        "social-security-number",
        "marital-status",
        "has-drivers-license",
        "intend-live-outside-us",
        "travel-outside-us-six-months",
      ],
    },
    {
      id: "profilePersonalSelfDriversLicense",
      pageId: "profile",
      applicant: "self",
      fieldIds: ["drivers-license-number", "drivers-license-state"],
      visibleWhen: [{ fieldId: "has-drivers-license", equals: "yes" }],
    },
    {
      id: "profilePersonalSelfOutsideUs",
      pageId: "profile",
      applicant: "self",
      fieldIds: ["outside-us-months", "outside-us-country"],
      visibleWhen: [{ fieldId: "intend-live-outside-us", equals: "yes" }],
    },
    {
      id: "profilePersonalSelfTravelOutsideUs",
      pageId: "profile",
      applicant: "self",
      fieldIds: ["travel-outside-us-country"],
      visibleWhen: [{ fieldId: "travel-outside-us-six-months", equals: "yes" }],
    },
    {
      id: "profilePersonalSelfPhysician",
      pageId: "profile",
      applicant: "self",
      fieldIds: [
        "physician-first-name",
        "physician-last-name",
        "physician-phone",
        "medical-facility-name",
        "medical-facility-street-address",
        "medical-facility-apt-suite",
        "medical-city",
        "medical-state",
        "medical-zip-code",
      ],
    },
    {
      id: "profileFinancialSelf",
      pageId: "profile",
      description: sectionLabels.financialInfo,
      applicant: "self",
      fieldIds: [
        "has-other-life-insurance",
        "existing-life-insurance-amount",
        "is-replacing-life-insurance",
        "has-pending-life-insurance-applications",
        "pending-life-insurance-amount",
        "pending-life-insurance-company",
        "has-disability-insurance",
        "is-replacing-disability-insurance",
        "disability-replacement-amount",
      ],
    },
    {
      id: "profilePersonalSpouse",
      pageId: "profile",
      applicant: "spouse",
      fieldIds: [
        "spouse-height-feet",
        "spouse-height-inches",
        "spouse-weight-lbs",
        "spouse-weight-12-months-ago-lbs",
        "spouse-social-security-number",
        "spouse-has-drivers-license",
        "spouse-intend-live-outside-us",
        "spouse-travel-outside-us-six-months",
      ],
      visibleWhen: [{ fieldId: "dependents", includes: "spouse" }],
    },
    {
      id: "profilePersonalSpouseDriversLicense",
      pageId: "profile",
      applicant: "spouse",
      fieldIds: [
        "spouse-drivers-license-number",
        "spouse-drivers-license-state",
      ],
      visibleWhen: [
        { fieldId: "dependents", includes: "spouse" },
        { fieldId: "spouse-has-drivers-license", equals: "yes" },
      ],
    },
    {
      id: "profilePersonalSpouseOutsideUs",
      pageId: "profile",
      applicant: "spouse",
      fieldIds: ["spouse-outside-us-months", "spouse-outside-us-country"],
      visibleWhen: [
        { fieldId: "dependents", includes: "spouse" },
        { fieldId: "spouse-intend-live-outside-us", equals: "yes" },
      ],
    },
    {
      id: "profilePersonalSpouseTravelOutsideUs",
      pageId: "profile",
      applicant: "spouse",
      fieldIds: ["spouse-travel-outside-us-country"],
      visibleWhen: [
        { fieldId: "dependents", includes: "spouse" },
        { fieldId: "spouse-travel-outside-us-six-months", equals: "yes" },
      ],
    },
    {
      id: "profilePersonalSpousePhysician",
      pageId: "profile",
      applicant: "spouse",
      fieldIds: [
        "spouse-physician-first-name",
        "spouse-physician-last-name",
        "spouse-physician-phone",
        "spouse-medical-facility-name",
        "spouse-medical-facility-street-address",
        "spouse-medical-facility-apt-suite",
        "spouse-medical-city",
        "spouse-medical-state",
        "spouse-medical-zip-code",
      ],
      visibleWhen: [{ fieldId: "dependents", includes: "spouse" }],
    },
    {
      id: "profileFinancialSpouse",
      pageId: "profile",
      applicant: "spouse",
      fieldIds: [
        "spouse-has-other-life-insurance",
        "spouse-existing-life-insurance-amount",
        "spouse-is-replacing-life-insurance",
        "spouse-has-pending-life-insurance-applications",
        "spouse-pending-life-insurance-amount",
        "spouse-pending-life-insurance-company",
        "spouse-has-disability-insurance",
        "spouse-is-replacing-disability-insurance",
        "spouse-disability-replacement-amount",
      ],
      visibleWhen: [{ fieldId: "dependents", includes: "spouse" }],
    },
  ],

  "advisor-login": [
    {
      id: "advisorLoginNew",
      pageId: "advisor-login",
      fieldIds: ["advisor-email", "advisor-phone", "advisor-code"],
      visibleWhen: [{ fieldId: "advisor-flow-type", equals: "new" }],
    },
    {
      id: "advisorLoginSaved",
      pageId: "advisor-login",
      fieldIds: ["applicant-email"],
      visibleWhen: [{ fieldId: "advisor-flow-type", equals: "saved" }],
    },
  ],
};
