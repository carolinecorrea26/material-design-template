import { describe, expect, it } from "vitest";
import { clients } from "../clients";
import { classifyConfigurable, resolveClientConfigurations } from "./resolveClientConfigurations";

describe("classifyConfigurable", () => {
  it("classifies the explicit configuration scope", () => {
    expect(classifyConfigurable("Client Configurable")).toBe("client");
    expect(classifyConfigurable("Global")).toBe("global");
  });
});

describe("resolveClientConfigurations", () => {
  it("overridden: a client-configurable row with a non-default live value", () => {
    const resolved = resolveClientConfigurations(clients.waepa);
    const themeColor = resolved.find((r) => r.key === "ClientConfig.themeColor");
    expect(themeColor?.kind).toBe("client");
    expect(themeColor?.liveValueAvailable).toBe(true);
    expect(themeColor?.status).toBe("overridden");
    expect(themeColor?.effective).toBe("dark-blue");
  });

  it("inherited: a client-configurable row this client leaves at its default", () => {
    const resolved = resolveClientConfigurations(clients.demo);
    const themeColor = resolved.find((r) => r.key === "ClientConfig.themeColor");
    expect(themeColor?.status).toBe("inherited");
    expect(themeColor?.effective).toBe("default");
  });

  it("schema-only rows (no live accessor, or not client-configurable) report inherited without fabricating a value", () => {
    const resolved = resolveClientConfigurations(clients.demo);
    const rules = resolved.find((r) => r.key === "content.navigation");
    expect(rules?.liveValueAvailable).toBe(false);
    expect(rules?.status).toBe("inherited");
  });
});
