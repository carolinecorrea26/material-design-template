import { formFlow } from "./formFlow";
import type { PageId } from "../types";
import { getPagePath } from "./pages";
import type { SiteId } from "../data";

export function getSitePrototypeUrl(siteId: SiteId): string {
  return getSitePagePrototypeUrl(siteId, "home");
}

/** Full navigation boots the selected Site before the existing autofill initializer runs. */
export function getSitePagePrototypeUrl(siteId: SiteId, pageId: PageId): string {
  const appBaseUrl = new URL(import.meta.env.BASE_URL, window.location.origin);
  const pagePath = getPagePath(pageId).replace(/^\/+/, "");
  const url = new URL(pagePath, appBaseUrl);
  url.searchParams.set("site", siteId);
  if (formFlow.includes(pageId)) url.searchParams.set("autofill", pageId);
  return url.toString();
}

