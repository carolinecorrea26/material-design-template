import type { ClientId } from "../../types";
import { clients } from "../../config/clients";
import { avmaClient } from "../../config/clients/avma";
import type { ProductContentBlock } from "../../config/clients/types";
import { buildContent } from "../index";
import type { LegalDocSection, SiteContent } from "../types";
import {
  homeDefaults,
  coverageDefaults,
  navigationDefaults,
  footerDefaults,
  reviewDefaults,
  receiptDefaults,
  helpDefaults,
  sharedDefaults,
  pagesDefaults,
  beneficiaryDefaults,
  dialogsDefaults,
  statusMessagesDefaults,
} from "../defaults";

// ---------------------------------------------------------------------------
// CMS content catalogue — every real, managed piece of user-facing copy,
// imagery, and document/link content in the prototype (excluding form field
// labels and error messages, which live outside this content system).
//
// Each entry knows how to read its own value off a resolved SiteContent tree
// (or, for the handful of things that live outside src/content/, off a
// client's config / known asset paths) for both the "global" baseline and
// any given client — so override detection ("is this different for the
// selected client?") falls out of a plain value comparison instead of
// needing separate bookkeeping per path.
// ---------------------------------------------------------------------------

export type CmsContentType = "Text" | "Image" | "Video" | "Document" | "Link";

export type CmsEntry = {
  id: string;
  type: CmsContentType;
  page: string;
  status: "Published";
  lastModified: null;
  globalValue: string;
  effectiveValue: (clientId: ClientId) => string;
  overridden: (clientId: ClientId) => boolean;
};

const globalContent: SiteContent = {
  home: homeDefaults,
  coverage: coverageDefaults,
  navigation: navigationDefaults,
  pages: pagesDefaults as SiteContent["pages"],
  footer: footerDefaults,
  review: reviewDefaults,
  receipt: receiptDefaults,
  help: helpDefaults,
  shared: sharedDefaults,
  beneficiary: beneficiaryDefaults,
  dialogs: dialogsDefaults,
  statusMessages: statusMessagesDefaults,
};

const contentByClient = new Map<ClientId, SiteContent>();
function contentFor(clientId: ClientId): SiteContent {
  let content = contentByClient.get(clientId);
  if (!content) {
    content = buildContent(clientId);
    contentByClient.set(clientId, content);
  }
  return content;
}

/** Resolves {{clientName}}/{{clientAcronym}}/{{associationName}} for display only — never used for override comparisons, which always compare raw values. */
function resolveForDisplay(str: string, branding?: { name: string; acronym: string }): string {
  const name = branding?.name ?? "[Client Name]";
  const acronym = branding?.acronym ?? "[Acronym]";
  return str
    .replace(/\{\{clientName\}\}/g, name)
    .replace(/\{\{clientAcronym\}\}/g, acronym)
    .replace(/\{\{associationName\}\}/g, name);
}

function contentEntry(
  id: string,
  type: CmsContentType,
  page: string,
  read: (content: SiteContent) => string,
): CmsEntry {
  const rawGlobal = read(globalContent);
  return {
    id,
    type,
    page,
    status: "Published",
    lastModified: null,
    globalValue: resolveForDisplay(rawGlobal),
    effectiveValue: (clientId) =>
      resolveForDisplay(read(contentFor(clientId)), clients[clientId].branding),
    overridden: (clientId) => read(contentFor(clientId)) !== rawGlobal,
  };
}

function externalEntry(
  id: string,
  type: CmsContentType,
  page: string,
  globalValue: string,
  effectiveValue: (clientId: ClientId) => string,
): CmsEntry {
  return {
    id,
    type,
    page,
    status: "Published",
    lastModified: null,
    globalValue,
    effectiveValue,
    overridden: (clientId) => effectiveValue(clientId) !== globalValue,
  };
}

function firstParagraph(doc: { sections: LegalDocSection[] }): string {
  const p = doc.sections.find(
    (s): s is { type: "paragraph"; text: string } => s.type === "paragraph",
  );
  return p?.text ?? "";
}

function flattenProductContent(blocks: ProductContentBlock[] | undefined): string {
  if (!blocks || blocks.length === 0) return "—";
  return blocks
    .map((b) => {
      if (b.type === "list") return b.items.join(" ");
      if (b.type === "section") return `${b.heading}: ${b.body.join(" ")}`;
      return b.text;
    })
    .join(" ");
}

const PAGE_LABELS: Record<string, string> = {
  home: "Home",
  membership: "Membership",
  eligibility: "Eligibility",
  coverage: "Coverage",
  beneficiary: "Beneficiary",
  contact: "Contact",
  review: "Review",
  docusign: "E-Sign (DocuSign)",
  "health-si": "Health Questions (SI)",
  "health-li": "Health Questions (LI)",
  "health-qd": "Health Questions (QD)",
  "health-di": "Health Questions (DI)",
  "health-cir": "Health Questions (CIR)",
  payment: "Payment",
  receipt: "Receipt",
  resume: "Resume Application",
  "resume-method": "Resume Application",
  "resume-code": "Resume Application",
  "advisor-login": "Advisor Portal",
  "advisor-send-confirmation": "Advisor Portal",
  "application-edit-confirmation": "Advisor Portal",
  profile: "Profile",
};

const PAGE_HEADER_IDS = Object.keys(PAGE_LABELS) as Array<keyof typeof PAGE_LABELS>;

const pageHeaderEntries: CmsEntry[] = PAGE_HEADER_IDS.map((pageId) =>
  contentEntry(`page-header-${pageId}`, "Text", PAGE_LABELS[pageId], (c) => {
    const page = (c.pages as Record<string, { title: string; subhead?: string } | undefined>)[
      pageId
    ];
    if (!page) return "—";
    return page.subhead ? `${page.title} — ${page.subhead}` : page.title;
  }),
);

export const cmsEntries: CmsEntry[] = [
  ...pageHeaderEntries,

  contentEntry(
    "page-membership-info-note",
    "Text",
    "Membership",
    (c) => c.pages.membership?.infoNote ?? "—",
  ),

  // ── Home ──────────────────────────────────────────────────────────────────
  contentEntry(
    "home-hero",
    "Text",
    "Home",
    (c) => `${c.home.hero.tagline} — ${c.home.hero.title}. ${c.home.hero.description}`,
  ),
  contentEntry(
    "home-hero-welcome-back",
    "Text",
    "Home",
    (c) => `${c.home.hero.welcomeBackTitle} — ${c.home.hero.welcomeBackDescription}`,
  ),
  contentEntry(
    "home-client-section",
    "Text",
    "Home",
    (c) =>
      c.home.clientSection
        ? `${c.home.clientSection.tagline} ${c.home.clientSection.paragraphs.join(" ")}`
        : "—",
  ),
  contentEntry(
    "home-how-applying-works",
    "Text",
    "Home",
    (c) => `${c.home.howApplyingWorks.title} — ${c.home.howApplyingWorks.description}`,
  ),
  contentEntry(
    "home-applying-step-1",
    "Text",
    "Home",
    (c) => `${c.home.applyingSteps[0].title} — ${c.home.applyingSteps[0].body}`,
  ),
  contentEntry(
    "home-applying-step-2",
    "Text",
    "Home",
    (c) => `${c.home.applyingSteps[1].title} — ${c.home.applyingSteps[1].body}`,
  ),
  contentEntry(
    "home-applying-step-3",
    "Text",
    "Home",
    (c) => `${c.home.applyingSteps[2].title} — ${c.home.applyingSteps[2].body}`,
  ),
  contentEntry(
    "home-applying-step-1-image",
    "Image",
    "Home",
    (c) => `${c.home.applyingSteps[0].imageSrc} (alt: "${c.home.applyingSteps[0].imageAlt}")`,
  ),
  contentEntry(
    "home-applying-step-2-image",
    "Image",
    "Home",
    (c) => `${c.home.applyingSteps[1].imageSrc} (alt: "${c.home.applyingSteps[1].imageAlt}")`,
  ),
  contentEntry(
    "home-applying-step-3-image",
    "Image",
    "Home",
    (c) => `${c.home.applyingSteps[2].imageSrc} (alt: "${c.home.applyingSteps[2].imageAlt}")`,
  ),
  contentEntry(
    "home-coverage-options-intro",
    "Text",
    "Home",
    (c) => `${c.home.coverageOptions.title} — ${c.home.coverageOptions.description}`,
  ),
  contentEntry(
    "home-nyl-credentials",
    "Text",
    "Home",
    (c) =>
      `${c.home.nylCredentials.name} — ${c.home.nylCredentials.tagline}. ${c.home.nylCredentials.description} (${c.home.nylCredentials.ratingsNote})`,
  ),
  contentEntry(
    "home-quote-section",
    "Text",
    "Home",
    (c) => `${c.home.quoteSection.title} — ${c.home.quoteSection.description}`,
  ),
  contentEntry(
    "home-no-coverage-categories-message",
    "Text",
    "Home",
    (c) => c.home.noCoverageCategoriesMessage,
  ),

  // ── Navigation (global) ──────────────────────────────────────────────────
  contentEntry(
    "navigation-progress-step-labels",
    "Text",
    "Global — Progress Stepper",
    (c) => Object.values(c.navigation.progressStepLabels).join(" → "),
  ),
  contentEntry(
    "navigation-transition-messages",
    "Text",
    "Global — Step Transitions",
    (c) =>
      Object.entries(c.navigation.transitionMessages)
        .map(([pageId, pair]) => `${pageId}: ${pair[0]}`)
        .join(" | "),
  ),
  contentEntry(
    "navigation-back-message",
    "Text",
    "Global — Step Transitions",
    (c) => c.navigation.backMessage,
  ),

  // ── Coverage ─────────────────────────────────────────────────────────────
  contentEntry(
    "coverage-category-description-li",
    "Text",
    "Coverage",
    (c) => c.coverage.categoryDescriptions.LI ?? "—",
  ),
  contentEntry(
    "coverage-category-description-ad",
    "Text",
    "Coverage",
    (c) => c.coverage.categoryDescriptions.AD ?? "—",
  ),
  contentEntry(
    "coverage-category-description-di",
    "Text",
    "Coverage",
    (c) => c.coverage.categoryDescriptions.DI ?? "—",
  ),
  contentEntry(
    "coverage-category-description-oo",
    "Text",
    "Coverage",
    (c) => c.coverage.categoryDescriptions.OO ?? "—",
  ),
  contentEntry(
    "coverage-category-description-sh",
    "Text",
    "Coverage",
    (c) => c.coverage.categoryDescriptions.SH ?? "—",
  ),

  // ── Footer (global) ──────────────────────────────────────────────────────
  contentEntry(
    "footer-underwritten-by",
    "Text",
    "Global — Footer",
    (c) => `${c.footer.underwrittenBy.name} — ${c.footer.underwrittenBy.policyForm}`,
  ),
  contentEntry(
    "footer-ratings",
    "Text",
    "Global — Footer",
    (c) => c.footer.ratings.map((r) => `${r.grade} (${r.source})`).join(", "),
  ),
  contentEntry("footer-ratings-as-of", "Text", "Global — Footer", (c) => c.footer.ratingsAsOf),
  contentEntry(
    "footer-legal-1",
    "Text",
    "Global — Footer",
    (c) => c.footer.legal[0] ?? "—",
  ),
  contentEntry(
    "footer-legal-2",
    "Text",
    "Global — Footer",
    (c) => c.footer.legal[1] ?? "—",
  ),
  contentEntry(
    "footer-terms-of-use",
    "Document",
    "Global — Footer",
    (c) =>
      `${c.footer.termsOfUseContent.title}${
        c.footer.termsOfUseContent.revision ? ` (rev. ${c.footer.termsOfUseContent.revision})` : ""
      } — ${firstParagraph(c.footer.termsOfUseContent)}`,
  ),
  contentEntry(
    "footer-privacy-notice",
    "Document",
    "Global — Footer",
    (c) => `${c.footer.privacyNoticeContent.title} — ${firstParagraph(c.footer.privacyNoticeContent)}`,
  ),

  // ── Review ───────────────────────────────────────────────────────────────
  contentEntry(
    "review-alert",
    "Text",
    "Review",
    (c) => `${c.review.alertTitle} ${c.review.alertItems.map((i) => i.title).join("; ")}`,
  ),
  contentEntry(
    "review-health-questions-note",
    "Text",
    "Review",
    (c) => `${c.review.healthQuestionsNote.title} — ${c.review.healthQuestionsNote.description}`,
  ),
  contentEntry(
    "review-read-and-sign",
    "Text",
    "Review",
    (c) => `${c.review.readAndSignTitle} — ${c.review.readAndSignContent}`,
  ),
  contentEntry(
    "review-electronic-consent",
    "Text",
    "E-Sign (DocuSign)",
    (c) => `${c.review.electronicConsentTitle} — ${c.review.electronicConsentContent}`,
  ),

  // ── Receipt ──────────────────────────────────────────────────────────────
  contentEntry("receipt-documents-note", "Text", "Receipt", (c) => c.receipt.documentsNote),
  contentEntry(
    "receipt-coverage-decisions",
    "Text",
    "Receipt",
    (c) => `${c.receipt.coverageDecisions.title} — ${c.receipt.coverageDecisions.description}`,
  ),
  contentEntry(
    "receipt-decision-statuses",
    "Text",
    "Receipt",
    (c) =>
      Object.values(c.receipt.decisionStatuses)
        .map((s) => `${s.label}: ${s.description}`)
        .join(" | "),
  ),
  contentEntry(
    "receipt-what-happens-next",
    "Text",
    "Receipt",
    (c) =>
      `${c.receipt.whatHappensNext.title} — ${c.receipt.whatHappensNext.items
        .map((i) => `${i.title}: ${i.description}`)
        .join("; ")}`,
  ),
  contentEntry("receipt-support-intro", "Text", "Receipt", (c) => c.receipt.support.title),

  // ── Help drawers / modals ────────────────────────────────────────────────
  contentEntry(
    "help-how-applying-works",
    "Text",
    "Home — How Applying Works Drawer",
    (c) => c.help.howApplyingWorks.intro,
  ),
  contentEntry(
    "help-application-review",
    "Text",
    "Home — Application Review Drawer",
    (c) => `${c.help.applicationReview.title} — ${c.help.applicationReview.intro}`,
  ),
  contentEntry(
    "help-group-insurance",
    "Text",
    "Home — Group Insurance Drawer",
    (c) => c.help.groupInsurance.intro,
  ),
  contentEntry(
    "help-coverage-options",
    "Text",
    "Coverage — Coverage Options Drawer",
    (c) => c.help.coverageOptions.intro,
  ),
  contentEntry(
    "help-beneficiary-basics",
    "Text",
    "Beneficiary — What Is a Beneficiary Drawer",
    (c) => c.help.beneficiary.whatIs.paragraphs.join(" "),
  ),
  contentEntry(
    "help-beneficiary-share",
    "Text",
    "Beneficiary — Percentage Share Drawer",
    (c) => c.help.beneficiary.percentageShare.paragraphs.join(" "),
  ),
  contentEntry(
    "help-why-asked",
    "Text",
    "Coverage — Why Is This Asked Drawer",
    (c) => `${c.help.whyAsked.intro} ${c.help.whyAsked.sections.map((s) => s.title).join("; ")}`,
  ),
  contentEntry(
    "help-payment-handling",
    "Text",
    "Payment — Payment Handling Drawer",
    (c) =>
      `${c.help.paymentHandling.intro} ${c.help.paymentHandling.sections
        .map((s) => s.title)
        .join("; ")}`,
  ),
  contentEntry(
    "help-quick-decision",
    "Text",
    "Health Questions — QuickDecision Drawer",
    (c) => `${c.help.quickDecision.titlePrefix} QuickDecision — ${c.help.quickDecision.intro}`,
  ),
  contentEntry(
    "help-coverage-portfolio",
    "Text",
    "Home — Coverage Portfolio Drawer",
    (c) => `${c.help.coveragePortfolio.title} — ${c.help.coveragePortfolio.intro}`,
  ),

  // ── Shared / global ──────────────────────────────────────────────────────
  contentEntry(
    "shared-cookie-banner-message",
    "Text",
    "Global — Cookie Banner",
    (c) => c.shared.cookieBanner.message,
  ),
  contentEntry(
    "shared-cookie-banner-link",
    "Link",
    "Global — Cookie Banner",
    (c) => `${c.shared.cookieBanner.learnMoreLabel}: ${c.shared.cookieBanner.learnMoreHref}`,
  ),

  // ── Beneficiary ──────────────────────────────────────────────────────────
  contentEntry(
    "beneficiary-no-more-online",
    "Text",
    "Beneficiary",
    (c) => c.beneficiary.noMoreOnlineMessage,
  ),
  contentEntry(
    "beneficiary-no-applicant-products",
    "Text",
    "Beneficiary",
    (c) => c.beneficiary.noApplicantProductsMessage,
  ),

  // ── Dialogs / modals ─────────────────────────────────────────────────────
  contentEntry(
    "dialog-edit-application",
    "Text",
    "Global — Edit Application Dialog",
    (c) =>
      `${c.dialogs.confirmation.editApplication.title} — ${c.dialogs.confirmation.editApplication.message}`,
  ),
  contentEntry(
    "dialog-dependent-coverage",
    "Text",
    "Coverage — Dependent Coverage Dialog",
    (c) =>
      `${c.dialogs.confirmation.dependentCoverage.title} — ${c.dialogs.confirmation.dependentCoverage.message}`,
  ),
  contentEntry(
    "dialog-send-to-applicant",
    "Text",
    "Advisor Portal — Send Application Dialog",
    (c) =>
      `${c.dialogs.sendApplication.sendToApplicant.title} — ${c.dialogs.sendApplication.sendToApplicant.introText}`,
  ),
  contentEntry(
    "dialog-request-edit",
    "Text",
    "Advisor Portal — Send Application Dialog",
    (c) =>
      `${c.dialogs.sendApplication.requestEditToApplication.title} — ${c.dialogs.sendApplication.requestEditToApplication.introText}`,
  ),
  contentEntry(
    "dialog-beneficiary-modal",
    "Text",
    "Beneficiary — Beneficiary Modal",
    (c) =>
      `${c.dialogs.beneficiary.addTitle} / ${c.dialogs.beneficiary.editTitle} — ${c.dialogs.beneficiary.applyToOthersTitle}: ${c.dialogs.beneficiary.applyToOthersPrompt}`,
  ),
  contentEntry(
    "dialog-coverage-details-title",
    "Text",
    "Coverage — Coverage Details Modal",
    (c) => c.dialogs.coverageDetails.fallbackTitle,
  ),

  // ── Status messages ──────────────────────────────────────────────────────
  contentEntry(
    "status-docusign",
    "Text",
    "E-Sign (DocuSign)",
    (c) => `${c.statusMessages.docusign.heading} — ${c.statusMessages.docusign.body}`,
  ),
  contentEntry(
    "status-health-qd",
    "Text",
    "Health Questions (QD)",
    (c) =>
      `${c.statusMessages.healthQd.heading} — ${c.statusMessages.healthQd.bodyBeforeMark}…${c.statusMessages.healthQd.bodyAfterMark}`,
  ),
  contentEntry(
    "status-health-cir",
    "Text",
    "Health Questions (CIR)",
    (c) => c.statusMessages.healthCir.body,
  ),

  // ── External to src/content/ — real per-client assets & config ─────────
  externalEntry(
    "home-hero-image",
    "Image",
    "Home",
    'Not shown by default — enabled per client via features.homePageVariant ("hero-image" or "welcome-back").',
    (clientId) => {
      const variant = clients[clientId].features?.homePageVariant ?? "default";
      return variant === "hero-image" || variant === "welcome-back"
        ? `/client/${clientId}/hero.png (shown — ${variant} variant)`
        : 'Not shown by default — enabled per client via features.homePageVariant ("hero-image" or "welcome-back").';
    },
  ),
  externalEntry(
    "global-client-logo",
    "Image",
    "Global — Header & Footer Branding",
    "No global logo — each client provides its own.",
    (clientId) => {
      const { logo, logoAlt } = clients[clientId].branding;
      return `${logo} (alt: "${logoAlt}")`;
    },
  ),
  externalEntry(
    "footer-license-info",
    "Text",
    "Global — Footer",
    "—",
    (clientId) => {
      const info = clients[clientId].licenseInfo;
      return info && info.length > 0 ? info.join(" / ") : "—";
    },
  ),
  externalEntry(
    "coverage-avma-hospital-indemnity-disclosure",
    "Text",
    "Coverage — AVMA Hospital Indemnity Product",
    "—",
    (clientId) =>
      clientId === "avma"
        ? flattenProductContent(
            avmaClient.coverages.overrides?.["sh-hospital-income"]?.productContent,
          )
        : "—",
  ),
  externalEntry(
    "coverage-brochure",
    "Document",
    "Coverage — Coverage Options Drawer",
    "No global brochure — each client provides its own coverage brochure/certificate PDF.",
    (clientId) => {
      if (clientId === "avma") {
        return "https://avmainsuranceservices.com/Downloads/AVMA/Applications/AVMA-SC-APP-LOAN-FORM.pdf";
      }
      if (clientId === "csea") {
        return "/client/csea/li-clerical.pdf";
      }
      return `/client/${clientId}/brochure.pdf`;
    },
  ),
  externalEntry(
    "coverage-brochure-csea-di-clerical",
    "Document",
    "Coverage — Coverage Options Drawer",
    "—",
    (clientId) => (clientId === "csea" ? "/client/csea/di-clerical.pdf" : "—"),
  ),
  externalEntry(
    "coverage-quote-cost-footnote",
    "Text",
    "Coverage — Quote Tool",
    "Quoted cost is the best rate available based on the information you provided. Final cost may be based upon factors such as gender, health status, and use of tobacco/nicotine. Rates current as of 2026.",
    () =>
      "Quoted cost is the best rate available based on the information you provided. Final cost may be based upon factors such as gender, health status, and use of tobacco/nicotine. Rates current as of 2026.",
  ),
];
