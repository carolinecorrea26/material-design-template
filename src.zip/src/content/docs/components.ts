// Generated from actual component imports in Storybook. Run node scripts/generate-component-catalog.mjs.
export const componentCatalog = [
  {
    "id": "component-details-table",
    "name": "DetailsTable",
    "section": "Application Patterns",
    "description": "Presents labeled values in a compact details table.",
    "storyId": "application-patterns-detailstable--confirmation-details",
    "source": "src/components/layout/DetailsTable.tsx"
  },
  {
    "id": "component-yes-no-detail-list",
    "name": "YesNoDetailList",
    "section": "Application Patterns",
    "description": "Numbered yes/no questions that reveal a canonical DynamicList on “Yes”.",
    "storyId": "application-patterns-yesnodetaillist--interactive",
    "source": "src/components/forms/YesNoDetailList.tsx"
  },
  {
    "id": "component-application-document-preview",
    "name": "ApplicationDocumentPreview",
    "section": "Content",
    "description": "Returns a group key if this field should be merged into a combined Name entry, null otherwise.",
    "storyId": "content-applicationdocumentpreview--default",
    "source": "src/components/content/ApplicationDocumentPreview.tsx"
  },
  {
    "id": "component-help-chips",
    "name": "HelpChips",
    "section": "Content",
    "description": "A help item that includes drawer content and title, extending the chip definition.",
    "storyId": "content-helpchips--default",
    "source": "src/components/content/HelpChips.tsx"
  },
  {
    "id": "component-legal-doc-list",
    "name": "LegalDocList",
    "section": "Content",
    "description": "Lists application documents and legal disclosures with links.",
    "storyId": "content-legaldoclist--terms-of-use",
    "source": "src/components/content/LegalDocList.tsx"
  },
  {
    "id": "component-quick-decision-explainer",
    "name": "QuickDecisionExplainer",
    "section": "Content",
    "description": "Inline styled QuickDecision mark with bold, success green, and lightning icon.",
    "storyId": "content-quickdecision--info-box-inline-collapse",
    "source": "src/components/content/QuickDecisionExplainer.tsx"
  },
  {
    "id": "component-quick-decision-indicator",
    "name": "QuickDecisionIndicator",
    "section": "Content",
    "description": "Marks coverages that support QuickDecision with the configured client icon.",
    "storyId": "content-quickdecision--info-box-inline-collapse",
    "source": "src/components/ui/QuickDecisionIndicator.tsx"
  },
  {
    "id": "component-quick-decision-info-box",
    "name": "QuickDecisionInfoBox",
    "section": "Content",
    "description": "Reusable QuickDecision info panel shown on the Coverage page, landing page coverage options section, and app menu coverage drawer.",
    "storyId": "content-quickdecision--info-box-inline-collapse",
    "source": "src/components/content/QuickDecisionInfoBox.tsx"
  },
  {
    "id": "component-coverage-cart",
    "name": "CoverageCart",
    "section": "Coverage & Commerce",
    "description": "\"drawer\" — used inside AppDrawer (AppHeader cart icon, Coverage page summary). Shows header with close button, empty state, product cards, and total. \"inline\" — used inline on the Coverage page below ProductCatalog. Shows cart panel directly, no close button. Supports rate frequency toggle, edit/delete actions.",
    "storyId": "coverage-commerce-coveragecart--empty-drawer",
    "source": "src/components/ui/CoverageCart.tsx"
  },
  {
    "id": "component-coverage-category-selector",
    "name": "CoverageCategorySelector",
    "section": "Coverage & Commerce",
    "description": "Categories available for selection.",
    "storyId": "coverage-commerce-coveragecategoryselector--default",
    "source": "src/components/forms/CoverageCategorySelector.tsx"
  },
  {
    "id": "component-coverage-needs-calculator",
    "name": "CoverageNeedsCalculator",
    "section": "Coverage & Commerce",
    "description": "Estimates life insurance needs from financial obligations and available resources.",
    "storyId": "coverage-commerce-coverageneedscalculator--default",
    "source": "src/components/forms/CoverageNeedsCalculator.tsx"
  },
  {
    "id": "component-coverage-options-panel",
    "name": "CoverageOptionsPanel",
    "section": "Coverage & Commerce",
    "description": "Explains available coverage categories and products on the homepage or in a drawer.",
    "storyId": "coverage-commerce-coverageoptionspanel--page-variant",
    "source": "src/components/ui/CoverageOptionsPanel.tsx"
  },
  {
    "id": "component-coverage-portfolio-drawer",
    "name": "CoveragePortfolioDrawer",
    "section": "Coverage & Commerce",
    "description": "When spouse is not applying, hide their portfolio.",
    "storyId": "coverage-commerce-coverageportfoliodrawer--member-only",
    "source": "src/components/ui/CoveragePortfolioDrawer.tsx"
  },
  {
    "id": "component-coverage-questions",
    "name": "CoverageQuestions",
    "section": "Coverage & Commerce",
    "description": "Collects the questions required by selected coverage categories.",
    "storyId": "coverage-commerce-coveragequestions--no-category-selected",
    "source": "src/components/forms/CoverageQuestions.tsx"
  },
  {
    "id": "component-eligibility-fields",
    "name": "EligibilityFields",
    "section": "Coverage & Commerce",
    "description": "When true, validation errors and age error are shown.",
    "storyId": "coverage-commerce-eligibilityfields--default",
    "source": "src/components/forms/EligibilityFields.tsx"
  },
  {
    "id": "component-estimator-product-card",
    "name": "EstimatorProductCard",
    "section": "Coverage & Commerce",
    "description": "Currently selected amount for member applicant.",
    "storyId": "coverage-commerce-estimatorproductcard--unselected",
    "source": "src/components/forms/EstimatorProductCard.tsx"
  },
  {
    "id": "component-featured-badge",
    "name": "FeaturedBadge",
    "section": "Coverage & Commerce",
    "description": "Small \"Featured\" badge chip used on product cards to indicate featured coverage products.",
    "storyId": "coverage-commerce-product-adornments--side-by-side",
    "source": "src/components/ui/FeaturedBadge.tsx"
  },
  {
    "id": "component-how-applying-works-panel",
    "name": "HowApplyingWorksPanel",
    "section": "Coverage & Commerce",
    "description": "Explains the three application steps using images or a configured animated preview.",
    "storyId": "coverage-commerce-howapplyingworkspanel--page-variant",
    "source": "src/components/ui/HowApplyingWorksPanel.tsx"
  },
  {
    "id": "component-member-verification",
    "name": "MemberVerification",
    "section": "Coverage & Commerce",
    "description": "Match the configured prototype verification facts without Site identity.",
    "storyId": "coverage-commerce-memberverification--interactive",
    "source": "src/components/ui/MemberVerification.tsx"
  },
  {
    "id": "component-physician-information",
    "name": "PhysicianInformation",
    "section": "Coverage & Commerce",
    "description": "Collects physician details for eligible spouse applications.",
    "storyId": "coverage-commerce-physicianinformation--default",
    "source": "src/components/forms/PhysicianInformation.tsx"
  },
  {
    "id": "component-product-catalog",
    "name": "ProductCatalog",
    "section": "Coverage & Commerce",
    "description": "Displays eligible insurance products, applicants and coverage amounts.",
    "storyId": "coverage-commerce-productcatalog--interactive",
    "source": "src/components/forms/ProductCatalog.tsx"
  },
  {
    "id": "component-product-cost-breakdown",
    "name": "ProductCostBreakdown",
    "section": "Coverage & Commerce",
    "description": "Displays premium details and supplemental fees for a product.",
    "storyId": "coverage-commerce-productcostbreakdown--monthly",
    "source": "src/components/ui/ProductCostBreakdown.tsx"
  },
  {
    "id": "component-quote-calculator",
    "name": "QuoteCalculator",
    "section": "Coverage & Commerce",
    "description": "Keep the existing drawer by default; homepage variants can render the same calculator state and business logic directly in the page.",
    "storyId": "coverage-commerce-quotecalculator--collects-eligibility",
    "source": "src/components/forms/QuoteCalculator.tsx"
  },
  {
    "id": "component-rate-frequency-control",
    "name": "RateFrequencyControl",
    "section": "Coverage & Commerce",
    "description": "Labeled monthly/annual control shared by quote and cart cost summaries.",
    "storyId": "coverage-commerce-ratefrequencycontrol--interactive",
    "source": "src/components/ui/RateFrequencyControl.tsx"
  },
  {
    "id": "component-rate-frequency-toggle",
    "name": "RateFrequencyToggle",
    "section": "Coverage & Commerce",
    "description": "Custom styled toggle switch for monthly/annual rate frequency display. Used in cost summary panels and quote comparison views.",
    "storyId": "coverage-commerce-ratefrequencytoggle--unchecked",
    "source": "src/components/ui/RateFrequencyToggle.tsx"
  },
  {
    "id": "component-total-cost-summary",
    "name": "TotalCostSummary",
    "section": "Coverage & Commerce",
    "description": "Shared \"Total Estimated Cost\" panel used by EstimatedCostPanel (Coverage page) and CoverageSummary (ECart drawer). Styling: bg #f8fafd, border 2px solid primary, borderRadius 16px. Total: fontWeight 900, color success.main.",
    "storyId": "coverage-commerce-totalcostsummary--default",
    "source": "src/components/ui/TotalCostSummary.tsx"
  },
  {
    "id": "component-app-snackbar",
    "name": "AppSnackbar",
    "section": "Feedback",
    "description": "Auto-hide duration in ms. Defaults to 2500.",
    "storyId": "feedback-appsnackbar--success",
    "source": "src/components/feedback/AppSnackbar.tsx"
  },
  {
    "id": "component-empty-state",
    "name": "EmptyState",
    "section": "Feedback",
    "description": "Icon to display. Defaults to PrivacyTipIcon.",
    "storyId": "feedback-emptystate--default",
    "source": "src/components/feedback/EmptyState.tsx"
  },
  {
    "id": "component-expiring-code-alert",
    "name": "ExpiringCodeAlert",
    "section": "Feedback",
    "description": "Shared active/expired/resend alert for resume links and verification codes.",
    "storyId": "feedback-resume-expiration--active-link",
    "source": "src/components/feedback/ExpiringCodeAlert.tsx"
  },
  {
    "id": "component-loading-overlay",
    "name": "LoadingOverlay",
    "section": "Feedback",
    "description": "Size variant: - \"sm\" Small inline spinner; use inside a button or tight UI region. - \"md\" Section-level spinner; overlays a card or form section. - \"lg\" Page-level spinner; fills the content area. - \"fullscreen\" Blocks the entire viewport; use for navigation to external pages (E-Sign, QuickDecision) or global submission flows.",
    "storyId": "feedback-loadingoverlay--small",
    "source": "src/components/feedback/LoadingOverlay.tsx"
  },
  {
    "id": "component-page-alert",
    "name": "PageAlert",
    "section": "Feedback",
    "description": "Alert severity. Defaults to \"error\".",
    "storyId": "feedback-pagealert--error",
    "source": "src/components/feedback/PageAlert.tsx"
  },
  {
    "id": "component-page-transition-skeleton",
    "name": "PageTransitionSkeleton",
    "section": "Feedback",
    "description": "Status message shown above the skeletons during a page transition.",
    "storyId": "feedback-pagetransitionskeleton--with-message",
    "source": "src/components/feedback/PageTransitionSkeleton.tsx"
  },
  {
    "id": "component-processing-status-page",
    "name": "ProcessingStatusPage",
    "section": "Feedback",
    "description": "Centered in-page processing status used while an external decision completes.",
    "storyId": "feedback-processingstatuspage--external-service",
    "source": "src/components/feedback/ProcessingStatusPage.tsx"
  },
  {
    "id": "component-progress-saved-snackbar",
    "name": "ProgressSavedSnackbar",
    "section": "Feedback",
    "description": "Confirms that application progress has been saved.",
    "storyId": "feedback-appsnackbar--success",
    "source": "src/components/feedback/ProgressSavedSnackbar.tsx"
  },
  {
    "id": "component-resend-countdown-row",
    "name": "ResendCountdownRow",
    "section": "Feedback",
    "description": "Shows the resend countdown and action for a verification message.",
    "storyId": "feedback-resume-expiration--active-link",
    "source": "src/components/feedback/ResendCountdownRow.tsx"
  },
  {
    "id": "component-conditional-group",
    "name": "ConditionalGroup",
    "section": "Forms",
    "description": "ConditionalGroup renders a left-bordered, indented container that visually groups follow-up questions which are conditional on a prior answer. This is a pure visual wrapper — the parent is responsible for deciding when to render it. It does not own show/hide logic.",
    "storyId": "forms-conditionalgroup--hidden-and-revealed",
    "source": "src/components/forms/ConditionalGroup.tsx"
  },
  {
    "id": "component-dynamic-list",
    "name": "DynamicList",
    "section": "Forms",
    "description": "Collects repeated records through add, edit and remove actions in a dialog.",
    "storyId": "forms-dynamiclist--empty",
    "source": "src/components/forms/DynamicList.tsx"
  },
  {
    "id": "component-dynamic-list-item",
    "name": "DynamicListItem",
    "section": "Forms",
    "description": "Displays one repeated record with its edit and remove controls.",
    "storyId": "forms-dynamiclistitem--default",
    "source": "src/components/forms/DynamicListItem.tsx"
  },
  {
    "id": "component-field-renderer",
    "name": "FieldRenderer",
    "section": "Forms",
    "description": "Renders a configured field with its input, validation and conditional behavior.",
    "storyId": "forms-fieldrenderer--playground",
    "source": "src/components/forms/FieldRenderer.tsx"
  },
  {
    "id": "component-radio-selection-group",
    "name": "RadioSelectionGroup",
    "section": "Forms",
    "description": "Accessible radio rows using the app's canonical SelectionGroup surface.",
    "storyId": "forms-radioselectiongroup--interactive",
    "source": "src/components/forms/RadioSelectionGroup.tsx"
  },
  {
    "id": "component-selection-group",
    "name": "SelectionGroup",
    "section": "Forms",
    "description": "Provides a selectable row or card with the shared selection styling.",
    "storyId": "forms-selectiongroup--checkbox-row-unselected",
    "source": "src/components/forms/SelectionGroup.tsx"
  },
  {
    "id": "component-application-preview",
    "name": "ApplicationPreview",
    "section": "Home",
    "description": "Animates a sample application through coverage selection, details and review.",
    "storyId": "home-applicationpreview--animated",
    "source": "src/components/home/ApplicationPreview.tsx"
  },
  {
    "id": "component-app-body",
    "name": "AppBody",
    "section": "Layout",
    "description": "Provides the main application content container and responsive spacing.",
    "storyId": "layout-appbody--default",
    "source": "src/components/layout/AppBody.tsx"
  },
  {
    "id": "component-app-footer",
    "name": "AppFooter",
    "section": "Layout",
    "description": "Displays administrator, insurer, support and legal details.",
    "storyId": "layout-appfooter--default",
    "source": "src/components/layout/AppFooter.tsx"
  },
  {
    "id": "component-app-header",
    "name": "AppHeader",
    "section": "Layout",
    "description": "Controls which header actions are shown. Defaults to \"applicationForm\".",
    "storyId": "layout-appheader--homepage-variant",
    "source": "src/components/layout/AppHeader.tsx"
  },
  {
    "id": "component-applicant-section-divider",
    "name": "ApplicantSectionDivider",
    "section": "Layout",
    "description": "Optional info note displayed below the section header and above the children.",
    "storyId": "layout-applicantsectiondivider--member-section",
    "source": "src/components/layout/ApplicantSectionDivider.tsx"
  },
  {
    "id": "component-app-menu",
    "name": "AppMenu",
    "section": "Layout",
    "description": "Provides application navigation and informational drawers.",
    "storyId": "layout-appmenu--default",
    "source": "src/components/layout/AppMenu.tsx"
  },
  {
    "id": "component-app-shell",
    "name": "AppShell",
    "section": "Layout",
    "description": "Controls which chrome elements AppLayout renders: - \"applicationForm\" Full chrome: header with hamburger menu + cart icon + progress bar, footer. Used for all application form pages. - \"homepage\" Marketing chrome: header with hamburger menu (no progress bar), footer. Used for the Home/Landing page. - \"advisorLogin\" | \"advisorSend\" Utility chrome: header with logo only, no menu, no progress bar. Used for advisor flow pages. - \"resumeEmailCode\" Utility chrome: header with logo only, no menu, no progress bar. Used for the resume magic-link / phone-code pages.",
    "storyId": "layout-appshell--application-form-variant",
    "source": "src/components/layout/AppShell.tsx"
  },
  {
    "id": "component-category-card",
    "name": "CategoryCard",
    "section": "Layout",
    "description": "Surface card wrapping a category header + content stack. Used on Payment, Beneficiary, and ProductCatalog pages.",
    "storyId": "layout-categorycard--default",
    "source": "src/components/layout/CategoryCard.tsx"
  },
  {
    "id": "component-category-header",
    "name": "CategoryHeader",
    "section": "Layout",
    "description": "Heading with an optional icon for coverage category sections. Rendered as an h3 (nested under the page's h2) with h6 visual styling preserved. Icon renders in primary color; label renders in default text color.",
    "storyId": "layout-categoryheader--with-icon",
    "source": "src/components/layout/CategoryHeader.tsx"
  },
  {
    "id": "component-client-help-banner",
    "name": "ClientHelpBanner",
    "section": "Layout",
    "description": "Provides client-configured phone, chat and other support actions.",
    "storyId": "layout-clienthelpbanner--default",
    "source": "src/components/layout/ClientHelpBanner.tsx"
  },
  {
    "id": "component-field-grid",
    "name": "FieldGrid",
    "section": "Layout",
    "description": "Responsive form row that collapses to one column below the sm breakpoint.",
    "storyId": "layout-fieldgrid--equal-columns",
    "source": "src/components/layout/FieldGrid.tsx"
  },
  {
    "id": "component-form-shell",
    "name": "FormShell",
    "section": "Layout",
    "description": "Arranges the form content, navigation and application progress.",
    "storyId": "layout-formshell--default",
    "source": "src/components/layout/FormShell.tsx"
  },
  {
    "id": "component-mobile-preview-frame",
    "name": "MobilePreviewFrame",
    "section": "Layout",
    "description": "Presentation-only mobile viewport shared by previews with otherwise unrelated data and interaction models.",
    "storyId": "layout-mobilepreviewframe--default",
    "source": "src/components/ui/MobilePreviewFrame.tsx"
  },
  {
    "id": "component-page-header",
    "name": "PageHeader",
    "section": "Layout",
    "description": "Optional help chips, info links, or contextual UI rendered below the title.",
    "storyId": "layout-pageheader--default",
    "source": "src/components/layout/PageHeader.tsx"
  },
  {
    "id": "component-page-shell",
    "name": "PageShell",
    "section": "Layout",
    "description": "Provides a shared page container and layout.",
    "storyId": "layout-pageshell--default",
    "source": "src/components/layout/PageShell.tsx"
  },
  {
    "id": "component-page-title",
    "name": "PageTitle",
    "section": "Layout",
    "description": "Displays the page heading, subtitle and supporting actions.",
    "storyId": "layout-pagetitle--title-only",
    "source": "src/components/layout/PageTitle.tsx"
  },
  {
    "id": "component-product-card",
    "name": "ProductCard",
    "section": "Layout",
    "description": "Green border + tinted bg when any applicant is selected.",
    "storyId": "layout-productcard--unselected",
    "source": "src/components/layout/ProductCard.tsx"
  },
  {
    "id": "component-section-divider",
    "name": "SectionDivider",
    "section": "Layout",
    "description": "Semantic presets — use these instead of specifying chipVariant/chipColor/size individually: \"subsection\" — outlined, default gray, small (coverage question sub-sections, page sections)",
    "storyId": "layout-sectiondivider--subsection-preset",
    "source": "src/components/layout/SectionDivider.tsx"
  },
  {
    "id": "component-page-nav",
    "name": "PageNav",
    "section": "Navigation",
    "description": "The form id this submit button targets.",
    "storyId": "navigation-pagenav--default",
    "source": "src/components/navigation/PageNav.tsx"
  },
  {
    "id": "component-progress-step",
    "name": "ProgressStep",
    "section": "Navigation",
    "description": "Builds a breadcrumb-friendly list of page entries for a step. Health pages are consolidated into a single \"Health\" entry.",
    "storyId": "navigation-progressstep--collapsed-steps",
    "source": "src/components/navigation/ProgressStep.tsx"
  },
  {
    "id": "component-app-drawer",
    "name": "AppDrawer",
    "section": "Overlays",
    "description": "Optional title shown in the standard drawer header with a close button. Omit when the content manages its own header.",
    "storyId": "overlays-appdrawer--default",
    "source": "src/components/layout/AppDrawer.tsx"
  },
  {
    "id": "component-app-modal",
    "name": "AppModal",
    "section": "Overlays",
    "description": "Defaults to \"contained\" for the primary action, \"text\" for secondary.",
    "storyId": "overlays-appmodal--default",
    "source": "src/components/layout/AppModal.tsx"
  },
  {
    "id": "component-confirmation-dialog",
    "name": "ConfirmationDialog",
    "section": "Overlays",
    "description": "Requests confirmation before continuing a consequential application action.",
    "storyId": "overlays-confirmationdialog--default",
    "source": "src/components/layout/ConfirmationDialog.tsx"
  },
  {
    "id": "component-cookie-dialog",
    "name": "CookieDialog",
    "section": "Overlays",
    "description": "Displays cookie information and consent controls.",
    "storyId": "overlays-cookiedialog--default",
    "source": "src/components/layout/CookieDialog.tsx"
  },
  {
    "id": "component-send-application-dialog",
    "name": "SendApplicationDialog",
    "section": "Overlays",
    "description": "Optional title override for the modal.",
    "storyId": "overlays-sendapplicationdialog--default",
    "source": "src/components/layout/SendApplicationDialog.tsx"
  }
];
