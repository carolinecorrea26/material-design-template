// ---------------------------------------------------------------------------
// Configurations data
//
// Extracted from src/pages/InformationArchitecture.tsx (Configurations
// section). Note: featureStatusDisplay (keyed on FeatureImplementationStatus)
// lives next to configurationsData in the source file, but it describes
// feature-implementation status display, not configuration rows/groups — it
// belongs conceptually with features.ts and was intentionally left in place
// rather than duplicated here.
// ---------------------------------------------------------------------------

export type ConfigurationScope = "Global" | "Client Configurable";
export type ConfigurationRequirement = "Required" | "Optional";

export function getConfigurationGroupAnchor(group: string): string {
  return `configuration-group-${group
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")}`;
}

export type ConfigRow = {
  /** Stable relational identifier. `name` remains the implementation key. */
  id: `config-${string}`;
  group: string;
  label: string;
  name: string; // code-style key shown as secondary identifier
  description: string;
  sourcePath: string;
  scope: ConfigurationScope;
  usedIn: string;
};

export type ConfigurationPage = {
  /** The registered page used for canonical Site Details ordering. */
  id: string;
  /** The user-facing value shown in the table's Page column. */
  label: string;
};

const CONFIGURATION_PAGE_BY_NAME: Partial<Record<string, ConfigurationPage>> = {
  "ClientConfig.features.homePageVariant": { id: "home", label: "Home" },
  "ClientConfig.features.defaultTemplate": { id: "home", label: "Home" },
  "ClientConfig.features.chat / chatUrl": { id: "home", label: "Home" },
  "ClientConfig.features.scheduleUrl": { id: "home", label: "Home" },
  "ClientConfig.features.linkUrl / linkLabel": { id: "home", label: "Home" },
  "content.home.hero.*": { id: "home", label: "Home" },
  "content.home.clientSection": { id: "home", label: "Home" },
  "content.home.howApplyingWorks / applyingSteps": { id: "home", label: "Home" },
  "content.home.coverageOptions": { id: "home", label: "Home" },
  "content.home.nylCredentials": { id: "home", label: "Home" },
  "ClientConfig.pages.requirements.beneficiary / payment": {
    id: "beneficiary",
    label: "Beneficiary / Payment",
  },
  "ClientConfig.coverages.categories": { id: "coverage", label: "Coverage" },
  "ClientConfig.coverages.categorySectionLabels / allCategoriesExpanded": {
    id: "coverage",
    label: "Coverage",
  },
  "ClientConfig.coverages.additionalCoverageWarning": { id: "coverage", label: "Coverage" },
  "content.coverage.categoryDescriptions": { id: "coverage", label: "Coverage" },
  "categoryMaxAggregateNotes / siteMaxAggregateNoteOverrides": {
    id: "coverage",
    label: "Coverage",
  },
  setCoverageAmount: { id: "coverage", label: "Coverage" },
  setCoverageOrder: { id: "coverage", label: "Coverage" },
  "ClientConfig.coverages.enabled / overrides": { id: "coverage", label: "Coverage" },
  "ClientConfig.coverages.coverageAmounts[productId]": {
    id: "coverage",
    label: "Coverage",
  },
  "overrides[].waitingPeriodOptions / maxBenefitPeriodOptions": {
    id: "coverage",
    label: "Coverage",
  },
  "overrides[].riders": { id: "coverage", label: "Coverage" },
  "ClientConfig.estimatedRateDisplay": { id: "coverage", label: "Coverage" },
  "productEstimatedCostBreakdown / policyFee / childApplicantRider": {
    id: "coverage",
    label: "Coverage",
  },
  "ClientConfig.coverageQuestions": { id: "coverage", label: "Coverage" },
  "ClientConfig.coverages.hideSmokerQuestion": { id: "coverage", label: "Coverage" },
  "ClientConfig.fields.eligibility.extra": { id: "eligibility", label: "Eligibility" },
  setState: { id: "eligibility", label: "Eligibility" },
  "ClientConfig.emailSupport.hideContactBox": {
    id: "mock-email-preview",
    label: "Mock Email Preview",
  },
  "ClientConfig.emailSupport.supportOverride": {
    id: "mock-email-preview",
    label: "Mock Email Preview",
  },
  "ClientConfig.emailSupport.contactOverride": {
    id: "mock-email-preview",
    label: "Mock Email Preview",
  },
};

export function getConfigurationPage(config: Pick<ConfigRow, "name">): ConfigurationPage {
  return CONFIGURATION_PAGE_BY_NAME[config.name] ?? { id: "global", label: "Global" };
}

/**
 * Human-readable values a newly provisioned client receives before applying
 * any client-specific overrides. Keep these concrete: this column documents
 * the shipped template, not whether an override object happens to be absent.
 */
const CONFIGURATION_DEFAULT_DISPLAY: Partial<Record<string, string>> = {
  "ClientConfig.branding": "None",
  "ClientConfig.theme": "NYL blue (#0668FF)",
  "ClientConfig.applicantLabels": "You; Your Spouse; Your Child(ren)",
  "ClientConfig.support.phone / phoneDisplay / phoneHours": "None",
  "ClientConfig.support.email / website / address": "None",
  "ClientConfig.licenseInfo[]": "None",
  "ClientConfig.emailSupport.hideContactBox": "Show contact box",
  "ClientConfig.emailSupport.supportOverride": "Client support details",
  "ClientConfig.emailSupport.contactOverride": "Client name and acronym",
  "ClientConfig.features.homePageVariant": "Default",
  "ClientConfig.features.defaultTemplate": "Multi-step",
  "ClientConfig.features.chat / chatUrl": "Disabled",
  "ClientConfig.features.scheduleUrl": "None",
  "ClientConfig.features.linkUrl / linkLabel": "None",
  "content.home.hero.*":
    'Tagline: “Simple • Secure • Member-only rates”; title: “Safeguard your financial future.”; subtext: “Coverage designed exclusively for {client name} members. Get started today!”; primary CTA: “Begin application”; secondary CTA: “Learn more”; resume prompt/link: “Already started an application?” / “Continue here”',
  "content.home.clientSection": "None — section is hidden",
  "content.home.howApplyingWorks / applyingSteps":
    '“How does applying work?” / “Three simple steps from application to coverage.”; steps: Apply online in minutes, Answer health questions, Get your decision',
  "content.home.coverageOptions":
    '“Your coverage options” / “Learn more about the coverage available to you.”',
  "content.home.nylCredentials":
    'New York Life Insurance Company — “A trusted name for over 180 years”; A++ / AAA / Aa1 / AA+ ratings; reports as of 09/30/2025',
  "ClientConfig.pages.requirements.beneficiary / payment": "Required",
  formFlow: "Home, Membership, Eligibility, Coverage, Profile, Beneficiary, Contact, Review, E-sign, applicable Health page(s), Payment, Receipt",
  "pages / pageGroups / progressSteps": "Canonical registered-page, page-group, and progress-step definitions",
  "ClientConfig.coverages.categories": "No global enabled-category list — supplied per client",
  "ClientConfig.coverages.categorySectionLabels / allCategoriesExpanded":
    "Standard category labels; collapsed",
  "ClientConfig.coverages.additionalCoverageWarning": "Apply for additional coverage",
  "content.coverage.categoryDescriptions": "Shared category descriptions from the global content defaults",
  "categoryMaxAggregateNotes / siteMaxAggregateNoteOverrides":
    "Life: $2,000,000 aggregate maximum for member and spouse; no note for other categories",
  setCoverageAmount: "None",
  setCoverageOrder: "None",
  "ClientConfig.coverages.enabled / overrides": "None",
  "ClientConfig.coverages.coverageAmounts[productId]": "Product defaults",
  "overrides[].waitingPeriodOptions / maxBenefitPeriodOptions": "Product defaults; no client override",
  "overrides[].riders": "Product defaults; no client override",
  "ClientConfig.estimatedRateDisplay": "Monthly; toggle hidden",
  "productEstimatedCostBreakdown / policyFee / childApplicantRider": "Disabled",
  "ClientConfig.coverageQuestions": "Shared default personal, work/income, and business question sections",
  "ClientConfig.coverages.hideSmokerQuestion": "No — show smoker/nicotine question when applicable",
  fieldCatalog: "Shared field catalog definitions",
  "ClientConfig.fields[pageId].extra / hidden / required / overrides": "No overrides",
  "ClientConfig.fields.eligibility.extra": "None",
  setState: "None",
  "content.pages[pageId].title / subhead / navTitle / infoNote": "Shared page titles, subheads, navigation titles, and info notes from src/content/defaults/pages.ts",
  "content.pages[pageId].sectionNotes": "None unless defined in shared page content",
  "content.help": "Shared help-panel content from src/content/defaults/help.ts",
  "content.navigation": "Shared transition messages, progress labels, and Back message",
  "content.footer": "Shared New York Life underwriter, ratings, legal copy, Terms of Use, and Privacy Notice content",
  pageSections: "Shared page-section and field mappings",
  "constants / coverageConstants": "Shared application and coverage constants",
  "src/config/clients/ (10 configs)": "No single client config — each site supplies its own configuration object",
  "src/content/defaults/": "Shared home, page, help, navigation, footer, review, receipt, dialog, and status copy",
};

export function getConfigurationDefaultDisplay(config: Pick<ConfigRow, "name">): string {
  return CONFIGURATION_DEFAULT_DISPLAY[config.name] ?? "None";
}

/**
 * Values accepted by each provisioning setting. Free-form settings describe
 * their supported shape here so the reference table is useful for both enum
 * choices and structured configuration objects.
 */
const CONFIGURATION_AVAILABLE_OPTIONS: Partial<Record<string, string>> = {
  "ClientConfig.branding": "name; acronym; logo asset path; logo alt text",
  "ClientConfig.theme":
    "Preset: default, teal, purple, dark-blue; or custom primary color: #RRGGBB",
  "ClientConfig.applicantLabels":
    "member, spouse, child — custom text up to 20 characters each",
  "ClientConfig.support.phone / phoneDisplay / phoneHours":
    "phone; phoneDisplay; optional phoneHours — free-form text",
  "ClientConfig.support.email / website / address":
    "email; website URL/domain; address: organization, street, city, state, ZIP",
  "ClientConfig.licenseInfo[]": "Zero or more disclosure strings, in display order",
  "ClientConfig.emailSupport.hideContactBox": "Show contact box; Hide contact box",
  "ClientConfig.emailSupport.supportOverride":
    "phone; email; website — each optional and independently inherited",
  "ClientConfig.emailSupport.contactOverride":
    "name; acronym — each optional and independently inherited",
  "ClientConfig.features.homePageVariant":
    "default; quoteFirst; hero-image; welcome-back",
  "ClientConfig.features.defaultTemplate": "single; multi",
  "ClientConfig.features.chat / chatUrl": "Disabled; Enabled with a valid chat URL",
  "ClientConfig.features.scheduleUrl": "None; valid scheduling URL",
  "ClientConfig.features.linkUrl / linkLabel": "None; valid URL with a custom label",
  "ClientConfig.pages.requirements.beneficiary / payment": "required; optional; none",
  "ClientConfig.coverages.categorySectionLabels / allCategoriesExpanded":
    "Labels for LI, AD, DI, OO, SH; accordions collapsed or expanded",
  "ClientConfig.coverages.additionalCoverageWarning":
    "applyForAdditional; applyForTotal",
  "ClientConfig.coverages.enabled / overrides":
    "Products: li-term, li-10yr, li-15yr, li-20yr, li-50plus, li-add, li-preferred, li-premier-accident, li-group-term, di-ltd-plus, di-ltd, di-mtd, di-step-rated, di-level-rated, di-short-term, oo-professional, oo-office-overhead, sh-critical-illness, sh-hospital-money, sh-hospital-income. Overrides: name, brochure URL, category (LI/AD/DI/OO/SH), identifiers, situs, riders, waiting/benefit periods, applicants (member/spouse/child), notes, featured, underwriting (FUW/GI/NA/QD/SI/TELE), warning, structured content",
  "ClientConfig.coverages.coverageAmounts[productId]":
    "Selection: range (min/max/increment), amount list, or labeled option list; scope: all, member, spouse, child, or applicant class; dependent calculation: percentage or fixed",
  "overrides[].waitingPeriodOptions / maxBenefitPeriodOptions":
    "Waiting period: label, value, days; maximum benefit period: label, value; optionally scoped to member, spouse, or child",
  "overrides[].riders":
    "id; name; description; optional amount selections; applicants (member/spouse/child); premium factor",
  "ClientConfig.estimatedRateDisplay":
    "Frequency toggle: shown or hidden; default frequency: monthly or annual",
  "productEstimatedCostBreakdown / policyFee / childApplicantRider":
    "Breakdown enabled or disabled; policy fee label + monthly/annual amount; child rider enabled or disabled + label + monthly/annual amount",
  "ClientConfig.coverageQuestions":
    "Always-show or remove-default section IDs; per-category additions for LI, AD, DI, OO, SH",
  "ClientConfig.coverages.hideSmokerQuestion":
    "Show smoker/nicotine question; Hide smoker/nicotine question",
  "ClientConfig.fields[pageId].extra / hidden / required / overrides":
    "Per page: extra, hidden, or required registered field IDs; overrides for label, placeholder, helper text, and options",
  "ClientConfig.fields.eligibility.extra":
    "Zero or more registered eligibility field IDs",
};

export function getConfigurationAvailableOptions(config: Pick<ConfigRow, "name">): string {
  return CONFIGURATION_AVAILABLE_OPTIONS[config.name] ?? "No configurable values documented";
}

const REQUIRED_CONFIGURATION_NAMES = new Set([
  "ClientConfig.branding",
  "ClientConfig.coverages.enabled / overrides",
]);

export function getConfigurationRequirement(
  config: Pick<ConfigRow, "name">,
): ConfigurationRequirement {
  return REQUIRED_CONFIGURATION_NAMES.has(config.name) ? "Required" : "Optional";
}

type ConfigRowSource = Omit<ConfigRow, "id">;

const configurationInventory: ConfigRowSource[] = [
  // ── A. Client identity & branding ─────────────────────────────────────────
  {
    group: "Client identity & branding",
    label: "Client branding",
    name: "ClientConfig.branding",
    description:
      "Client name, short acronym, logo asset, and logo alt text. If the logo fails to load, the client name is displayed instead.",
    sourcePath: "src/config/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "AppHeader, AppShell, email templates",
  },
  {
    group: "Client identity & branding",
    label: "Site theme",
    name: "ClientConfig.theme",
    description:
      "Sets the site's primary brand color. The application derives the supporting primary palette; semantic and neutral colors remain global.",
    sourcePath: "src/config/clients/*.ts / src/app/theme.ts",
    scope: "Client Configurable",
    usedIn: "ThemeProvider (global)",
  },
  {
    group: "Client identity & branding",
    label: "Applicant labels",
    name: "ClientConfig.applicantLabels",
    description:
      "Overrides the default Member/Spouse/Child headings across Coverage and applicant sections. Max 20 characters. Does not affect applicant IDs or business logic.",
    sourcePath: "src/config/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "ApplicantSectionDivider, CoverageQuestions",
  },
  // ── B. Support & contact ──────────────────────────────────────────────────
  {
    group: "Support & contact",
    label: "Support phone & hours",
    name: "ClientConfig.support.phone / phoneDisplay / phoneHours",
    description:
      "Machine-readable support phone, human-readable display version, and optional support hours. When configured, the help banner renders 'Call for help' with optional hours.",
    sourcePath: "src/config/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "ClientHelpBanner, AppFooter, AppMenu",
  },
  {
    group: "Support & contact",
    label: "Support email, website & address",
    name: "ClientConfig.support.email / website / address",
    description:
      "Support email, client website (full URL or bare domain), and structured mailing address. Each is hidden when absent.",
    sourcePath: "src/config/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "ClientHelpBanner, AppFooter",
  },
  {
    group: "Support & contact",
    label: "License disclosures",
    name: "ClientConfig.licenseInfo[]",
    description:
      "Array of client licensing disclosure strings shown in the footer or legal area. Rendered in configured order.",
    sourcePath: "src/config/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "AppFooter",
  },
  {
    group: "Support & contact",
    label: "Hide email contact box",
    name: "ClientConfig.emailSupport.hideContactBox",
    description:
      "When true, suppresses the \"Questions? We're here to help\" contact box in this client's outbound emails (autosave, pending/deletion reminders, submission confirmation, and the advisor-sent application email).",
    sourcePath: "src/config/clients/*.ts / src/utils/mockEmail.ts",
    scope: "Client Configurable",
    usedIn: "Email Templates (Global/Client tabs), outbound mock emails",
  },
  {
    group: "Support & contact",
    label: "Email support override",
    name: "ClientConfig.emailSupport.supportOverride",
    description:
      "Overrides the client-configured phone, email, and website shown in the emails' support box. Unset properties fall back individually to ClientConfig.support.",
    sourcePath: "src/config/clients/*.ts / src/utils/mockEmail.ts",
    scope: "Client Configurable",
    usedIn: "Email Templates (Global/Client tabs), outbound mock emails",
  },
  {
    group: "Support & contact",
    label: "Email contact override",
    name: "ClientConfig.emailSupport.contactOverride",
    description:
      "Overrides the client-configured name and acronym used for the contact shown in the emails' support box. Unset properties fall back individually to ClientConfig.branding.",
    sourcePath: "src/config/clients/*.ts / src/utils/mockEmail.ts",
    scope: "Client Configurable",
    usedIn: "Email Templates (Global/Client tabs), outbound mock emails",
  },
  // ── C. Landing Page behavior ──────────────────────────────────────────────
  {
    group: "Landing Page",
    label: "Landing Page variant",
    name: "ClientConfig.features.homePageVariant",
    description:
      "Selects the Landing Page composition, including the placement of the quote experience and supporting content.",
    sourcePath: "src/config/clients/*.ts / src/pages/Home.tsx",
    scope: "Client Configurable",
    usedIn: "Home page",
  },
  {
    group: "Landing Page",
    label: "Default form template",
    name: "ClientConfig.features.defaultTemplate",
    description:
      "Selects the client's default form layout. The compact layout forces the app into its narrow responsive presentation and places Membership directly after the Home hero. Overrideable per session by the ?template= URL parameter.",
    sourcePath:
      "src/config/clients/*.ts / src/config/template/resolveTemplate.ts / src/app/theme.ts / src/pages/Home.tsx",
    scope: "Client Configurable",
    usedIn: "App theme, Home page",
  },
  {
    group: "Landing Page",
    label: "Chat support",
    name: "ClientConfig.features.chat / chatUrl",
    description:
      "Enables a chat action in the help banner and optionally in the app header. Hidden when false or when no valid URL is configured.",
    sourcePath: "src/config/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "ClientHelpBanner, AppHeader",
  },
  {
    group: "Landing Page",
    label: "Schedule-a-call support",
    name: "ClientConfig.features.scheduleUrl",
    description:
      "Displays a 'Schedule a call' action in the help banner, opening a scheduling page in a modal.",
    sourcePath: "src/config/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "ClientHelpBanner",
  },
  {
    group: "Landing Page",
    label: "Custom help/action link",
    name: "ClientConfig.features.linkUrl / linkLabel",
    description:
      "Optional client-defined action link (URL + label) in the help banner. Not displayed when absent or without a valid destination.",
    sourcePath: "src/config/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "ClientHelpBanner",
  },
  {
    group: "Landing Page",
    label: "Hero copy",
    name: "content.home.hero.*",
    description:
      "Landing Page hero copy: tagline, title, description, CTA label, secondary CTA label, resume prompt/link label, welcome-back title and description. Supports {{clientName}} interpolation.",
    sourcePath: "src/content/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "Home page hero section",
  },
  {
    group: "Landing Page",
    label: "Client-specific homepage section",
    name: "content.home.clientSection",
    description:
      "Optional client informational block on the Landing Page with a tagline and paragraphs array. Rendered only when configured.",
    sourcePath: "src/content/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "Home page",
  },
  {
    group: "Landing Page",
    label: "How Applying Works content",
    name: "content.home.howApplyingWorks / applyingSteps",
    description:
      "Title, description, and step array (title and body) for the How Applying Works section. Present on default and hero-image variants; hidden on welcome-back.",
    sourcePath: "src/content/defaults/home.ts / src/content/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "Home page, How Applying Works modal",
  },
  {
    group: "Landing Page",
    label: "Coverage options introduction",
    name: "content.home.coverageOptions",
    description:
      "Title and description for the Coverage Options section on the Landing Page. Present on default and hero-image variants; hidden on welcome-back.",
    sourcePath: "src/content/defaults/home.ts / src/content/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "Home page",
  },
  {
    group: "Landing Page",
    label: "NYL credentials",
    name: "content.home.nylCredentials",
    description:
      "NYL name, tagline, description, ratings note, and ratings array. Centrally governed — ratings and effective dates are updated globally, not per client.",
    sourcePath: "src/content/defaults/home.ts",
    scope: "Global",
    usedIn: "Home page footer",
  },
  // ── D. Page inclusion & workflow ──────────────────────────────────────────
  {
    group: "Page inclusion & workflow",
    label: "Beneficiary & Payment page mode",
    name: "ClientConfig.pages.requirements.beneficiary / payment",
    description:
      "Controls whether Beneficiary and Payment participate in the application flow. Excluded pages are removed from routing, the stepper, breadcrumbs, and Review; non-required pages begin with a Yes/No prompt. The older pages.excluded and pages.optional arrays are deprecated.",
    sourcePath: "src/config/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "Router, formFlow, ProgressStep, Review",
  },
  {
    group: "Page inclusion & workflow",
    label: "Form flow",
    name: "formFlow",
    description:
      "Ordered page sequence with skip/visibility logic. Determines which pages appear in the resolved flow for a given client and coverage selection.",
    sourcePath: "src/config/formFlow.ts",
    scope: "Global",
    usedIn: "PageNav next/prev, progress calculation",
  },
  {
    group: "Page inclusion & workflow",
    label: "Page registry & progress steps",
    name: "pages / pageGroups / progressSteps",
    description:
      "Page registry (IDs, paths, types, group assignments), logical page groupings for the progress bar, and breadcrumb step definitions mapping stages to page IDs.",
    sourcePath:
      "src/config/pages.ts / src/config/pageGroups.ts / src/config/progressSteps.ts",
    scope: "Global",
    usedIn: "Router, ProgressStep, PageNav",
  },
  // ── E. Coverage categories ────────────────────────────────────────────────
  {
    group: "Coverage categories",
    label: "Enabled categories",
    name: "ClientConfig.coverages.categories",
    description:
      "Array of enabled coverage category IDs (LI, AD, DI, OO, SH) for the client. Display order follows array order. Eligibility may further reduce visible categories.",
    sourcePath: "src/config/clients/*.ts / src/config/coverageCategories.ts",
    scope: "Client Configurable",
    usedIn: "CoverageCategorySelector, ProductCatalog, form flow",
  },
  {
    group: "Coverage categories",
    label: "Category label overrides & expand behavior",
    name: "ClientConfig.coverages.categorySectionLabels / allCategoriesExpanded",
    description:
      "Per-category display label overrides and a boolean controlling whether category accordions start expanded on load.",
    sourcePath: "src/config/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "ProductCatalog, CoverageCategorySelector",
  },
  {
    group: "Coverage categories",
    label: "Coverage amount basis",
    name: "ClientConfig.coverages.additionalCoverageWarning",
    description:
      "Controls whether applicants enter an additional amount or a total coverage amount.",
    sourcePath: "src/config/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "ProductCatalog, coverage amount logic",
  },
  {
    group: "Coverage categories",
    label: "Category descriptions",
    name: "content.coverage.categoryDescriptions",
    description:
      "Explanatory copy displayed per coverage category. Shared defaults apply unless overridden per client.",
    sourcePath: "src/content/defaults/coverage.ts / src/content/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "ProductCatalog, CoverageCategorySelector",
  },
  {
    group: "Coverage categories",
    label: "Max aggregate coverage note (info alert)",
    name: "categoryMaxAggregateNotes / siteMaxAggregateNoteOverrides",
    description:
      "Info alert shown at the top of a coverage category's product list stating the maximum aggregate amount available per member/spouse/child across policies (e.g. LI's $2,000,000 cap). Defaults apply per category unless a client override maps the category to a replacement note object or null to suppress it entirely. WAEPA overrides LI with member/spouse-only text (\"The maximum available for a member/spouse is $2,000,000.\"); AVMA overrides LI with member/spouse/child text noting the Basic Protection Package exclusion.",
    sourcePath: "src/config/coverageConstants.ts (getMaxAggregateNotes)",
    scope: "Client Configurable",
    usedIn: "ProductCatalog",
  },
  // ── F. Products & coverage options ───────────────────────────────────────
  {
    group: "Products & coverage options",
    label: "Set coverage amount",
    name: "setCoverageAmount",
    description:
      "Planned configuration. Sets the Coverage page coverage-amount dropdown to a specified amount and disables the control so the applicant cannot change it.",
    sourcePath: "Planned — not yet implemented in prototype",
    scope: "Client Configurable",
    usedIn: "Coverage page coverage amount dropdown",
  },
  {
    group: "Products & coverage options",
    label: "Set coverage amount order",
    name: "setCoverageOrder",
    description:
      "Planned configuration. Controls whether coverage-amount dropdown options are displayed in ascending or descending order.",
    sourcePath: "Planned — not yet implemented in prototype",
    scope: "Client Configurable",
    usedIn: "Coverage page coverage amount dropdown",
  },
  {
    group: "Products & coverage options",
    label: "Enabled products & overrides",
    name: "ClientConfig.coverages.enabled / overrides",
    description:
      "Selects the products offered by the site and applies per-product presentation, eligibility, identifier, underwriting, and supporting-content overrides.",
    sourcePath: "src/config/clients/*.ts / src/config/coverages/index.ts",
    scope: "Client Configurable",
    usedIn: "ProductCatalog, QuoteModal, health routing",
  },
  {
    group: "Products & coverage options",
    label: "Scoped coverage amounts",
    name: "ClientConfig.coverages.coverageAmounts[productId]",
    description:
      "Defines the coverage amounts available for each product and applicant scope, including derived dependent coverage.",
    sourcePath: "src/config/coverages/index.ts → coverageAmounts",
    scope: "Client Configurable",
    usedIn: "ProductCatalog, CoverageCart, QuoteModal",
  },
  {
    group: "Products & coverage options",
    label: "Waiting period & benefit period options",
    name: "overrides[].waitingPeriodOptions / maxBenefitPeriodOptions",
    description:
      "Defines the elimination/waiting periods and maximum benefit periods offered for applicable DI/OO products.",
    sourcePath: "src/config/coverages/index.ts → overrides",
    scope: "Client Configurable",
    usedIn: "ProductCatalog",
  },
  {
    group: "Products & coverage options",
    label: "Rider definitions",
    name: "overrides[].riders",
    description:
      "Defines the riders offered per product and their pricing and health-routing behavior. Rider IDs must be stable across config changes.",
    sourcePath: "src/config/coverages/index.ts → overrides[].riders",
    scope: "Client Configurable",
    usedIn: "ProductCatalog, form flow health routing",
  },
  // ── I. Premium & estimated cost display ───────────────────────────────────
  {
    group: "Premium & estimated cost",
    label: "Frequency toggle",
    name: "ClientConfig.estimatedRateDisplay",
    description:
      "Controls the monthly/annual frequency toggle and default frequency for estimated cost display.",
    sourcePath: "src/config/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "CoverageCart, QuoteModal, TotalCostSummary",
  },
  {
    group: "Premium & estimated cost",
    label: "Cost breakdown & supplemental fees",
    name: "productEstimatedCostBreakdown / policyFee / childApplicantRider",
    description:
      "Controls supplemental cost line items beneath product estimates.",
    sourcePath: "src/config/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "ProductCostBreakdown, CoverageCart",
  },
  // ── J. Coverage-question sections ─────────────────────────────────────────
  {
    group: "Coverage question sections",
    label: "Coverage question section rules",
    name: "ClientConfig.coverageQuestions",
    description:
      "Controls which Coverage page question sections appear: always-shown sections, removed default sections, and per-category additional sections. References stable section IDs from the shared pageSections catalog.",
    sourcePath:
      "src/config/clients/*.ts / src/config/pageSections/pageSections.ts",
    scope: "Client Configurable",
    usedIn: "CoverageQuestions",
  },
  {
    group: "Coverage question sections",
    label: "Hide smoker/nicotine question (quote tool)",
    name: "ClientConfig.coverages.hideSmokerQuestion",
    description:
      "When true, suppresses the smoker/nicotine-use question in the standalone quote tool (QuoteModal drawer and the home page's QuoteCalculator) for LI/SH category selections, regardless of category. Does not affect the real Coverage page application flow (useCoverageState), which always asks the smoker question for LI/SH — WAEPA's underwriting still requires it there, only their public quote estimator omits it.",
    sourcePath: "src/config/coverageConstants.ts (getCategoryRequirements)",
    scope: "Client Configurable",
    usedIn: "QuoteModal, QuoteCalculator",
  },
  // ── K. Field configuration ────────────────────────────────────────────────
  {
    group: "Field configuration",
    label: "Field catalog",
    name: "fieldCatalog",
    description:
      "Master field definitions: labels, input types, options, validation rules, format, placeholder, helper text, autoComplete. All field rendering flows through FieldRenderer using these definitions.",
    sourcePath: "src/config/fields/index.ts",
    scope: "Client Configurable",
    usedIn: "FieldRenderer, pageSections, form state",
  },
  {
    group: "Field configuration",
    label: "Per-page field overrides",
    name: "ClientConfig.fields[pageId].extra / hidden / required / overrides",
    description:
      "Controls field presence, requirement, and presentation per client and page. Hidden fields must not be required, and field IDs must exist in the catalog.",
    sourcePath: "src/config/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "FieldRenderer, pageSections",
  },
  {
    group: "Field configuration",
    label: "Client eligibility fields",
    name: "ClientConfig.fields.eligibility.extra",
    description:
      "Client-specific eligibility questions inserted into the Eligibility page. New fields must be created as reusable supported field definitions, not client-only JSX.",
    sourcePath: "src/config/clients/*.ts → clientFields/",
    scope: "Client Configurable",
    usedIn: "Eligibility page, EligibilityFields",
  },
  {
    group: "Field configuration",
    label: "Set state",
    name: "setState",
    description:
      "Planned configuration. Sets the Eligibility page state dropdown to a specified state and disables the control so the applicant cannot change it.",
    sourcePath: "Planned — not yet implemented in prototype",
    scope: "Client Configurable",
    usedIn: "Eligibility page state dropdown",
  },
  // ── L. Page, section & help content ──────────────────────────────────────
  {
    group: "Page & help content",
    label: "Page title, subtitle & info note",
    name: "content.pages[pageId].title / subhead / navTitle / infoNote",
    description:
      "Per-page content: main H1 heading, subtitle, navigation label, and an optional informational note displayed below the title.",
    sourcePath: "src/content/defaults/pages.ts / src/content/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "PageHeader, AppHeader progress, ProgressStep",
  },
  {
    group: "Page & help content",
    label: "Section notes",
    name: "content.pages[pageId].sectionNotes",
    description:
      "Informational notes keyed by section ID, displayed below specific section headings.",
    sourcePath: "src/content/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "Form pages (section rendering)",
  },
  {
    group: "Page & help content",
    label: "Help panel content",
    name: "content.help",
    description:
      "Structured help content for How Applying Works, application review, group insurance, Coverage, beneficiary allocation, field rationale, and payment handling. Client overrides merge at the property level.",
    sourcePath: "src/content/defaults/help.ts / src/content/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "HelpChips, AppMenu, helpContent.tsx",
  },
  {
    group: "Page & help content",
    label: "Navigation & transition messages",
    name: "content.navigation",
    description:
      "Route transition messages (by destination page), progress step labels (by stage ID), and the shared Back navigation message. Pages excluded from the flow must not appear in step labels.",
    sourcePath:
      "src/content/defaults/navigation.ts / src/config/transitionMessages.ts",
    scope: "Global",
    usedIn: "LoadingOverlay, ProgressStep",
  },
  // ── M. Footer, legal & compliance ─────────────────────────────────────────
  {
    group: "Footer, legal & compliance",
    label: "Footer content & ratings",
    name: "content.footer",
    description:
      "Administrator label, underwriter name and address, financial strength ratings with 'as of' date, additional legal lines, and Terms of Use / Privacy Notice links. Ratings and effective date are centrally governed. Terms of Use and Privacy Notice content are fixed and not client-configurable.",
    sourcePath: "src/content/defaults/footer.ts / src/content/clients/*.ts",
    scope: "Client Configurable",
    usedIn: "AppFooter, LegalDocList",
  },
  // ── Shared infrastructure ─────────────────────────────────────────────────
  {
    group: "Shared infrastructure",
    label: "Page sections catalog",
    name: "pageSections",
    description:
      "Section-to-field mappings per page with visibleWhen rules and applicant scoping. Client configuration should reference section IDs only; structural definitions belong here.",
    sourcePath: "src/config/pageSections/pageSections.ts",
    scope: "Client Configurable",
    usedIn: "FieldRenderer, CoverageQuestions, ApplicationDocumentPreview",
  },
  {
    group: "Shared infrastructure",
    label: "Shared constants",
    name: "constants / coverageConstants",
    description:
      "Shared UI constants (YES_NO_OPTIONS, SURFACE_SX, CARD_RADIUS) and coverage-specific constants for amount calculations.",
    sourcePath: "src/config/constants.ts / src/config/coverageConstants.ts",
    scope: "Global",
    usedIn: "FieldRenderer options, layout styles, coverage amount logic",
  },
  {
    group: "Shared infrastructure",
    label: "Client site configs",
    name: "src/config/clients/ (10 configs)",
    description:
      "Legacy configuration objects combining branding, support, features, pages, coverages, fields, and estimatedRateDisplay. Site-based resolvers adapt these while the remaining configuration domains are normalized incrementally.",
    sourcePath: "src/config/clients/",
    scope: "Client Configurable",
    usedIn: "Site compatibility adapters and remaining page rendering",
  },
  {
    group: "Shared infrastructure",
    label: "Default content",
    name: "src/content/defaults/",
    description:
      "Shared default content used when a client does not override it: page titles, helper copy, Landing Page content, footer content, navigation messages, receipt/review content.",
    sourcePath: "src/content/defaults/",
    scope: "Global",
    usedIn: "All content-consuming components",
  },
];

/**
 * Actual site configuration options. Content editing, global constants,
 * derived category behavior, structural catalogs, and unimplemented ideas
 * intentionally stay out of this list so provisioning choices are explicit.
 */
const NON_OPTION_NAMES = new Set([
  "ClientConfig.coverages.categories",
  "categoryMaxAggregateNotes / siteMaxAggregateNoteOverrides",
  "fieldCatalog",
  "formFlow",
  "pages / pageGroups / progressSteps",
  "pageSections",
  "constants / coverageConstants",
  "src/config/clients/ (10 configs)",
  "src/content/defaults/",
]);

function configurationId(name: string): ConfigRow["id"] {
  return `config-${name
    .replace(/ClientConfig\.?/g, "")
    .replace(/\[\]/g, "-list")
    .replace(/[^a-zA-Z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .toLowerCase()}`;
}

export const configurationsData: ConfigRow[] = configurationInventory
  .filter(
    (row) =>
      row.scope === "Client Configurable" &&
      !row.name.startsWith("content.") &&
      !row.sourcePath.startsWith("Planned") &&
      !NON_OPTION_NAMES.has(row.name),
  )
  .map((row) => ({ ...row, id: configurationId(row.name) }));

/**
 * Distinct `group` values from configurationsData, ordered to roughly follow
 * the application's flow: branding/identity and shared infrastructure first
 * (they underpin everything else), then support & contact, then the Landing
 * Page, then per-page-group configuration in the order those pages/concerns
 * appear in the app flow (page inclusion/workflow → coverage categories →
 * products & coverage options → coverage question sections → premium/cost
 * display → field configuration → page & help content), with footer/legal
 * last since it's compliance/wrap-up content rather than an application step.
 */
export const applicationFlowGroupOrder: string[] = [
  "Client identity & branding",
  "Shared infrastructure",
  "Support & contact",
  "Landing Page",
  "Page inclusion & workflow",
  "Coverage categories",
  "Products & coverage options",
  "Coverage question sections",
  "Premium & estimated cost",
  "Field configuration",
  "Page & help content",
  "Footer, legal & compliance",
];
