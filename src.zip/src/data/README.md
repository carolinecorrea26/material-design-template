# Normalized data model — phase 3

This directory is the incremental canonical relational layer shared by the runtime and Portal Admin.
Legacy `ClientConfig` consumers remain supported through adapters while identity and relationships move
to stable Client, Site, and Association IDs.

**Client, Site, and Association are separate domain identities even when they happen to be 1:1.**

## Canonical identities and relationships

```text
Client
 ├──< Site
 └──< Association

Site ──< SiteAssociation >── Association
```

- `Client.id` identifies the customer/account.
- `Site.id` identifies a deployment or application experience.
- `Association.id` identifies the membership organization independently of Client and Site.
- `SiteAssociation.id` is deterministic (`{siteId}--{associationId}`) and enables an Association for a Site.
- `Association.clientId`, `Site.clientId`, `SiteAssociation.siteId`, and
  `SiteAssociation.associationId` are validated relational IDs.
- A Site can only expose Associations owned by its Client.

## Association selection and active context

A Site may configure one of three selection modes:

- `fixed`: resolves a configured Association directly; no selection control is shown.
- `url-parameter`: validates the documented `association` value against enabled Site relationships.
  Missing or invalid required values return an explicit blocking state; arbitrary URL text is never
  displayed or converted into an asset path.
- `select`: generates the Membership searchable-select options from `getAssociationsForSite(siteId)`.
  The submitted Association ID becomes the active Association in the existing application context.

`resolveAssociationSelection` is the pure domain resolver. Browser/form adapters supply the URL and
form values to `resolveActiveAssociation`; UI components consume the result rather than implementing
selection independently.

Association branding is separate from Association data. A Site may opt into
`associationBranding.useAssociationLogo`. Effective branding resolves in this order:

```text
Client branding → Site branding override → active Association logo (when enabled) → effective branding
```

If the active Association has no logo, the resolver safely retains the effective Site/Client logo.

## ISITRUST and WAEPA proof cases

- All 25 formerly hardcoded ISITRUST Membership options are canonical Association records and
  SiteAssociation records. `isitrust-default` uses `select` mode; its field options are derived at runtime.
- WAEPA has one canonical Association record. Both `waepa-standard` and `waepa-gi` use `fixed` mode and
  reference that same record, proving one Client → many Sites → one shared Association.
- AMA, ASCE, and AVMA have fixed canonical Associations where the full identity is explicit in current data.
  Other legacy clients remain unconfigured rather than inventing Association names.

## Current source-of-truth audit

| Business concept | Current canonical/runtime source | Parallel or derived representation |
| --- | --- | --- |
| Clients and Sites | `registry.ts`; WAEPA authored in `waepa.ts` | Other clients adapt `config/clients/*.ts`; `clientGroups.ts` remains legacy |
| Associations and Site relationships | `associations.ts` and registry relationship APIs | Membership field options are derived, not authored |
| Active Association and branding | `associationSelection.ts`, `activeAssociation.ts`, `resolvers.ts`, existing application context | None for Association selection; legacy ClientConfig still supplies non-Association defaults |
| Pages, groups, and progress | Existing `src/config` registries | Documentation resolvers add display metadata |
| Fields | `config/fields` | `membershipClientFields` remains a Site-keyed parallel source for genuinely Site-specific membership rules |
| Coverage/config/rules/flows | Existing normalized Phase 1 registries and resolvers | Several legacy/config documentation representations remain |
| CMS and content | `SiteId`-keyed content overrides, CMS entries, and content builders | Legacy-client adapter retained only for design previews |
| Email | `SiteId`-keyed preview generation and persistence | Legacy stored previews are upgraded through a compatibility adapter when read |

## Compatibility retained

- `getActiveClient()` still returns the legacy effective `ClientConfig` for the active Site.
- `resolveClientId()` still returns the Site's legacy runtime ID.
- Runtime-generated links and developer tools emit `?site=`. `?client=` remains a supported read-only compatibility alias.
- `legacyClientId`, the `waepagi` legacy ID, `clientGroups.ts`, and `ClientConfig` remain in place.
- WAEPA's special Membership behavior remains unchanged.
- Association selection changes neither the active Client ID nor the active Site ID.

## Remaining duplicated/parallel sources

1. `membershipClientFields` still holds genuinely Site-specific questions and conditional fields, but no Association lists.
2. Page components still consume effective legacy `ClientConfig` through the active-Site adapter while their configuration domains are normalized.
3. `pageFields.ts` duplicates relationships present in `pageSections.ts`.
4. Configuration definitions, executable defaults/accessors, flow diagrams, and rule prose remain separately authored.
5. Single-site Clients other than WAEPA are still adapted from `src/config/clients`.
6. `legacyClientId`, `clientGroups.ts`, and the `waepagi` compatibility ID remain until configuration consumers no longer require `ClientConfig`.

## Phase 3 runtime migration

Content overrides/builders, CMS inspection, email previews, resume links, prototype links, coverage-note
overrides, membership overrides, cross-Site page discovery, and developer Site switching now use `SiteId`.
Association-aware runtime copy and email payloads resolve the active canonical Association independently
from Client and Site identity. Stored email previews written before this migration are mapped to a Site
when read. Compatibility-only structures have not been removed while configuration consumers still need them.

## Recommended phase 4

Move the remaining single-site clients into explicit Client defaults plus Site overrides, migrate page
components from the effective `ClientConfig` adapter to domain-specific Site resolvers, derive flat page
fields from page sections, and then retire `clientGroups.ts`, `clientGroupId`, `siteLabel`, the `waepagi`
legacy ID, and `resolveClientId()` only after their final consumers have moved.
