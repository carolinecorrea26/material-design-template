import { getClientAliasForSite, getSite } from "../repositories/sites";

/** Unique Site acronym for selectors; preserves stored identities and URLs. */
export function getSiteAcronym(siteKey: string): string {
  return (getSite(siteKey) ? getClientAliasForSite(siteKey) : siteKey).toUpperCase();
}
