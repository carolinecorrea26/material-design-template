import type { Meta, StoryObj } from '@storybook/react-vite';
import { Stack, Typography } from '@mui/material';
import ComponentCatalogTable from '../components/docs/ComponentCatalogTable';
import { componentCatalog } from '../content/docs/components';
import { componentRoleLabels, componentRoles, reusableComponents } from '../domain/componentCatalog';

const rows = componentCatalog.map((row, position) => ({ id: row.id, key: row.id, position, definition: { ...row, storybookPath: `?path=/story/${row.storyId}` } }));
const localStoryUrl = (storyId: string) => `./?path=/story/${storyId}`;

const meta = {
  title: 'Reusable components/Catalog',
  id: 'component-reuse',
  parameters: { layout: 'fullscreen' },
} satisfies Meta;
export default meta;

/** An index of canonical examples, not duplicate stories or definitions. */
export const Catalog: StoryObj = {
  render: () => <Stack spacing={2} sx={{ p: { xs: 2, md: 4 } }}>
    <Typography variant="h1">Reusable components</Typography>
    <Typography>One definition per component, classified as application frame, page section or shared piece. Reuse is derived separately from production placements. Contains links and internal parts explain composition; conditional variants are included.</Typography>
    <ComponentCatalogTable reusable storyUrl={localStoryUrl} catalog={rows} rows={reusableComponents(rows)} />
  </Stack>,
};

export const Structure: StoryObj = {
  name: 'Application frame, sections and shared pieces',
  render: () => <Stack spacing={3} sx={{ p: { xs: 2, md: 4 } }}>
    <Typography variant="h1">Component structure</Typography>
    <Typography>Application frame → page sections → shared pieces. This index reads the saved component JSON. Layout, Forms, Pages, Dialogs, Feedback and Transitions remain browsing categories; role describes each component’s primary responsibility.</Typography>
    <Typography>The prototype composes these React implementations with saved Site settings, fields, content and flow rules. Contains records direct registered source dependencies, including conditional paths. Slots and named exports stay within their owning component, and page examples demonstrate usage without creating new definitions.</Typography>
    {componentRoles.map(role => <Stack spacing={1} key={role}>
      <Typography variant="h2">{componentRoleLabels[role]}</Typography>
      <ComponentCatalogTable label={componentRoleLabels[role]} storyUrl={localStoryUrl} catalog={rows} rows={rows.filter(row => row.definition.role === role)} />
    </Stack>)}
  </Stack>,
};
