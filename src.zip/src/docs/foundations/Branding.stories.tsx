import type { Meta } from "@storybook/react-vite";
import { BrandingGuidelines } from "../../components/docs/BrandingGuidelines";
export default { title: "Foundations/Branding", parameters: {layout:"padded"} } satisfies Meta;
export const Branding = BrandingGuidelines;
