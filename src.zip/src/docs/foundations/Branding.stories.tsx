import type { Meta } from "@storybook/react-vite";
import { Alert, Box, Card, CardContent, Chip, Stack, Typography } from "@mui/material";
import { DocsPage, DocsSection, SourceNote, DocsTable, TableRow, TableCell } from "../shared/DocsBlocks";

const meta = {
  title: "Foundations/Branding",
  parameters: { layout: "padded" },
} satisfies Meta;

export default meta;

const CLIENTS: { id: string; acronym: string; name: string; logo: string; ext: "svg" | "png" }[] = [
  { id: "demo", acronym: "DEMO", name: "Demo Client", logo: "/client/demo/logo.svg", ext: "svg" },
  { id: "waepa", acronym: "WAEPA", name: "Worldwide Assurance for Employees of Public Agencies", logo: "/client/waepa/logo.png", ext: "png" },
  { id: "csea", acronym: "CSEA", name: "CSEA Group Sponsored Insurance Program", logo: "/client/csea/logo.png", ext: "png" },
  { id: "ama", acronym: "AMA", name: "American Medical Association", logo: "/client/ama/logo.png", ext: "png" },
  { id: "abe", acronym: "ABE", name: "American Bar Endowment", logo: "/client/abe/logo.png", ext: "png" },
  { id: "avma", acronym: "AVMA", name: "American Veterinary Medical Association", logo: "/client/avma/logo.png", ext: "png" },
  { id: "nso", acronym: "NSO", name: "Nurses Services Organization", logo: "/client/nso/logo.png", ext: "png" },
];

export const Branding = () => (
  <DocsPage
    eyebrow="Foundations"
    title="Branding"
    intro="Reusable presentation rules for client logos and hero imagery. Active-client selection, per-client feature configuration, and the full client roster are Portal Admin / Information Architecture concerns — this page only covers the display rules every client's assets must satisfy."
    maxWidth={1100}
  >
    <DocsSection
      title="Client logo gallery"
      description="Every client's real logo asset, rendered at its natural size against the 200px(mobile)/250px(desktop)-wide, 35px-tall constraint AppHeader applies."
    >
      <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
        {CLIENTS.map((c) => (
          <Card key={c.id} variant="outlined" sx={{ width: 200 }}>
            <CardContent sx={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 1 }}>
              <Box
                sx={{
                  height: 35,
                  maxWidth: 180,
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <img
                  src={c.logo}
                  alt={`${c.name} logo`}
                  style={{ maxHeight: 35, maxWidth: 180, width: "auto", height: "auto" }}
                />
              </Box>
              <Typography variant="caption" sx={{ fontWeight: 700 }}>{c.acronym}</Typography>
              <Typography variant="caption" color="text.secondary" sx={{ textAlign: "center", fontFamily: "monospace", fontSize: "0.65rem" }}>
                {c.logo}
              </Typography>
            </CardContent>
          </Card>
        ))}
      </Stack>
      <SourceNote>public/client/&#123;clientId&#125;/logo.&#123;svg,png&#125;; src/config/clients/*.ts — branding.logo/logoAlt; rendered by AppHeader.tsx</SourceNote>
    </DocsSection>

    <DocsSection title="Logo constraints">
      <Typography variant="body2" color="text.secondary">
        Max <strong>200px</strong> wide on mobile, <strong>250px</strong> on
        desktop (sm+); max <strong>35px</strong> tall; rendered at natural
        aspect ratio (width/height: auto — never stretched to fill the box).
      </Typography>
    </DocsSection>

    <DocsSection title="Hero image constraints">
      <Typography variant="body2" color="text.secondary">
        Max <strong>500px</strong> wide, height auto, 32px corner radius.
        Used only in the Home page's <code>hero-image</code> and{" "}
        <code>welcome-back</code> variants (never <code>default</code>).
        Source path pattern: <code>/client/&#123;clientId&#125;/hero.png</code>.
      </Typography>
    </DocsSection>

    <DocsSection title="Hero text length">
      <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
        No hard character limit is enforced in code today. To keep the hero
        title readable at the <code>h1</code> size (2.25rem, weight 800)
        inside its ~800px column, keep titles to roughly{" "}
        <strong>60 characters or fewer</strong> and descriptions to roughly{" "}
        <strong>160 characters or fewer</strong> so both wrap to no more than
        two lines on desktop.
      </Typography>
      <Chip
        label="Open question — recommend adding validation in client content config"
        size="small"
        color="warning"
        variant="outlined"
      />
    </DocsSection>

    <DocsSection title="Reserved theme colors">
      <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
        Client brand presets (see <code>Foundations / Colors</code>) are all
        blue/teal/purple tones. Never use red, orange, green, or yellow as a
        client's primary brand color — those hues carry fixed semantic
        meaning elsewhere in the UI (error, avoid, success, notice
        respectively).
      </Typography>
    </DocsSection>

    <DocsSection title="Flagged: hardcoded, non-client-configurable branding">
      <Alert severity="warning" sx={{ maxWidth: 800 }}>
        Four places render a hardcoded New York Life logo (
        <code>/logo.svg</code>) instead of reading from client config:{" "}
        <code>AppFooter.tsx:224</code> (ratings logo),{" "}
        <code>Home.tsx:465</code>, <code>CookieDialog.tsx:53</code>, and{" "}
        <code>mockEmail.ts:377</code>. This is a real gap for a genuinely
        multi-client template — flagged here, not fixed in this pass.
      </Alert>
    </DocsSection>

    <DocsSection title="Roster / where each client is configured">
      <DocsTable columns={["Client ID", "Acronym", "Legal name"]}>
        {CLIENTS.map((c) => (
          <TableRow key={c.id}>
            <TableCell sx={{ fontFamily: "monospace" }}>{c.id}</TableCell>
            <TableCell sx={{ fontWeight: 700 }}>{c.acronym}</TableCell>
            <TableCell>{c.name}</TableCell>
          </TableRow>
        ))}
      </DocsTable>
      <Typography variant="caption" color="text.secondary" sx={{ display: "block", mt: 1 }}>
        Active-client resolution logic, per-client feature flags, and
        content overrides are documented in Portal Admin → Information
        Architecture, not here.
      </Typography>
    </DocsSection>
  </DocsPage>
);
