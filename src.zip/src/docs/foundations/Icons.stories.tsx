import type { Meta } from "@storybook/react-vite";
import { IconsGuidelines } from "../../components/docs/IconsGuidelines";
export default { title: "Foundations/Icons", parameters: {layout:"padded"} } satisfies Meta;
export const Icons = IconsGuidelines;
