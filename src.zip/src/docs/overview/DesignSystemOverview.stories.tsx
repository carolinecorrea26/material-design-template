import type { Meta } from "@storybook/react-vite";
import { Alert, Stack, Typography } from "@mui/material";
import { DocsPage, DocsSection } from "../shared/DocsBlocks";

const meta = {
  title: "Overview/Design System Overview",
  parameters: { layout: "padded" },
} satisfies Meta;

export default meta;

export const DesignSystemOverview = () => (
  <DocsPage
    title="Design System Overview"
    intro="This Storybook is becoming the authoritative design system, reusable component library, and reusable UI-pattern documentation for the template prototype. It is being built up in phases against the current source, not designed from scratch — see src/docs/StorybookAudit.md for the full audit and migration plan behind everything in this section."
  >
    <DocsSection title="What Storybook owns">
      <Typography variant="body2" color="text.secondary">
        Design foundations and tokens, reusable components and their APIs,
        variants and states, form controls and validation/error
        presentation, reusable interaction patterns, responsive UI behavior,
        accessibility implementation guidance, and feedback/loading/status
        patterns.
      </Typography>
    </DocsSection>

    <DocsSection title="What stays in the running app (Portal Admin / Information Architecture)">
      <Typography variant="body2" color="text.secondary">
        Pages, fields by page, application flows, business rules, feature
        implementation status, client configuration, URL parameters,
        product/applicant eligibility, content configuration, integrations,
        and workflow requirements/triggers. The same detailed UI rule should
        not need to be maintained independently in both systems — where a
        rule is really about how a component looks or behaves, it belongs
        here; where it's about why the application invokes it, it belongs in
        Information Architecture.
      </Typography>
    </DocsSection>

    <DocsSection title="Current migration status">
      <Stack spacing={1}>
        <Typography variant="body2">
          <strong>Foundations</strong> — colors, typography, spacing, shape,
          elevation, breakpoints/responsive design, MUI theme overrides,
          branding, and icons are migrated and read live from{" "}
          <code>src/app/theme.ts</code>.
        </Typography>
        <Typography variant="body2">
          <strong>Guidelines / Accessibility</strong> — migrated from the
          Information Architecture page's Accessibility section, translated
          into actionable guidance rather than a pasted requirements table.
        </Typography>
        <Typography variant="body2">
          <strong>Forms, Layout, Navigation, Content, Feedback, Overlays,
          Coverage & Commerce component stories</strong> — not yet built.
          The in-app <code>Design System</code> page (
          <code>src/pages/DesignSystem.tsx</code>) still contains the only
          coverage of these today and remains in place until parity is
          reached.
        </Typography>
      </Stack>
    </DocsSection>

    <Alert severity="info" sx={{ maxWidth: 760 }}>
      Do not treat this Storybook as complete yet. Check{" "}
      <code>src/docs/StorybookAudit.md</code>'s migration matrix for the
      authoritative status of any specific section or component before
      assuming something is documented here just because it exists in the
      app.
    </Alert>
  </DocsPage>
);
