/** Site-owned collection/presentation choices, persisted as Library configuration. */
export type ApplicantExperience = {
  factMappings?: Record<string, { field: string; values: Record<string, string> }>;
  eligibleStatesOnly?: boolean;
  eligibleStates?: string[];
  childEligibility?: { mode: 'details' | 'notice-only'; note: string };
};
export function isApplicantExperience(value: unknown): value is ApplicantExperience {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const v = value as ApplicantExperience;
  return (v.factMappings === undefined || Object.values(v.factMappings).every(m => typeof m.field === "string" && m.values && typeof m.values === "object" && Object.values(m.values).every(x => typeof x === "string"))) && (v.eligibleStatesOnly === undefined || typeof v.eligibleStatesOnly === 'boolean') && (v.eligibleStates === undefined || Array.isArray(v.eligibleStates) && v.eligibleStates.every(s => /^[A-Z]{2}$/.test(s)) && new Set(v.eligibleStates).size === v.eligibleStates.length) && (!v.eligibleStatesOnly || !!v.eligibleStates?.length) && (v.childEligibility === undefined || ['details', 'notice-only'].includes(v.childEligibility.mode) && typeof v.childEligibility.note === 'string' && !!v.childEligibility.note.trim());
}
