import type { PageId, PageGroupId } from "./identities";
import type { FieldId } from "./fields";
import type { PageSectionId } from "../config/pageSections/types";

export type ProgressStepId = string;
export type Page = { id: PageId; groupId?: PageGroupId; path: string; type: string };
export type PageGroup = { id: PageGroupId; pageIds: PageId[] };
export type ProgressStep = { id: ProgressStepId; pageIds: PageId[]; label: string };
export type PageSection = { id: PageSectionId; pageId: PageId; fieldIds: FieldId[] };
