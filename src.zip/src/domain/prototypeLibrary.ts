import { isApplicantExperience } from "./applicantExperience";
import { isBenefitPolicy } from "./benefitPolicy";
import type { ClientConfig } from './configuration';
import type { CoverageDefinition, CoverageAmountAssignment, CoverageApplicantId } from './coverage';
import { resolveEffectiveSite, type EffectiveSiteData } from './effectiveSite';
import { isLibraryDraft } from './libraryDraft';
import type { SiteContent } from '../content/types';
import { resolveCoverageJourneyPolicy } from './coverageJourneyPolicy';

export type PrototypeLibrary = ReturnType<typeof resolvePrototypeLibrary>;
let active: PrototypeLibrary | null = null;
export function getPrototypeLibrary(siteKey?: string) { return active && (!siteKey || active.site.siteKey === siteKey) ? active : null; }
export function installPrototypeLibrary(library: PrototypeLibrary | null) { active = library; }
function put(root: Record<string, unknown>, path: string[], value: unknown) {
  if (!path.length || path.some(key => ['__proto__', 'constructor', 'prototype'].includes(key))) throw new Error('Unsafe Library path');
  let cursor = root;
  for (const key of path.slice(0, -1)) { if (!cursor[key] || typeof cursor[key] !== 'object' || Array.isArray(cursor[key])) cursor[key] = {}; cursor = cursor[key] as Record<string, unknown>; }
  cursor[path.at(-1)!] = structuredClone(value);
}
/** Presentation adapter for the existing applicant components. All inputs come
 * from the persisted reviewed revision; no catalog imports or extraction. */
export function resolvePrototypeLibrary(data: EffectiveSiteData, siteKey: string, revision: string) {
  const site = resolveEffectiveSite(data, siteKey);
  const root: Record<string, unknown> = { id: site.clientKey, branding: {}, support: {}, pages: {}, fields: {}, coverages: {}, features: {}, flows: {} };
  for (const row of site.configuration.configurations) {
    const path = data.configurationDefinitions.find(d => d.key === row.key)?.definition.path;
    if (path) put(root, path, row.value);
  }
  root.branding = Object.fromEntries(site.configuration.branding.map(row => [row.key, row.value]));
  root.support = Object.fromEntries(site.configuration.support.map(row => [row.key, row.value]));
  const client = root as unknown as ClientConfig;
  const identity = data.sites.find(s => s.key === siteKey)!;
  const clientIdentity = data.clients.find(c => c.id === identity.clientId)!;
  client.features = { ...client.features, defaultTemplate: identity.templateType };
  if (client.applicantExperience !== undefined && !isApplicantExperience(client.applicantExperience)) throw new Error("Invalid applicant experience configuration");
  client.coverages.enabled = site.products.map(p => p.productKey);
  client.reviewPolicy = site.configuration.reviewPolicies[0]?.value as ClientConfig['reviewPolicy'];
  const rates = site.configuration.ratePresentationPolicies[0]?.value as { praseConfigured: boolean; quoteToolEnabled: boolean };
  if (!rates?.praseConfigured || !rates.quoteToolEnabled) client.features = { ...client.features, homePageVariant: 'hero-image' };
  client.fields = Object.fromEntries(site.configuration.pages.map(page => [page.key, { hidden: page.fields.filter(f => !f.included).map(f => f.key), extra: client.fields[page.key as keyof typeof client.fields]?.extra ?? [], overrides: Object.fromEntries(page.fields.map(f => [f.key, f.definition])) }]));
  const products: CoverageDefinition[] = site.configuration.products.map(product => {
    const row = data.products.find(p => p.key === product.productKey);
    if (!row) throw new Error('Missing Library product');
    const journey = resolveCoverageJourneyPolicy(site, product.productKey);
    if (!journey) throw new Error(`Invalid journey: ${product.productKey}`);
    const coverage = { ...structuredClone(row.definition), ...Object.fromEntries(product.presentation.map(p => [p.key, p.value])), id: product.productKey, categoryId: row.categoryKey, applicants: site.products.find(p => p.productKey === product.productKey)!.applicants.filter(a => product.applicantRules.some(r => r.value.applicantTypeKey === a.applicantKey && r.value.eligible && r.value.conditionKey === null)).map(a => a.applicantKey), underwritingType: journey.defaultUnderwritingPathway } as CoverageDefinition;
    coverage.coverageAmounts = product.amounts.map(rule => {
      if (rule.status !== 'resolved' || rule.amount?.status !== 'resolved') throw new Error(`Unresolved amount: ${rule.key}`);
      const { pattern, bands, options } = rule.amount;
      const a: CoverageAmountAssignment = { scope: { ...(rule.value.applicantTypeKey ? { applicantType: rule.value.applicantTypeKey as CoverageApplicantId } : {}), ...(rule.value.applicantClass ? { applicantClassId: rule.value.applicantClass } : {}) } };
      if (pattern.value.amountType === 'multiplier') a.derivedFrom = { applicantType: pattern.value.baseApplicantKey as 'member' | 'spouse', calculation: { type: 'percentage', value: pattern.value.multiplier! * 100 } };
      else a.selections = [...bands.map(b => ({ type: 'range' as const, min: b.value.minimum!, max: b.value.maximum!, increment: b.value.increment! })), ...(pattern.value.amountType === 'fixed' ? [{ type: 'amountList' as const, values: [pattern.value.minimum!] }] : options.length ? [{ type: 'amountList' as const, values: options.map(o => Number(o.value.value)) }] : [])];
      return a;
    });
    const benefit = product.benefitPolicies[0]?.value;
    if (isBenefitPolicy(benefit)) coverage.coverageAmounts = benefit.applicants.map(rule => ({ scope: { applicantType: rule.applicantKey as CoverageApplicantId, ...(rule.applicantClass ? { applicantClassId: rule.applicantClass } : {}) }, selections: [{ type: 'range', min: rule.minimum, max: rule.maximum, increment: rule.increment }] }));
    coverage.requirements = { ...coverage.requirements, ...client.coverages.overrides?.[product.productKey]?.requirements,
      eligibility: data.eligibilityConstraints.filter(c => c.siteKey === siteKey && c.productKey === product.productKey).map(c => ({ applicantType: c.applicantTypeKey as CoverageApplicantId, ...(c.minimumAgeDays !== null ? { minimumAgeDays: c.minimumAgeDays } : {}), ...(c.minimumAgeYears !== null ? { minimumAgeYears: c.minimumAgeYears } : {}), ...(c.maximumAgeYears !== null ? { maximumAgeYears: c.maximumAgeYears } : {}), ...(c.studentMaximumAgeYears !== null ? { fullTimeStudentMaximumAgeYears: c.studentMaximumAgeYears } : {}), ...(c.unmarried !== null ? { unmarried: c.unmarried } : {}), ...(c.minimumWorkHours !== null ? { minimumWorkHoursPerWeek: c.minimumWorkHours } : {}) })),
      dependencies: product.dependencies.map(r => ({ applicantType: r.value.applicantTypeKey as CoverageApplicantId, requiresApplicant: r.value.requiresApplicantKey as CoverageApplicantId, categoryId: r.value.categoryKey as CoverageDefinition['categoryId'], sameProduct: r.value.sameProduct })),
      ...(isBenefitPolicy(benefit) ? { exclusiveProducts: benefit.exclusiveProducts } : {}),
      maximumPlans: product.maximumPlans.map(r => ({ applicantType: r.value.applicantTypeKey as CoverageApplicantId, categoryId: r.value.categoryKey as CoverageDefinition['categoryId'], count: r.value.count })) };
    coverage.underwritingBands = product.underwritingRules.map(r => ({ scope: { applicantType: r.value.applicantTypeKey as CoverageApplicantId }, minimumAgeYears: r.value.minimumAge!, maximumAgeYears: r.value.maximumAge!, minimumAmount: r.value.minimumAmount!, maximumAmount: r.value.maximumAmount!, minimumAmountExclusive: r.value.minimumAmountExclusive, underwritingType: r.value.pathway as CoverageDefinition['underwritingType'], label: r.value.pathway ?? '', status: r.value.status as 'documented' }));
    coverage.riders = (product.presentation.find(p => p.key === "riders")?.value as CoverageDefinition["riders"]) ?? product.riders.filter(r => r.enabled && r.definition).map(r => ({ ...r.definition!.value, premiumFactor: r.definition!.value.premiumFactor ?? 0 }));
    for (const kind of ['waiting', 'benefit'] as const) {
      const rows = product.benefitPeriods.filter(r => r.value.kind === kind);
      const options = (applicant: string | null) => rows.filter(r => r.value.applicantTypeKey === applicant).map(r => ({ label: r.value.label, value: r.value.value, days: r.value.days ?? 0 }));
      if (kind === 'waiting') { coverage.waitingPeriodOptions = options(null).length ? options(null) : undefined; coverage.waitingPeriodOptionsByApplicant = Object.fromEntries(coverage.applicants.map(a => [a, options(a).length ? options(a) : options(null).length ? options(null) : undefined])); }
      else { coverage.maxBenefitPeriodOptions = options(null).length ? options(null) : undefined; coverage.maxBenefitPeriodOptionsByApplicant = Object.fromEntries(coverage.applicants.map(a => [a, options(a).length ? options(a) : options(null).length ? options(null) : undefined])); }
    }
    for (const kind of ['gNumber', 'planCode'] as const) {
      const rows = product.identifiers.filter(r => r.value.kind === kind);
      if (rows.length) Object.assign(coverage, { [kind]: rows.at(-1)!.value.definition });
    }
    if (!coverage.planCode) coverage.planCode = { primary: journey.mappings[0].identifiers.planCode.display };
    return coverage;
  });
  const content: Record<string, unknown> = {};
  for (const value of site.configuration.content) { const path = data.contentEntries.find(c => c.key === value.key)?.definition.path; if (path) put(content, path, value.value); }
  return { clientIdentity, sourceSiteKey: data.sites.find(s => s.legacyClientId === data.sites.find(s => s.key === siteKey)?.legacyClientId && !s.id.startsWith('build-site-'))?.key ?? siteKey, site, client, products, settings: root, content: content as unknown as SiteContent, revision };
}
export function validatePrototypeEnvelope(value: unknown, siteKey: string) {
  const envelope = value as { mode: string; revision: string; payload: unknown };
  if (envelope?.mode !== 'mock' || typeof envelope.revision !== 'string' || !isLibraryDraft(envelope.payload) || envelope.payload.siteKey !== siteKey) throw new Error('Invalid persisted prototype Library');
  return resolvePrototypeLibrary(envelope.payload.data, siteKey, envelope.revision);
}
