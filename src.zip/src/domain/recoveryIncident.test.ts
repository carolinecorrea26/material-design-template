import { expect, it } from 'vitest';
import { recoveryIncident, supportReference } from './recoveryIncident';
import { recoveryPresentation } from '../content/applicationRecovery';

it('uses stable codes and never classifies by diagnostic text', () => {
  const incident = recoveryIncident({ code: 'unrecognized', operation: 'save', outcome: 'failed', message: 'SESSION_EXPIRED', answers: { email: 'private@example.invalid' }, token: 'private-token' });
  expect(incident).toEqual({ code: 'TECHNICAL_ERROR', operation: 'save', outcome: 'failed' });
  expect(recoveryPresentation(incident).state).toBe('technical-error');
  expect(JSON.stringify(recoveryPresentation(incident))).not.toContain('private');
});
it.each([
  ['VALIDATION_FAILED', 'field', 'validation'], ['OFFLINE', 'alert', 'offline'], ['SAVE_FAILED', 'alert', 'save-failed'],
  ['SAVE_CONFLICT', 'alert', 'save-conflict'], ['APPLICATION_UNAVAILABLE', 'page', 'application-unavailable'],
  ['OPERATION_PENDING', 'status', 'processing-pending'], ['OPERATION_COMPLETE', 'status', 'processing-complete'],
] as const)('maps %s to its approved presentation', (code, placement, state) => {
  const result = recoveryPresentation({ code, operation: 'save', outcome: code === 'OPERATION_COMPLETE' ? 'succeeded' : 'failed' });
  expect(result.placement).toBe(placement);
  expect(result.state).toBe(state);
});
it.each(['payment', 'submission'] as const)('never offers repeat or start-new actions for an unconfirmed %s', operation => {
  const result = recoveryPresentation({ code: 'TECHNICAL_ERROR', operation, outcome: 'unknown', reference: 'REQ-7C2F91AB' });
  expect(result.state).toBe('outcome-unknown');
  expect(result.actions).toEqual([]);
  expect(result.message).toContain(operation);
  expect(result.incident.reference).toBe('REQ-7C2F91AB');
});
it('only carries an explicitly supplied opaque reference and never invents one', () => {
  expect(recoveryIncident({ code: 'TECHNICAL_ERROR', reference: 'req-7c2f91ab' }).reference).toBe('REQ-7C2F91AB');
  for (const unsafe of ['person@example.invalid', 'token=private', '123-45-6789', 'REQ-<script>', 'REQ-medical-answer']) expect(supportReference(unsafe)).toBeUndefined();
  expect(recoveryIncident({ code: 'TECHNICAL_ERROR' })).not.toHaveProperty('reference');
});
