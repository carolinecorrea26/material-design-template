import { libraryDisplayId } from './provenance';
import { isLibraryDraft, type LibraryDraft } from './libraryDraft';
import { resolvePrototypeLibrary } from './prototypeLibrary';

export type SiteBuildIdentity = { siteKey: string; siteName: string; template: 'single' | 'multi'; organizationKey: string; organizationName: string; clientKey: string; clientName: string; newOrganization: boolean; newClient: boolean; organizationAcronym?: string; organizationContact?: string; organizationEmail?: string; organizationPhone?: string; clientAcronym?: string; clientContact?: string; clientEmail?: string; clientPhone?: string; clientLogo?: string };
/** Copy scoped rows and their references; shared Library definitions retain their identity. */
export function createSiteBuild(source: LibraryDraft, identity: SiteBuildIdentity): LibraryDraft {
  if (!/^[a-z][a-z0-9-]{2,79}$/.test(identity.siteKey) || !identity.organizationKey || !identity.clientKey || !identity.siteName.trim() || !identity.clientName.trim() || !identity.organizationName.trim()) throw new Error('Enter site, TPA and client names and a unique lowercase site key.');
  for (const kind of ['organization', 'client'] as const) {
    if (!(kind === 'organization' ? identity.newOrganization : identity.newClient)) continue;
    if (![identity[`${kind}Acronym`], identity[`${kind}Contact`], identity[`${kind}Phone`]].every(value => value?.trim()) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(identity[`${kind}Email`] ?? '')) throw new Error('Provide an acronym, contact name, valid email and phone for each new TPA or client.');
  }
  const draft = structuredClone(source);
  if (draft.data.sites.some(s => s.key === identity.siteKey)) throw new Error('That site key already exists. Edit the existing Site instead.');
  const organizations = draft.data.organizations;
  if (!organizations) throw new Error('Load the TPA Library before creating a Site.');
  const sourceSite = draft.data.sites.find(s => s.key === source.siteKey)!;
  const sourceClient = draft.data.clients.find(c => c.id === sourceSite.clientId)!;
  const org = organizations.find(o => o.key === identity.organizationKey);
  if (!identity.newOrganization && !org) throw new Error('Select an existing TPA.');
  if (identity.newOrganization && org) throw new Error('TPA key already exists.');
  const client = draft.data.clients.find(c => c.key === identity.clientKey);
  if (!identity.newClient && (!client || client.organizationId !== org?.id)) throw new Error('Choose a client belonging to the selected TPA.');
  if (identity.newClient && client) throw new Error('Client key already exists.');
  const copyClientDefaults = identity.newClient || !draft.data.configurationValues.some(r => r.scope === 'client' && r.clientKey === identity.clientKey);
  const timestamp = new Date().toISOString();
  const organizationId = org?.id ?? `build-org-${identity.organizationKey}`;
  const clientId = client?.id ?? `build-client-${identity.clientKey}`;
  if (identity.newOrganization) organizations.push({ ...organizations.find(o => o.id === sourceClient.organizationId)!, id: organizationId, key: identity.organizationKey, displayId: libraryDisplayId('organizations', identity.organizationKey), name: identity.organizationName, createdAt: timestamp, updatedAt: timestamp });
  if (identity.newClient) draft.data.clients.push({ ...sourceClient, id: clientId, key: identity.clientKey, displayId: libraryDisplayId('clients', identity.clientKey), name: identity.clientName.trim(), status: 'active', acronym: identity.clientAcronym?.trim() || identity.clientKey.toUpperCase(), organizationId, createdAt: timestamp, updatedAt: timestamp });
  if (identity.newOrganization) {
    draft.data.organizationProfiles ??= [];
    draft.data.organizationProfiles.push({ id: `profile-${organizationId}`, key: `profile-${organizationId}`, organizationKey: identity.organizationKey, position: draft.data.organizationProfiles.length, definition: { name: identity.organizationName, acronym: identity.organizationAcronym, support: { contactName: identity.organizationContact, email: identity.organizationEmail, phone: identity.organizationPhone } } });
  }
  if (client) client.status = 'active';
  const copies: { tableName: string; table: Record<string, unknown>[]; row: Record<string, unknown> }[] = [];
  const ids = new Map<string, string>([[sourceSite.id, `build-site-${identity.siteKey}`]]);
  for (const [tableName, rows] of Object.entries(draft.data)) {
    if (['sites', 'clients', 'organizations', 'organizationProfiles'].includes(tableName)) continue;
    for (const row of rows as unknown as Record<string, unknown>[]) {
      if (row.siteKey === source.siteKey || row.siteId === sourceSite.id || copyClientDefaults && row.clientKey === sourceClient.key && row.scope === 'client') {
        ids.set(String(row.id), `build-${identity.siteKey}-${row.id}`);
        copies.push({ tableName, table: rows as unknown as Record<string, unknown>[], row });
      }
    }
  }
  for (const { tableName, table, row } of copies) {
    const copied = structuredClone(row);
    for (const [key, value] of Object.entries(copied)) {
      if (key === 'siteKey' && value === source.siteKey) copied[key] = identity.siteKey;
      else if (key === 'clientKey' && value === sourceClient.key) copied[key] = identity.clientKey;
      else if (typeof value === 'string' && (key === 'id' || key.endsWith('Id')) && ids.has(value)) copied[key] = ids.get(value);
    }
    if (copied.scope === 'client' && copied.clientKey === identity.clientKey && !identity.newClient && ['brandingProfiles', 'supportProfiles'].includes(tableName)) continue;
    if (typeof copied.key === 'string') copied.key = `build.${identity.siteKey}.${copied.key}`;
    copied.displayId = libraryDisplayId(tableName, String(copied.key ?? copied.id));
    table.push(copied);
  }
  if (copyClientDefaults && !identity.newClient) {
    for (const [table, definition] of [['brandingProfiles', { name: identity.clientName, acronym: client!.acronym, logo: '', logoAlt: identity.clientName }], ['supportProfiles', {}]] as const) {
      if (!draft.data[table].some(r => r.scope === 'client' && r.clientKey === identity.clientKey)) draft.data[table].push({ id: `build-${identity.siteKey}-${table}`, key: `build-${identity.siteKey}-${table}`, position: draft.data[table].length, scope: 'client', clientKey: identity.clientKey, siteKey: null, definition });
    }
  }
  if (identity.newClient && identity.clientAcronym) {
    for (const row of draft.data.supportProfiles.filter(r => r.scope === 'client' && r.clientKey === identity.clientKey)) row.definition = { contactName: identity.clientContact, email: identity.clientEmail, phone: identity.clientPhone };
    for (const row of draft.data.brandingProfiles.filter(r => r.scope === 'client' && r.clientKey === identity.clientKey)) Object.assign(row.definition, { name: identity.clientName, acronym: identity.clientAcronym, logo: identity.clientLogo || '', logoAlt: identity.clientName });
  }
  if (identity.clientKey !== sourceClient.key) {
    // Copied Site overrides must not display another client's identity or contacts.
    draft.data.brandingProfiles = draft.data.brandingProfiles.filter(r => r.siteKey !== identity.siteKey);
    draft.data.supportProfiles = draft.data.supportProfiles.filter(r => r.siteKey !== identity.siteKey);
  }
  draft.data.sites.push({ ...sourceSite, id: ids.get(sourceSite.id)!, key: identity.siteKey, displayId: libraryDisplayId('sites', identity.siteKey), clientId, name: identity.siteName, displayName: identity.siteName, templateType: identity.template, environment: 'prototype', createdAt: timestamp, updatedAt: timestamp });
  draft.siteKey = identity.siteKey; draft.editVersion = 0; delete draft.mockTransport;
  if (!isLibraryDraft(draft)) throw new Error('The selected Library cannot be copied into a valid Site.');
  resolvePrototypeLibrary(draft.data, draft.siteKey, draft.baseRevision);
  return draft;
}

/** Opaque generated IDs are independent of user-facing names and acronyms. */
export function newBuildKey(kind: 'site' | 'client' | 'tpa') { return `${kind}-${crypto.randomUUID()}`; }
