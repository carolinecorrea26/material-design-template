/** Step 1 contract. Scope approval does not approve business rules or activate runtime data. */
export const activeSiteMigrationScope = {
  version: 1,
  approvedOn: "2026-10-01",
  approvalReference: "User clarification in the project review: all sites means the sites currently active in the prototype.",
  sites: [
    { key: "demo-default", clientKey: "demo", mcrRequired: false },
    { key: "abe-default", clientKey: "abe", mcrRequired: true },
    { key: "ama-default", clientKey: "ama", mcrRequired: true },
    { key: "asce-default", clientKey: "asce", mcrRequired: true },
    { key: "avma-default", clientKey: "avma", mcrRequired: true },
    { key: "csea-default", clientKey: "csea", mcrRequired: true },
    { key: "nso-default", clientKey: "nso", mcrRequired: true },
    { key: "isitrust-default", clientKey: "isitrust", mcrRequired: true },
    { key: "waepa-standard", clientKey: "waepa", mcrRequired: true },
    { key: "waepa-gi", clientKey: "waepa", mcrRequired: true },
  ],
  sources: {
    mcr: {
      name: "04-MCR-new-version-full.xlsx",
      snapshotPath: "src/migration/sources/mcr.json",
      snapshotSha256: "8092f32013e2f74b2996da44cd3621a8ad40c7491f1e0a99a2dbbe525ceb9fe5",
      sha256: "4ff085ca5c52102010e9ea061a630eda41c3347d28f2e3e7a8dba44ef9d8617e",
      authority: "Coverage evidence for the scoped clients; explicit reviewed adoption is required.",
      currency: "Awaiting confirmation that this is the current authoritative workbook.",
    },
    checklist: {
      name: "05-requirements-to-fill-out-checklist.xlsx",
      sha256: "f13fddee8fe6acf1938454cd4ce1472bc86c7bb71813017afadc2b872c47a638",
      authority: "Completeness and discrepancy evidence; does not override the workbook.",
    },
    prototype: {
      authority: "Current page, field, flow and layout baseline; intentional changes require recorded decisions.",
    },
    decisions: {
      path: "docs/asce-business-decisions.md",
      authority: "Existing approved ASCE decisions apply only to their exact canonical targets.",
    },
  },
  // Source triage hints verified against the pinned Main sheet. These do not
  // approve Client ownership, create Sites or adopt any product configuration.
  clientIdentityReviewHints: [
    { clientKey: "avma", sourceAcronym: "AVMA LIFE", sourceReference: "Main!B187:B198", status: "review-required" },
    { clientKey: "isitrust", sourceAcronym: "ISI", sourceReference: "Main!B278:B287", status: "review-required" },
  ],
  // User confirmed standard CSEA; GI rows remain archived, never standard identity hints.
  excludedIdentityEvidence: [{ siteKey: "csea-default", sourceReference: "Main!B246:B247", reason: "CSEA GI is not the confirmed standard Site" }],
  deferred: ["Other MCR clients and Sites", "Runtime refactoring and activation", "Visual Site Builder", "Admin login and TOTP"],
} as const;

export const activeMigrationSiteKeys = activeSiteMigrationScope.sites.map(site => site.key);

/** Definitions for the per-product acceptance register, not executable business rules. */
export const coverageAcceptanceDomains = [
  { key: "identity", label: "Product and plan identity", tables: ["products", "productIdentifiers"], acceptance: "Reviewed Client/Site/product/plan mapping with G-number, plan-code and applicant/class variants; no ambiguous ownership." },
  { key: "applicants", label: "Applicant availability", tables: ["siteProductApplicants", "productApplicantEligibility"], acceptance: "Explicit member, spouse and child availability, including applicable classes and conditional assignments." },
  { key: "eligibility", label: "Eligibility", tables: ["eligibilityConstraints"], acceptance: "Reviewed age basis and boundaries, child/student/marital/work restrictions, and missing-fact behavior." },
  { key: "amounts", label: "Coverage amounts", tables: ["productAmountRules"], acceptance: "Reviewed ranges, increments, lists, formulas and derivations, including boundaries and dependent values." },
  { key: "limits", label: "Dependencies and limits", tables: ["coverageDependencies", "maximumPlanRules", "aggregateLimits"], acceptance: "Explicit applicability for dependencies, maximum plans, aggregate limits and ordered benefit caps." },
  { key: "underwriting", label: "Underwriting", tables: ["underwritingBands"], acceptance: "Reviewed pathways and applicant/class/age/amount bands; unresolved cases cannot inherit an approval." },
  { key: "riders", label: "Riders", tables: ["productRiders"], acceptance: "Reviewed enabled riders, applicants, amounts, derivations, eligibility and pricing availability." },
  { key: "residency", label: "Residency", tables: ["residencyRules"], acceptance: "Reviewed Site and product exclusions, jurisdiction applicability and effective conditions." },
  { key: "periods", label: "Waiting and benefit periods", tables: ["benefitPeriodOptions", "productCoveragePlans"], acceptance: "Reviewed selectable and mandatory periods, plan variants, combinations and conditional packages." },
  { key: "questions", label: "Question sets", tables: ["productQuestionSets"], acceptance: "Reviewed health, financial, tobacco and attestation versions, field mappings and conditional visibility/requiredness." },
  { key: "payment", label: "Payment", tables: [], acceptance: "Reviewed payment/skip rules, methods, frequency, billing fees and processor applicability." },
  { key: "documents", label: "Documents", tables: ["documentDefinitions"], acceptance: "Reviewed application forms, disclosures, consent, brochures and beneficiary requirements with exact versions or explicit missing assets." },
  { key: "rates", label: "Rates", tables: ["productRateTables"], acceptance: "Authoritative rate inputs and dimensions with calculation tests, or an approved unavailable outcome that suppresses prices." },
] as const;
