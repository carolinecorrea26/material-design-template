import { describe, expect, it } from "vitest";
import { createMigrationDatabase, createReviewedMigrationDatabase } from "./fixtures";
import { applyProvisionalSourceDecisions } from "./provisionalSourceDecisions";
import { mcrSource } from "./mcr";
import { reviewActiveSiteIdentities } from "./activeSiteIdentity";
import { validateMigrationDatabase } from "./integrity";
import { resolveEffectiveEligibility, resolveEffectiveSite } from "../domain/effectiveSite";
import { resolveNormalizedRate } from "../domain/normalizedRates";
import { validateNormalizedCoverageAmount } from "../domain/normalizedCoverageAmounts";

const db = createReviewedMigrationDatabase();
describe("user-authorized provisional source choices", () => {
  it("retains disputed evidence and distinguishes provisional CSEA from the baseline", () => {
    expect(mcrSource.cells.find(cell => cell.sheet === "Main" && cell.cell === "B246")?.value).toBe("CSEA GI");
    expect(reviewActiveSiteIdentities(db, mcrSource.cells).assignments.find(row => row.key === "csea-default.di-ltd")).toMatchObject({ status: "source-linked", row: 246, provisional: true });
    expect(reviewActiveSiteIdentities(createMigrationDatabase(), mcrSource.cells).assignments.find(row => row.key === "csea-default.di-ltd")?.status).toBe("blocked");
    expect(validateMigrationDatabase(db)).toEqual([]);
  });
  it("enforces provisional ages, work hours and child ages without a student extension", () => {
    for (const [siteKey, productKey, applicantKey] of [["nso-default", "di-ltd", "member"], ["avma-default", "li-20yr", "member"], ["avma-default", "li-20yr", "spouse"]]) {
      const site = resolveEffectiveSite(db, siteKey);
      const facts = { ageYears: 59, workHoursPerWeek: 20, unmarried: true, selectedPlans: [{ applicantKey: "member", categoryKey: "life", productKey }] };
      expect(resolveEffectiveEligibility(site, productKey, applicantKey, facts)).toMatchObject({ status: "resolved", eligible: true });
      expect(resolveEffectiveEligibility(site, productKey, applicantKey, { ...facts, ageYears: 60 })).toMatchObject({ status: "resolved", eligible: false });
      if (siteKey === "nso-default") expect(resolveEffectiveEligibility(site, productKey, applicantKey, { ...facts, workHoursPerWeek: 19 })).toMatchObject({ eligible: false });
    }
    const ama = resolveEffectiveSite(db, "ama-default");
    const child = { ageYears: 26, ageDays: 9500, unmarried: true, selectedPlans: [{ applicantKey: "member", categoryKey: "life", productKey: "li-preferred" }] };
    expect(resolveEffectiveEligibility(ama, "li-preferred", "child", child)).toMatchObject({ status: "resolved", eligible: true });
    expect(resolveEffectiveEligibility(ama, "li-preferred", "child", { ...child, ageYears: 27, fullTimeStudent: true })).toMatchObject({ eligible: false });
    expect(resolveEffectiveEligibility(ama, "li-preferred", "child", { ...child, ageYears: 0, ageDays: 13 })).toMatchObject({ eligible: false });
    expect(resolveEffectiveEligibility(ama, "li-preferred", "child", { ...child, ageYears: 0, ageDays: 14 })).toMatchObject({ eligible: true });
  });
  it("uses ISI recorded ranges and excludes child coverage", () => {
    const site = resolveEffectiveSite(db, "isitrust-default");
    for (const applicant of ["member", "spouse"]) {
      for (const amount of [5000, 10000, 100000]) expect(validateNormalizedCoverageAmount(site, "sh-critical-illness", applicant, amount).allowed).toBe(true);
      for (const amount of [4999, 5001, 105000]) expect(validateNormalizedCoverageAmount(site, "sh-critical-illness", applicant, amount).allowed).toBe(false);
    }
    expect(validateNormalizedCoverageAmount(site, "sh-critical-illness", "child", 5000).allowed).toBe(false);
  });
  it("persists explicit unavailable rates and revisit records after serialization", () => {
    const copy = JSON.parse(JSON.stringify(db));
    copy.semanticRequirements.reverse();
    for (const siteRow of copy.sites) {
      const site = resolveEffectiveSite(copy, siteRow.key);
      expect(site).toEqual(resolveEffectiveSite(db, siteRow.key));
      if (siteRow.key === "demo-default") { expect(site.provisionalDecisions).toEqual([]); continue; }
      expect(site.provisionalDecisions.length).toBeGreaterThan(0);
      for (const decision of site.provisionalDecisions) expect(decision.value).toMatchObject({ revisit: true, sourceReconciliation: "deferred", runtimeActivation: "pending" });
      for (const product of site.configuration.products) expect(resolveNormalizedRate(site, product.productKey)).toMatchObject({ status: "unavailable", amount: null, displayPrice: false, provisional: true, revisit: true });
    }
    expect(db.configurationValues.find(row => row.key === "nso-default.li-term.provisional-billing-fee")?.value).toMatchObject({ billMeFee: 0, revisit: true });
    expect(db.configurationValues.find(row => row.key === "ama-default.li-term.provisional-term-credit")?.value).toMatchObject({ premiumCredit: 0, revisit: true });
  });
  it("rejects changed evidence before mutation and repeats deterministically", () => {
    const copy = structuredClone(db);
    expect(() => applyProvisionalSourceDecisions(copy, mcrSource.cells.map(cell => cell.cell === "O321" && cell.sheet === "Main" ? { ...cell, value: "changed" } : cell))).toThrow("Provisional source changed");
    expect(copy).toEqual(db);
    applyProvisionalSourceDecisions(copy, mcrSource.cells);
    const sorted = (database: typeof db) => Object.fromEntries(Object.entries(database).map(([table, rows]) => [table, [...rows].sort((a, b) => a.id.localeCompare(b.id))]));
    expect(sorted(copy)).toEqual(sorted(db));
  });
});
