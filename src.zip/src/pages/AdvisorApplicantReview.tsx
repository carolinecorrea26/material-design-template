import { useState } from "react";
import ReportRoundedIcon from "@mui/icons-material/ReportRounded";
import InfoRoundedIcon from "@mui/icons-material/InfoRounded";
import ArrowForwardRoundedIcon from "@mui/icons-material/ArrowForwardRounded";
import { Alert, Box, Button, Stack, Typography } from "@mui/material";
import { useNavigate } from "react-router-dom";
import FormRoutePage from "../app/RoutePage";
import ApplicationDocumentPreview from "../components/content/ApplicationDocumentPreview";
import SendApplicationDialog from "../components/layout/SendApplicationDialog";
import { getPagePath } from "../config/pages";
import type { ApplicationFormValues } from "../app/ApplicationFormContext";
import type { PageId } from "../types";

/**
 * Advisor-assisted flow: applicant-facing review page.
 *
 * Reached via resume?flow=advisor. Displays the application the advisor
 * completed. Steps from Getting Started through Profile are locked for the
 * applicant — they cannot navigate back into them.
 *
 * Clicking any edit (pencil) button on the application preview opens a
 * confirmation dialog. Confirming sends the application back to the advisor
 * and navigates to ApplicationEditConfirmation.
 *
 * Clicking Continue advances to the standard Review page where the applicant
 * completes consent and proceeds through Health / Payment / E-Sign / Receipt.
 */
export default function AdvisorApplicantReview() {
  const navigate = useNavigate();
  const [editDialogOpen, setEditDialogOpen] = useState(false);

  // Dummy advisor email used as the send-back target
  const advisorEmail = "advisor@example.com";

  // Called by ApplicationDocumentPreview when any edit icon is clicked.
  // In the advisor-applicant view we intercept all edits and show the
  // send-back dialog instead of navigating to the source page.
  function handleEditSection(_pageId: PageId) {
    setEditDialogOpen(true);
  }

  function handleEditConfirm() {
    setEditDialogOpen(false);
    navigate(getPagePath("application-edit-confirmation"));
  }

  return (
    <>
      <FormRoutePage
        pageId="advisor-applicant-review"
        hideActions
      >
        {({ watchedValues }) => {
          const formValues = watchedValues as ApplicationFormValues;

          return (
            <Stack spacing={2.5}>
              <Alert
                severity="info"
                icon={<InfoRoundedIcon fontSize="large" />}
              >
                <Stack spacing={0.5}>
                  <Typography variant="body2" fontWeight={600}>
                    Your advisor has completed this section of the application.
                  </Typography>
                  <Typography variant="body2">
                    Review the information below. If anything needs to be
                    corrected, click the edit icon and your application will be
                    sent back to your advisor. Otherwise, click Continue to
                    complete and submit your application.
                  </Typography>
                </Stack>
              </Alert>

              <Alert
                severity="warning"
                icon={<ReportRoundedIcon fontSize="medium" />}
                sx={{ py: 0.75 }}
              >
                <Typography variant="body2">
                  Steps completed by your advisor — Getting Started, Coverage,
                  and Profile — are locked and cannot be edited directly.
                </Typography>
              </Alert>

              <ApplicationDocumentPreview
                values={formValues}
                signatureName=""
                signedDate=""
                currentDate={new Intl.DateTimeFormat("en-US", {
                  month: "2-digit",
                  day: "2-digit",
                  year: "numeric",
                }).format(new Date())}
                onEditSection={handleEditSection}
                hideSignature
              />

              <Box>
                <Button
                  variant="contained"
                  size="large"
                  fullWidth
                  endIcon={<ArrowForwardRoundedIcon />}
                  onClick={() => navigate(getPagePath("review"))}
                >
                  Continue
                </Button>
              </Box>
            </Stack>
          );
        }}
      </FormRoutePage>

      <SendApplicationDialog
        open={editDialogOpen}
        onClose={() => setEditDialogOpen(false)}
        onConfirm={handleEditConfirm}
        recipientEmail={advisorEmail}
        recipientLabel="advisor"
      />
    </>
  );
}
