import { type ReactNode, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  Divider,
  InputAdornment,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from "@mui/material";
import ExpandMoreRoundedIcon from "@mui/icons-material/ExpandMoreRounded";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import FieldRenderer from "../components/forms/FieldRenderer";
import DynamicList from "../components/forms/DynamicList";
import AppHeader from "../components/layout/AppHeader";
import AppMenu from "../components/layout/AppMenu";
import { getActiveClient } from "../config/client/getActiveClient";
import { formatUSD } from "../utils/formatUSD";
import DocsSidebarNav from "../components/docs/DocsSidebarNav";
import ComponentInventorySection from "../components/docs/ComponentInventorySection";
import type { FieldDefinition } from "../config/fields/types";

// Navigation & actions
import ArrowBackIosRoundedIcon from "@mui/icons-material/ArrowBackIosRounded";
import ArrowForwardRoundedIcon from "@mui/icons-material/ArrowForwardRounded";
import ArrowRightAltRoundedIcon from "@mui/icons-material/ArrowRightAltRounded";
import ArrowRightRoundedIcon from "@mui/icons-material/ArrowRightRounded";
import MenuIcon from "@mui/icons-material/Menu";
import RefreshRoundedIcon from "@mui/icons-material/RefreshRounded";
import LoopRoundedIcon from "@mui/icons-material/LoopRounded";
import AddIcon from "@mui/icons-material/Add";
import AddCircleOutlineRoundedIcon from "@mui/icons-material/AddCircleOutlineRounded";
import CloseIcon from "@mui/icons-material/Close";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import DeleteOutlineRoundedIcon from "@mui/icons-material/DeleteOutlineRounded";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import SendRoundedIcon from "@mui/icons-material/SendRounded";
import FileDownloadRoundedIcon from "@mui/icons-material/FileDownloadRounded";
import PrintOutlinedIcon from "@mui/icons-material/PrintOutlined";

// Status & feedback
import CheckIcon from "@mui/icons-material/Check";
import CheckCircleRoundedIcon from "@mui/icons-material/CheckCircleRounded";
import CheckRoundedIcon from "@mui/icons-material/CheckRounded";
import CircleOutlinedIcon from "@mui/icons-material/CircleOutlined";
import RadioButtonCheckedIcon from "@mui/icons-material/RadioButtonChecked";
import HighlightOffRoundedIcon from "@mui/icons-material/HighlightOffRounded";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import ReportRoundedIcon from "@mui/icons-material/ReportRounded";
import TaskAltIcon from "@mui/icons-material/TaskAlt";
import StarsRoundedIcon from "@mui/icons-material/StarsRounded";

// Communication & support
import ChatIcon from "@mui/icons-material/Chat";
import ChatBubbleOutlineIcon from "@mui/icons-material/ChatBubbleOutline";
import EmailOutlinedIcon from "@mui/icons-material/EmailOutlined";
import HeadsetMicIcon from "@mui/icons-material/HeadsetMic";
import PhoneIcon from "@mui/icons-material/Phone";
import PhoneOutlinedIcon from "@mui/icons-material/PhoneOutlined";
import SupportAgentRoundedIcon from "@mui/icons-material/SupportAgentRounded";
import DraftsRoundedIcon from "@mui/icons-material/DraftsRounded";
import MailLockRoundedIcon from "@mui/icons-material/MailLockRounded";

// Security & trust
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import VerifiedUserOutlinedIcon from "@mui/icons-material/VerifiedUserOutlined";
import PrivacyTipIcon from "@mui/icons-material/PrivacyTip";
import SupervisorAccountRoundedIcon from "@mui/icons-material/SupervisorAccountRounded";
import AccessibleOutlinedIcon from "@mui/icons-material/AccessibleOutlined";

// Coverage & content
import BusinessOutlinedIcon from "@mui/icons-material/BusinessOutlined";
import CalculateOutlinedIcon from "@mui/icons-material/CalculateOutlined";
import CalculateRoundedIcon from "@mui/icons-material/CalculateRounded";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import CreditCardOffOutlinedIcon from "@mui/icons-material/CreditCardOffOutlined";
import Diversity1RoundedIcon from "@mui/icons-material/Diversity1Rounded";
import EscalatorWarningRoundedIcon from "@mui/icons-material/EscalatorWarningRounded";
import LocalHospitalOutlinedIcon from "@mui/icons-material/LocalHospitalOutlined";
import OfflineBoltIcon from "@mui/icons-material/OfflineBolt";
import PersonalInjuryOutlinedIcon from "@mui/icons-material/PersonalInjuryOutlined";
import PersonRoundedIcon from "@mui/icons-material/PersonRounded";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import ShoppingCartOutlinedIcon from "@mui/icons-material/ShoppingCartOutlined";
import TuneRoundedIcon from "@mui/icons-material/TuneRounded";
import LanguageOutlinedIcon from "@mui/icons-material/LanguageOutlined";
import AccessTimeOutlinedIcon from "@mui/icons-material/AccessTimeOutlined";

import {
  CARD_RADIUS,
  FIELD_BORDER_COLOR,
  LABEL_COLOR,
  TEXT_PRIMARY,
} from "../app/theme";

// ---------------------------------------------------------------------------
// Reusable UI pieces (kept local — mirrors InformationArchitecture.tsx)
// ---------------------------------------------------------------------------

function SearchField({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <TextField
      size="small"
      placeholder={placeholder ?? "Filter…"}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      slotProps={{
        input: {
          startAdornment: (
            <InputAdornment position="start">
              <SearchRoundedIcon fontSize="small" />
            </InputAdornment>
          ),
        },
      }}
      sx={{ minWidth: 220, maxWidth: 360 }}
    />
  );
}

function ResponsiveTableContainer({ children }: { children: ReactNode }) {
  return (
    <TableContainer
      component={Card}
      variant="outlined"
      sx={{
        overflowX: "auto",
        width: "100%",
        "& td, & th": { fontSize: { xs: "0.75rem", md: "0.8125rem" } },
        "& td": { whiteSpace: "normal" },
        "& th": { whiteSpace: "nowrap", fontWeight: 700 },
      }}
    >
      {children}
    </TableContainer>
  );
}

function SectionAccordion({
  id,
  title,
  description,
  count,
  children,
}: {
  id: string;
  title: string;
  description?: string;
  count?: number;
  children: ReactNode;
}) {
  return (
    <Accordion
      id={id}
      defaultExpanded
      disableGutters
      sx={{
        border: "1px solid",
        borderColor: "divider",
        borderRadius: "24px !important",
        boxShadow: "0 12px 28px rgba(15, 23, 42, 0.06)",
        overflow: "hidden",
        "&:before": { display: "none" },
      }}
    >
      <AccordionSummary
        expandIcon={<ExpandMoreRoundedIcon />}
        sx={{
          px: { xs: 2, md: 3 },
          py: 1,
          backgroundColor: "background.subtle",
          borderBottom: "1px solid",
          borderColor: "divider",
        }}
      >
        <Box>
          <Stack direction="row" spacing={1} alignItems="center">
            <Typography variant="h5" component="h2" sx={{ fontWeight: 800 }}>
              {title}
            </Typography>
            {count != null && <Chip label={count} size="small" />}
          </Stack>
          {description && (
            <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
              {description}
            </Typography>
          )}
        </Box>
      </AccordionSummary>
      <AccordionDetails sx={{ p: { xs: 2, md: 3 } }}>
        {children}
      </AccordionDetails>
    </Accordion>
  );
}

// ---------------------------------------------------------------------------
// Color data (source: src/app/theme.ts)
// ---------------------------------------------------------------------------

type Swatch = { label: string; value: string; note?: string };

const semanticSwatches: Swatch[] = [
  { label: "primary.main", value: "#0668ff", note: "Default brand color" },
  { label: "primary.light", value: "#5c94ff" },
  { label: "primary.dark", value: "#034cba" },
  { label: "success.main", value: "#009465", note: "Reserved — confirmations only" },
  { label: "error.main", value: "#ed0a0a", note: "Reserved — errors only" },
];

const neutralSwatches: Swatch[] = [
  { label: "text.primary", value: TEXT_PRIMARY },
  { label: "text.secondary", value: "#49596f" },
  { label: "text.tertiary", value: "#5b7090" },
  { label: "text.disabled", value: "#99a4b5" },
  { label: "background.default", value: "#f9fafc" },
  { label: "background.paper", value: "#ffffff" },
  { label: "background.subtle", value: "#f5f8fd" },
  { label: "background.surface", value: "#eef1f4" },
  { label: "background.iconBadge", value: "#c9d6eb" },
  { label: "divider", value: "rgba(52, 59, 72, 0.12)" },
];

const containerSwatches: Swatch[] = [
  { label: "panel.main", value: "#f5f8fd", note: "border rgba(0,22,57,0.08)" },
  { label: "notice.main", value: "#fffcf0", note: "border #e9e3cb" },
  { label: "support.main", value: "#ecf3ff", note: "border #c8d5ea" },
];

type ThemePreset = {
  name: string;
  main: string;
  light: string;
  dark: string;
};

const themePresets: ThemePreset[] = [
  { name: "default", main: "#0668ff", light: "#5c94ff", dark: "#034cba" },
  { name: "teal", main: "#0882a1", light: "#39a4bf", dark: "#005b70" },
  { name: "purple", main: "#3f51b5", light: "#7986cb", dark: "#283593" },
  { name: "dark-blue", main: "#045aab", light: "#316493", dark: "#002f5b" },
];

function ColorSwatch({ swatch }: { swatch: Swatch }) {
  const isCssColor =
    swatch.value.startsWith("#") || swatch.value.startsWith("rgba");
  return (
    <Stack spacing={0.75} sx={{ width: 176 }}>
      <Box
        sx={{
          height: 64,
          borderRadius: 3,
          border: "1px solid rgba(0,0,0,0.08)",
          backgroundColor: isCssColor ? swatch.value : "transparent",
          backgroundImage:
            swatch.value === "transparent"
              ? "repeating-conic-gradient(#e5e9ef 0% 25%, #ffffff 0% 50%) 50% / 12px 12px"
              : undefined,
        }}
      />
      <Typography variant="caption" sx={{ fontWeight: 700 }}>
        {swatch.label}
      </Typography>
      <Typography variant="caption" color="text.secondary">
        {swatch.value}
      </Typography>
      {swatch.note && (
        <Typography variant="caption" color="text.secondary" sx={{ fontStyle: "italic" }}>
          {swatch.note}
        </Typography>
      )}
    </Stack>
  );
}

// ---------------------------------------------------------------------------
// Component override data (source: src/app/theme.ts `components`)
// ---------------------------------------------------------------------------

type OverrideRow = { component: string; summary: string };

const overrideRows: OverrideRow[] = [
  {
    component: "MuiButton",
    summary:
      "Pill shape (radius 9999), bold label, no uppercase transform, subtle lift + shadow on hover for contained buttons.",
  },
  {
    component: "MuiOutlinedInput",
    summary: `Radius ${CARD_RADIUS}, border color ${FIELD_BORDER_COLOR}, darkens on hover, primary on focus, error on validation failure. Entered text renders bold; placeholder stays regular weight.`,
  },
  {
    component: "MuiInputLabel / MuiFormLabel",
    summary: `Label color ${LABEL_COLOR}, medium weight, switches to primary when focused. Required asterisk renders in error color.`,
  },
  {
    component: "MuiToggleButton / MuiToggleButtonGroup",
    summary: `Used as the radio/segmented-control shell. Radius ${CARD_RADIUS}, bordered, selected state tints background with primary at 10% opacity and bumps label weight to 900.`,
  },
  {
    component: "MuiFormControlLabel",
    summary:
      "Full-width row, label bolds to weight 900 automatically when its checkbox/radio is checked.",
  },
  {
    component: "MuiCard / MuiAlert",
    summary: `Shared radius ${CARD_RADIUS} across cards and alerts for one consistent surface language.`,
  },
  {
    component: "MuiChip",
    summary: "Icon spacing tightened; default filled variant uses surface gray background.",
  },
  {
    component: "MuiLink",
    summary: "Primary color, bold weight, underline only on hover (not by default).",
  },
  {
    component: "MuiStepIcon / MuiStepConnector",
    summary: "Neutral gray (#8fa1b9) by default; active and completed steps switch to primary.",
  },
  {
    component: "MuiAppBar",
    summary: "White background, bottom divider border, no drop shadow — flat header style.",
  },
];

// ---------------------------------------------------------------------------
// Icon inventory (grouped by purpose, not by page)
// ---------------------------------------------------------------------------

type IconEntry = { Icon: typeof CheckIcon; label: string; usedIn: string };
type IconGroup = { id: string; title: string; icons: IconEntry[] };

const iconGroups: IconGroup[] = [
  {
    id: "navigation-icons",
    title: "Navigation & actions",
    icons: [
      { Icon: MenuIcon, label: "Menu", usedIn: "AppHeader" },
      { Icon: ArrowBackIosRoundedIcon, label: "Back", usedIn: "Back navigation" },
      { Icon: ArrowForwardRoundedIcon, label: "Forward", usedIn: "TOC / links" },
      { Icon: ArrowRightAltRoundedIcon, label: "Continue", usedIn: "Primary CTA buttons" },
      { Icon: ArrowRightRoundedIcon, label: "Next", usedIn: "Inline navigation" },
      { Icon: RefreshRoundedIcon, label: "Refresh", usedIn: "Retry actions" },
      { Icon: LoopRoundedIcon, label: "Loop", usedIn: "Retry / resend actions" },
      { Icon: AddIcon, label: "Add", usedIn: "DynamicList" },
      { Icon: AddCircleOutlineRoundedIcon, label: "Add (outline)", usedIn: "DynamicList" },
      { Icon: CloseIcon, label: "Close", usedIn: "Dialogs" },
      { Icon: CloseRoundedIcon, label: "Close (rounded)", usedIn: "Modals, drawers" },
      { Icon: DeleteOutlineIcon, label: "Delete", usedIn: "DynamicListItem" },
      { Icon: DeleteOutlineRoundedIcon, label: "Delete (rounded)", usedIn: "DynamicListItem" },
      { Icon: EditOutlinedIcon, label: "Edit", usedIn: "DynamicListItem" },
      { Icon: SendRoundedIcon, label: "Send", usedIn: "Resume / advisor send" },
      { Icon: FileDownloadRoundedIcon, label: "Download", usedIn: "Receipt" },
      { Icon: PrintOutlinedIcon, label: "Print", usedIn: "Review" },
      { Icon: SearchRoundedIcon, label: "Search", usedIn: "Filter fields" },
    ],
  },
  {
    id: "status-icons",
    title: "Status & feedback",
    icons: [
      { Icon: CheckIcon, label: "Check", usedIn: "Selection states" },
      { Icon: CheckCircleRoundedIcon, label: "Check circle", usedIn: "Success states" },
      { Icon: CheckRoundedIcon, label: "Check (rounded)", usedIn: "Selection states" },
      { Icon: CircleOutlinedIcon, label: "Circle outline", usedIn: "Unselected radio" },
      { Icon: RadioButtonCheckedIcon, label: "Radio checked", usedIn: "Selected radio" },
      { Icon: HighlightOffRoundedIcon, label: "Highlight off", usedIn: "Error / remove states" },
      { Icon: InfoOutlinedIcon, label: "Info", usedIn: "AlertBanner info, CartDrawer" },
      { Icon: ReportRoundedIcon, label: "Report", usedIn: "Review page alerts" },
      { Icon: TaskAltIcon, label: "Task complete", usedIn: "CartDrawer" },
      { Icon: StarsRoundedIcon, label: "Featured", usedIn: "FeaturedBadge" },
    ],
  },
  {
    id: "communication-icons",
    title: "Communication & support",
    icons: [
      { Icon: ChatIcon, label: "Chat", usedIn: "AppHeader" },
      { Icon: ChatBubbleOutlineIcon, label: "Chat bubble", usedIn: "ClientHelpBanner" },
      { Icon: EmailOutlinedIcon, label: "Email", usedIn: "AppMenu, AppFooter" },
      { Icon: HeadsetMicIcon, label: "Headset", usedIn: "Receipt support section" },
      { Icon: PhoneIcon, label: "Phone", usedIn: "ClientHelpBanner" },
      { Icon: PhoneOutlinedIcon, label: "Phone (outline)", usedIn: "AppMenu, AppFooter" },
      { Icon: SupportAgentRoundedIcon, label: "Support agent", usedIn: "AdvisorLogin" },
      { Icon: DraftsRoundedIcon, label: "Drafts", usedIn: "MockEmailPreview" },
      { Icon: MailLockRoundedIcon, label: "Secure mail", usedIn: "Resume flow" },
    ],
  },
  {
    id: "trust-icons",
    title: "Security & trust",
    icons: [
      { Icon: LockOutlinedIcon, label: "Lock", usedIn: "SSN field, AdvisorLogin" },
      { Icon: VerifiedUserOutlinedIcon, label: "Verified", usedIn: "Home hero tagline" },
      { Icon: PrivacyTipIcon, label: "Privacy tip", usedIn: "Cart / quote drawers" },
      { Icon: SupervisorAccountRoundedIcon, label: "Spouse section", usedIn: "formSectionTitle" },
      { Icon: AccessibleOutlinedIcon, label: "Disability coverage", usedIn: "coverageCategories (DI)" },
    ],
  },
  {
    id: "coverage-icons",
    title: "Coverage & content",
    icons: [
      { Icon: ShoppingCartIcon, label: "Cart", usedIn: "AppHeader" },
      { Icon: ShoppingCartOutlinedIcon, label: "Cart (outline)", usedIn: "TotalCostCart, CartDrawer" },
      { Icon: CalculateOutlinedIcon, label: "Calculate", usedIn: "helpContent" },
      { Icon: CalculateRoundedIcon, label: "Calculate (rounded)", usedIn: "Quote calculator" },
      { Icon: CalendarMonthIcon, label: "Calendar", usedIn: "ClientHelpBanner" },
      { Icon: CreditCardOffOutlinedIcon, label: "Card declined", usedIn: "helpContent" },
      { Icon: Diversity1RoundedIcon, label: "Life coverage", usedIn: "coverageCategories (LI)" },
      { Icon: BusinessOutlinedIcon, label: "Business coverage", usedIn: "coverageCategories (BOE)" },
      { Icon: EscalatorWarningRoundedIcon, label: "Child section", usedIn: "formSectionTitle" },
      { Icon: LocalHospitalOutlinedIcon, label: "Health coverage", usedIn: "coverageCategories (Health)" },
      { Icon: OfflineBoltIcon, label: "Quick Decision", usedIn: "QuickDecisionIndicator/Explainer" },
      { Icon: PersonalInjuryOutlinedIcon, label: "Disability/OO coverage", usedIn: "coverageCategories" },
      { Icon: PersonRoundedIcon, label: "Person", usedIn: "Applicant sections" },
      { Icon: TuneRoundedIcon, label: "Tune", usedIn: "helpContent" },
      { Icon: LanguageOutlinedIcon, label: "Language / website", usedIn: "AppMenu, AppFooter" },
      { Icon: AccessTimeOutlinedIcon, label: "Hours", usedIn: "AppMenu, AppFooter" },
    ],
  },
];

// ---------------------------------------------------------------------------
// Alert usage matrix (source: severity usage across pages/components)
// ---------------------------------------------------------------------------

type AlertRule = {
  severity: "error" | "warning" | "info" | "success";
  meaning: string;
  usedFor: string;
};

const alertRules: AlertRule[] = [
  {
    severity: "error",
    meaning: "Blocking problem the user must resolve before continuing.",
    usedFor:
      "Expired/invalid resume links, failed code validation, membership/eligibility failures, quote errors.",
  },
  {
    severity: "warning",
    meaning: "Caution — not blocking, but needs the user's attention.",
    usedFor:
      "Incomplete required info (Membership, Payment), cart total not yet confirmed, Review consent reminders.",
  },
  {
    severity: "info",
    meaning: "Contextual, non-urgent detail or status update.",
    usedFor:
      "TPA integration notices, autosave confirmations, applicant-section notes, Receipt next steps.",
  },
  {
    severity: "success",
    meaning: "Confirms a completed action.",
    usedFor:
      "Eligibility confirmation, advisor send confirmation, progress-saved snackbar.",
  },
];

const toc = [
  { id: "colors-section", label: "Colors" },
  { id: "typography-section", label: "Typography" },
  { id: "overrides-section", label: "Component overrides" },
  { id: "field-examples-section", label: "Form field examples" },
  { id: "field-errors-section", label: "Field errors" },
  { id: "components-section", label: "Component examples" },
  { id: "component-library-section", label: "Component library" },
  { id: "icons-section", label: "Icons" },
  { id: "branding-section", label: "Branding guidelines" },
  { id: "rules-section", label: "Design rules" },
  { id: "accessibility-section", label: "Accessibility" },
];

// ---------------------------------------------------------------------------
// Accessibility requirements (moved from InformationArchitecture.tsx — this
// is a WCAG conformance checklist for the visual/interaction system, not
// per-client application architecture, so it lives with the rest of the
// design system reference material).
// ---------------------------------------------------------------------------

type A11yStatus = "Implemented" | "Partial" | "Requires production testing";

const a11yStatusColor: Record<
  A11yStatus,
  "success" | "warning" | "default"
> = {
  Implemented: "success",
  Partial: "warning",
  "Requires production testing": "default",
};

const accessibilityRequirements: {
  area: string;
  requirement: string;
  detail: string;
  wcag: string;
  status: A11yStatus;
}[] = [
  // Semantic structure
  {
    area: "Semantic structure",
    requirement: "Meaningful heading hierarchy",
    detail:
      "Each page exposes one primary heading (page title) with nested section/category headings that do not skip levels, so assistive technology users can navigate by heading structure.",
    wcag: "1.3.1 Info and Relationships; 2.4.6 Headings and Labels",
    status: "Implemented",
  },
  {
    area: "Semantic structure",
    requirement: "Native HTML elements for interactive controls",
    detail:
      "Buttons, links, form fields, and native selection controls use the corresponding native element (button, a, input, select) rather than styled non-interactive elements, so browsers and assistive technology expose correct default behavior and semantics without extra ARIA.",
    wcag: "4.1.2 Name, Role, Value",
    status: "Implemented",
  },
  {
    area: "Semantic structure",
    requirement: "ARIA supplements, not duplicates, native semantics",
    detail:
      "ARIA attributes are added only where native HTML cannot express the needed semantics (e.g. a custom card acting as a radio option). Native MUI controls that already expose correct roles/labels are not given redundant or conflicting ARIA.",
    wcag: "4.1.2 Name, Role, Value",
    status: "Implemented",
  },
  {
    area: "Semantic structure",
    requirement: "Landmarks and application structure",
    detail:
      "The page shell exposes a single main landmark, header, and footer. Dialogs, drawers, alerts, and menus use the correct ARIA role (dialog/alertdialog, menu, alert/status) so their structure and purpose are exposed to assistive technology.",
    wcag: "1.3.1 Info and Relationships; 4.1.2 Name, Role, Value",
    status: "Implemented",
  },

  // Keyboard accessibility
  {
    area: "Keyboard accessibility",
    requirement: "All functionality operable by keyboard",
    detail:
      "Every interactive control — including custom selection cards, category tabs, and expand/collapse toggles — must be reachable and operable via Tab/Shift+Tab and activated with Enter/Space, with no mouse-only interactions.",
    wcag: "2.1.1 Keyboard",
    status: "Partial",
  },
  {
    area: "Keyboard accessibility",
    requirement: "Logical focus order",
    detail:
      "Tab order follows the visual/task order of the page. Fixed/overlay UI (e.g. the cookie banner) is reachable in an order consistent with its visual prominence rather than being tabbed to last.",
    wcag: "2.4.3 Focus Order",
    status: "Implemented",
  },
  {
    area: "Keyboard accessibility",
    requirement: "Custom controls match native keyboard behavior",
    detail:
      "Custom radio-style selection groups (coverage category cards, gender/tobacco toggles, Yes/No question rows) support the same activation model as native radio buttons (roving tabindex, Enter/Space to select). Full native arrow-key roving between options is a documented follow-up, not yet implemented everywhere.",
    wcag: "2.1.1 Keyboard; 4.1.2 Name, Role, Value",
    status: "Partial",
  },
  {
    area: "Keyboard accessibility",
    requirement: "No keyboard traps",
    detail:
      "Dialogs, drawers, and menus use MUI's built-in focus trap and Escape-to-close behavior; no custom code disables or overrides this default trap/restore behavior.",
    wcag: "2.1.2 No Keyboard Trap",
    status: "Implemented",
  },
  {
    area: "Keyboard accessibility",
    requirement: "Modal focus containment and restoration",
    detail:
      "Dialogs and drawers trap focus while open and restore it to a sensible element when closed. Where the triggering element is removed as part of the same action (e.g. removing a list row), focus is explicitly redirected to a stable nearby control instead of being dropped to the document body.",
    wcag: "2.4.3 Focus Order; 3.2.1 On Focus",
    status: "Implemented",
  },

  // Focus visibility and management
  {
    area: "Focus visibility and management",
    requirement: "Visible focus indicator",
    detail:
      "All interactive elements retain a visible focus outline (MUI defaults, plus a matching custom outline on selection-group rows). No global style suppresses the browser/MUI focus ring without a compensating visible replacement.",
    wcag: "2.4.7 Focus Visible",
    status: "Implemented",
  },
  {
    area: "Focus visibility and management",
    requirement: "Focus not hidden behind fixed UI",
    detail:
      "Focused content must not be visually obscured by sticky/fixed headers, footers, or banners. This should be re-verified with real content lengths and viewport sizes during production QA.",
    wcag: "2.4.11 Focus Not Obscured (Minimum)",
    status: "Requires production testing",
  },
  {
    area: "Focus visibility and management",
    requirement: "Focus management on major content reveals",
    detail:
      "When a primary action reveals substantial new content and removes the control that triggered it (e.g. the quote tool's \"See my quote\"), focus moves to the newly revealed region instead of being silently dropped.",
    wcag: "3.2.1 On Focus; 4.1.3 Status Messages",
    status: "Implemented",
  },
  {
    area: "Focus visibility and management",
    requirement: "Skip repetitive navigation",
    detail:
      "A \"Skip to main content\" link is the first focusable element on every page, letting keyboard users bypass the repeated header/navigation controls.",
    wcag: "2.4.1 Bypass Blocks",
    status: "Implemented",
  },
  {
    area: "Focus visibility and management",
    requirement: "Focus moves toward validation errors",
    detail:
      "On failed submission, the page scrolls/focuses the first field in error so keyboard and screen reader users land on the problem instead of having to search the page.",
    wcag: "3.3.1 Error Identification",
    status: "Implemented",
  },

  // Forms and validation
  {
    area: "Forms and validation",
    requirement: "Every control has an accessible name",
    detail:
      "Text fields, selects, checkboxes, and radios use a real associated label. Icon-only controls (remove/edit/close buttons, cart icon, hamburger menu, tab icons on small screens) carry an aria-label describing their action/destination, including per-row context where multiple similar controls exist on one page (e.g. \"Remove Jane Doe (50%)\").",
    wcag: "1.1.1 Non-text Content; 2.5.3 Label in Name; 4.1.2 Name, Role, Value",
    status: "Implemented",
  },
  {
    area: "Forms and validation",
    requirement: "Required fields communicated programmatically",
    detail:
      "Required checkboxes and inputs expose the native required attribute (or aria-required) in addition to the visual asterisk, so the requirement is announced, not just shown.",
    wcag: "3.3.2 Labels or Instructions",
    status: "Implemented",
  },
  {
    area: "Forms and validation",
    requirement: "Errors identify the affected field and are exposed to AT",
    detail:
      "Field-level errors are surfaced through the shared field renderer's error/helper-text wiring (native TextField/Select association, plus explicit aria-describedby for custom radio and checkbox-group rows) rather than through a same-page banner alone.",
    wcag: "3.3.1 Error Identification; 4.1.2 Name, Role, Value",
    status: "Implemented",
  },
  {
    area: "Forms and validation",
    requirement: "Helper text is programmatically associated",
    detail:
      "Helper/instructional text below a field or group is linked via aria-describedby so it is read together with the control, not just visually adjacent to it.",
    wcag: "1.3.1 Info and Relationships; 3.3.2 Labels or Instructions",
    status: "Implemented",
  },
  {
    area: "Forms and validation",
    requirement: "Errors are not communicated by color alone",
    detail:
      "Error states pair a text message (and, where used, an icon) with the red/error color styling — color is never the only signal that a field or option is invalid.",
    wcag: "1.4.1 Use of Color",
    status: "Implemented",
  },
  {
    area: "Forms and validation",
    requirement: "Related controls expose a group name",
    detail:
      "Radio groups and checkbox groups (Yes/No medical questions, gender/tobacco selection, verification method, security questions, coverage riders) are wrapped in a radiogroup/group role with aria-labelledby pointing at the visible question text, so the group's purpose is announced once per group rather than being absent.",
    wcag: "1.3.1 Info and Relationships; 4.1.2 Name, Role, Value",
    status: "Implemented",
  },
  {
    area: "Forms and validation",
    requirement: "Avoid unnecessary redundant entry",
    detail:
      "Information the application already has (e.g. previously entered contact/eligibility data used to prefill later steps) is not required to be re-entered by the user where the template already carries it forward.",
    wcag: "3.3.7 Redundant Entry",
    status: "Implemented",
  },

  // Dynamic content and status messaging
  {
    area: "Dynamic content and status messaging",
    requirement: "Loading and calculation states are announced",
    detail:
      "Recalculating cost/estimate panels and \"Loading your coverage options\" states use role=\"status\"/aria-live=\"polite\" (with decorative spinners hidden or labeled) so a screen reader user is told a value is updating instead of it silently changing.",
    wcag: "4.1.3 Status Messages",
    status: "Implemented",
  },
  {
    area: "Dynamic content and status messaging",
    requirement: "Save/confirmation toasts use appropriate urgency",
    detail:
      "Routine confirmations (progress saved, success toasts) use role=\"status\" (polite); only genuine errors/warnings use role=\"alert\" (assertive), so routine updates don't interrupt the user the way an error would.",
    wcag: "4.1.3 Status Messages",
    status: "Implemented",
  },
  {
    area: "Dynamic content and status messaging",
    requirement: "List add/remove actions are announced",
    detail:
      "Adding, editing, or removing a repeatable item (beneficiaries, dependents, physicians) posts a short polite live-region message confirming what happened, since the visual list change alone is not exposed to assistive technology.",
    wcag: "4.1.3 Status Messages",
    status: "Implemented",
  },
  {
    area: "Dynamic content and status messaging",
    requirement: "Route/flow transitions that skip the standard transition are still announced",
    detail:
      "Pages reached by a direct navigation outside the standard Next-button transition (which otherwise shows its own status announcement) provide their own brief live-region confirmation on arrival.",
    wcag: "4.1.3 Status Messages",
    status: "Implemented",
  },
  {
    area: "Dynamic content and status messaging",
    requirement: "Non-essential UI changes are not overly verbose",
    detail:
      "Live regions are scoped to meaningful state changes (results, errors, confirmations) rather than wrapping every visual re-render, to avoid chatty/redundant announcements.",
    wcag: "4.1.3 Status Messages",
    status: "Implemented",
  },

  // Dialogs, drawers, and overlays
  {
    area: "Dialogs, drawers, and overlays",
    requirement: "Dialogs and drawers expose an accessible name",
    detail:
      "Every modal dialog and drawer (confirmation dialogs, the hamburger menu, the coverage summary drawer, and all AppDrawer-based help panels) is labelled via aria-labelledby pointing at its visible title, or an explicit aria-label when no visible title is used.",
    wcag: "4.1.2 Name, Role, Value",
    status: "Implemented",
  },
  {
    area: "Dialogs, drawers, and overlays",
    requirement: "Modal behavior is keyboard accessible",
    detail:
      "Dialogs/drawers open with focus moved inside, trap Tab navigation while open, and close on Escape, using MUI's default modal behavior without being overridden.",
    wcag: "2.1.1 Keyboard; 2.1.2 No Keyboard Trap",
    status: "Implemented",
  },
  {
    area: "Dialogs, drawers, and overlays",
    requirement: "Close controls have meaningful names",
    detail:
      "Every icon-only close control (dialogs, drawers, the menu, the cookie banner, the schedule-a-call dialog) has an aria-label identifying what it closes, not just a generic icon.",
    wcag: "1.1.1 Non-text Content; 4.1.2 Name, Role, Value",
    status: "Implemented",
  },
  {
    area: "Dialogs, drawers, and overlays",
    requirement: "Alert/confirmation dialogs use alertdialog semantics",
    detail:
      "Destructive or warning confirmations (remove item, send back to advisor) use role=\"alertdialog\"; general informational dialogs use the default dialog role.",
    wcag: "4.1.2 Name, Role, Value",
    status: "Implemented",
  },
  {
    area: "Dialogs, drawers, and overlays",
    requirement: "Background content is excluded from the keyboard interaction while a modal is open",
    detail:
      "MUI's default modal/backdrop behavior (aria-hidden on background content, focus trap) is relied on as-is; no dialog disables this default.",
    wcag: "2.1.2 No Keyboard Trap; 4.1.2 Name, Role, Value",
    status: "Implemented",
  },

  // Images and icons
  {
    area: "Images and icons",
    requirement: "Informative images have meaningful alt text",
    detail:
      "Logos and any content-bearing images use descriptive, purpose-driven alt text rather than a filename or repeated caption.",
    wcag: "1.1.1 Non-text Content",
    status: "Implemented",
  },
  {
    area: "Images and icons",
    requirement: "Decorative icons are hidden from assistive technology",
    detail:
      "Decorative icons (section icons, spinners paired with visible loading text, category icon badges) rely on MUI's default aria-hidden behavior for SvgIcon, or set aria-hidden explicitly, so they are not announced as unlabeled graphics.",
    wcag: "1.1.1 Non-text Content",
    status: "Implemented",
  },
  {
    area: "Images and icons",
    requirement: "Icon-only buttons have accessible names",
    detail:
      "Every icon-only IconButton in the shared shell and page content (cart, menu, close, back, remove, edit, expand/collapse) has an aria-label describing its action, including dynamic state where relevant (e.g. the cart button announces the current item count).",
    wcag: "1.1.1 Non-text Content; 4.1.2 Name, Role, Value",
    status: "Implemented",
  },

  // Navigation and progress
  {
    area: "Navigation and progress",
    requirement: "Current step/page is programmatically identifiable",
    detail:
      "The active step in the application progress stepper is marked with aria-current=\"step\" (in addition to its visual styling), and breadcrumb-style navigation marks the active page with aria-current=\"page\".",
    wcag: "4.1.2 Name, Role, Value",
    status: "Implemented",
  },
  {
    area: "Navigation and progress",
    requirement: "Progress is not communicated by styling alone",
    detail:
      "Step completion/active state pairs its visual treatment (bold text, checkmark) with the programmatic aria-current marker described above.",
    wcag: "1.4.1 Use of Color; 4.1.2 Name, Role, Value",
    status: "Implemented",
  },
  {
    area: "Navigation and progress",
    requirement: "Navigation controls have meaningful names",
    detail:
      "Back/next controls, category tabs, and menu triggers carry accessible names describing their destination or action, including when their visible text label is hidden at small viewport widths.",
    wcag: "2.4.4 Link Purpose (In Context); 4.1.2 Name, Role, Value",
    status: "Implemented",
  },

  // Color and visual presentation
  {
    area: "Color and visual presentation",
    requirement: "Text and UI components meet AA contrast",
    detail:
      "Body text, interactive control borders/icons, and status colors are designed to meet WCAG 2.2 AA contrast ratios (4.5:1 normal text, 3:1 large text and non-text UI components). Final verification against the production color palette and client-theme overrides is a production/testing requirement.",
    wcag: "1.4.3 Contrast (Minimum); 1.4.11 Non-text Contrast",
    status: "Requires production testing",
  },
  {
    area: "Color and visual presentation",
    requirement: "Information is not conveyed by color alone",
    detail:
      "Status/eligibility/error indicators pair color with text, icon, or both, so removing color does not remove meaning.",
    wcag: "1.4.1 Use of Color",
    status: "Implemented",
  },
  {
    area: "Color and visual presentation",
    requirement: "Usable at 200% zoom / with text resizing",
    detail:
      "Layouts use relative units and MUI's responsive breakpoints rather than fixed pixel containers that would clip content when text is enlarged. Should be spot-checked at 200% browser zoom across the longest pages (Review, Coverage) during production QA.",
    wcag: "1.4.4 Resize Text; 1.4.10 Reflow",
    status: "Requires production testing",
  },
  {
    area: "Color and visual presentation",
    requirement: "Responsive layouts do not remove content or functionality",
    detail:
      "Narrow-viewport variants (mobile stepper, drawer-based panels, hidden tab text labels) hide only redundant visual labels, never remove functionality — hidden text labels are replaced with an equivalent aria-label rather than dropped.",
    wcag: "1.4.10 Reflow; 4.1.2 Name, Role, Value",
    status: "Implemented",
  },

  // Pointer/touch interaction
  {
    area: "Pointer/touch interaction",
    requirement: "Targets meet minimum size or spacing",
    detail:
      "Interactive controls, including icon-only buttons, target at least a 24x24 CSS pixel hit area (or equivalent spacing from neighboring targets) per WCAG 2.2's target-size exception allowances. Small icon controls introduced or modified during this pass were checked against this; a full pass across every legacy control is a production/testing follow-up.",
    wcag: "2.5.8 Target Size (Minimum)",
    status: "Requires production testing",
  },
  {
    area: "Pointer/touch interaction",
    requirement: "No functionality requires precise dragging",
    detail:
      "The template does not use drag-only interactions (sliders, drag-to-reorder) anywhere in the current page set; all quantity/amount controls use selects, steppers, or typed input instead.",
    wcag: "2.5.7 Dragging Movements",
    status: "Implemented",
  },
  {
    area: "Pointer/touch interaction",
    requirement: "Controls remain usable on touch devices",
    detail:
      "Custom selection rows and cards use onClick (which fires for touch and mouse alike) rather than hover-only or mouse-event-only handlers, and swipeable drawers fall back to tap-to-open/close.",
    wcag: "2.5.1 Pointer Gestures",
    status: "Implemented",
  },

  // Authentication / resume flow
  {
    area: "Authentication / resume flow",
    requirement: "No cognitive-function test without an accessible alternative",
    detail:
      "Resume/verification steps (email link, text/voice code, security questions) rely on object recognition or a code the user already possesses/receives, not on solving a puzzle, transcribing a distorted image, or memorizing new information — satisfying the WCAG 2.2 Accessible Authentication minimum.",
    wcag: "3.3.8 Accessible Authentication (Minimum)",
    status: "Implemented",
  },
  {
    area: "Authentication / resume flow",
    requirement: "Users can recover from an expired or failed code",
    detail:
      "The verification-code screen provides a working \"Resend code\" action that resets the countdown and confirms (visually and via a live-region announcement) that a new code was sent, rather than a dead link/button.",
    wcag: "3.3.8 Accessible Authentication (Minimum); 4.1.3 Status Messages",
    status: "Implemented",
  },

  // Testing & validation
  {
    area: "Testing & validation",
    requirement: "Automated accessibility testing",
    detail:
      "Automated tooling (e.g. axe-core or equivalent) should be run against each page/state as part of production readiness. Automated testing alone catches roughly a third of WCAG issues and must not be treated as proof of conformance.",
    wcag: "N/A — process requirement",
    status: "Requires production testing",
  },
  {
    area: "Testing & validation",
    requirement: "Keyboard-only testing",
    detail:
      "Every flow (application form, quote tool, beneficiary management, resume/authentication) should be walked end-to-end using only the keyboard before production sign-off.",
    wcag: "N/A — process requirement",
    status: "Requires production testing",
  },
  {
    area: "Testing & validation",
    requirement: "Screen reader testing",
    detail:
      "Primary flows should be tested with at least one desktop screen reader (NVDA or JAWS with Chrome/Edge) and one mobile screen reader (VoiceOver or TalkBack), including dynamic states (validation, loading, drawers).",
    wcag: "N/A — process requirement",
    status: "Requires production testing",
  },
  {
    area: "Testing & validation",
    requirement: "Zoom and reflow testing",
    detail:
      "Pages should be checked at 200% browser zoom and at narrow viewport widths to confirm no content or functionality is lost or overlapping.",
    wcag: "1.4.4 Resize Text; 1.4.10 Reflow",
    status: "Requires production testing",
  },
  {
    area: "Testing & validation",
    requirement: "Contrast verification against final visual design",
    detail:
      "Final text, icon, and UI-component colors (including any client-specific theme overrides) should be verified against WCAG 2.2 AA contrast ratios using the production color values, not the prototype's placeholder palette alone.",
    wcag: "1.4.3 Contrast (Minimum); 1.4.11 Non-text Contrast",
    status: "Requires production testing",
  },
  {
    area: "Testing & validation",
    requirement: "Manual review of dynamic states and form errors",
    detail:
      "Loading, calculation, validation-error, and confirmation states should be manually reviewed with assistive technology, since these are the states most likely to regress silently as the template evolves.",
    wcag: "4.1.3 Status Messages; 3.3.1 Error Identification",
    status: "Requires production testing",
  },
];

// ---------------------------------------------------------------------------
// FieldRenderer examples — one instance of every input pattern FieldRenderer
// supports (source: src/components/forms/FieldRenderer.tsx)
// ---------------------------------------------------------------------------

type FieldExample = {
  title: string;
  note: string;
  field: FieldDefinition;
};

const fieldExamples: FieldExample[] = [
  {
    title: "Text — floating label",
    note: "Default label mode: label floats inside the input border.",
    field: {
      id: "ds-text-floating",
      label: "First name",
      inputType: "text",
      required: true,
      autoComplete: "given-name",
    },
  },
  {
    title: "Text — standard label",
    note: "labelVariant: 'standard' — label sits above the input as a FormLabel.",
    field: {
      id: "ds-text-standard",
      label: "Last name",
      inputType: "text",
      labelVariant: "standard",
      required: true,
      autoComplete: "family-name",
    },
  },
  {
    title: "Email",
    note: "format: 'email' — validated on blur, mobile email keyboard.",
    field: {
      id: "ds-email",
      label: "Email address",
      inputType: "text",
      format: "email",
      required: true,
      autoComplete: "email",
    },
  },
  {
    title: "Phone — with type dropdown",
    note: "format: 'phone' — auto-formats digits, inline Mobile/Home/Business selector as an end adornment.",
    field: {
      id: "ds-phone",
      label: "Phone number",
      inputType: "text",
      format: "phone",
      required: true,
    },
  },
  {
    title: "Phone — plain",
    note: "showPhoneTypeSelector: false — formatted phone input with no type selector.",
    field: {
      id: "ds-phone-plain",
      label: "Business phone",
      inputType: "text",
      format: "phone",
      showPhoneTypeSelector: false,
    },
  },
  {
    title: "Number",
    note: "inputType: 'number' — digit-only, numeric mobile keyboard.",
    field: {
      id: "ds-number",
      label: "Years self-employed",
      inputType: "number",
    },
  },
  {
    title: "Currency",
    note: "format: 'currency' — auto-formats to $ with thousands separators.",
    field: {
      id: "ds-currency",
      label: "Average monthly income",
      inputType: "text",
      format: "currency",
    },
  },
  {
    title: "Percent",
    note: "format: 'percent' — strips to a max of 3 digits, no symbol.",
    field: {
      id: "ds-percent",
      label: "Ownership share",
      inputType: "text",
      format: "percent",
    },
  },
  {
    title: "SSN — input with icon",
    note: "format: 'ssn' — lock icon start adornment; digits mask to bullets, last digit shown briefly.",
    field: {
      id: "ds-ssn",
      label: "Social Security Number",
      inputType: "text",
      format: "ssn",
      required: true,
    },
  },
  {
    title: "Date",
    note: "inputType: 'date' — MM/DD/YYYY display, stored as YYYY-MM-DD.",
    field: {
      id: "ds-date",
      label: "Date of birth",
      inputType: "date",
      required: true,
      autoComplete: "bday",
    },
  },
  {
    title: "Month / year",
    note: "format: 'month-year' — MM/YYYY display, e.g. coverage start date.",
    field: {
      id: "ds-month-year",
      label: "Coverage start",
      inputType: "text",
      format: "month-year",
    },
  },
  {
    title: "Textarea",
    note: "multiline: true — free-form multi-line text.",
    field: {
      id: "ds-textarea",
      label: "Additional details",
      inputType: "text",
      multiline: true,
      minRows: 3,
      placeholder: "Add any additional context here…",
    },
  },
  {
    title: "Dropdown — floating label",
    note: "inputType: 'dropdown' — MUI Select with a floating InputLabel.",
    field: {
      id: "ds-dropdown-floating",
      label: "State",
      inputType: "dropdown",
      required: true,
      options: [
        { value: "ny", label: "New York" },
        { value: "ca", label: "California" },
        { value: "tx", label: "Texas" },
      ],
    },
  },
  {
    title: "Dropdown — standard label",
    note: "inputType: 'dropdown' + labelVariant: 'standard' — external FormLabel.",
    field: {
      id: "ds-dropdown-standard",
      label: "Business type",
      inputType: "dropdown",
      labelVariant: "standard",
      options: [
        { value: "sole-prop", label: "Sole Proprietor" },
        { value: "corp", label: "Professional Corporation" },
        { value: "llc", label: "LLC" },
      ],
    },
  },
  {
    title: "Searchable select",
    note: "inputType: 'searchable-select' — MUI Autocomplete with type-ahead filtering.",
    field: {
      id: "ds-searchable-select",
      label: "AVMA graduation year",
      inputType: "searchable-select",
      options: Array.from({ length: 6 }, (_, i) => {
        const year = String(2024 - i);
        return { value: year, label: year };
      }),
    },
  },
  {
    title: "Multi-select",
    note: "inputType: 'multi-select' — Select multiple, checkboxes inside a dropdown.",
    field: {
      id: "ds-multi-select",
      label: "Tobacco products used",
      inputType: "multi-select",
      options: [
        { value: "cigarettes", label: "Cigarettes" },
        { value: "cigars", label: "Cigars" },
        { value: "vaping", label: "Vaping / e-cigarettes" },
        { value: "chewing", label: "Chewing tobacco" },
      ],
    },
  },
  {
    title: "Radio",
    note: "inputType: 'radio' — full-width SelectionGroup rows, one tap target per option.",
    field: {
      id: "ds-radio",
      label: "Do you use tobacco products?",
      inputType: "radio",
      required: true,
      options: [
        { value: "yes", label: "Yes" },
        { value: "no", label: "No" },
      ],
    },
  },
  {
    title: "Checkbox — single",
    note: "inputType: 'checkbox' — single boolean toggle in a SelectionGroup row.",
    field: {
      id: "ds-checkbox",
      label: "I authorize this bank account for premium payments.",
      inputType: "checkbox",
      required: true,
    },
  },
  {
    title: "Checkbox group",
    note: "inputType: 'checkbox-group' — multiple independent checkboxes, stores an array.",
    field: {
      id: "ds-checkbox-group",
      label: "Which of these apply to you?",
      inputType: "checkbox-group",
      options: [
        { value: "self-employed", label: "Self-employed" },
        { value: "work-from-home", label: "Work from home" },
        { value: "travel-often", label: "Travel outside the US often" },
      ],
    },
  },
];

type DemoFormValues = Record<string, string | boolean | string[]>;

function FieldExampleCard({ example }: { example: FieldExample }) {
  const {
    control,
    formState: { errors },
  } = useForm<DemoFormValues>({
    defaultValues: {
      [example.field.id]: example.field.inputType === "checkbox"
        ? false
        : example.field.inputType === "checkbox-group" ||
            example.field.inputType === "multi-select"
          ? []
          : "",
      "phone-type": "mobile",
    },
  });

  return (
    <Card
      variant="outlined"
      sx={{ borderRadius: 3, height: "100%", display: "flex", flexDirection: "column" }}
    >
      <CardContent sx={{ flex: 1 }}>
        <Typography variant="subtitle2" sx={{ mb: 0.5 }}>
          {example.title}
        </Typography>
        <Typography
          variant="caption"
          color="text.secondary"
          sx={{ display: "block", mb: 2 }}
        >
          {example.note}
        </Typography>
        <FieldRenderer field={example.field} control={control} errors={errors} />
      </CardContent>
    </Card>
  );
}

// ---------------------------------------------------------------------------
// Field error examples — same FieldRenderer, forced into its error state via
// react-hook-form validation (real validation rules from FieldRenderer).
// ---------------------------------------------------------------------------

const errorFieldExamples: FieldExample[] = [
  {
    title: "Text — error",
    note: "Required field left empty: red outline + \"{Field label} is required.\" helper text.",
    field: {
      id: "ds-error-text",
      label: "Email address",
      inputType: "text",
      format: "email",
      required: true,
    },
  },
  {
    title: "Dropdown — error",
    note: "Required select with no value chosen.",
    field: {
      id: "ds-error-dropdown",
      label: "State",
      inputType: "dropdown",
      required: true,
      options: [
        { value: "ny", label: "New York" },
        { value: "ca", label: "California" },
      ],
    },
  },
  {
    title: "Radio — error",
    note: "Required radio group with no option selected.",
    field: {
      id: "ds-error-radio",
      label: "Do you use tobacco products?",
      inputType: "radio",
      required: true,
      options: [
        { value: "yes", label: "Yes" },
        { value: "no", label: "No" },
      ],
    },
  },
  {
    title: "Checkbox — error",
    note: "Required consent checkbox left unchecked.",
    field: {
      id: "ds-error-checkbox",
      label: "I authorize this bank account for premium payments.",
      inputType: "checkbox",
      required: true,
    },
  },
];

function FieldErrorExampleCard({ example }: { example: FieldExample }) {
  const {
    control,
    trigger,
    formState: { errors },
  } = useForm<DemoFormValues>({
    mode: "onChange",
    defaultValues: {
      [example.field.id]:
        example.field.inputType === "checkbox" ? false : "",
    },
  });

  // Force validation to run once on mount so the error state renders
  // immediately, without requiring the visitor to interact with the field.
  useEffect(() => {
    void trigger();
  }, [trigger]);

  return (
    <Card
      variant="outlined"
      sx={{
        borderRadius: 3,
        height: "100%",
        display: "flex",
        flexDirection: "column",
        borderColor: "error.main",
      }}
    >
      <CardContent sx={{ flex: 1 }}>
        <Typography variant="subtitle2" sx={{ mb: 0.5 }}>
          {example.title}
        </Typography>
        <Typography
          variant="caption"
          color="text.secondary"
          sx={{ display: "block", mb: 2 }}
        >
          {example.note}
        </Typography>
        <FieldRenderer field={example.field} control={control} errors={errors} />
      </CardContent>
    </Card>
  );
}

// ---------------------------------------------------------------------------
// Beneficiary "Add" modal example (DynamicList — self-contained, no shared
// app state; safe to mount live).
// ---------------------------------------------------------------------------

const beneficiaryModalFields: FieldDefinition[] = [
  { id: "ds-ben-first-name", label: "First Name", inputType: "text", required: true },
  { id: "ds-ben-last-name", label: "Last Name", inputType: "text", required: true },
  {
    id: "ds-ben-relationship",
    label: "Relationship",
    inputType: "dropdown",
    required: true,
    options: [
      { value: "spouse", label: "Spouse" },
      { value: "child", label: "Child" },
      { value: "parent", label: "Parent" },
      { value: "sibling", label: "Sibling" },
      { value: "other", label: "Other" },
    ],
  },
  { id: "ds-ben-share", label: "% Share", inputType: "number", required: true },
];

const beneficiaryFieldToKey = {
  "ds-ben-first-name": "firstName",
  "ds-ben-last-name": "lastName",
  "ds-ben-relationship": "relationship",
  "ds-ben-share": "share",
} as const;

function BeneficiaryModalExample() {
  const { control } = useForm<Record<string, any>>({
    defaultValues: {
      beneficiaries: [
        {
          firstName: "Jordan",
          lastName: "Lee",
          relationship: "spouse",
          share: "100",
        },
      ],
    },
  });

  return (
    <DynamicList
      control={control}
      name="beneficiaries"
      label="Beneficiary"
      mapping={{ fields: beneficiaryModalFields, fieldToKey: beneficiaryFieldToKey }}
      getItemLabel={(item) => `${item.firstName} ${item.lastName}`}
      renderItem={(item) => (
        <Typography variant="body2">
          <strong>
            {item.firstName} {item.lastName}
          </strong>{" "}
          — {item.relationship}, {item.share}% share
        </Typography>
      )}
    />
  );
}

// ---------------------------------------------------------------------------
// Coverage cart — static visual reconstruction (not wired to live app state).
// The real ECart/CartDrawer reads shared session data; a static mock keeps
// this reference deterministic and avoids touching a real in-progress
// application's saved selections.
// ---------------------------------------------------------------------------

const mockCartLines = [
  { product: "Term Life Insurance", applicant: "Primary Applicant", amount: "$250,000", monthly: 24.5 },
  { product: "Term Life Insurance", applicant: "Spouse", amount: "$100,000", monthly: 11.75 },
  { product: "Accidental Death & Dismemberment", applicant: "Primary Applicant", amount: "$50,000", monthly: 4.25 },
];

function CoverageCartPreview() {
  const total = mockCartLines.reduce((sum, line) => sum + line.monthly, 0);

  return (
    <Card variant="outlined" sx={{ borderRadius: CARD_RADIUS, maxWidth: 380 }}>
      <CardContent>
        <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 1.5 }}>
          <Typography variant="subtitle2">Your Coverage</Typography>
          <Chip label="Estimate" size="small" variant="outlined" />
        </Stack>
        <Stack spacing={1.5} divider={<Divider />}>
          {mockCartLines.map((line, i) => (
            <Stack key={i} spacing={0.25}>
              <Typography variant="body2" sx={{ fontWeight: 700 }}>
                {line.product}
              </Typography>
              <Stack direction="row" justifyContent="space-between">
                <Typography variant="caption" color="text.secondary">
                  {line.applicant} · {line.amount}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {formatUSD(line.monthly)}/mo
                </Typography>
              </Stack>
            </Stack>
          ))}
        </Stack>
        <Divider sx={{ my: 1.5 }} />
        <Stack direction="row" justifyContent="space-between" alignItems="baseline">
          <Typography variant="subtitle2">Estimated total</Typography>
          <Typography variant="subtitle1" sx={{ fontWeight: 800 }}>
            {formatUSD(total)}/mo
          </Typography>
        </Stack>
      </CardContent>
    </Card>
  );
}

// ---------------------------------------------------------------------------
// App menu preview — real AppMenu, opened via a local toggle so it's safe
// and deterministic to demo (no shared state, closes like the real drawer).
// ---------------------------------------------------------------------------

function AppMenuPreview() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button variant="outlined" startIcon={<MenuIcon />} onClick={() => setOpen(true)}>
        Open menu
      </Button>
      <AppMenu open={open} onClose={() => setOpen(false)} client={getActiveClient()} />
    </>
  );
}

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

export default function DesignSystem() {
  const [iconFilter, setIconFilter] = useState("");

  const filteredIconGroups = useMemo(() => {
    if (!iconFilter) return iconGroups;
    const lc = iconFilter.toLowerCase();
    return iconGroups
      .map((group) => ({
        ...group,
        icons: group.icons.filter((icon) =>
          `${icon.label} ${icon.usedIn}`.toLowerCase().includes(lc),
        ),
      }))
      .filter((group) => group.icons.length > 0);
  }, [iconFilter]);

  const totalIconCount = filteredIconGroups.reduce(
    (sum, g) => sum + g.icons.length,
    0,
  );

  return (
    <Box
      sx={{
        py: { xs: 3, md: 5 },
        px: { xs: 2, md: 4 },
        width: "100vw",
        maxWidth: "100vw",
        ml: "calc(-50vw + 50%)",
        boxSizing: "border-box",
      }}
    >
      <Stack spacing={3}>
        <Box>
          <Chip
            label="Internal prototype documentation"
            color="error"
            variant="outlined"
            sx={{ mb: 2 }}
          />
          <Typography variant="h3" component="h1" sx={{ fontWeight: 800 }}>
            Design System
          </Typography>
          <Typography
            variant="body1"
            color="text.secondary"
            sx={{ mt: 1, maxWidth: 920 }}
          >
            Visual reference for the application's theme, iconography, brand
            guidelines, and layout conventions. Derived from{" "}
            <code>src/app/theme.ts</code> and the active implementation
            (demo client).
          </Typography>
        </Box>

        <Card
          id="table-of-contents"
          sx={{
            border: "1px solid",
            borderColor: "divider",
            borderRadius: "24px",
            boxShadow: "0 12px 28px rgba(15, 23, 42, 0.06)",
            display: { xs: "block", md: "none" },
          }}
        >
          <CardContent>
            <Typography variant="h6" component="h2" sx={{ fontWeight: 800 }}>
              Table of contents
            </Typography>
            <Stack
              direction="row"
              useFlexGap
              flexWrap="wrap"
              spacing={1}
              sx={{ mt: 2 }}
            >
              {toc.map((item) => (
                <Chip
                  key={item.id}
                  component="a"
                  href={`#${item.id}`}
                  clickable
                  label={item.label}
                  variant="outlined"
                />
              ))}
            </Stack>
          </CardContent>
        </Card>

        <Box sx={{ display: "flex", gap: 4, alignItems: "flex-start" }}>
          <DocsSidebarNav items={toc} />
          <Stack spacing={3} sx={{ flex: 1, minWidth: 0 }}>
        {/* 1. COLORS */}
        <SectionAccordion
          id="colors-section"
          title="Colors"
          description="Palette tokens defined in the theme. Success and error are reserved semantic colors — see Branding guidelines below."
        >
          <Stack spacing={3}>
            <Box>
              <Typography variant="subtitle2" sx={{ mb: 1.5 }}>
                Brand & semantic
              </Typography>
              <Stack direction="row" flexWrap="wrap" gap={2}>
                {semanticSwatches.map((s) => (
                  <ColorSwatch key={s.label} swatch={s} />
                ))}
              </Stack>
            </Box>
            <Divider />
            <Box>
              <Typography variant="subtitle2" sx={{ mb: 1.5 }}>
                Text & surface neutrals
              </Typography>
              <Stack direction="row" flexWrap="wrap" gap={2}>
                {neutralSwatches.map((s) => (
                  <ColorSwatch key={s.label} swatch={s} />
                ))}
              </Stack>
            </Box>
            <Divider />
            <Box>
              <Typography variant="subtitle2" sx={{ mb: 1.5 }}>
                Contextual containers
              </Typography>
              <Typography variant="caption" color="text.secondary" sx={{ mb: 1.5, display: "block" }}>
                panel = neutral info panels · notice = caution/notice boxes · support = help/support callouts
              </Typography>
              <Stack direction="row" flexWrap="wrap" gap={2}>
                {containerSwatches.map((s) => (
                  <ColorSwatch key={s.label} swatch={s} />
                ))}
              </Stack>
            </Box>
            <Divider />
            <Box>
              <Typography variant="subtitle2" sx={{ mb: 1.5 }}>
                Client brand presets (ThemeColorId)
              </Typography>
              <Typography variant="caption" color="text.secondary" sx={{ mb: 1.5, display: "block" }}>
                Each client selects one preset, which replaces{" "}
                <code>primary.main / light / dark</code> only — all other
                tokens above stay fixed.
              </Typography>
              <ResponsiveTableContainer>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>Preset</TableCell>
                      <TableCell>Main</TableCell>
                      <TableCell>Light</TableCell>
                      <TableCell>Dark</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {themePresets.map((preset) => (
                      <TableRow key={preset.name}>
                        <TableCell sx={{ fontWeight: 700 }}>{preset.name}</TableCell>
                        {[preset.main, preset.light, preset.dark].map((hex) => (
                          <TableCell key={hex}>
                            <Stack direction="row" spacing={1} alignItems="center">
                              <Box
                                sx={{
                                  width: 20,
                                  height: 20,
                                  borderRadius: 1,
                                  backgroundColor: hex,
                                  border: "1px solid rgba(0,0,0,0.08)",
                                  flexShrink: 0,
                                }}
                              />
                              <Typography variant="caption">{hex}</Typography>
                            </Stack>
                          </TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ResponsiveTableContainer>
            </Box>
          </Stack>
        </SectionAccordion>

        {/* 2. TYPOGRAPHY */}
        <SectionAccordion
          id="typography-section"
          title="Typography"
          description="Font family: Inter, system-ui, -apple-system, Segoe UI, Roboto, Helvetica Neue, Arial, sans-serif."
        >
          <Stack spacing={2.5}>
            {(["h1", "h2", "h3", "h4", "h5", "h6"] as const).map((variant) => (
              <Stack
                key={variant}
                direction={{ xs: "column", sm: "row" }}
                spacing={2}
                alignItems={{ sm: "baseline" }}
              >
                <Chip label={variant} size="small" sx={{ width: 48 }} />
                <Typography variant={variant} sx={{ fontWeight: 800 }}>
                  The quick brown fox
                </Typography>
              </Stack>
            ))}
            <Divider />
            <Stack direction={{ xs: "column", sm: "row" }} spacing={2} alignItems={{ sm: "baseline" }}>
              <Chip label="body1" size="small" sx={{ width: 130 }} />
              <Typography variant="body1">
                Body copy uses text.primary at regular weight.
              </Typography>
            </Stack>
            <Stack direction={{ xs: "column", sm: "row" }} spacing={2} alignItems={{ sm: "baseline" }}>
              <Chip label="subtitle2" size="small" sx={{ width: 130 }} />
              <Typography variant="subtitle2">Semibold subtitle text</Typography>
            </Stack>
            <Stack direction={{ xs: "column", sm: "row" }} spacing={2} alignItems={{ sm: "baseline" }}>
              <Chip label="overline" size="small" sx={{ width: 130 }} />
              <Typography variant="overline">Overline label</Typography>
            </Stack>
            <Divider />
            <Typography variant="subtitle2">Custom form variants</Typography>
            <Stack direction={{ xs: "column", sm: "row" }} spacing={2} alignItems={{ sm: "baseline" }}>
              <Chip label="formPageTitle" size="small" sx={{ width: 130 }} />
              <Typography variant="formPageTitle">Application page title</Typography>
            </Stack>
            <Stack direction={{ xs: "column", sm: "row" }} spacing={2} alignItems={{ sm: "baseline" }}>
              <Chip label="formSectionLabel" size="small" sx={{ width: 130 }} />
              <Typography variant="formSectionLabel">Section label</Typography>
            </Stack>
            <Stack direction={{ xs: "column", sm: "row" }} spacing={2} alignItems={{ sm: "baseline" }}>
              <Chip label="formBackLink" size="small" sx={{ width: 130 }} />
              <Typography variant="formBackLink">Back link text</Typography>
            </Stack>
            <Stack direction={{ xs: "column", sm: "row" }} spacing={2} alignItems={{ sm: "baseline" }}>
              <Chip label="productNameLabel" size="small" sx={{ width: 130 }} />
              <Typography variant="productNameLabel">Term Life Insurance</Typography>
            </Stack>
          </Stack>
        </SectionAccordion>

        {/* 3. COMPONENT OVERRIDES */}
        <SectionAccordion
          id="overrides-section"
          title="Component overrides"
          description={`Shared surface radius: ${CARD_RADIUS}. Base spacing unit: 8px.`}
          count={overrideRows.length}
        >
          <ResponsiveTableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>MUI component</TableCell>
                  <TableCell>Override summary</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {overrideRows.map((row) => (
                  <TableRow key={row.component}>
                    <TableCell sx={{ fontWeight: 700, whiteSpace: "nowrap" }}>
                      {row.component}
                    </TableCell>
                    <TableCell sx={{ whiteSpace: "normal" }}>{row.summary}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ResponsiveTableContainer>
        </SectionAccordion>

        {/* 4. FORM FIELD EXAMPLES */}
        <SectionAccordion
          id="field-examples-section"
          title="Form field examples"
          description="One live instance of every input pattern FieldRenderer supports, rendered with the real component."
          count={fieldExamples.length}
        >
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: {
                xs: "1fr",
                sm: "repeat(2, minmax(0, 1fr))",
                lg: "repeat(3, minmax(0, 1fr))",
              },
              gap: 2,
            }}
          >
            {fieldExamples.map((example) => (
              <FieldExampleCard key={example.field.id} example={example} />
            ))}
          </Box>
        </SectionAccordion>

        {/* 5. FIELD ERRORS */}
        <SectionAccordion
          id="field-errors-section"
          title="Field errors"
          description="Real FieldRenderer validation errors, forced to render immediately for reference. Page-level error banners are covered under Design rules → Alerts."
          count={errorFieldExamples.length}
        >
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: {
                xs: "1fr",
                sm: "repeat(2, minmax(0, 1fr))",
                lg: "repeat(4, minmax(0, 1fr))",
              },
              gap: 2,
            }}
          >
            {errorFieldExamples.map((example) => (
              <FieldErrorExampleCard key={example.field.id} example={example} />
            ))}
          </Box>
        </SectionAccordion>

        {/* 6. COMPONENT EXAMPLES */}
        <SectionAccordion
          id="components-section"
          title="Component examples"
          description="Live instances of larger site components, mounted directly from source. Interactive elements are safe to click — none of these write to the app's real saved-application state."
        >
          <Stack spacing={3}>
            <Box>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>
                App header
              </Typography>
              <Typography variant="caption" color="text.secondary" sx={{ mb: 1.5, display: "block" }}>
                Rendered in the <code>homepage</code> chrome variant here to
                keep this reference read-only (the <code>applicationForm</code>{" "}
                variant additionally shows a progress bar and cart icon in-app).
              </Typography>
              <Box sx={{ border: "1px solid", borderColor: "divider", borderRadius: 3, overflow: "hidden" }}>
                <AppHeader client={getActiveClient()} variant="homepage" />
              </Box>
            </Box>

            <Divider />

            <Box>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>
                App menu
              </Typography>
              <Typography variant="caption" color="text.secondary" sx={{ mb: 1.5, display: "block" }}>
                Full-screen slide-in drawer with coverage tools and support info.
              </Typography>
              <AppMenuPreview />
            </Box>

            <Divider />

            <Box>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>
                Coverage cart
              </Typography>
              <Typography variant="caption" color="text.secondary" sx={{ mb: 1.5, display: "block" }}>
                Static visual reconstruction with mock data — the real
                component reads the shared application session, which isn't
                deterministic for a documentation page.
              </Typography>
              <CoverageCartPreview />
            </Box>

            <Divider />

            <Box>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>
                Beneficiary "Add" modal
              </Typography>
              <Typography variant="caption" color="text.secondary" sx={{ mb: 1.5, display: "block" }}>
                DynamicList: repeating field-array pattern with a modal-based
                add/edit form. Click "Add Beneficiary" to see the dialog.
              </Typography>
              <Box sx={{ maxWidth: 480 }}>
                <BeneficiaryModalExample />
              </Box>
            </Box>
          </Stack>
        </SectionAccordion>

        {/* 6.5 COMPONENT LIBRARY */}
        <SectionAccordion
          id="component-library-section"
          title="Component library"
          description="Inventory of reusable app-specific UI components: category, description, usage locations, source path, and Storybook link. Moved from Information Architecture, since this documents the component library rather than application architecture."
        >
          <ComponentInventorySection />
        </SectionAccordion>

        {/* 7. ICONS */}
        <SectionAccordion
          id="icons-section"
          title="Icons"
          description="All icons currently used across the site, grouped by purpose."
          count={totalIconCount}
        >
          <Stack spacing={3}>
            <SearchField
              value={iconFilter}
              onChange={setIconFilter}
              placeholder="Filter icons…"
            />
            {filteredIconGroups.map((group) => (
              <Box key={group.id}>
                <Typography variant="subtitle2" sx={{ mb: 1.5 }}>
                  {group.title}
                </Typography>
                <Stack direction="row" flexWrap="wrap" gap={1.5}>
                  {group.icons.map(({ Icon, label, usedIn }) => (
                    <Stack
                      key={label}
                      spacing={0.5}
                      alignItems="center"
                      sx={{
                        width: 128,
                        p: 1.5,
                        border: "1px solid",
                        borderColor: "divider",
                        borderRadius: 3,
                      }}
                      title={usedIn}
                    >
                      <Icon color="primary" />
                      <Typography
                        variant="caption"
                        sx={{ textAlign: "center", fontWeight: 600 }}
                      >
                        {label}
                      </Typography>
                      <Typography
                        variant="caption"
                        color="text.secondary"
                        sx={{ textAlign: "center", fontSize: "0.65rem" }}
                      >
                        {usedIn}
                      </Typography>
                    </Stack>
                  ))}
                </Stack>
              </Box>
            ))}
          </Stack>
        </SectionAccordion>

        {/* 8. BRANDING GUIDELINES */}
        <SectionAccordion
          id="branding-section"
          title="Branding guidelines"
          description="Logo, hero image, and hero copy constraints applied per client."
        >
          <Stack spacing={2}>
            <Card variant="outlined" sx={{ borderRadius: CARD_RADIUS }}>
              <CardContent>
                <Typography variant="subtitle2" sx={{ mb: 1 }}>
                  Logo
                </Typography>
                <Stack
                  direction={{ xs: "column", sm: "row" }}
                  spacing={2}
                  alignItems={{ sm: "center" }}
                >
                  <Box
                    sx={{
                      maxWidth: { xs: 200, sm: 250 },
                      maxHeight: 35,
                      width: "100%",
                      height: 35,
                      borderRadius: 1,
                      border: "1px dashed",
                      borderColor: "divider",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      backgroundColor: "background.subtle",
                      flexShrink: 0,
                    }}
                  >
                    <Typography variant="caption" color="text.secondary">
                      logo area
                    </Typography>
                  </Box>
                  <Typography variant="body2" color="text.secondary">
                    Max <strong>200px</strong> wide on mobile, <strong>250px</strong> on
                    desktop (sm+); max <strong>35px</strong> tall. Rendered at natural
                    aspect ratio (width/height: auto). Source: AppHeader.
                  </Typography>
                </Stack>
              </CardContent>
            </Card>

            <Card variant="outlined" sx={{ borderRadius: CARD_RADIUS }}>
              <CardContent>
                <Typography variant="subtitle2" sx={{ mb: 1 }}>
                  Hero image
                </Typography>
                <Stack
                  direction={{ xs: "column", sm: "row" }}
                  spacing={2}
                  alignItems={{ sm: "center" }}
                >
                  <Box
                    sx={{
                      maxWidth: 250,
                      width: "100%",
                      aspectRatio: "500 / 320",
                      borderRadius: 4,
                      border: "1px dashed",
                      borderColor: "divider",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      backgroundColor: "background.subtle",
                      flexShrink: 0,
                    }}
                  >
                    <Typography variant="caption" color="text.secondary">
                      hero.png
                    </Typography>
                  </Box>
                  <Typography variant="body2" color="text.secondary">
                    Max <strong>500px</strong> wide, height auto, rounded corners
                    (radius 4 = 32px). Used only in the <code>hero-image</code> and{" "}
                    <code>welcome-back</code> Home page variants. Source path pattern:{" "}
                    <code>/client/&#123;clientId&#125;/hero.png</code>.
                  </Typography>
                </Stack>
              </CardContent>
            </Card>

            <Card variant="outlined" sx={{ borderRadius: CARD_RADIUS }}>
              <CardContent>
                <Typography variant="subtitle2" sx={{ mb: 1 }}>
                  Hero text length
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  No hard character limit is enforced in code today. To keep
                  the hero title readable at the <code>h1</code> size (2.25rem,
                  weight 800) inside its ~800px column, keep titles to roughly{" "}
                  <strong>60 characters or fewer</strong> and descriptions to
                  roughly <strong>160 characters or fewer</strong> so both wrap
                  to no more than two lines on desktop.
                </Typography>
                <Chip
                  label="⚠️ Open question — recommend adding validation in client content config"
                  size="small"
                  color="warning"
                  variant="outlined"
                  sx={{ mt: 1.5 }}
                />
              </CardContent>
            </Card>

            <Card variant="outlined" sx={{ borderRadius: CARD_RADIUS }}>
              <CardContent>
                <Typography variant="subtitle2" sx={{ mb: 1 }}>
                  Reserved theme colors
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
                  Client brand presets (see Colors above) are all blue/teal/
                  purple tones. Do not use red, orange, green, or yellow as a
                  client's primary brand color — those hues carry fixed meaning
                  elsewhere in the UI and a matching brand color would make
                  errors, success confirmations, or notices harder to
                  distinguish.
                </Typography>
                <Stack direction="row" flexWrap="wrap" gap={1.5}>
                  {[
                    { label: "Red — error only", value: "#ed0a0a" },
                    { label: "Green — success only", value: "#009465" },
                    { label: "Yellow — notice only", value: "#fffcf0" },
                    { label: "Orange — avoid entirely", value: "#f57c00" },
                  ].map((c) => (
                    <Stack key={c.label} direction="row" spacing={1} alignItems="center">
                      <Box
                        sx={{
                          width: 16,
                          height: 16,
                          borderRadius: "50%",
                          backgroundColor: c.value,
                          border: "1px solid rgba(0,0,0,0.15)",
                        }}
                      />
                      <Typography variant="caption" color="text.secondary">
                        {c.label}
                      </Typography>
                    </Stack>
                  ))}
                </Stack>
              </CardContent>
            </Card>
          </Stack>
        </SectionAccordion>

        {/* 9. DESIGN RULES */}
        <SectionAccordion
          id="rules-section"
          title="Design rules"
          description="Layout and interaction conventions applied across form pages."
        >
          <Stack spacing={3}>
            <Box>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>
                Field stacking
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Fields stack vertically by default (single column). Fields are
                only placed side by side when they are directly related —
                e.g. street + apartment, or city + state + ZIP.
              </Typography>
              <Stack spacing={1.5}>
                <Box>
                  <Typography variant="caption" color="text.secondary">
                    Unrelated fields — vertical
                  </Typography>
                  <Stack spacing={1} sx={{ mt: 0.5 }}>
                    {["Email", "Phone number"].map((label) => (
                      <Box
                        key={label}
                        sx={{
                          border: `1px solid ${FIELD_BORDER_COLOR}`,
                          borderRadius: CARD_RADIUS,
                          px: 2,
                          py: 1.5,
                        }}
                      >
                        <Typography variant="caption" color="text.secondary">
                          {label}
                        </Typography>
                      </Box>
                    ))}
                  </Stack>
                </Box>
                <Box>
                  <Typography variant="caption" color="text.secondary">
                    Related fields — grid (e.g. Contact page address block)
                  </Typography>
                  <Box
                    sx={{
                      display: "grid",
                      gridTemplateColumns: { xs: "1fr", sm: "2fr 1fr" },
                      gap: 1,
                      mt: 0.5,
                    }}
                  >
                    <Box sx={{ border: `1px solid ${FIELD_BORDER_COLOR}`, borderRadius: CARD_RADIUS, px: 2, py: 1.5 }}>
                      <Typography variant="caption" color="text.secondary">Street address</Typography>
                    </Box>
                    <Box sx={{ border: `1px solid ${FIELD_BORDER_COLOR}`, borderRadius: CARD_RADIUS, px: 2, py: 1.5 }}>
                      <Typography variant="caption" color="text.secondary">Apt / Unit</Typography>
                    </Box>
                  </Box>
                  <Box
                    sx={{
                      display: "grid",
                      gridTemplateColumns: { xs: "1fr", sm: "2fr 1fr 1fr" },
                      gap: 1,
                      mt: 1,
                    }}
                  >
                    <Box sx={{ border: `1px solid ${FIELD_BORDER_COLOR}`, borderRadius: CARD_RADIUS, px: 2, py: 1.5 }}>
                      <Typography variant="caption" color="text.secondary">City</Typography>
                    </Box>
                    <Box sx={{ border: `1px solid ${FIELD_BORDER_COLOR}`, borderRadius: CARD_RADIUS, px: 2, py: 1.5 }}>
                      <Typography variant="caption" color="text.secondary">State</Typography>
                    </Box>
                    <Box sx={{ border: `1px solid ${FIELD_BORDER_COLOR}`, borderRadius: CARD_RADIUS, px: 2, py: 1.5 }}>
                      <Typography variant="caption" color="text.secondary">ZIP</Typography>
                    </Box>
                  </Box>
                </Box>
              </Stack>
            </Box>

            <Divider />

            <Box>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>
                Form template layout
              </Typography>
              <Typography variant="body2" color="text.secondary">
                template=multi (default) uses the app's real, viewport-based
                responsive breakpoints — no width overrides. template=single
                keeps the same routes/pages/navigation but forces the whole
                app into its narrow-screen layout via createAppTheme's
                forceMobileLayout option, which pins the md/lg/xl
                breakpoints to an unreachable width regardless of the actual
                browser width (see Site Rules → Form Template). sm (600px)
                is deliberately left at its default so sm-level
                padding/spacing — e.g. FormRoutePage's FormShell, which uses{" "}
                <code>px: {"{"} xs: 2, sm: "48px" {"}"}</code> — still gets
                that breathing room on a real desktop-width browser instead
                of staying pinned to its tightest xs padding. In single
                template, Home's hero (tagline, title, description; no hero
                image) is capped at 700px and centered, while the form
                column beneath it (filled by the real Membership page) is
                capped at a wider 800px — the hero is intentionally
                narrower than the form.
              </Typography>
            </Box>

            <Divider />

            <Box>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>
                Alerts
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                One <code>AlertBanner</code> / <code>PageAlert</code> component
                covers all four severities. Severity communicates meaning —
                don't substitute one for another for visual variety.
              </Typography>
              <Stack spacing={1.5}>
                {alertRules.map((rule) => (
                  <Alert key={rule.severity} severity={rule.severity} sx={{ alignItems: "flex-start" }}>
                    <Typography variant="body2" sx={{ fontWeight: 700 }}>
                      {rule.meaning}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      Used for: {rule.usedFor}
                    </Typography>
                  </Alert>
                ))}
              </Stack>
            </Box>

            <Divider />

            <Box>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>
                Shape & motion
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Buttons are always pill-shaped (radius 9999) with a small
                upward lift on hover. Cards, alerts, inputs, and toggle
                buttons share the same {CARD_RADIUS} surface radius so
                stacked surfaces read as one consistent system.
              </Typography>
            </Box>
          </Stack>
        </SectionAccordion>

        {/* ACCESSIBILITY */}
        <SectionAccordion
          id="accessibility-section"
          title="Accessibility"
          description="WCAG 2.2 conformance checklist for the shared visual/interaction system — headings, keyboard support, focus, forms, dialogs, color, and touch targets. Applies uniformly across clients; not affected by client configuration."
          count={accessibilityRequirements.length}
        >
          {(() => {
            const groupOrder: string[] = [];
            const grouped: Record<string, typeof accessibilityRequirements> =
              {};
            for (const r of accessibilityRequirements) {
              if (!grouped[r.area]) {
                groupOrder.push(r.area);
                grouped[r.area] = [];
              }
              grouped[r.area].push(r);
            }
            return (
              <Stack spacing={3}>
                <Stack
                  direction="row"
                  useFlexGap
                  flexWrap="wrap"
                  spacing={1}
                  alignItems="center"
                >
                  <Typography
                    variant="caption"
                    color="text.secondary"
                    sx={{ fontWeight: 600, mr: 0.5 }}
                  >
                    Status:
                  </Typography>
                  {(Object.keys(a11yStatusColor) as A11yStatus[]).map(
                    (status) => (
                      <Chip
                        key={status}
                        label={status}
                        size="small"
                        color={a11yStatusColor[status]}
                        variant="outlined"
                      />
                    ),
                  )}
                </Stack>

                <Stack spacing={1.5}>
                  {groupOrder.map((area) => (
                    <Accordion
                      key={area}
                      defaultExpanded
                      disableGutters
                      sx={{
                        border: "1px solid",
                        borderColor: "divider",
                        borderRadius: "12px !important",
                        overflow: "hidden",
                        boxShadow: "none",
                        "&:before": { display: "none" },
                      }}
                    >
                      <AccordionSummary
                        expandIcon={<ExpandMoreRoundedIcon />}
                        sx={{
                          px: 2,
                          py: 0.75,
                          minHeight: 44,
                          backgroundColor: "background.subtle",
                          borderBottom: "1px solid",
                          borderColor: "divider",
                        }}
                      >
                        <Stack direction="row" spacing={1} alignItems="center">
                          <Typography
                            variant="subtitle2"
                            sx={{ fontWeight: 700 }}
                          >
                            {area}
                          </Typography>
                          <Chip
                            label={grouped[area].length}
                            size="small"
                            sx={{ height: 18, fontSize: "0.7rem" }}
                          />
                        </Stack>
                      </AccordionSummary>
                      <AccordionDetails sx={{ p: 0 }}>
                        <ResponsiveTableContainer>
                          <Table size="small">
                            <TableHead>
                              <TableRow>
                                <TableCell sx={{ minWidth: 220 }}>
                                  Requirement
                                </TableCell>
                                <TableCell sx={{ minWidth: 320 }}>
                                  Detail
                                </TableCell>
                                <TableCell sx={{ minWidth: 180 }}>
                                  WCAG 2.2 Reference
                                </TableCell>
                                <TableCell sx={{ minWidth: 100 }}>
                                  Status
                                </TableCell>
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {grouped[area].map((row, i) => (
                                <TableRow key={i}>
                                  <TableCell
                                    sx={{
                                      verticalAlign: "top",
                                      fontWeight: 600,
                                      fontSize: "0.8125rem",
                                    }}
                                  >
                                    {row.requirement}
                                  </TableCell>
                                  <TableCell
                                    sx={{
                                      verticalAlign: "top",
                                      fontSize: "0.8125rem",
                                      whiteSpace: "normal !important",
                                    }}
                                  >
                                    {row.detail}
                                  </TableCell>
                                  <TableCell
                                    sx={{
                                      verticalAlign: "top",
                                      fontSize: "0.75rem",
                                      color: "text.secondary",
                                    }}
                                  >
                                    {row.wcag}
                                  </TableCell>
                                  <TableCell sx={{ verticalAlign: "top" }}>
                                    <Chip
                                      label={row.status}
                                      size="small"
                                      color={a11yStatusColor[row.status]}
                                      variant="outlined"
                                      sx={{
                                        height: 20,
                                        "& .MuiChip-label": {
                                          fontSize: "0.7rem",
                                          px: 1,
                                        },
                                      }}
                                    />
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </ResponsiveTableContainer>
                      </AccordionDetails>
                    </Accordion>
                  ))}
                </Stack>
              </Stack>
            );
          })()}
        </SectionAccordion>
          </Stack>
        </Box>
      </Stack>
    </Box>
  );
}
