import ReportRoundedIcon from "@mui/icons-material/ReportRounded";
import PrintOutlinedIcon from "@mui/icons-material/PrintOutlined";
import { Alert, Box, Button, Stack, Typography } from "@mui/material";
import { useNavigate } from "react-router-dom";
import FormRoutePage from "../components/page/RoutePage";
import ApplicantSection from "../components/fields/ApplicantSection";
import {
  isApplicantApplying,
  shouldShowApplicantLabel,
} from "../utils/applicantVisibility";
import { SECTION_SURFACE_BG } from "../app/theme";
import FieldRenderer from "../components/fields/FieldRenderer";
import type { PageId } from "../types";
import { getActiveClientCoverages } from "../config/client/getActiveClientCoverages";
import { fieldCatalog } from "../config/fields";
import ApplicationDocumentPreview from "../components/overlays/DocumentPreview";
import { getContent } from "../content";
import type { ApplicationFormValues } from "../app/ApplicationFormContext";

const reviewContent = getContent().review;

export default function Review() {
  const navigate = useNavigate();

  function printSection() {
    window.print();
  }

  return (
    <FormRoutePage
      pageId="review"
      devFillFields={(currentValues) => [
        fieldCatalog["review-self-consent"],
        ...(isApplicantApplying("spouse", currentValues)
          ? [fieldCatalog["review-spouse-consent"]]
          : []),
      ]}
    >
      {({ control, errors, watchedValues }) => {
        const values = watchedValues as ApplicationFormValues;
        const hasSpouse = isApplicantApplying("spouse", values);

        const selectedCoverageIds = Array.isArray(values.coverageSelections)
          ? values.coverageSelections
          : [];
        const selectedCoverageIdSet = new Set(
          selectedCoverageIds.map((id) => String(id)),
        );
        const selectedCoverages = getActiveClientCoverages().filter(
          (coverage) => selectedCoverageIdSet.has(coverage.id),
        );
        const showHealthQuestionsNote = selectedCoverages.some(
          (coverage) => coverage.underwritingType === "FUW",
        );

        function openEdit(pageId: PageId) {
          navigate(`/${pageId}`);
        }

        return (
          <Stack spacing={2.5}>
            <Alert
              severity="warning"
              icon={<ReportRoundedIcon fontSize="large" />}
            >
              <Stack spacing={1.5}>
                <Typography variant="body2" fontWeight={600}>
                  {reviewContent.alertTitle}
                </Typography>

                <Box
                  component="ul"
                  sx={{ m: 0, pl: 3, "& li + li": { mt: 1.5 } }}
                >
                  {reviewContent.alertItems.map((item) => (
                    <li key={item.title}>
                      <Box>
                        <Typography variant="body2" fontWeight={600}>
                          {item.title}
                        </Typography>
                        <Typography variant="body2">
                          {item.description}
                        </Typography>
                      </Box>
                    </li>
                  ))}

                  {showHealthQuestionsNote ? (
                    <li>
                      <Box>
                        <Typography variant="body2" fontWeight={600}>
                          {reviewContent.healthQuestionsNote.title}
                        </Typography>
                        <Typography variant="body2">
                          {reviewContent.healthQuestionsNote.description}
                        </Typography>
                      </Box>
                    </li>
                  ) : null}
                </Box>
              </Stack>
            </Alert>

            <ApplicationDocumentPreview
              values={values}
              signatureName=""
              signedDate=""
              currentDate={new Intl.DateTimeFormat("en-US", {
                month: "2-digit",
                day: "2-digit",
                year: "numeric",
              }).format(new Date())}
              onEditSection={openEdit}
              hideSignature
            />

            <Box>
              <Typography
                variant="subtitle1"
                sx={{ mb: 1, fontWeight: 700, textAlign: "center" }}
              >
                {reviewContent.readAndSignTitle}
              </Typography>
              <Box
                sx={{
                  overflowY: "auto",
                  border: "1px solid rgba(0, 0, 0, 0.12)",
                  borderRadius: 1,
                  p: 1.5,
                  backgroundColor: SECTION_SURFACE_BG,
                }}
              >
                <Typography
                  variant="body2"
                  sx={{
                    whiteSpace: "pre-wrap",
                    fontSize: "0.8125rem",
                    lineHeight: 1.5,
                  }}
                >
                  {reviewContent.readAndSignContent}
                </Typography>
              </Box>
              <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 1 }}>
                <Button
                  startIcon={<PrintOutlinedIcon />}
                  onClick={printSection}
                >
                  Print
                </Button>
              </Box>
            </Box>

            <Box>
              <Typography
                variant="subtitle1"
                sx={{ mb: 1, fontWeight: 700, textAlign: "center" }}
              >
                {reviewContent.electronicConsentTitle}
              </Typography>
              <Box
                sx={{
                  maxHeight: 200,
                  overflowY: "auto",
                  border: "1px solid rgba(0, 0, 0, 0.12)",
                  borderRadius: 1,
                  p: 1.5,
                  backgroundColor: SECTION_SURFACE_BG,
                }}
              >
                <Typography
                  variant="body2"
                  sx={{
                    whiteSpace: "pre-wrap",
                    fontSize: "0.8125rem",
                    lineHeight: 1.5,
                  }}
                >
                  {reviewContent.electronicConsentContent}
                </Typography>
              </Box>
              <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 1 }}>
                <Button
                  startIcon={<PrintOutlinedIcon />}
                  onClick={printSection}
                >
                  Print
                </Button>
              </Box>
            </Box>

            <Stack spacing={1.5}>
              <ApplicantSection
                applicant="self"
                showLabel={shouldShowApplicantLabel("self", values)}
              >
                <FieldRenderer
                  field={fieldCatalog["review-self-consent"]}
                  control={control}
                  errors={errors}
                />
              </ApplicantSection>

              {hasSpouse ? (
                <ApplicantSection applicant="spouse" showLabel>
                  <FieldRenderer
                    field={fieldCatalog["review-spouse-consent"]}
                    control={control}
                    errors={errors}
                  />
                </ApplicantSection>
              ) : null}
            </Stack>
          </Stack>
        );
      }}
    </FormRoutePage>
  );
}
