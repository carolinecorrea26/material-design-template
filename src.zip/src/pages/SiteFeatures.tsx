import type { ComponentType } from "react";
import {
  Box,
  Card,
  CardContent,
  Link,
  Stack,
  Typography,
} from "@mui/material";
import { Link as RouterLink } from "react-router-dom";
import CalculateRoundedIcon from "@mui/icons-material/CalculateRounded";
import SupportAgentRoundedIcon from "@mui/icons-material/SupportAgentRounded";
import RestoreRoundedIcon from "@mui/icons-material/RestoreRounded";
import SaveRoundedIcon from "@mui/icons-material/SaveRounded";
import MarkEmailUnreadRoundedIcon from "@mui/icons-material/MarkEmailUnreadRounded";
import VerifiedUserRoundedIcon from "@mui/icons-material/VerifiedUserRounded";
import MonitorHeartRoundedIcon from "@mui/icons-material/MonitorHeartRounded";
import DrawRoundedIcon from "@mui/icons-material/DrawRounded";
import LinkRoundedIcon from "@mui/icons-material/LinkRounded";
import HelpOutlineRoundedIcon from "@mui/icons-material/HelpOutlineRounded";
import PaymentsRoundedIcon from "@mui/icons-material/PaymentsRounded";
import Diversity1RoundedIcon from "@mui/icons-material/Diversity1Rounded";
import LightbulbRoundedIcon from "@mui/icons-material/LightbulbRounded";
import { capabilitiesData } from "../content/docs/capabilities";
import { parkedIdeas } from "../content/docs/parkedIdeas";
import { getConfigurationGroupAnchor } from "../content/docs/configurations";
import { getPagePath } from "../config/pages";

type FeatureGroupId = "application-experience" | "workflow-persistence" | "verification-routing";

type ConfigurationLink = {
  label: string;
  group?: string;
  href?: string;
};

type FeaturePresentation = {
  Icon: ComponentType<{ color?: "primary"; fontSize?: "small" | "medium" }>;
  group: FeatureGroupId;
  configurationOptions: ConfigurationLink[];
};

const featureGroups: { id: FeatureGroupId; title: string; description: string }[] = [
  {
    id: "application-experience",
    title: "Application Experience",
    description: "Applicant-facing shopping, assistance, completion, and support capabilities.",
  },
  {
    id: "workflow-persistence",
    title: "Workflow & Persistence",
    description: "Alternate application journeys and capabilities that preserve or recover progress.",
  },
  {
    id: "verification-routing",
    title: "Verification & Routing",
    description: "Capabilities that verify applicants or alter routing based on client, coverage, or entry context.",
  },
];

const featurePresentation: Record<string, FeaturePresentation> = {
  "capability-quote": {
    Icon: CalculateRoundedIcon,
    group: "application-experience",
    configurationOptions: [
      { label: "Coverage/product availability", group: "Products & coverage options" },
      { label: "Coverage amount ranges", group: "Products & coverage options" },
      { label: "Estimated rate display", group: "Premium & estimated cost" },
    ],
  },
  "capability-page-helpers": {
    Icon: HelpOutlineRoundedIcon,
    group: "application-experience",
    configurationOptions: [
      { label: "Help panel content", group: "Page & help content" },
      { label: "Page/section helper content", group: "Page & help content" },
    ],
  },
  "capability-online-payment": {
    Icon: PaymentsRoundedIcon,
    group: "application-experience",
    configurationOptions: [
      { label: "Payment page mode", group: "Page inclusion & workflow" },
    ],
  },
  "capability-online-beneficiary": {
    Icon: Diversity1RoundedIcon,
    group: "application-experience",
    configurationOptions: [
      { label: "Beneficiary page mode", group: "Page inclusion & workflow" },
      { label: "Applicable coverage products", group: "Products & coverage options" },
    ],
  },
  "capability-esign": {
    Icon: DrawRoundedIcon,
    group: "application-experience",
    configurationOptions: [
      { label: "Signing page/workflow inclusion", group: "Page inclusion & workflow" },
    ],
  },
  "capability-advisor": {
    Icon: SupportAgentRoundedIcon,
    group: "workflow-persistence",
    configurationOptions: [
      { label: "Advisor flow/page inclusion", group: "Page inclusion & workflow" },
    ],
  },
  "capability-resume": {
    Icon: RestoreRoundedIcon,
    group: "workflow-persistence",
    configurationOptions: [
      { label: "Resume flow/page inclusion", group: "Page inclusion & workflow" },
      { label: "Resume contact/content", group: "Page & help content" },
    ],
  },
  "capability-autosave": {
    Icon: SaveRoundedIcon,
    group: "workflow-persistence",
    configurationOptions: [
      { label: "Persistence infrastructure", group: "Shared infrastructure" },
    ],
  },
  "capability-abandoned-leads": {
    Icon: MarkEmailUnreadRoundedIcon,
    group: "workflow-persistence",
    configurationOptions: [
      { label: "Support/contact configuration", group: "Support & contact" },
      { label: "Reminder/support content", group: "Page & help content" },
    ],
  },
  "capability-tpa": {
    Icon: VerifiedUserRoundedIcon,
    group: "verification-routing",
    configurationOptions: [
      { label: "Verification fields", group: "Field configuration" },
      { label: "Verification routing", group: "Page inclusion & workflow" },
    ],
  },
  "capability-health-underwriting": {
    Icon: MonitorHeartRoundedIcon,
    group: "verification-routing",
    configurationOptions: [
      { label: "Product underwriting type", group: "Products & coverage options" },
      { label: "Health-page routing", group: "Page inclusion & workflow" },
    ],
  },
  "capability-url-entry": {
    Icon: LinkRoundedIcon,
    group: "verification-routing",
    configurationOptions: [
      { label: "Supported URL parameters", href: "#url-parameters-subsection" },
    ],
  },
};

const futureFeatures = [
  {
    title: "InstantID",
    description:
      "Planned identity-verification capability expected to streamline or replace parts of eligibility and member verification once scoped.",
  },
  ...parkedIdeas.map((idea) => ({ title: idea.title, description: idea.notes.join(" ") })),
];

export default function SiteFeatures() {
  const siteDetailsPath = getPagePath("site-details");

  const configurationHref = (option: ConfigurationLink) => {
    if (option.href) return `${siteDetailsPath}${option.href}`;
    if (option.group) return `${siteDetailsPath}#${getConfigurationGroupAnchor(option.group)}`;
    return `${siteDetailsPath}#configuration-options-subsection`;
  };

  return (
    <Box
      sx={{
        py: { xs: 3, md: 4 },
        px: { xs: 2, md: 4 },
        width: "100vw",
        maxWidth: "100vw",
        ml: "calc(-50vw + 50%)",
        boxSizing: "border-box",
      }}
    >
      <Stack spacing={3}>
        <Box>
          <Typography variant="h4" component="h1" sx={{ fontWeight: 800, mb: 1 }}>
            Site Features
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ maxWidth: 900 }}>
            High-level capabilities supported by the Portal template, organized by how they affect the applicant journey. Configuration links open the relevant Site Details configuration area; related links open the supporting flow or behavior documentation.
          </Typography>
        </Box>

        {featureGroups.map((group) => {
          const features = capabilitiesData.filter(
            (feature) => featurePresentation[feature.id]?.group === group.id,
          );

          return (
            <Box key={group.id} component="section">
              <Typography variant="h6" sx={{ fontWeight: 800 }}>
                {group.title}
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
                {group.description}
              </Typography>

              <Box
                sx={{
                  display: "grid",
                  gridTemplateColumns: {
                    xs: "1fr",
                    sm: "repeat(2, minmax(0, 1fr))",
                    lg: "repeat(3, minmax(0, 1fr))",
                    xl: "repeat(4, minmax(0, 1fr))",
                  },
                  gap: 1.5,
                }}
              >
                {features.map((feature) => {
                  const presentation = featurePresentation[feature.id] ?? {
                    Icon: LightbulbRoundedIcon,
                    group: group.id,
                    configurationOptions: [],
                  };
                  const Icon = presentation.Icon;

                  return (
                    <Card key={feature.id} variant="outlined" sx={{ borderRadius: 2.5, height: "100%" }}>
                      <CardContent sx={{ p: 2, "&:last-child": { pb: 2 } }}>
                        <Stack spacing={1.25}>
                          <Stack direction="row" spacing={1} alignItems="flex-start">
                            <Icon color="primary" fontSize="small" />
                            <Box sx={{ minWidth: 0 }}>
                              <Typography variant="subtitle2" sx={{ fontWeight: 700, lineHeight: 1.3 }}>
                                {feature.name}
                              </Typography>
                              <Typography
                                variant="caption"
                                color="text.secondary"
                                sx={{ display: "block", mt: 0.4, lineHeight: 1.45 }}
                              >
                                {feature.summary}
                              </Typography>
                            </Box>
                          </Stack>

                          {presentation.configurationOptions.length > 0 && (
                            <Box>
                              <Typography variant="caption" sx={{ fontWeight: 700, display: "block", mb: 0.35 }}>
                                Configuration options
                              </Typography>
                              <Stack spacing={0.15}>
                                {presentation.configurationOptions.map((option) => (
                                  <Link
                                    key={`${feature.id}-${option.label}`}
                                    component={RouterLink}
                                    to={configurationHref(option)}
                                    variant="caption"
                                    sx={{ fontWeight: 600, lineHeight: 1.4 }}
                                  >
                                    {option.label}
                                  </Link>
                                ))}
                              </Stack>
                            </Box>
                          )}

                          {feature.seeAlso.length > 0 && (
                            <Box>
                              <Typography variant="caption" sx={{ fontWeight: 700, display: "block", mb: 0.35 }}>
                                Related links
                              </Typography>
                              <Stack spacing={0.15}>
                                {feature.seeAlso.map((link) => (
                                  <Link
                                    key={link.href + link.label}
                                    component={RouterLink}
                                    to={`${siteDetailsPath}${link.href}`}
                                    variant="caption"
                                    sx={{ fontWeight: 600, lineHeight: 1.4 }}
                                  >
                                    {link.label}
                                  </Link>
                                ))}
                              </Stack>
                            </Box>
                          )}
                        </Stack>
                      </CardContent>
                    </Card>
                  );
                })}
              </Box>
            </Box>
          );
        })}

        <Box component="section">
          <Typography variant="h6" sx={{ fontWeight: 800 }}>
            Future / Planned Features
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
            Ideas and planned capabilities not yet scoped as currently supported site features.
          </Typography>
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: {
                xs: "1fr",
                sm: "repeat(2, minmax(0, 1fr))",
                lg: "repeat(3, minmax(0, 1fr))",
                xl: "repeat(4, minmax(0, 1fr))",
              },
              gap: 1.5,
            }}
          >
            {futureFeatures.map((feature) => (
              <Card key={feature.title} variant="outlined" sx={{ borderRadius: 2.5 }}>
                <CardContent sx={{ p: 2, "&:last-child": { pb: 2 } }}>
                  <Stack direction="row" spacing={1} alignItems="flex-start">
                    <LightbulbRoundedIcon color="primary" fontSize="small" />
                    <Box>
                      <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
                        {feature.title}
                      </Typography>
                      <Typography variant="caption" color="text.secondary" sx={{ lineHeight: 1.45 }}>
                        {feature.description}
                      </Typography>
                    </Box>
                  </Stack>
                </CardContent>
              </Card>
            ))}
          </Box>
        </Box>
      </Stack>
    </Box>
  );
}
