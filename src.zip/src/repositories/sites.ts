import { getPrototypeLibrary } from '../domain/prototypeLibrary';
import { createSiteRepository } from "./siteRepository";
import { staticSiteAdapter } from "./staticSiteAdapter";
export const siteRepository = createSiteRepository(staticSiteAdapter);
export const { clientEntities, tpaEntities, siteEntities, associationEntities, siteAssociationEntities, siteCoverageEntities, getClient, getTpa, getTpaForClient, getClientsForTpa, getSitesForTpa, validateTpaIntegrity, getAssociation, getAssociationsForClient, getSiteAssociations, getSitesForAssociation, validateAssociationIntegrity, getSitesForClient, getSiteCoverages, getSiteIdForClientAlias, getClientAliasForSite, } = siteRepository;

export function getSite(id: string) {
  const active = getPrototypeLibrary(id);
  if (!active) return siteRepository.getSite(id);
  const row = active.site;
  return { id, clientId: row.clientKey, name: row.name.value, templateType: active.client.features?.defaultTemplate ?? 'multi', status: 'active' as const };
}
export function getClientForSite(id: string) {
  const active = getPrototypeLibrary(id);
  if (!active) return siteRepository.getClientForSite(id);
  return { id: active.clientIdentity.id, tpaId: active.clientIdentity.organizationId, name: active.clientIdentity.name, acronym: active.clientIdentity.acronym, branding: active.client.branding, support: active.client.support, configurationDefaults: active.client };
}

export function getEffectiveSiteConfig(id: string) { return getPrototypeLibrary(id)?.client ?? siteRepository.getEffectiveSiteConfig(id); }
export function getAssociationsForSite(id: string) { return siteRepository.getAssociationsForSite(getPrototypeLibrary(id)?.sourceSiteKey ?? id); }
