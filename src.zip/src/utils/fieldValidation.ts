import type { FieldDefinition } from "../domain/fields";

export type FieldValidationCheck = { rule: string; message: string; kind: "required" | "value"; validate: (value: unknown) => boolean };

/** Shared by the form renderer and Library: descriptions follow executable checks. */
export function fieldValidationChecks(field: FieldDefinition): FieldValidationCheck[] {
  const checks: FieldValidationCheck[] = [];
  const add = (rule: string, message: string, validate: FieldValidationCheck["validate"], kind: FieldValidationCheck["kind"] = "value") => checks.push({ rule, message, validate, kind });
  if (field.inputType === "checkbox") {
    if (field.required) add("Must be checked", `${field.label} is required.`, value => value === true);
    return checks;
  }
  if (field.inputType === "checkbox-group" || field.inputType === "multi-select") {
    if (field.required) add("Select at least one option", "Select at least one option.", value => Array.isArray(value) && value.length > 0);
    return checks;
  }
  if (field.required) add("Required", `${field.label} is required.`, value => !!value, "required");
  let valueCheck: FieldValidationCheck | undefined;
  const format = (rule: string, message: string, validate: FieldValidationCheck["validate"]) => { valueCheck = { kind: "value", rule, message, validate: value => !value || validate(value) }; };
  const digits = (value: unknown) => String(value).replace(/\D/g, "");
  if (field.autoComplete === "postal-code") format("ZIP / postal code: at least 5 characters", "Enter a valid ZIP / Postal Code.", value => String(value).trim().length >= 5);
  if (field.format === "email") format("Valid email address", "Enter a valid email address.", value => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value)));
  if (field.format === "phone") format("Phone number: exactly 10 digits", "Enter a valid 10-digit phone number.", value => digits(value).length === 10);
  if (field.format === "ssn") format("SSN: exactly 9 digits", "Enter a valid 9-digit SSN.", value => digits(value).length === 9);
  if (field.format === "percent") format("Percentage: up to 3 digits", "Enter a percent value with up to 3 digits.", value => digits(value).length <= 3);
  if (field.format === "month-year") format("Month / year: 6 digits (MM/YYYY)", "Enter a valid month and year (MM/YYYY).", value => digits(value).length === 6);
  if (field.inputType === "number") format(field.allowDecimal ? "Nonnegative number; decimals allowed" : "Nonnegative whole number", "Enter a valid nonnegative number.", value => (field.allowDecimal ? /^\d+(\.\d+)?$/ : /^\d+$/).test(String(value)));
  if (valueCheck) checks.push(valueCheck);
  return checks;
}

export function getFieldValidationRules(field: FieldDefinition) {
  const rules: { required?: string; validate?: (value: unknown) => true | string } = {};
  for (const check of fieldValidationChecks(field)) {
    if (check.kind === "required") rules.required = check.message;
    else rules.validate = value => check.validate(value) || check.message;
  }
  return rules;
}
