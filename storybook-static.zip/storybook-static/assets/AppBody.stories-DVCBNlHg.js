import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,dt as n,t as r}from"./esm-AWQ-KJXU.js";import{n as i,t as a}from"./AppBody-CEpR1-1X.js";var o,s,c,l;e((()=>{r(),i(),o=t(),s={title:`Layout/AppBody`,component:a,parameters:{layout:`fullscreen`,docs:{description:{component:`AppBody is the main content wrapper AppShell places between AppHeader
and AppFooter: a \`<main id="main-content" tabIndex={-1}>\` landmark (the
skip-link target), responsive max-width/padding, and a scroll-to-top
effect keyed off pathname changes (via a patched history + a
useSyncExternalStore subscription, not react-router's own location).`}}}},c={render:()=>(0,o.jsx)(a,{children:(0,o.jsx)(n,{variant:`body2`,color:`text.secondary`,children:`Page content goes here. In the real app, AppShell renders AppHeader above this and AppFooter below it.`})})},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  render: () => <AppBody>
      <Typography variant="body2" color="text.secondary">
        Page content goes here. In the real app, AppShell renders
        AppHeader above this and AppFooter below it.
      </Typography>
    </AppBody>
}`,...c.parameters?.docs?.source}}},l=[`Default`]}))();export{c as Default,l as __namedExportsOrder,s as default};