import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ct as r,Ot as i,dt as a,rt as o,t as s}from"./esm-AWQ-KJXU.js";import{a as c,i as l}from"./theme-B3ct2zHf.js";import{n as u,t as d}from"./AppDrawer-BZqEFTP6.js";function f(e){let[t,n]=(0,p.useState)(!1);return(0,m.jsxs)(m.Fragment,{children:[(0,m.jsx)(o,{variant:`outlined`,onClick:()=>n(!0),children:`Open drawer`}),(0,m.jsx)(d,{...e,open:t,onClose:()=>n(!1),children:(0,m.jsx)(a,{variant:`body2`,color:`text.secondary`,children:`Drawer content goes here.`})})]})}var p,m,h,g,_,v,y,b;t((()=>{p=e(n(),1),s(),u(),c(),m=i(),h={title:`Overlays/AppDrawer`,component:d,parameters:{layout:`centered`,docs:{description:{component:"AppDrawer is the shared adaptive drawer shell: a right-side panel on\ndesktop, a bottom sheet on mobile. `swipeable` opts into `SwipeableDrawer`\non mobile instead of plain `Drawer` — but the cart (AppHeader) is the only\nreal consumer that passes it. AppMenu's 4 sub-drawers and every page-level\ndrawer (Beneficiary, Home, HealthDi, Payment, Membership, HealthSi,\nCoverage) render as a plain, non-swipeable `Drawer` even on mobile, which\nis an inconsistent mobile interaction pattern worth knowing about before\nadding a new drawer, not a bug in this component itself."}}}},g={name:`Desktop — right panel`,render:()=>(0,m.jsx)(f,{title:`Drawer title`})},_={name:`Mobile — bottom sheet (forceMobileLayout)`,render:()=>(0,m.jsx)(r,{theme:l(`default`,{forceMobileLayout:!0}),children:(0,m.jsx)(f,{title:`Drawer title`})}),parameters:{docs:{description:{story:`Uses the same forceMobileLayout theme technique as Foundations/Breakpoints to reliably force the mobile branch. Below md, the drawer anchors to the bottom instead of the right and this story renders a plain Drawer, not a SwipeableDrawer — see Swipeable below for the opt-in variant.`}}}},v={name:`Mobile — swipeable (cart's opt-in)`,render:()=>(0,m.jsx)(r,{theme:l(`default`,{forceMobileLayout:!0}),children:(0,m.jsx)(f,{title:`Cart`,swipeable:!0})}),parameters:{docs:{description:{story:`swipeable={true} switches to MUI's SwipeableDrawer with disableSwipeToOpen — swipe-to-dismiss, but not swipe-from-edge-to-open. AppHeader's cart drawer is the only real call site that passes this prop today.`}}}},y={name:`No title (ariaLabel only)`,render:()=>(0,m.jsx)(f,{ariaLabel:`Untitled drawer example`}),parameters:{docs:{description:{story:`When content manages its own header (e.g. a sub-drawer with its own back button), omit title and pass ariaLabel instead so the drawer still has an accessible name.`}}}},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  name: "Desktop — right panel",
  render: () => <DrawerDemo title="Drawer title" />
}`,...g.parameters?.docs?.source}}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  name: "Mobile — bottom sheet (forceMobileLayout)",
  render: () => <ThemeProvider theme={createAppTheme("default", {
    forceMobileLayout: true
  })}>
      <DrawerDemo title="Drawer title" />
    </ThemeProvider>,
  parameters: {
    docs: {
      description: {
        story: "Uses the same forceMobileLayout theme technique as Foundations/Breakpoints to reliably force the mobile branch. Below md, the drawer anchors to the bottom instead of the right and this story renders a plain Drawer, not a SwipeableDrawer — see Swipeable below for the opt-in variant."
      }
    }
  }
}`,..._.parameters?.docs?.source}}},v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{
  name: "Mobile — swipeable (cart's opt-in)",
  render: () => <ThemeProvider theme={createAppTheme("default", {
    forceMobileLayout: true
  })}>
      <DrawerDemo title="Cart" swipeable />
    </ThemeProvider>,
  parameters: {
    docs: {
      description: {
        story: "swipeable={true} switches to MUI's SwipeableDrawer with disableSwipeToOpen — swipe-to-dismiss, but not swipe-from-edge-to-open. AppHeader's cart drawer is the only real call site that passes this prop today."
      }
    }
  }
}`,...v.parameters?.docs?.source}}},y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  name: "No title (ariaLabel only)",
  render: () => <DrawerDemo ariaLabel="Untitled drawer example" />,
  parameters: {
    docs: {
      description: {
        story: "When content manages its own header (e.g. a sub-drawer with its own back button), omit title and pass ariaLabel instead so the drawer still has an accessible name."
      }
    }
  }
}`,...y.parameters?.docs?.source}}},b=[`Default`,`MobileBottomSheet`,`Swipeable`,`NoTitleAriaLabelOnly`]}))();export{g as Default,_ as MobileBottomSheet,y as NoTitleAriaLabelOnly,v as Swipeable,b as __namedExportsOrder,h as default};