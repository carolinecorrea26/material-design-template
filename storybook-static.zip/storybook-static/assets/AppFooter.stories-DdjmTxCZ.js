import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t}from"./esm-AWQ-KJXU.js";import{n,t as r}from"./getActiveClient-DQgJg1Xd.js";import{n as i,t as a}from"./AppFooter-CiiatZDh.js";var o,s,c,l;e((()=>{i(),n(),o=t(),s={title:`Layout/AppFooter`,component:a,parameters:{layout:`fullscreen`,docs:{description:{component:`AppFooter renders support info and opens the Terms of Use / Privacy
Notice modals (via LegalDocList — see Content/LegalDocList for that
content in isolation). 3-column grid on desktop collapsing to 1 column
on mobile. Also listens for a global \`app:open-privacy-notice\` custom
event (dispatched elsewhere in the app, e.g. from a field's helper
text) to open the Privacy Notice modal on demand.`}}}},c={render:()=>(0,o.jsx)(a,{client:r()}),parameters:{docs:{description:{story:`Click "Terms of Use" or "Privacy Notice" to open the real legal-content modals.`}}}},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  render: () => <AppFooter client={getActiveClient()} />,
  parameters: {
    docs: {
      description: {
        story: 'Click "Terms of Use" or "Privacy Notice" to open the real legal-content modals.'
      }
    }
  }
}`,...c.parameters?.docs?.source}}},l=[`Default`]}))();export{c as Default,l as __namedExportsOrder,s as default};