import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r}from"./esm-AWQ-KJXU.js";import{n as i,t as a}from"./getActiveClient-DQgJg1Xd.js";import{r as o,t as s}from"./ApplicationFormContext-BU7mcIce.js";import{n as c,t as l}from"./AppHeader-Bjwidd0h.js";function u({initialValues:e={},children:t}){let[n,r]=(0,f.useState)(e);return(0,p.jsx)(s.Provider,{value:{values:n,setPageValues:e=>r(t=>({...t,...e})),resetValues:()=>r({})},children:t})}function d(e){(0,f.useEffect)(()=>{window.history.pushState({},``,e)},[e])}var f,p,m,h,g,_,v;t((()=>{f=e(n(),1),c(),i(),o(),p=r(),m={title:`Layout/AppHeader`,component:l,parameters:{layout:`fullscreen`,docs:{description:{component:`AppHeader determines which page it's on via \`window.location.pathname\`
through its own history-patched subscription — not react-router's
\`useLocation()\` — so Storybook's MemoryRouter decorator alone can't drive
its progress-bar/cart-icon visibility. Every story below sets the real
browser URL via \`window.history.pushState()\` before rendering, which is
exactly the API AppHeader's own patch listens to, rather than faking the
behavior some other way.`}}}},h={render:()=>{function e(){return d(`/`),(0,p.jsx)(l,{client:a(),variant:`homepage`})}return(0,p.jsx)(u,{children:(0,p.jsx)(e,{})})}},g={name:`applicationForm variant, mid-flow with coverage in cart`,render:()=>{function e(){return d(`/coverage`),(0,p.jsx)(l,{client:a(),variant:`applicationForm`})}return(0,p.jsx)(u,{initialValues:{coverageSelections:[`li-term`],productApplicants:{"li-term":[`member`]},coverageAmounts:{"li-term:member":1e5}},children:(0,p.jsx)(e,{})})},parameters:{docs:{description:{story:`On the coverage page with one product already added: the progress bar reflects real getFormProgressPercent() output for this page, and the cart icon shows a real badge count from the seeded coverageSelections.`}}}},_={name:`variant="advisorLogin" (logo only, no menu/progress/cart)`,render:()=>{function e(){return d(`/advisor-login`),(0,p.jsx)(l,{client:a(),variant:`advisorLogin`})}return(0,p.jsx)(u,{children:(0,p.jsx)(e,{})})}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  render: () => {
    function Demo() {
      useSetPathname("/");
      return <AppHeader client={getActiveClient()} variant="homepage" />;
    }
    return <LocalFormProvider>
        <Demo />
      </LocalFormProvider>;
  }
}`,...h.parameters?.docs?.source}}},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  name: "applicationForm variant, mid-flow with coverage in cart",
  render: () => {
    function Demo() {
      useSetPathname("/coverage");
      return <AppHeader client={getActiveClient()} variant="applicationForm" />;
    }
    return <LocalFormProvider initialValues={{
      coverageSelections: ["li-term"],
      productApplicants: {
        "li-term": ["member"]
      },
      coverageAmounts: {
        "li-term:member": 100000
      }
    }}>
        <Demo />
      </LocalFormProvider>;
  },
  parameters: {
    docs: {
      description: {
        story: "On the coverage page with one product already added: the progress bar reflects real getFormProgressPercent() output for this page, and the cart icon shows a real badge count from the seeded coverageSelections."
      }
    }
  }
}`,...g.parameters?.docs?.source}}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  name: 'variant="advisorLogin" (logo only, no menu/progress/cart)',
  render: () => {
    function Demo() {
      useSetPathname("/advisor-login");
      return <AppHeader client={getActiveClient()} variant="advisorLogin" />;
    }
    return <LocalFormProvider>
        <Demo />
      </LocalFormProvider>;
  }
}`,..._.parameters?.docs?.source}}},v=[`HomepageVariant`,`ApplicationFormVariant`,`UtilityVariant`]}))();export{g as ApplicationFormVariant,h as HomepageVariant,_ as UtilityVariant,v as __namedExportsOrder,m as default};