import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r,at as i,rt as a,t as o}from"./esm-AWQ-KJXU.js";import{n as s,t as c}from"./getActiveClient-DQgJg1Xd.js";import{i as l,r as u}from"./AppHeader-Bjwidd0h.js";function d(){let[e,t]=(0,f.useState)(!0);return(0,p.jsxs)(i,{sx:{p:2},children:[(0,p.jsx)(a,{variant:`outlined`,onClick:()=>t(!0),children:`Reopen menu`}),(0,p.jsx)(u,{open:e,onClose:()=>t(!1),client:c()})]})}var f,p,m,h,g;t((()=>{f=e(n(),1),o(),l(),s(),p=r(),m={title:`Layout/AppMenu`,component:u,parameters:{layout:`fullscreen`,docs:{description:{component:`AppMenu is the full-screen hamburger nav drawer (opened from AppHeader),
with 4 nested sub-drawers: How Applying Works (see
Coverage & Commerce/HowApplyingWorksPanel), About Coverage (see
Coverage & Commerce/CoverageOptionsPanel), Coverage Needs Calculator
(see Coverage & Commerce/CoverageNeedsCalculator), and QuickDecision℠
(see Content/QuickDecision). Renders as a plain right-side \`Drawer\`
(not \`AppDrawer\`), unlike its own nested sub-drawers which do use
AppDrawer.`}}}},h={render:()=>(0,p.jsx)(d,{}),parameters:{docs:{description:{story:`Try opening each of the 4 sub-drawer links — How Applying Works, About Coverage, Coverage Needs Calculator, and the QuickDecision℠ link inside How Applying Works' step text.`}}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  render: () => <AppMenuDemo />,
  parameters: {
    docs: {
      description: {
        story: "Try opening each of the 4 sub-drawer links — How Applying Works, About Coverage, Coverage Needs Calculator, and the QuickDecision℠ link inside How Applying Works' step text."
      }
    }
  }
}`,...h.parameters?.docs?.source}}},g=[`Default`]}))();export{h as Default,g as __namedExportsOrder,m as default};