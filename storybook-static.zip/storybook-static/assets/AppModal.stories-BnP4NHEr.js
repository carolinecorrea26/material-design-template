import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r,dt as i,rt as a,t as o}from"./esm-AWQ-KJXU.js";import{n as s,t as c}from"./AppModal-Cd4VrM3d.js";function l({children:e,...t}){let[n,r]=(0,u.useState)(!1);return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(a,{variant:`outlined`,onClick:()=>r(!0),children:`Open modal`}),(0,d.jsx)(c,{...t,open:n,onClose:()=>r(!1),children:e??(0,d.jsx)(i,{variant:`body2`,color:`text.secondary`,children:`Modal content goes here.`})})]})}var u,d,f,p,m,h,g,_,v;t((()=>{u=e(n(),1),o(),s(),d=r(),f={title:`Overlays/AppModal`,component:c,parameters:{layout:`centered`,docs:{description:{component:`AppModal is the base dialog primitive underneath ConfirmationDialog and
SendApplicationDialog (see Overlays/ConfirmationDialog,
Overlays/SendApplicationDialog) — fullScreen below md, a configurable
maxWidth on desktop, and a role prop for switching between "dialog" and
"alertdialog" semantics.`}}}},p={render:()=>(0,d.jsx)(l,{title:`Modal title`})},m={name:`Single action (Dismiss)`,render:()=>(0,d.jsx)(l,{title:`Terms of use`,actions:[{label:`Dismiss`,onClick:()=>{}}]})},h={name:`Two actions (confirm + cancel)`,render:()=>(0,d.jsx)(l,{title:`Discard changes?`,role:`alertdialog`,minHeight:`auto`,maxWidth:480,actions:[{label:`Discard`,onClick:()=>{},color:`error`},{label:`Keep editing`,onClick:()=>{},variant:`text`}]})},g={name:`showCloseIcon={false}`,render:()=>(0,d.jsx)(l,{title:`No close icon`,showCloseIcon:!1,minHeight:`auto`,maxWidth:480,actions:[{label:`OK`,onClick:()=>{}}]}),parameters:{docs:{description:{story:`When the × icon is hidden, an action button becomes the only way to close the dialog via the mouse — always pair this with at least one action.`}}}},_={name:`forceFullScreen (desktop)`,render:()=>(0,d.jsx)(l,{title:`Always full screen`,forceFullScreen:!0,children:(0,d.jsx)(i,{variant:`body2`,color:`text.secondary`,children:`Used for content meant to fill the entire viewport regardless of screen size, e.g. documentation section browsers.`})})},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: () => <ModalDemo title="Modal title" />
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  name: "Single action (Dismiss)",
  render: () => <ModalDemo title="Terms of use" actions={[{
    label: "Dismiss",
    onClick: () => {}
  }]} />
}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  name: "Two actions (confirm + cancel)",
  render: () => <ModalDemo title="Discard changes?" role="alertdialog" minHeight="auto" maxWidth={480} actions={[{
    label: "Discard",
    onClick: () => {},
    color: "error"
  }, {
    label: "Keep editing",
    onClick: () => {},
    variant: "text"
  }]} />
}`,...h.parameters?.docs?.source}}},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  name: "showCloseIcon={false}",
  render: () => <ModalDemo title="No close icon" showCloseIcon={false} minHeight="auto" maxWidth={480} actions={[{
    label: "OK",
    onClick: () => {}
  }]} />,
  parameters: {
    docs: {
      description: {
        story: "When the × icon is hidden, an action button becomes the only way to close the dialog via the mouse — always pair this with at least one action."
      }
    }
  }
}`,...g.parameters?.docs?.source}}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  name: "forceFullScreen (desktop)",
  render: () => <ModalDemo title="Always full screen" forceFullScreen>
      <Typography variant="body2" color="text.secondary">
        Used for content meant to fill the entire viewport regardless of
        screen size, e.g. documentation section browsers.
      </Typography>
    </ModalDemo>
}`,..._.parameters?.docs?.source}}},v=[`Default`,`SingleAction`,`TwoActions`,`NoCloseIcon`,`ForceFullScreen`]}))();export{p as Default,_ as ForceFullScreen,g as NoCloseIcon,m as SingleAction,h as TwoActions,v as __namedExportsOrder,f as default};