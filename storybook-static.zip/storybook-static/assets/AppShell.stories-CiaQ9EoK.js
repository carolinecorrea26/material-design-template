import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r,dt as i,t as a}from"./esm-AWQ-KJXU.js";import{r as o,t as s}from"./ApplicationFormContext-BU7mcIce.js";import{a as c,o as l}from"./AppHeader-Bjwidd0h.js";function u({children:e}){let[t,n]=(0,f.useState)({});return(0,p.jsx)(s.Provider,{value:{values:t,setPageValues:e=>n(t=>({...t,...e})),resetValues:()=>n({})},children:e})}function d(e){(0,f.useEffect)(()=>{window.history.pushState({},``,e)},[e])}var f,p,m,h,g,_,v;t((()=>{f=e(n(),1),a(),l(),o(),p=r(),m={title:`Layout/AppShell`,component:c,parameters:{layout:`fullscreen`,docs:{description:{component:`AppShell is the top-level layout composing AppHeader + AppBody +
AppFooter + the skip-link + CookieDialog + DevTools, selecting header/
footer chrome via \`variant\` — see the 5 variants documented on
AppShellVariant. It calls getActiveClient() internally (no client prop),
so every story here uses the real active client, same as AppHeader's
own stories. The cookie banner shows on first render unless
localStorage.cookieConsent is already "accepted" in this browser.`}}}},h={render:()=>{function e(){return d(`/coverage`),(0,p.jsx)(c,{variant:`applicationForm`,children:(0,p.jsx)(i,{variant:`body2`,color:`text.secondary`,children:`Form page content goes here.`})})}return(0,p.jsx)(u,{children:(0,p.jsx)(e,{})})}},g={render:()=>{function e(){return d(`/`),(0,p.jsx)(c,{variant:`homepage`,children:(0,p.jsx)(i,{variant:`body2`,color:`text.secondary`,children:`Homepage content goes here.`})})}return(0,p.jsx)(u,{children:(0,p.jsx)(e,{})})}},_={name:`variant="advisorLogin" (utility chrome — logo only)`,render:()=>{function e(){return d(`/advisor-login`),(0,p.jsx)(c,{variant:`advisorLogin`,children:(0,p.jsx)(i,{variant:`body2`,color:`text.secondary`,children:`Advisor login page content goes here.`})})}return(0,p.jsx)(u,{children:(0,p.jsx)(e,{})})}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  render: () => {
    function Demo() {
      useSetPathname("/coverage");
      return <AppShell variant="applicationForm">
          <Typography variant="body2" color="text.secondary">
            Form page content goes here.
          </Typography>
        </AppShell>;
    }
    return <LocalFormProvider>
        <Demo />
      </LocalFormProvider>;
  }
}`,...h.parameters?.docs?.source}}},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  render: () => {
    function Demo() {
      useSetPathname("/");
      return <AppShell variant="homepage">
          <Typography variant="body2" color="text.secondary">
            Homepage content goes here.
          </Typography>
        </AppShell>;
    }
    return <LocalFormProvider>
        <Demo />
      </LocalFormProvider>;
  }
}`,...g.parameters?.docs?.source}}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  name: 'variant="advisorLogin" (utility chrome — logo only)',
  render: () => {
    function Demo() {
      useSetPathname("/advisor-login");
      return <AppShell variant="advisorLogin">
          <Typography variant="body2" color="text.secondary">
            Advisor login page content goes here.
          </Typography>
        </AppShell>;
    }
    return <LocalFormProvider>
        <Demo />
      </LocalFormProvider>;
  }
}`,..._.parameters?.docs?.source}}},v=[`ApplicationFormVariant`,`HomepageVariant`,`AdvisorLoginVariant`]}))();export{_ as AdvisorLoginVariant,h as ApplicationFormVariant,g as HomepageVariant,v as __namedExportsOrder,m as default};