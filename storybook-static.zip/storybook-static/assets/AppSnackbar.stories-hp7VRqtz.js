import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r,rt as i,t as a}from"./esm-AWQ-KJXU.js";import{i as o,n as s,r as c,t as l}from"./ProgressSavedSnackbar-C_J7NJZl.js";function u({severity:e,message:t}){let[n,r]=(0,d.useState)(!1);return(0,f.jsxs)(f.Fragment,{children:[(0,f.jsxs)(i,{variant:`outlined`,onClick:()=>r(!0),children:[`Show `,e,` snackbar`]}),(0,f.jsx)(c,{open:n,onClose:()=>r(!1),message:t,severity:e})]})}var d,f,p,m,h,g,_,v,y;t((()=>{d=e(n(),1),a(),o(),s(),f=r(),p={title:`Feedback/AppSnackbar`,component:c,parameters:{layout:`centered`,docs:{description:{component:`AppSnackbar is the base transient-feedback snackbar: bottom-center on
small screens, top-center on large screens, with severity mapped to the
correct ARIA live-region role (alert for error/warning, status for
info/success — matching PageAlert's own mapping). ProgressSavedSnackbar
is a one-line preset built on top of it.`}}}},m={render:()=>(0,f.jsx)(u,{severity:`success`,message:`Saved successfully.`})},h={render:()=>(0,f.jsx)(u,{severity:`error`,message:`Something went wrong.`})},g={render:()=>(0,f.jsx)(u,{severity:`warning`,message:`This may take a moment.`})},_={render:()=>(0,f.jsx)(u,{severity:`info`,message:`Your session will expire soon.`})},v={name:`ProgressSavedSnackbar (preset)`,render:()=>{let[e,t]=(0,d.useState)(!1);return(0,f.jsxs)(f.Fragment,{children:[(0,f.jsx)(i,{variant:`outlined`,onClick:()=>t(!0),children:`Show "Progress saved"`}),(0,f.jsx)(l,{open:e,onClose:()=>t(!1)})]})}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  render: () => <SnackbarDemo severity="success" message="Saved successfully." />
}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  render: () => <SnackbarDemo severity="error" message="Something went wrong." />
}`,...h.parameters?.docs?.source}}},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  render: () => <SnackbarDemo severity="warning" message="This may take a moment." />
}`,...g.parameters?.docs?.source}}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  render: () => <SnackbarDemo severity="info" message="Your session will expire soon." />
}`,..._.parameters?.docs?.source}}},v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{
  name: "ProgressSavedSnackbar (preset)",
  render: () => {
    const [open, setOpen] = useState(false);
    return <>
        <Button variant="outlined" onClick={() => setOpen(true)}>
          Show "Progress saved"
        </Button>
        <ProgressSavedSnackbar open={open} onClose={() => setOpen(false)} />
      </>;
  }
}`,...v.parameters?.docs?.source}}},y=[`Success`,`Error`,`Warning`,`Info`,`ProgressSavedPreset`]}))();export{h as Error,_ as Info,v as ProgressSavedPreset,m as Success,g as Warning,y as __namedExportsOrder,p as default};