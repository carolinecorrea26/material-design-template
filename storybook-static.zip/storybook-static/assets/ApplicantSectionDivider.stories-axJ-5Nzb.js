import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,dt as n,t as r}from"./esm-AWQ-KJXU.js";import{i,r as a}from"./EscalatorWarningRounded-BSPrRzLn.js";import{n as o,r as s,t as c}from"./ApplicantSectionDivider-Sg0vRr8X.js";var l,u,d,f,p,m,h,g;e((()=>{r(),s(),i(),l=t(),u={title:`Layout/ApplicantSectionDivider`,component:c,parameters:{layout:`padded`,docs:{description:{component:`ApplicantSectionDivider marks a block of content as belonging to a
specific applicant (member/spouse/child), resolving the client-overridable
title/icon via getResolvedApplicantSectionTitles. Per the site's
applicant-display rule, the member/self label is hidden when only the
member is applying (\`showLabel={false}\`) and shown once another applicant
is also applying.`}}}},d={render:()=>(0,l.jsx)(c,{applicant:`self`,children:(0,l.jsx)(n,{variant:`body2`,children:`Member's fields go here.`})})},f={render:()=>(0,l.jsx)(c,{applicant:`spouse`,children:(0,l.jsx)(n,{variant:`body2`,children:`Spouse's fields go here.`})})},p={render:()=>(0,l.jsx)(c,{applicant:`spouse`,note:`Spouse coverage requires additional health questions.`,children:(0,l.jsx)(n,{variant:`body2`,children:`Spouse's fields go here.`})})},m={name:`showLabel=false (member-only flow)`,render:()=>(0,l.jsx)(c,{applicant:`self`,showLabel:!1,children:(0,l.jsx)(n,{variant:`body2`,children:`No header renders — used when the member is the only applicant, per the applicant-display rule ("member section title hidden for member-only flow").`})})},h={name:`ApplicantSectionLabel (named export, used standalone)`,render:()=>(0,l.jsx)(o,{label:`Spouse`,icon:a})},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: () => <ApplicantSectionDivider applicant="self">
      <Typography variant="body2">Member's fields go here.</Typography>
    </ApplicantSectionDivider>
}`,...d.parameters?.docs?.source}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  render: () => <ApplicantSectionDivider applicant="spouse">
      <Typography variant="body2">Spouse's fields go here.</Typography>
    </ApplicantSectionDivider>
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: () => <ApplicantSectionDivider applicant="spouse" note="Spouse coverage requires additional health questions.">
      <Typography variant="body2">Spouse's fields go here.</Typography>
    </ApplicantSectionDivider>
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  name: "showLabel=false (member-only flow)",
  render: () => <ApplicantSectionDivider applicant="self" showLabel={false}>
      <Typography variant="body2">
        No header renders — used when the member is the only applicant, per
        the applicant-display rule ("member section title hidden for
        member-only flow").
      </Typography>
    </ApplicantSectionDivider>
}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  name: "ApplicantSectionLabel (named export, used standalone)",
  render: () => <ApplicantSectionLabel label="Spouse" icon={SupervisorAccountRoundedIcon} />
}`,...h.parameters?.docs?.source}}},g=[`MemberSection`,`SpouseSection`,`WithNote`,`LabelHiddenMemberOnlyFlow`,`LabelStandalone`]}))();export{m as LabelHiddenMemberOnlyFlow,h as LabelStandalone,d as MemberSection,f as SpouseSection,p as WithNote,g as __namedExportsOrder,u as default};