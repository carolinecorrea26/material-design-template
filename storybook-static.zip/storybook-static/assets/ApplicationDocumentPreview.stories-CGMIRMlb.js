import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,at as n,t as r}from"./esm-AWQ-KJXU.js";import{a as i,o as a}from"./ApplicationFormContext-BU7mcIce.js";import{n as o,t as s}from"./ApplicationDocumentPreview-7RZtraSy.js";var c,l,u,d,f,p,m;e((()=>{r(),o(),a(),c=t(),l={title:`Content/ApplicationDocumentPreview`,component:s,parameters:{layout:`padded`,docs:{description:{component:`ApplicationDocumentPreview is the Review page's full paginated
print-style application readout — heavy formatting/section-building
logic (914 lines), tightly coupled to the application's real field/page
config, so it's documented as a page-specific pattern rather than a
general-purpose component per the Phase 1 audit. Real dummy data comes
from the app's own generateFormDataUpToPage() autofill helper (the same
one every other stateful story in this instance uses), not hand-typed
placeholder values.`}}}},u=i(`review`),d={render:()=>(0,c.jsx)(n,{sx:{maxWidth:800},children:(0,c.jsx)(s,{values:u,signatureName:`Jordan Rivera`,signedDate:`2026-09-14`,currentDate:`2026-09-14`})})},f={name:`hideSignature=true`,render:()=>(0,c.jsx)(n,{sx:{maxWidth:800},children:(0,c.jsx)(s,{values:u,signatureName:`Jordan Rivera`,signedDate:`2026-09-14`,currentDate:`2026-09-14`,hideSignature:!0})}),parameters:{docs:{description:{story:`Used for the advisor-facing edit-review flow, where the e-sign block hasn't happened yet and shouldn't be implied.`}}}},p={name:`onEditSection (per-section edit buttons)`,render:()=>(0,c.jsx)(n,{sx:{maxWidth:800},children:(0,c.jsx)(s,{values:u,signatureName:`Jordan Rivera`,signedDate:`2026-09-14`,currentDate:`2026-09-14`,onEditSection:e=>{console.log(`Edit section:`,e)}})})},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: () => <Box sx={{
    maxWidth: 800
  }}>
      <ApplicationDocumentPreview values={values} signatureName="Jordan Rivera" signedDate="2026-09-14" currentDate="2026-09-14" />
    </Box>
}`,...d.parameters?.docs?.source}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  name: "hideSignature=true",
  render: () => <Box sx={{
    maxWidth: 800
  }}>
      <ApplicationDocumentPreview values={values} signatureName="Jordan Rivera" signedDate="2026-09-14" currentDate="2026-09-14" hideSignature />
    </Box>,
  parameters: {
    docs: {
      description: {
        story: "Used for the advisor-facing edit-review flow, where the e-sign block hasn't happened yet and shouldn't be implied."
      }
    }
  }
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  name: "onEditSection (per-section edit buttons)",
  render: () => <Box sx={{
    maxWidth: 800
  }}>
      <ApplicationDocumentPreview values={values} signatureName="Jordan Rivera" signedDate="2026-09-14" currentDate="2026-09-14" onEditSection={pageId => {
      console.log("Edit section:", pageId);
    }} />
    </Box>
}`,...p.parameters?.docs?.source}}},m=[`Default`,`HiddenSignature`,`WithEditButtons`]}))();export{d as Default,f as HiddenSignature,p as WithEditButtons,m as __namedExportsOrder,l as default};