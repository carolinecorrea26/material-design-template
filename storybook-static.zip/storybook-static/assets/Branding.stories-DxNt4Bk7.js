import{n as e}from"./chunk-BneVvdWh.js";import{$ as t,Ot as n,S as r,at as i,dt as a,ft as o,nt as s,t as c}from"./esm-AWQ-KJXU.js";import{i as l,n as u,s as d,t as f}from"./DocsBlocks-BEbHO4Nl.js";var p,m,h,g;e((()=>{c(),d(),p=n(),m={title:`Foundations/Branding`,parameters:{layout:`padded`}},h=()=>(0,p.jsxs)(f,{eyebrow:`Foundations`,title:`Branding`,intro:`Presentation rules for client-provided logos, hero images, and brand colors. The CMS owns each client's actual editable assets and copy; this page owns how those values are rendered.`,maxWidth:1e3,children:[(0,p.jsxs)(u,{title:`Logo display`,description:`Representative content inside the same maximum display area used by the application header.`,children:[(0,p.jsx)(s,{variant:`outlined`,sx:{maxWidth:360},children:(0,p.jsx)(t,{children:(0,p.jsx)(i,{sx:{width:{xs:200,sm:250},maxWidth:`100%`,height:35,display:`flex`,alignItems:`center`,justifyContent:`center`,border:`1px dashed`,borderColor:`divider`,bgcolor:`background.subtle`},children:(0,p.jsx)(a,{variant:`caption`,sx:{fontWeight:800},children:`CLIENT LOGO · NATURAL ASPECT RATIO`})})})}),(0,p.jsxs)(r,{spacing:.5,sx:{mt:2},children:[(0,p.jsxs)(a,{variant:`body2`,color:`text.secondary`,children:[`Maximum width is `,(0,p.jsx)(`strong`,{children:`200px`}),` on mobile and`,` `,(0,p.jsx)(`strong`,{children:`250px`}),` from the small breakpoint upward. Maximum height is `,(0,p.jsx)(`strong`,{children:`35px`}),`. Width and height remain automatic, so the source aspect ratio is never stretched.`]}),(0,p.jsx)(a,{variant:`body2`,color:`text.secondary`,children:`Every meaningful logo needs concise, purpose-driven alternative text. Do not repeat nearby copy or use a filename as the alt value.`})]}),(0,p.jsx)(l,{children:`src/components/layout/AppHeader.tsx — rendering constraints; ClientConfig.branding.logo / logoAlt — configured asset references`})]}),(0,p.jsxs)(u,{title:`Hero image display`,children:[(0,p.jsxs)(a,{variant:`body2`,color:`text.secondary`,children:[`Hero images render at a maximum width of `,(0,p.jsx)(`strong`,{children:`500px`}),`, with automatic height and a `,(0,p.jsx)(`strong`,{children:`32px`}),` corner radius. They are used only by the `,(0,p.jsx)(`code`,{children:`hero-image`}),` and `,(0,p.jsx)(`code`,{children:`welcome-back`}),` `,`home-page variants. Images must retain enough contrast and whitespace for their surrounding text treatment and must have appropriate text alternatives when they convey information.`]}),(0,p.jsx)(l,{children:`src/pages/Home.tsx — hero rendering; CMS documentation — actual image and copy values`})]}),(0,p.jsx)(u,{title:`Hero typography and copy fit`,children:(0,p.jsxs)(a,{variant:`body2`,color:`text.secondary`,children:[`Hero titles use the theme's `,(0,p.jsx)(`code`,{children:`h1`}),` treatment. No hard copy limit is enforced; as authoring guidance, keep titles near 60 characters and descriptions near 160 characters so each remains close to two desktop lines. The CMS owns the actual heading and description.`]})}),(0,p.jsx)(u,{title:`Brand color guardrails`,children:(0,p.jsx)(a,{variant:`body2`,color:`text.secondary`,children:`A client primary color must preserve readable contrast and remain visually distinct from application-controlled semantic colors. Error, success, warning/notice, and neutral system colors are not client brand settings. Review a custom primary across interactive states and both text and surface contexts before approval.`})}),(0,p.jsx)(o,{severity:`info`,sx:{maxWidth:800},children:`Add or edit the actual logo, hero image, headings, and copy in the CMS documentation. Use this Storybook page to validate how those values will be displayed.`})]}),h.__docgenInfo={description:``,methods:[],displayName:`Branding`},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`() => <DocsPage eyebrow="Foundations" title="Branding" intro="Presentation rules for client-provided logos, hero images, and brand colors. The CMS owns each client's actual editable assets and copy; this page owns how those values are rendered." maxWidth={1000}>
    <DocsSection title="Logo display" description="Representative content inside the same maximum display area used by the application header.">
      <Card variant="outlined" sx={{
      maxWidth: 360
    }}>
        <CardContent>
          <Box sx={{
          width: {
            xs: 200,
            sm: 250
          },
          maxWidth: "100%",
          height: 35,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          border: "1px dashed",
          borderColor: "divider",
          bgcolor: "background.subtle"
        }}>
            <Typography variant="caption" sx={{
            fontWeight: 800
          }}>
              CLIENT LOGO · NATURAL ASPECT RATIO
            </Typography>
          </Box>
        </CardContent>
      </Card>
      <Stack spacing={0.5} sx={{
      mt: 2
    }}>
        <Typography variant="body2" color="text.secondary">
          Maximum width is <strong>200px</strong> on mobile and{" "}
          <strong>250px</strong> from the small breakpoint upward. Maximum
          height is <strong>35px</strong>. Width and height remain automatic,
          so the source aspect ratio is never stretched.
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Every meaningful logo needs concise, purpose-driven alternative text.
          Do not repeat nearby copy or use a filename as the alt value.
        </Typography>
      </Stack>
      <SourceNote>
        src/components/layout/AppHeader.tsx — rendering constraints;
        ClientConfig.branding.logo / logoAlt — configured asset references
      </SourceNote>
    </DocsSection>

    <DocsSection title="Hero image display">
      <Typography variant="body2" color="text.secondary">
        Hero images render at a maximum width of <strong>500px</strong>, with
        automatic height and a <strong>32px</strong> corner radius. They are
        used only by the <code>hero-image</code> and <code>welcome-back</code>{" "}
        home-page variants. Images must retain enough contrast and whitespace
        for their surrounding text treatment and must have appropriate text
        alternatives when they convey information.
      </Typography>
      <SourceNote>
        src/pages/Home.tsx — hero rendering; CMS documentation — actual image
        and copy values
      </SourceNote>
    </DocsSection>

    <DocsSection title="Hero typography and copy fit">
      <Typography variant="body2" color="text.secondary">
        Hero titles use the theme&apos;s <code>h1</code> treatment. No hard copy
        limit is enforced; as authoring guidance, keep titles near 60
        characters and descriptions near 160 characters so each remains close
        to two desktop lines. The CMS owns the actual heading and description.
      </Typography>
    </DocsSection>

    <DocsSection title="Brand color guardrails">
      <Typography variant="body2" color="text.secondary">
        A client primary color must preserve readable contrast and remain
        visually distinct from application-controlled semantic colors. Error,
        success, warning/notice, and neutral system colors are not client brand
        settings. Review a custom primary across interactive states and both
        text and surface contexts before approval.
      </Typography>
    </DocsSection>

    <Alert severity="info" sx={{
    maxWidth: 800
  }}>
      Add or edit the actual logo, hero image, headings, and copy in the CMS
      documentation. Use this Storybook page to validate how those values will
      be displayed.
    </Alert>
  </DocsPage>`,...h.parameters?.docs?.source}}},g=[`Branding`]}))();export{h as Branding,g as __namedExportsOrder,m as default};