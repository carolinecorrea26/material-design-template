import{n as e}from"./chunk-BneVvdWh.js";import{$ as t,Ct as n,Ot as r,S as i,St as a,Tt as o,at as s,c,dt as l,f as u,ft as d,nt as f,r as p,t as m}from"./esm-AWQ-KJXU.js";import{a as h,i as g}from"./theme-B3ct2zHf.js";import{i as _,n as v,r as y,s as b,t as x}from"./DocsBlocks-BEbHO4Nl.js";function S({label:e}){let n=o(),r=p(n.breakpoints.up(`md`)),i=p(n.breakpoints.up(`sm`));return(0,C.jsx)(f,{variant:`outlined`,sx:{flex:1,minWidth:220},children:(0,C.jsxs)(t,{children:[(0,C.jsx)(l,{variant:`subtitle2`,gutterBottom:!0,children:e}),(0,C.jsxs)(l,{variant:`body2`,children:[(0,C.jsx)(`code`,{children:`up("sm")`}),`: `,(0,C.jsx)(`strong`,{children:String(i)})]}),(0,C.jsxs)(l,{variant:`body2`,children:[(0,C.jsx)(`code`,{children:`up("md")`}),`: `,(0,C.jsx)(`strong`,{children:String(r)})]}),(0,C.jsx)(s,{sx:{mt:1,display:{xs:`block`,md:`none`}},children:(0,C.jsxs)(l,{variant:`caption`,color:`warning.main`,children:[`Narrow-screen branch rendered (`,`{ xs: block, md: none }`,`)`]})}),(0,C.jsx)(s,{sx:{mt:1,display:{xs:`none`,md:`block`}},children:(0,C.jsxs)(l,{variant:`caption`,color:`success.main`,children:[`Wide-screen branch rendered (`,`{ xs: none, md: block }`,`)`]})})]})})}var C,w,T,E,D,O;e((()=>{a(),m(),h(),b(),C=r(),w={title:`Foundations/Breakpoints & Responsive Design`,parameters:{layout:`padded`}},T=g(),E=g(`default`,{forceMobileLayout:!0}),D=()=>{let e=o();return(0,C.jsxs)(x,{eyebrow:`Foundations`,title:`Breakpoints & Responsive Design`,intro:`Standard MUI breakpoints, plus one prototype-specific override — forceMobileLayout — that several structural components key off of. Resize this panel (or use the toolbar's viewport control) to see the live readout below respond to your actual browser width.`,maxWidth:1100,children:[(0,C.jsxs)(v,{title:`Breakpoint values`,children:[(0,C.jsxs)(y,{columns:[`Key`,`Min width (px)`,`Typical use`],children:[(0,C.jsxs)(c,{children:[(0,C.jsx)(u,{sx:{fontFamily:`monospace`},children:`xs`}),(0,C.jsx)(u,{children:e.breakpoints.values.xs}),(0,C.jsx)(u,{children:`Phone — the default/base styling.`})]}),(0,C.jsxs)(c,{children:[(0,C.jsx)(u,{sx:{fontFamily:`monospace`},children:`sm`}),(0,C.jsx)(u,{children:e.breakpoints.values.sm}),(0,C.jsx)(u,{children:`Padding/spacing bumps (e.g. FormShell). Deliberately left real even under forceMobileLayout.`})]}),(0,C.jsxs)(c,{children:[(0,C.jsx)(u,{sx:{fontFamily:`monospace`},children:`md`}),(0,C.jsx)(u,{children:e.breakpoints.values.md}),(0,C.jsx)(u,{children:`Structural desktop/mobile branches: ProgressStep's sidebar-vs-stepper, AppDrawer's side-panel-vs-bottom-sheet, AppModal's fullScreen toggle, HelpChips' overflow-fade, MemberVerification's fullScreen dialog.`})]}),(0,C.jsxs)(c,{children:[(0,C.jsx)(u,{sx:{fontFamily:`monospace`},children:`lg`}),(0,C.jsx)(u,{children:e.breakpoints.values.lg}),(0,C.jsx)(u,{children:`Wider multi-column layouts (e.g. field example grids going to 3 columns).`})]}),(0,C.jsxs)(c,{children:[(0,C.jsx)(u,{sx:{fontFamily:`monospace`},children:`xl`}),(0,C.jsx)(u,{children:e.breakpoints.values.xl}),(0,C.jsx)(u,{children:`Rarely used directly.`})]})]}),(0,C.jsx)(_,{children:`Values read live from useTheme().breakpoints.values — MUI defaults, unmodified by this app under normal (non-forceMobileLayout) rendering.`})]}),(0,C.jsxs)(v,{title:`forceMobileLayout`,description:`A client-configurable "single" form template pins md/lg/xl to an unreachable width (1e6) while leaving xs/sm untouched, so every useMediaQuery(breakpoints.up("md")) structural check below resolves to its narrow-screen branch regardless of actual browser width. sm stays real specifically so sm-level padding (e.g. FormShell's px: { xs: 2, sm: "48px" }) still applies on an actual desktop browser.`,children:[(0,C.jsxs)(i,{direction:{xs:`column`,md:`row`},spacing:2,children:[(0,C.jsx)(n,{theme:T,children:(0,C.jsx)(S,{label:`Real theme (template=multi)`})}),(0,C.jsx)(n,{theme:E,children:(0,C.jsx)(S,{label:`forceMobileLayout: true (template=single)`})})]}),(0,C.jsxs)(d,{severity:`info`,sx:{mt:2,maxWidth:760},children:[`Both cards above render at your actual current browser width — the right card always reports `,(0,C.jsx)(`code`,{children:`up("md")`}),` as`,` `,(0,C.jsx)(`code`,{children:`false`}),` because its theme's `,(0,C.jsx)(`code`,{children:`md`}),` breakpoint is set to an unreachable value, not because the viewport is actually narrow.`]}),(0,C.jsx)(_,{children:`src/app/theme.ts — createAppTheme's forceMobileLayout option; src/config/template/resolveTemplate.ts selects "single" vs "multi"`})]}),(0,C.jsx)(v,{title:`Reflow at narrow widths`,children:(0,C.jsxs)(l,{variant:`body2`,color:`text.secondary`,sx:{maxWidth:720},children:[`Per the application's accessibility requirements (see`,` `,(0,C.jsx)(`code`,{children:`Guidelines / Accessibility`}),`), narrow-viewport variants (mobile stepper, drawer-based panels, hidden tab text labels) are required to hide only redundant `,(0,C.jsx)(`em`,{children:`visual`}),` labels — never functionality — and any hidden text label must be replaced with an equivalent `,(0,C.jsx)(`code`,{children:`aria-label`}),` rather than dropped.`]})})]})},D.__docgenInfo={description:``,methods:[],displayName:`BreakpointsAndResponsiveDesign`},D.parameters={...D.parameters,docs:{...D.parameters?.docs,source:{originalSource:`() => {
  const theme = useTheme();
  return <DocsPage eyebrow="Foundations" title="Breakpoints & Responsive Design" intro="Standard MUI breakpoints, plus one prototype-specific override — forceMobileLayout — that several structural components key off of. Resize this panel (or use the toolbar's viewport control) to see the live readout below respond to your actual browser width." maxWidth={1100}>
      <DocsSection title="Breakpoint values">
        <DocsTable columns={["Key", "Min width (px)", "Typical use"]}>
          <TableRow>
            <TableCell sx={{
            fontFamily: "monospace"
          }}>xs</TableCell>
            <TableCell>{theme.breakpoints.values.xs}</TableCell>
            <TableCell>Phone — the default/base styling.</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{
            fontFamily: "monospace"
          }}>sm</TableCell>
            <TableCell>{theme.breakpoints.values.sm}</TableCell>
            <TableCell>Padding/spacing bumps (e.g. FormShell). Deliberately left real even under forceMobileLayout.</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{
            fontFamily: "monospace"
          }}>md</TableCell>
            <TableCell>{theme.breakpoints.values.md}</TableCell>
            <TableCell>Structural desktop/mobile branches: ProgressStep's sidebar-vs-stepper, AppDrawer's side-panel-vs-bottom-sheet, AppModal's fullScreen toggle, HelpChips' overflow-fade, MemberVerification's fullScreen dialog.</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{
            fontFamily: "monospace"
          }}>lg</TableCell>
            <TableCell>{theme.breakpoints.values.lg}</TableCell>
            <TableCell>Wider multi-column layouts (e.g. field example grids going to 3 columns).</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{
            fontFamily: "monospace"
          }}>xl</TableCell>
            <TableCell>{theme.breakpoints.values.xl}</TableCell>
            <TableCell>Rarely used directly.</TableCell>
          </TableRow>
        </DocsTable>
        <SourceNote>Values read live from useTheme().breakpoints.values — MUI defaults, unmodified by this app under normal (non-forceMobileLayout) rendering.</SourceNote>
      </DocsSection>

      <DocsSection title="forceMobileLayout" description={\`A client-configurable "single" form template pins md/lg/xl to an unreachable width (1e6) while leaving xs/sm untouched, so every useMediaQuery(breakpoints.up("md")) structural check below resolves to its narrow-screen branch regardless of actual browser width. sm stays real specifically so sm-level padding (e.g. FormShell's px: { xs: 2, sm: "48px" }) still applies on an actual desktop browser.\`}>
        <Stack direction={{
        xs: "column",
        md: "row"
      }} spacing={2}>
          <ThemeProvider theme={realTheme}>
            <BreakpointReadout label="Real theme (template=multi)" />
          </ThemeProvider>
          <ThemeProvider theme={forcedMobileTheme}>
            <BreakpointReadout label="forceMobileLayout: true (template=single)" />
          </ThemeProvider>
        </Stack>
        <Alert severity="info" sx={{
        mt: 2,
        maxWidth: 760
      }}>
          Both cards above render at your actual current browser width — the
          right card always reports <code>up("md")</code> as{" "}
          <code>false</code> because its theme's <code>md</code> breakpoint is
          set to an unreachable value, not because the viewport is actually
          narrow.
        </Alert>
        <SourceNote>src/app/theme.ts — createAppTheme's forceMobileLayout option; src/config/template/resolveTemplate.ts selects "single" vs "multi"</SourceNote>
      </DocsSection>

      <DocsSection title="Reflow at narrow widths">
        <Typography variant="body2" color="text.secondary" sx={{
        maxWidth: 720
      }}>
          Per the application's accessibility requirements (see{" "}
          <code>Guidelines / Accessibility</code>), narrow-viewport variants
          (mobile stepper, drawer-based panels, hidden tab text labels) are
          required to hide only redundant <em>visual</em> labels — never
          functionality — and any hidden text label must be replaced with an
          equivalent <code>aria-label</code> rather than dropped.
        </Typography>
      </DocsSection>
    </DocsPage>;
}`,...D.parameters?.docs?.source}}},O=[`BreakpointsAndResponsiveDesign`]}))();export{D as BreakpointsAndResponsiveDesign,O as __namedExportsOrder,w as default};