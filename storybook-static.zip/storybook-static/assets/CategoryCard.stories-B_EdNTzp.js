import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,dt as n,t as r}from"./esm-AWQ-KJXU.js";import{n as i,t as a}from"./Diversity1Rounded-DB0NGYtJ.js";import{n as o,t as s}from"./CategoryCard-7w5ch0Lw.js";var c,l,u,d;e((()=>{r(),i(),o(),c=t(),l={title:`Layout/CategoryCard`,component:s,parameters:{layout:`padded`,docs:{description:{component:`CategoryCard wraps CategoryHeader plus a content Stack in the shared
category-section surface (CATEGORY_SECTION_SX). Used on Payment,
Beneficiary, and ProductCatalog.`}}}},u={render:()=>(0,c.jsxs)(s,{label:`Life Insurance`,icon:a,children:[(0,c.jsx)(n,{variant:`body2`,children:`Product cards for this category go here.`}),(0,c.jsx)(n,{variant:`body2`,children:`A second content block.`})]})},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  render: () => <CategoryCard label="Life Insurance" icon={Diversity1RoundedIcon}>
      <Typography variant="body2">Product cards for this category go here.</Typography>
      <Typography variant="body2">A second content block.</Typography>
    </CategoryCard>
}`,...u.parameters?.docs?.source}}},d=[`Default`]}))();export{u as Default,d as __namedExportsOrder,l as default};