import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t}from"./esm-AWQ-KJXU.js";import{n,t as r}from"./Diversity1Rounded-DB0NGYtJ.js";import{n as i,t as a}from"./CategoryHeader-DILkVx4b.js";var o,s,c,l,u;e((()=>{n(),i(),o=t(),s={title:`Layout/CategoryHeader`,component:a,parameters:{layout:`padded`,docs:{description:{component:`CategoryHeader is a coverage-category heading, rendered as a real h3
(nested correctly under the page's h2) with h6 visual styling — fixed
from h6 to h3 during the CL-022 accessibility pass so category headings
no longer skip a heading level.`}}}},c={render:()=>(0,o.jsx)(a,{label:`Life Insurance`,icon:r})},l={render:()=>(0,o.jsx)(a,{label:`Life Insurance`})},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  render: () => <CategoryHeader label="Life Insurance" icon={Diversity1RoundedIcon} />
}`,...c.parameters?.docs?.source}}},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  render: () => <CategoryHeader label="Life Insurance" />
}`,...l.parameters?.docs?.source}}},u=[`WithIcon`,`WithoutIcon`]}))();export{c as WithIcon,l as WithoutIcon,u as __namedExportsOrder,s as default};