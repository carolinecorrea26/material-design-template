import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{G as r,J as i,K as a,Ot as o,X as s,at as c,dt as l,pt as u,rt as d,t as f}from"./esm-AWQ-KJXU.js";import{a as p,i as m,n as h,o as g,r as _,t as v}from"./Phone-BAG3KphE.js";import{n as y,t as b}from"./Close-DDY3CvKm.js";function x({client:e}){let[t,n]=(0,S.useState)(!1),{phone:o,phoneDisplay:f,phoneHours:m}=e.support,{chat:h,chatUrl:g,scheduleUrl:y,linkUrl:x,linkLabel:w}=e.features??{};return o?(0,C.jsxs)(C.Fragment,{children:[(0,C.jsx)(c,{sx:{width:`100vw`,position:`relative`,left:`50%`,right:`50%`,ml:`-50vw`,mr:`-50vw`,bgcolor:`primary.dark`},children:(0,C.jsxs)(c,{sx:{maxWidth:`100%`,mx:`auto`,px:2,py:.5,display:`flex`,alignItems:`center`,justifyContent:`center`,flexWrap:`wrap`,gap:1.5},children:[(0,C.jsxs)(c,{sx:{display:`flex`,alignItems:`center`,gap:1,flexWrap:`wrap`,justifyContent:`center`},children:[(0,C.jsxs)(d,{variant:`outlined`,size:`small`,href:`tel:${o}`,startIcon:(0,C.jsx)(v,{}),sx:{color:`#fff`,borderColor:`rgba(255,255,255,0.6)`,"&:hover":{borderColor:`#fff`,bgcolor:`rgba(255,255,255,0.08)`},textTransform:`none`,fontWeight:600,fontSize:`0.8rem`},children:[`Call for help `,f||o]}),m&&(0,C.jsx)(l,{variant:`caption`,sx:{color:`rgba(255,255,255,0.85)`,whiteSpace:`nowrap`},children:m})]}),h&&(0,C.jsxs)(C.Fragment,{children:[(0,C.jsx)(r,{orientation:`vertical`,flexItem:!0,sx:{borderColor:`rgba(255,255,255,0.3)`}}),(0,C.jsx)(d,{variant:`outlined`,size:`small`,onClick:()=>{let e=g||`https://example.com/chat`;window.open(e,`ClientChat`,`width=400,height=600,scrollbars=yes`)},startIcon:(0,C.jsx)(_,{}),sx:{color:`#fff`,borderColor:`rgba(255,255,255,0.6)`,"&:hover":{borderColor:`#fff`,bgcolor:`rgba(255,255,255,0.08)`},textTransform:`none`,fontWeight:600,fontSize:`0.8rem`},children:`Chat now`})]}),x&&(0,C.jsxs)(C.Fragment,{children:[(0,C.jsx)(r,{orientation:`vertical`,flexItem:!0,sx:{borderColor:`rgba(255,255,255,0.3)`}}),(0,C.jsx)(d,{variant:`outlined`,size:`small`,href:x,target:`_blank`,rel:`noopener noreferrer`,sx:{color:`#fff`,borderColor:`rgba(255,255,255,0.6)`,"&:hover":{borderColor:`#fff`,bgcolor:`rgba(255,255,255,0.08)`},textTransform:`none`,fontWeight:600,fontSize:`0.8rem`},children:w||`${e.branding.acronym} help`})]}),y&&(0,C.jsxs)(C.Fragment,{children:[(0,C.jsx)(r,{orientation:`vertical`,flexItem:!0,sx:{borderColor:`rgba(255,255,255,0.3)`}}),(0,C.jsx)(d,{variant:`outlined`,size:`small`,onClick:()=>n(!0),startIcon:(0,C.jsx)(p,{}),sx:{color:`#fff`,borderColor:`rgba(255,255,255,0.6)`,"&:hover":{borderColor:`#fff`,bgcolor:`rgba(255,255,255,0.08)`},textTransform:`none`,fontWeight:600,fontSize:`0.8rem`},children:`Schedule a call`})]})]})}),(0,C.jsxs)(s,{open:t,onClose:()=>n(!1),maxWidth:`sm`,fullWidth:!0,children:[(0,C.jsxs)(a,{sx:{display:`flex`,alignItems:`center`,justifyContent:`space-between`},children:[`Schedule a Call`,(0,C.jsx)(u,{onClick:()=>n(!1),"aria-label":`Close schedule a call dialog`,size:`small`,children:(0,C.jsx)(b,{})})]}),(0,C.jsx)(i,{children:(0,C.jsx)(c,{component:`iframe`,src:y,title:`Schedule a call`,sx:{width:`100%`,height:500,border:`none`}})})]})]}):null}var S,C,w=t((()=>{S=e(n(),1),f(),h(),m(),g(),y(),C=o(),x.__docgenInfo={description:``,methods:[],displayName:`ClientHelpBanner`,props:{client:{required:!0,tsType:{name:`signature`,type:`object`,raw:`{
  id: ClientId;
  /**
   * Groups multiple ClientConfig entries as sites of one logical client for
   * site-selection UI (e.g. Site Details' client picker). Defaults to \`id\`
   * when omitted, i.e. every client is its own single-site group unless
   * stated otherwise. See src/config/clients/clientGroups.ts.
   */
  clientGroupId?: string;
  /** Short label distinguishing this site within its clientGroupId (e.g. "Multi-step (default)"). */
  siteLabel?: string;
  branding: ClientBranding;
  support: ClientSupport;
  pages: ClientPages;
  coverages: ClientCoverages;
  fields: ClientFields;
  /** Client-specific flow overrides; global flows remain the baseline source of truth. */
  flows?: ClientFlows;
  /** Per-client configuration for the "Questions? We're here to help" contact box in outbound emails. */
  emailSupport?: ClientEmailSupport;
  /** @deprecated Content is now managed in src/content/. This field is unused. */
  content?: ClientContent;
  features?: ClientFeatures;
  /** Site-level brand color input. Semantic and neutral colors remain application-controlled. */
  theme?: ClientThemeConfig;
  licenseInfo?: string[];
  coverageQuestions?: ClientCoverageQuestions;
  /** Override default applicant section header labels. Max 20 chars each. */
  applicantLabels?: ClientApplicantLabels;
  /** Deployment environment links for this client's site. Unset until provisioned. */
  siteUrls?: ClientSiteUrls;
  /** Query-string parameters (from src/content/docs/urlParameters.ts) this client actually uses in live URLs. Unset/empty until confirmed. */
  urlParametersInUse?: string[];
}`,signature:{properties:[{key:`id`,value:{name:`union`,raw:`| "demo"
| "abe"
| "ama"
| "asce"
| "avma"
| "csea"
| "isitrust"
| "nso"
| "waepa"
| "waepagi"`,elements:[{name:`literal`,value:`"demo"`},{name:`literal`,value:`"abe"`},{name:`literal`,value:`"ama"`},{name:`literal`,value:`"asce"`},{name:`literal`,value:`"avma"`},{name:`literal`,value:`"csea"`},{name:`literal`,value:`"isitrust"`},{name:`literal`,value:`"nso"`},{name:`literal`,value:`"waepa"`},{name:`literal`,value:`"waepagi"`}],required:!0}},{key:`clientGroupId`,value:{name:`string`,required:!1},description:`Groups multiple ClientConfig entries as sites of one logical client for
site-selection UI (e.g. Site Details' client picker). Defaults to \`id\`
when omitted, i.e. every client is its own single-site group unless
stated otherwise. See src/config/clients/clientGroups.ts.`},{key:`siteLabel`,value:{name:`string`,required:!1},description:`Short label distinguishing this site within its clientGroupId (e.g. "Multi-step (default)").`},{key:`branding`,value:{name:`signature`,type:`object`,raw:`{
  name: string;
  acronym: string;
  logo: string;
  logoAlt: string;
}`,signature:{properties:[{key:`name`,value:{name:`string`,required:!0}},{key:`acronym`,value:{name:`string`,required:!0}},{key:`logo`,value:{name:`string`,required:!0}},{key:`logoAlt`,value:{name:`string`,required:!0}}]},required:!0}},{key:`support`,value:{name:`signature`,type:`object`,raw:`{
  phone?: string;
  phoneDisplay?: string;
  phoneHours?: string;
  email?: string;
  website?: string;
  address?: {
    organization?: string;
    street?: string;
    city?: string;
    state?: string;
    zip?: string;
  };
}`,signature:{properties:[{key:`phone`,value:{name:`string`,required:!1}},{key:`phoneDisplay`,value:{name:`string`,required:!1}},{key:`phoneHours`,value:{name:`string`,required:!1}},{key:`email`,value:{name:`string`,required:!1}},{key:`website`,value:{name:`string`,required:!1}},{key:`address`,value:{name:`signature`,type:`object`,raw:`{
  organization?: string;
  street?: string;
  city?: string;
  state?: string;
  zip?: string;
}`,signature:{properties:[{key:`organization`,value:{name:`string`,required:!1}},{key:`street`,value:{name:`string`,required:!1}},{key:`city`,value:{name:`string`,required:!1}},{key:`state`,value:{name:`string`,required:!1}},{key:`zip`,value:{name:`string`,required:!1}}]},required:!1}}]},required:!0}},{key:`pages`,value:{name:`signature`,type:`object`,raw:`{
  requirements?: Partial<
    Record<"beneficiary" | "payment", ClientPageRequirement>
  >;
  /** @deprecated Use requirements with mode "none" instead. */
  excluded?: PageId[];
  /** @deprecated Use requirements with mode "optional" instead. */
  optional?: PageId[];
}`,signature:{properties:[{key:`requirements`,value:{name:`Partial`,elements:[{name:`Record`,elements:[{name:`union`,raw:`"beneficiary" | "payment"`,elements:[{name:`literal`,value:`"beneficiary"`},{name:`literal`,value:`"payment"`}]},{name:`union`,raw:`"required" | "optional" | "none"`,elements:[{name:`literal`,value:`"required"`},{name:`literal`,value:`"optional"`},{name:`literal`,value:`"none"`}]}],raw:`Record<"beneficiary" | "payment", ClientPageRequirement>`}],raw:`Partial<
  Record<"beneficiary" | "payment", ClientPageRequirement>
>`,required:!1}},{key:`excluded`,value:{name:`Array`,elements:[{name:`unknown[number]["id"]`,raw:`Page["id"]`,required:!1}],raw:`PageId[]`,required:!1},description:`@deprecated Use requirements with mode "none" instead.`},{key:`optional`,value:{name:`Array`,elements:[{name:`unknown[number]["id"]`,raw:`Page["id"]`,required:!1}],raw:`PageId[]`,required:!1},description:`@deprecated Use requirements with mode "optional" instead.`}]},required:!0}},{key:`coverages`,value:{name:`signature`,type:`object`,raw:`{
  categories?: CoverageCategoryId[];
  enabled?: CoverageId[];
  ranges?: Partial<Record<CoverageId, ClientCoverageRangeConfig>>;
  descriptions?: Partial<Record<CoverageId, string>>;
  overrides?: Partial<Record<CoverageId, ClientCoverageOverrides>>;
  /** When true, all coverage category accordions are expanded by default. */
  allCategoriesExpanded?: boolean;
  estimatedRateDisplay?: ClientEstimatedRateDisplay;
  /**
   * Controls the wording of the "apply for additional coverage" warning on the Coverage page.
   * "applyForAdditional" (default): "...apply only for the additional coverage you want."
   * "applyForTotal": "...apply for the total amount of coverage you want (amount you currently have + amount you're requesting)."
   */
  additionalCoverageWarning?: "applyForAdditional" | "applyForTotal";
  /** Product-card estimated cost breakdown config (optional per client). */
  productEstimatedCostBreakdown?: ClientProductEstimatedCostBreakdown;
  /** Override the default coverage category section header labels (e.g. "Office Overhead Expense"). */
  categorySectionLabels?: Partial<Record<CoverageCategoryId, string>>;
  /** When true, the quote tool and coverage questions skip the smoker/nicotine question for this client. */
  hideSmokerQuestion?: boolean;
}`,signature:{properties:[{key:`categories`,value:{name:`Array`,elements:[{name:`unknown[number]["id"]`,raw:`CoverageCategory["id"]`,required:!1}],raw:`CoverageCategoryId[]`,required:!1}},{key:`enabled`,value:{name:`Array`,elements:[{name:`unknown[number]["id"]`,raw:`Coverage["id"]`}],raw:`CoverageId[]`,required:!1}},{key:`ranges`,value:{name:`Partial`,elements:[{name:`Record`,elements:[{name:`unknown[number]["id"]`,raw:`Coverage["id"]`},{name:`signature`,type:`object`,raw:`{
  min?: number;
  max?: number;
  amountStep?: number;
  spouseMin?: number;
  spouseMax?: number;
  spouseAmountStep?: number;
  childMin?: number;
  childMax?: number;
  childAmountStep?: number;
}`,signature:{properties:[{key:`min`,value:{name:`number`,required:!1}},{key:`max`,value:{name:`number`,required:!1}},{key:`amountStep`,value:{name:`number`,required:!1}},{key:`spouseMin`,value:{name:`number`,required:!1}},{key:`spouseMax`,value:{name:`number`,required:!1}},{key:`spouseAmountStep`,value:{name:`number`,required:!1}},{key:`childMin`,value:{name:`number`,required:!1}},{key:`childMax`,value:{name:`number`,required:!1}},{key:`childAmountStep`,value:{name:`number`,required:!1}}]}}],raw:`Record<CoverageId, ClientCoverageRangeConfig>`}],raw:`Partial<Record<CoverageId, ClientCoverageRangeConfig>>`,required:!1}},{key:`descriptions`,value:{name:`Partial`,elements:[{name:`Record`,elements:[{name:`unknown[number]["id"]`,raw:`Coverage["id"]`},{name:`string`}],raw:`Record<CoverageId, string>`}],raw:`Partial<Record<CoverageId, string>>`,required:!1}},{key:`overrides`,value:{name:`Partial`,elements:[{name:`Record`,elements:[{name:`unknown[number]["id"]`,raw:`Coverage["id"]`},{name:`signature`,type:`object`,raw:`{
  name?: string;
  /** External product brochure or certificate URL. */
  brochureUrl?: string;
  categoryId?: CoverageCategoryId;
  riders?: ClientRiderConfig[];
  waitingPeriodOptions?: ClientWaitingPeriodConfig[];
  waitingPeriodOptionsByApplicant?: Partial<
    Record<"member" | "spouse" | "child", ClientWaitingPeriodConfig[]>
  >;
  maxBenefitPeriodOptions?: ClientMaxBenefitPeriodConfig[];
  maxBenefitPeriodOptionsByApplicant?: Partial<
    Record<"member" | "spouse" | "child", ClientMaxBenefitPeriodConfig[]>
  >;
  applicants?: ("member" | "spouse" | "child")[];
  coverageNote?: string;
  featured?: boolean;
  underwritingType?: CoverageUnderwritingType;
  /** Per-applicant info notes displayed above the applicant fields */
  applicantNotes?: CoverageApplicantNotes;
  /** Product-level alert displayed below the product description */
  productWarning?: CoverageProductWarning;
  /** Structured content block displayed below the product warning */
  productContent?: ProductContentBlock[];
}`,signature:{properties:[{key:`name`,value:{name:`string`,required:!1}},{key:`brochureUrl`,value:{name:`string`,required:!1},description:`External product brochure or certificate URL.`},{key:`categoryId`,value:{name:`unknown[number]["id"]`,raw:`CoverageCategory["id"]`,required:!1}},{key:`riders`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  id: string;
  name: string;
  description: string;
  hasAmount?: boolean;
  minAmount?: number;
  maxAmount?: number;
  spouseMinAmount?: number;
  spouseMaxAmount?: number;
  childMinAmount?: number;
  childMaxAmount?: number;
  applicants?: ("member" | "spouse" | "child")[];
  premiumFactor: number;
}`,signature:{properties:[{key:`id`,value:{name:`string`,required:!0}},{key:`name`,value:{name:`string`,required:!0}},{key:`description`,value:{name:`string`,required:!0}},{key:`hasAmount`,value:{name:`boolean`,required:!1}},{key:`minAmount`,value:{name:`number`,required:!1}},{key:`maxAmount`,value:{name:`number`,required:!1}},{key:`spouseMinAmount`,value:{name:`number`,required:!1}},{key:`spouseMaxAmount`,value:{name:`number`,required:!1}},{key:`childMinAmount`,value:{name:`number`,required:!1}},{key:`childMaxAmount`,value:{name:`number`,required:!1}},{key:`applicants`,value:{name:`Array`,elements:[{name:`unknown`}],raw:`("member" | "spouse" | "child")[]`,required:!1}},{key:`premiumFactor`,value:{name:`number`,required:!0}}]}}],raw:`ClientRiderConfig[]`,required:!1}},{key:`waitingPeriodOptions`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  label: string;
  value: string;
  days: number;
}`,signature:{properties:[{key:`label`,value:{name:`string`,required:!0}},{key:`value`,value:{name:`string`,required:!0}},{key:`days`,value:{name:`number`,required:!0}}]}}],raw:`ClientWaitingPeriodConfig[]`,required:!1}},{key:`waitingPeriodOptionsByApplicant`,value:{name:`Partial`,elements:[{name:`Record`,elements:[{name:`union`,raw:`"member" | "spouse" | "child"`,elements:[{name:`literal`,value:`"member"`},{name:`literal`,value:`"spouse"`},{name:`literal`,value:`"child"`}]},{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  label: string;
  value: string;
  days: number;
}`,signature:{properties:[{key:`label`,value:{name:`string`,required:!0}},{key:`value`,value:{name:`string`,required:!0}},{key:`days`,value:{name:`number`,required:!0}}]}}],raw:`ClientWaitingPeriodConfig[]`}],raw:`Record<"member" | "spouse" | "child", ClientWaitingPeriodConfig[]>`}],raw:`Partial<
  Record<"member" | "spouse" | "child", ClientWaitingPeriodConfig[]>
>`,required:!1}},{key:`maxBenefitPeriodOptions`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  label: string;
  value: string;
}`,signature:{properties:[{key:`label`,value:{name:`string`,required:!0}},{key:`value`,value:{name:`string`,required:!0}}]}}],raw:`ClientMaxBenefitPeriodConfig[]`,required:!1}},{key:`maxBenefitPeriodOptionsByApplicant`,value:{name:`Partial`,elements:[{name:`Record`,elements:[{name:`union`,raw:`"member" | "spouse" | "child"`,elements:[{name:`literal`,value:`"member"`},{name:`literal`,value:`"spouse"`},{name:`literal`,value:`"child"`}]},{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  label: string;
  value: string;
}`,signature:{properties:[{key:`label`,value:{name:`string`,required:!0}},{key:`value`,value:{name:`string`,required:!0}}]}}],raw:`ClientMaxBenefitPeriodConfig[]`}],raw:`Record<"member" | "spouse" | "child", ClientMaxBenefitPeriodConfig[]>`}],raw:`Partial<
  Record<"member" | "spouse" | "child", ClientMaxBenefitPeriodConfig[]>
>`,required:!1}},{key:`applicants`,value:{name:`Array`,elements:[{name:`unknown`}],raw:`("member" | "spouse" | "child")[]`,required:!1}},{key:`coverageNote`,value:{name:`string`,required:!1}},{key:`featured`,value:{name:`boolean`,required:!1}},{key:`underwritingType`,value:{name:`union`,raw:`| "FUW"
| "GI"
| "NA"
| "QD"
| "SI"
| "TELE"`,elements:[{name:`literal`,value:`"FUW"`},{name:`literal`,value:`"GI"`},{name:`literal`,value:`"NA"`},{name:`literal`,value:`"QD"`},{name:`literal`,value:`"SI"`},{name:`literal`,value:`"TELE"`}],required:!1}},{key:`applicantNotes`,value:{name:`Partial`,elements:[{name:`Record`,elements:[{name:`union`,raw:`"member" | "spouse" | "child"`,elements:[{name:`literal`,value:`"member"`},{name:`literal`,value:`"spouse"`},{name:`literal`,value:`"child"`}]},{name:`string`}],raw:`Record<"member" | "spouse" | "child", string>`}],raw:`Partial<
  Record<"member" | "spouse" | "child", string>
>`,required:!1},description:`Per-applicant info notes displayed above the applicant fields`},{key:`productWarning`,value:{name:`signature`,type:`object`,raw:`{
  severity: "warning" | "info";
  /** Bold title line (rendered separately, 16px bold) */
  title?: string;
  message: string;
}`,signature:{properties:[{key:`severity`,value:{name:`union`,raw:`"warning" | "info"`,elements:[{name:`literal`,value:`"warning"`},{name:`literal`,value:`"info"`}],required:!0}},{key:`title`,value:{name:`string`,required:!1},description:`Bold title line (rendered separately, 16px bold)`},{key:`message`,value:{name:`string`,required:!0}}]},required:!1},description:`Product-level alert displayed below the product description`},{key:`productContent`,value:{name:`Array`,elements:[{name:`union`,raw:`| { type: "heading"; text: string }
| { type: "paragraph"; text: string }
| { type: "list"; items: string[] }
| { type: "section"; heading: string; body: string[] }`,elements:[{name:`signature`,type:`object`,raw:`{ type: "heading"; text: string }`,signature:{properties:[{key:`type`,value:{name:`literal`,value:`"heading"`,required:!0}},{key:`text`,value:{name:`string`,required:!0}}]}},{name:`signature`,type:`object`,raw:`{ type: "paragraph"; text: string }`,signature:{properties:[{key:`type`,value:{name:`literal`,value:`"paragraph"`,required:!0}},{key:`text`,value:{name:`string`,required:!0}}]}},{name:`signature`,type:`object`,raw:`{ type: "list"; items: string[] }`,signature:{properties:[{key:`type`,value:{name:`literal`,value:`"list"`,required:!0}},{key:`items`,value:{name:`Array`,elements:[{name:`string`}],raw:`string[]`,required:!0}}]}},{name:`signature`,type:`object`,raw:`{ type: "section"; heading: string; body: string[] }`,signature:{properties:[{key:`type`,value:{name:`literal`,value:`"section"`,required:!0}},{key:`heading`,value:{name:`string`,required:!0}},{key:`body`,value:{name:`Array`,elements:[{name:`string`}],raw:`string[]`,required:!0}}]}}]}],raw:`ProductContentBlock[]`,required:!1},description:`Structured content block displayed below the product warning`}]}}],raw:`Record<CoverageId, ClientCoverageOverrides>`}],raw:`Partial<Record<CoverageId, ClientCoverageOverrides>>`,required:!1}},{key:`allCategoriesExpanded`,value:{name:`boolean`,required:!1},description:`When true, all coverage category accordions are expanded by default.`},{key:`estimatedRateDisplay`,value:{name:`signature`,type:`object`,raw:`{
  showFrequencyToggle?: boolean;
  defaultFrequency?: EstimatedRateFrequency;
}`,signature:{properties:[{key:`showFrequencyToggle`,value:{name:`boolean`,required:!1}},{key:`defaultFrequency`,value:{name:`union`,raw:`"monthly" | "annual"`,elements:[{name:`literal`,value:`"monthly"`},{name:`literal`,value:`"annual"`}],required:!1}}]},required:!1}},{key:`additionalCoverageWarning`,value:{name:`union`,raw:`"applyForAdditional" | "applyForTotal"`,elements:[{name:`literal`,value:`"applyForAdditional"`},{name:`literal`,value:`"applyForTotal"`}],required:!1},description:`Controls the wording of the "apply for additional coverage" warning on the Coverage page.
"applyForAdditional" (default): "...apply only for the additional coverage you want."
"applyForTotal": "...apply for the total amount of coverage you want (amount you currently have + amount you're requesting)."`},{key:`productEstimatedCostBreakdown`,value:{name:`signature`,type:`object`,raw:`{
  enabled?: boolean;
  policyFee?: {
    label?: string;
    amount: ClientAmountByFrequency;
  };
  childApplicantRider?: {
    enabled?: boolean;
    label?: string;
    amount?: ClientAmountByFrequency;
  };
}`,signature:{properties:[{key:`enabled`,value:{name:`boolean`,required:!1}},{key:`policyFee`,value:{name:`signature`,type:`object`,raw:`{
  label?: string;
  amount: ClientAmountByFrequency;
}`,signature:{properties:[{key:`label`,value:{name:`string`,required:!1}},{key:`amount`,value:{name:`signature`,type:`object`,raw:`{
  monthly?: number;
  annual?: number;
}`,signature:{properties:[{key:`monthly`,value:{name:`number`,required:!1}},{key:`annual`,value:{name:`number`,required:!1}}]},required:!1}}]},required:!1}},{key:`childApplicantRider`,value:{name:`signature`,type:`object`,raw:`{
  enabled?: boolean;
  label?: string;
  amount?: ClientAmountByFrequency;
}`,signature:{properties:[{key:`enabled`,value:{name:`boolean`,required:!1}},{key:`label`,value:{name:`string`,required:!1}},{key:`amount`,value:{name:`signature`,type:`object`,raw:`{
  monthly?: number;
  annual?: number;
}`,signature:{properties:[{key:`monthly`,value:{name:`number`,required:!1}},{key:`annual`,value:{name:`number`,required:!1}}]},required:!1}}]},required:!1}}]},required:!1},description:`Product-card estimated cost breakdown config (optional per client).`},{key:`categorySectionLabels`,value:{name:`Partial`,elements:[{name:`Record`,elements:[{name:`unknown[number]["id"]`,raw:`CoverageCategory["id"]`,required:!1},{name:`string`}],raw:`Record<CoverageCategoryId, string>`}],raw:`Partial<Record<CoverageCategoryId, string>>`,required:!1},description:`Override the default coverage category section header labels (e.g. "Office Overhead Expense").`},{key:`hideSmokerQuestion`,value:{name:`boolean`,required:!1},description:`When true, the quote tool and coverage questions skip the smoker/nicotine question for this client.`}]},required:!0}},{key:`fields`,value:{name:`Partial`,elements:[{name:`Record`,elements:[{name:`unknown[number]["id"]`,raw:`Page["id"]`,required:!1},{name:`signature`,type:`object`,raw:`{
  extra?: FieldId[];
  hidden?: FieldId[];
  required?: FieldId[];
  overrides?: Partial<Record<FieldId, Partial<FieldDefinition>>>;
}`,signature:{properties:[{key:`extra`,value:{name:`Array`,elements:[{name:`string`}],raw:`FieldId[]`,required:!1}},{key:`hidden`,value:{name:`Array`,elements:[{name:`string`}],raw:`FieldId[]`,required:!1}},{key:`required`,value:{name:`Array`,elements:[{name:`string`}],raw:`FieldId[]`,required:!1}},{key:`overrides`,value:{name:`Partial`,elements:[{name:`Record`,elements:[{name:`string`},{name:`Partial`,elements:[{name:`signature`,type:`object`,raw:`{
  id: string;
  label: string;
  tooltip?: string;
  inputType: FieldInputType;
  required?: boolean;
  placeholder?: string;
  helperText?: string;
  options?: FieldOption[];
  autoComplete?: string;
  inputMode?: "text" | "email" | "tel" | "numeric";
  format?: "email" | "phone" | "ssn" | "currency" | "percent" | "month-year";
  labelVariant?: "floating" | "standard";
  multiline?: boolean;
  minRows?: number;
  disabled?: boolean;
  /** Override the companion phone-type field name (default: "phone-type") */
  phoneTypeFieldId?: string;
  /** Whether to show the companion phone type selector (default: true) */
  showPhoneTypeSelector?: boolean;
}`,signature:{properties:[{key:`id`,value:{name:`string`,required:!0}},{key:`label`,value:{name:`string`,required:!0}},{key:`tooltip`,value:{name:`string`,required:!1}},{key:`inputType`,value:{name:`union`,raw:`| "text"
| "number"
| "date"
| "radio"
| "dropdown"
| "searchable-select"
| "checkbox"
| "checkbox-group"
| "multi-select"
| "percent"`,elements:[{name:`literal`,value:`"text"`},{name:`literal`,value:`"number"`},{name:`literal`,value:`"date"`},{name:`literal`,value:`"radio"`},{name:`literal`,value:`"dropdown"`},{name:`literal`,value:`"searchable-select"`},{name:`literal`,value:`"checkbox"`},{name:`literal`,value:`"checkbox-group"`},{name:`literal`,value:`"multi-select"`},{name:`literal`,value:`"percent"`}],required:!0}},{key:`required`,value:{name:`boolean`,required:!1}},{key:`placeholder`,value:{name:`string`,required:!1}},{key:`helperText`,value:{name:`string`,required:!1}},{key:`options`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  value: string;
  label: string;
}`,signature:{properties:[{key:`value`,value:{name:`string`,required:!0}},{key:`label`,value:{name:`string`,required:!0}}]}}],raw:`FieldOption[]`,required:!1}},{key:`autoComplete`,value:{name:`string`,required:!1}},{key:`inputMode`,value:{name:`union`,raw:`"text" | "email" | "tel" | "numeric"`,elements:[{name:`literal`,value:`"text"`},{name:`literal`,value:`"email"`},{name:`literal`,value:`"tel"`},{name:`literal`,value:`"numeric"`}],required:!1}},{key:`format`,value:{name:`union`,raw:`"email" | "phone" | "ssn" | "currency" | "percent" | "month-year"`,elements:[{name:`literal`,value:`"email"`},{name:`literal`,value:`"phone"`},{name:`literal`,value:`"ssn"`},{name:`literal`,value:`"currency"`},{name:`literal`,value:`"percent"`},{name:`literal`,value:`"month-year"`}],required:!1}},{key:`labelVariant`,value:{name:`union`,raw:`"floating" | "standard"`,elements:[{name:`literal`,value:`"floating"`},{name:`literal`,value:`"standard"`}],required:!1}},{key:`multiline`,value:{name:`boolean`,required:!1}},{key:`minRows`,value:{name:`number`,required:!1}},{key:`disabled`,value:{name:`boolean`,required:!1}},{key:`phoneTypeFieldId`,value:{name:`string`,required:!1},description:`Override the companion phone-type field name (default: "phone-type")`},{key:`showPhoneTypeSelector`,value:{name:`boolean`,required:!1},description:`Whether to show the companion phone type selector (default: true)`}]}}],raw:`Partial<FieldDefinition>`}],raw:`Record<FieldId, Partial<FieldDefinition>>`}],raw:`Partial<Record<FieldId, Partial<FieldDefinition>>>`,required:!1}}]}}],raw:`Record<
  PageId,
  {
    extra?: FieldId[];
    hidden?: FieldId[];
    required?: FieldId[];
    overrides?: Partial<Record<FieldId, Partial<FieldDefinition>>>;
  }
>`}],raw:`Partial<
  Record<
    PageId,
    {
      extra?: FieldId[];
      hidden?: FieldId[];
      required?: FieldId[];
      overrides?: Partial<Record<FieldId, Partial<FieldDefinition>>>;
    }
  >
>`,required:!0}},{key:`flows`,value:{name:`signature`,type:`object`,raw:`{
  /** Client-specific replacements for global flow definitions. Resolved through resolveClientFlows. */
  overrides?: Partial<Record<FlowId, FlowDefinition>>;
}`,signature:{properties:[{key:`overrides`,value:{name:`Partial`,elements:[{name:`Record`,elements:[{name:`union`,raw:`| "consumer"
| "advisor"
| "resume"
| "autosave"
| "quote"
| "tpaVerification"`,elements:[{name:`literal`,value:`"consumer"`},{name:`literal`,value:`"advisor"`},{name:`literal`,value:`"resume"`},{name:`literal`,value:`"autosave"`},{name:`literal`,value:`"quote"`},{name:`literal`,value:`"tpaVerification"`}],required:!0},{name:`signature`,type:`object`,raw:`{
  id: FlowId;
  title: string;
  /** Framing prose, rendered once above the diagram. */
  intro: string;
  nodes: FlowNodeDef[];
  edges: FlowEdgeDef[];
}`,signature:{properties:[{key:`id`,value:{name:`union`,raw:`| "consumer"
| "advisor"
| "resume"
| "autosave"
| "quote"
| "tpaVerification"`,elements:[{name:`literal`,value:`"consumer"`},{name:`literal`,value:`"advisor"`},{name:`literal`,value:`"resume"`},{name:`literal`,value:`"autosave"`},{name:`literal`,value:`"quote"`},{name:`literal`,value:`"tpaVerification"`}],required:!0}},{key:`title`,value:{name:`string`,required:!0}},{key:`intro`,value:{name:`string`,required:!0},description:`Framing prose, rendered once above the diagram.`},{key:`nodes`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  /** Flow-local id, conventionally \`\${flowId}-\${slug}\`. Independent of pageId. */
  id: string;
  kind: FlowNodeKind;
  label: string;
  description?: string;
  /** Only present when kind === "page" — the real page this node represents. */
  pageId?: PageId;
}`,signature:{properties:[{key:`id`,value:{name:`string`,required:!0},description:"Flow-local id, conventionally `${flowId}-${slug}`. Independent of pageId."},{key:`kind`,value:{name:`union`,raw:`| "start" // flow entry point that isn't itself a routed page
| "end" // terminal state that isn't itself a routed page
| "page" // maps to a real PageId — must carry pageId
| "decision" // user/system branch point with more than one outgoing labeled edge
| "action" // a dialog/modal/system step that isn't a routed page (e.g. SendApplicationDialog)
| "summary" // stands in for a set of real pages that aren't sequential/branchable in a documented way
| "external"`,elements:[{name:`literal`,value:`"start"`},{name:`literal`,value:`"end"`},{name:`literal`,value:`"page"`},{name:`literal`,value:`"decision"`},{name:`literal`,value:`"action"`},{name:`literal`,value:`"summary"`},{name:`literal`,value:`"external"`}],required:!0}},{key:`label`,value:{name:`string`,required:!0}},{key:`description`,value:{name:`string`,required:!1}},{key:`pageId`,value:{name:`unknown[number]["id"]`,raw:`Page["id"]`,required:!1},description:`Only present when kind === "page" — the real page this node represents.`}]}}],raw:`FlowNodeDef[]`,required:!0}},{key:`edges`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  id: string;
  source: string; // FlowNodeDef.id
  target: string; // FlowNodeDef.id
  /** Branch label, e.g. "Send", "Cancel", "Text code", "Unsuccessful". Undefined for unconditional edges. */
  condition?: string;
  styleHint?: FlowEdgeStyleHint;
}`,signature:{properties:[{key:`id`,value:{name:`string`,required:!0}},{key:`source`,value:{name:`string`,required:!0}},{key:`target`,value:{name:`string`,required:!0}},{key:`condition`,value:{name:`string`,required:!1},description:`Branch label, e.g. "Send", "Cancel", "Text code", "Unsuccessful". Undefined for unconditional edges.`},{key:`styleHint`,value:{name:`union`,raw:`| "normal"
| "loop-back" // returns to an earlier node (e.g. cancel, unsuccessful verification)
| "dialog-return"`,elements:[{name:`literal`,value:`"normal"`},{name:`literal`,value:`"loop-back"`},{name:`literal`,value:`"dialog-return"`}],required:!1}}]}}],raw:`FlowEdgeDef[]`,required:!0}}]}}],raw:`Record<FlowId, FlowDefinition>`}],raw:`Partial<Record<FlowId, FlowDefinition>>`,required:!1},description:`Client-specific replacements for global flow definitions. Resolved through resolveClientFlows.`}]},required:!1},description:`Client-specific flow overrides; global flows remain the baseline source of truth.`},{key:`emailSupport`,value:{name:`signature`,type:`object`,raw:`{
  /** When true, suppresses the "Questions? We're here to help" contact box in this client's outbound emails. */
  hideContactBox?: boolean;
  /** Overrides the client-configured phone/email/website shown in the email support box. */
  supportOverride?: ClientEmailSupportOverride;
  /** Overrides the client-configured name/acronym used for the contact shown in the email support box. */
  contactOverride?: ClientEmailContactOverride;
}`,signature:{properties:[{key:`hideContactBox`,value:{name:`boolean`,required:!1},description:`When true, suppresses the "Questions? We're here to help" contact box in this client's outbound emails.`},{key:`supportOverride`,value:{name:`signature`,type:`object`,raw:`{
  phone?: string;
  email?: string;
  website?: string;
}`,signature:{properties:[{key:`phone`,value:{name:`string`,required:!1}},{key:`email`,value:{name:`string`,required:!1}},{key:`website`,value:{name:`string`,required:!1}}]},required:!1},description:`Overrides the client-configured phone/email/website shown in the email support box.`},{key:`contactOverride`,value:{name:`signature`,type:`object`,raw:`{
  name?: string;
  acronym?: string;
}`,signature:{properties:[{key:`name`,value:{name:`string`,required:!1}},{key:`acronym`,value:{name:`string`,required:!1}}]},required:!1},description:`Overrides the client-configured name/acronym used for the contact shown in the email support box.`}]},required:!1},description:`Per-client configuration for the "Questions? We're here to help" contact box in outbound emails.`},{key:`content`,value:{name:`signature`,type:`object`,raw:`{
  global?: {
    banners?: string[];
    disclaimers?: string[];
  };
  pages?: Partial<
    Record<
      PageId,
      {
        intro?: string;
        help?: string[];
        banners?: string[];
        disclaimers?: string[];
      }
    >
  >;
}`,signature:{properties:[{key:`global`,value:{name:`signature`,type:`object`,raw:`{
  banners?: string[];
  disclaimers?: string[];
}`,signature:{properties:[{key:`banners`,value:{name:`Array`,elements:[{name:`string`}],raw:`string[]`,required:!1}},{key:`disclaimers`,value:{name:`Array`,elements:[{name:`string`}],raw:`string[]`,required:!1}}]},required:!1}},{key:`pages`,value:{name:`Partial`,elements:[{name:`Record`,elements:[{name:`unknown[number]["id"]`,raw:`Page["id"]`,required:!1},{name:`signature`,type:`object`,raw:`{
  intro?: string;
  help?: string[];
  banners?: string[];
  disclaimers?: string[];
}`,signature:{properties:[{key:`intro`,value:{name:`string`,required:!1}},{key:`help`,value:{name:`Array`,elements:[{name:`string`}],raw:`string[]`,required:!1}},{key:`banners`,value:{name:`Array`,elements:[{name:`string`}],raw:`string[]`,required:!1}},{key:`disclaimers`,value:{name:`Array`,elements:[{name:`string`}],raw:`string[]`,required:!1}}]}}],raw:`Record<
  PageId,
  {
    intro?: string;
    help?: string[];
    banners?: string[];
    disclaimers?: string[];
  }
>`}],raw:`Partial<
  Record<
    PageId,
    {
      intro?: string;
      help?: string[];
      banners?: string[];
      disclaimers?: string[];
    }
  >
>`,required:!1}}]},required:!1},description:`@deprecated Content is now managed in src/content/. This field is unused.`},{key:`features`,value:{name:`signature`,type:`object`,raw:`{
  chat?: boolean;
  chatUrl?: string;
  scheduleUrl?: string;
  linkUrl?: string;
  linkLabel?: string;
  homePageVariant?: HomePageVariant;
  defaultTemplate?: FormTemplate;
}`,signature:{properties:[{key:`chat`,value:{name:`boolean`,required:!1}},{key:`chatUrl`,value:{name:`string`,required:!1}},{key:`scheduleUrl`,value:{name:`string`,required:!1}},{key:`linkUrl`,value:{name:`string`,required:!1}},{key:`linkLabel`,value:{name:`string`,required:!1}},{key:`homePageVariant`,value:{name:`union`,raw:`"default" | "hero-image" | "welcome-back"`,elements:[{name:`literal`,value:`"default"`},{name:`literal`,value:`"hero-image"`},{name:`literal`,value:`"welcome-back"`}],required:!1}},{key:`defaultTemplate`,value:{name:`union`,raw:`"single" | "multi"`,elements:[{name:`literal`,value:`"single"`},{name:`literal`,value:`"multi"`}],required:!1}}]},required:!1}},{key:`theme`,value:{name:`union`,raw:`| {
    type: "preset";
    preset: ThemeColorId;
    primary?: never;
  }
| {
    type: "custom";
    primary: \`#\${string}\`;
    preset?: never;
  }`,elements:[{name:`signature`,type:`object`,raw:`{
  type: "preset";
  preset: ThemeColorId;
  primary?: never;
}`,signature:{properties:[{key:`type`,value:{name:`literal`,value:`"preset"`,required:!0}},{key:`preset`,value:{name:`union`,raw:`"default" | "teal" | "purple" | "dark-blue"`,elements:[{name:`literal`,value:`"default"`},{name:`literal`,value:`"teal"`},{name:`literal`,value:`"purple"`},{name:`literal`,value:`"dark-blue"`}],required:!0}},{key:`primary`,value:{name:`never`,required:!1}}]}},{name:`signature`,type:`object`,raw:`{
  type: "custom";
  primary: \`#\${string}\`;
  preset?: never;
}`,signature:{properties:[{key:`type`,value:{name:`literal`,value:`"custom"`,required:!0}},{key:`primary`,value:{name:`literal`,value:"`#${string}`",required:!0}},{key:`preset`,value:{name:`never`,required:!1}}]}}],required:!1},description:`Site-level brand color input. Semantic and neutral colors remain application-controlled.`},{key:`licenseInfo`,value:{name:`Array`,elements:[{name:`string`}],raw:`string[]`,required:!1}},{key:`coverageQuestions`,value:{name:`intersection`,raw:`{
  /** Sections always shown when any category is selected. */
  always?: PageSectionId[];
  /** Section IDs to remove from the default section sets for all categories. */
  removeDefaults?: PageSectionId[];
} & Partial<Record<CoverageCategoryId, PageSectionId[]>>`,elements:[{name:`signature`,type:`object`,raw:`{
  /** Sections always shown when any category is selected. */
  always?: PageSectionId[];
  /** Section IDs to remove from the default section sets for all categories. */
  removeDefaults?: PageSectionId[];
}`,signature:{properties:[{key:`always`,value:{name:`Array`,elements:[{name:`union`,raw:`| "default"
| "selfEligibility"
| "dependentSelection"
| "spouseSection"
| "childSection"
| "selfCoverageQuestions"
| "selfCoverageTobacco"
| "selfCoverageWorkIncome"
| "selfCoverageBusinessExpenses"
| "spouseCoverageQuestions"
| "spouseCoverageTobacco"
| "spouseCoverageWorkIncome"
| "contactResidentialAddress"
| "contactBusinessInfo"
| "contactSpouse"
| "profilePersonalSelf"
| "profilePersonalSelfDriversLicense"
| "profilePersonalSelfOutsideUs"
| "profilePersonalSelfTravelOutsideUs"
| "profilePersonalSelfPhysician"
| "profilePersonalSpouse"
| "profilePersonalSpouseDriversLicense"
| "profilePersonalSpouseOutsideUs"
| "profilePersonalSpouseTravelOutsideUs"
| "profilePersonalSpousePhysician"
| "profileFinancialSelf"
| "profileFinancialQuestionnaireSelf"
| "profileFinancialSpouse"
| "advisorLoginNew"
| "advisorLoginSaved"`,elements:[{name:`literal`,value:`"default"`},{name:`literal`,value:`"selfEligibility"`},{name:`literal`,value:`"dependentSelection"`},{name:`literal`,value:`"spouseSection"`},{name:`literal`,value:`"childSection"`},{name:`literal`,value:`"selfCoverageQuestions"`},{name:`literal`,value:`"selfCoverageTobacco"`},{name:`literal`,value:`"selfCoverageWorkIncome"`},{name:`literal`,value:`"selfCoverageBusinessExpenses"`},{name:`literal`,value:`"spouseCoverageQuestions"`},{name:`literal`,value:`"spouseCoverageTobacco"`},{name:`literal`,value:`"spouseCoverageWorkIncome"`},{name:`literal`,value:`"contactResidentialAddress"`},{name:`literal`,value:`"contactBusinessInfo"`},{name:`literal`,value:`"contactSpouse"`},{name:`literal`,value:`"profilePersonalSelf"`},{name:`literal`,value:`"profilePersonalSelfDriversLicense"`},{name:`literal`,value:`"profilePersonalSelfOutsideUs"`},{name:`literal`,value:`"profilePersonalSelfTravelOutsideUs"`},{name:`literal`,value:`"profilePersonalSelfPhysician"`},{name:`literal`,value:`"profilePersonalSpouse"`},{name:`literal`,value:`"profilePersonalSpouseDriversLicense"`},{name:`literal`,value:`"profilePersonalSpouseOutsideUs"`},{name:`literal`,value:`"profilePersonalSpouseTravelOutsideUs"`},{name:`literal`,value:`"profilePersonalSpousePhysician"`},{name:`literal`,value:`"profileFinancialSelf"`},{name:`literal`,value:`"profileFinancialQuestionnaireSelf"`},{name:`literal`,value:`"profileFinancialSpouse"`},{name:`literal`,value:`"advisorLoginNew"`},{name:`literal`,value:`"advisorLoginSaved"`}]}],raw:`PageSectionId[]`,required:!1},description:`Sections always shown when any category is selected.`},{key:`removeDefaults`,value:{name:`Array`,elements:[{name:`union`,raw:`| "default"
| "selfEligibility"
| "dependentSelection"
| "spouseSection"
| "childSection"
| "selfCoverageQuestions"
| "selfCoverageTobacco"
| "selfCoverageWorkIncome"
| "selfCoverageBusinessExpenses"
| "spouseCoverageQuestions"
| "spouseCoverageTobacco"
| "spouseCoverageWorkIncome"
| "contactResidentialAddress"
| "contactBusinessInfo"
| "contactSpouse"
| "profilePersonalSelf"
| "profilePersonalSelfDriversLicense"
| "profilePersonalSelfOutsideUs"
| "profilePersonalSelfTravelOutsideUs"
| "profilePersonalSelfPhysician"
| "profilePersonalSpouse"
| "profilePersonalSpouseDriversLicense"
| "profilePersonalSpouseOutsideUs"
| "profilePersonalSpouseTravelOutsideUs"
| "profilePersonalSpousePhysician"
| "profileFinancialSelf"
| "profileFinancialQuestionnaireSelf"
| "profileFinancialSpouse"
| "advisorLoginNew"
| "advisorLoginSaved"`,elements:[{name:`literal`,value:`"default"`},{name:`literal`,value:`"selfEligibility"`},{name:`literal`,value:`"dependentSelection"`},{name:`literal`,value:`"spouseSection"`},{name:`literal`,value:`"childSection"`},{name:`literal`,value:`"selfCoverageQuestions"`},{name:`literal`,value:`"selfCoverageTobacco"`},{name:`literal`,value:`"selfCoverageWorkIncome"`},{name:`literal`,value:`"selfCoverageBusinessExpenses"`},{name:`literal`,value:`"spouseCoverageQuestions"`},{name:`literal`,value:`"spouseCoverageTobacco"`},{name:`literal`,value:`"spouseCoverageWorkIncome"`},{name:`literal`,value:`"contactResidentialAddress"`},{name:`literal`,value:`"contactBusinessInfo"`},{name:`literal`,value:`"contactSpouse"`},{name:`literal`,value:`"profilePersonalSelf"`},{name:`literal`,value:`"profilePersonalSelfDriversLicense"`},{name:`literal`,value:`"profilePersonalSelfOutsideUs"`},{name:`literal`,value:`"profilePersonalSelfTravelOutsideUs"`},{name:`literal`,value:`"profilePersonalSelfPhysician"`},{name:`literal`,value:`"profilePersonalSpouse"`},{name:`literal`,value:`"profilePersonalSpouseDriversLicense"`},{name:`literal`,value:`"profilePersonalSpouseOutsideUs"`},{name:`literal`,value:`"profilePersonalSpouseTravelOutsideUs"`},{name:`literal`,value:`"profilePersonalSpousePhysician"`},{name:`literal`,value:`"profileFinancialSelf"`},{name:`literal`,value:`"profileFinancialQuestionnaireSelf"`},{name:`literal`,value:`"profileFinancialSpouse"`},{name:`literal`,value:`"advisorLoginNew"`},{name:`literal`,value:`"advisorLoginSaved"`}]}],raw:`PageSectionId[]`,required:!1},description:`Section IDs to remove from the default section sets for all categories.`}]}},{name:`Partial`,elements:[{name:`Record`,elements:[{name:`unknown[number]["id"]`,raw:`CoverageCategory["id"]`,required:!1},{name:`Array`,elements:[{name:`union`,raw:`| "default"
| "selfEligibility"
| "dependentSelection"
| "spouseSection"
| "childSection"
| "selfCoverageQuestions"
| "selfCoverageTobacco"
| "selfCoverageWorkIncome"
| "selfCoverageBusinessExpenses"
| "spouseCoverageQuestions"
| "spouseCoverageTobacco"
| "spouseCoverageWorkIncome"
| "contactResidentialAddress"
| "contactBusinessInfo"
| "contactSpouse"
| "profilePersonalSelf"
| "profilePersonalSelfDriversLicense"
| "profilePersonalSelfOutsideUs"
| "profilePersonalSelfTravelOutsideUs"
| "profilePersonalSelfPhysician"
| "profilePersonalSpouse"
| "profilePersonalSpouseDriversLicense"
| "profilePersonalSpouseOutsideUs"
| "profilePersonalSpouseTravelOutsideUs"
| "profilePersonalSpousePhysician"
| "profileFinancialSelf"
| "profileFinancialQuestionnaireSelf"
| "profileFinancialSpouse"
| "advisorLoginNew"
| "advisorLoginSaved"`,elements:[{name:`literal`,value:`"default"`},{name:`literal`,value:`"selfEligibility"`},{name:`literal`,value:`"dependentSelection"`},{name:`literal`,value:`"spouseSection"`},{name:`literal`,value:`"childSection"`},{name:`literal`,value:`"selfCoverageQuestions"`},{name:`literal`,value:`"selfCoverageTobacco"`},{name:`literal`,value:`"selfCoverageWorkIncome"`},{name:`literal`,value:`"selfCoverageBusinessExpenses"`},{name:`literal`,value:`"spouseCoverageQuestions"`},{name:`literal`,value:`"spouseCoverageTobacco"`},{name:`literal`,value:`"spouseCoverageWorkIncome"`},{name:`literal`,value:`"contactResidentialAddress"`},{name:`literal`,value:`"contactBusinessInfo"`},{name:`literal`,value:`"contactSpouse"`},{name:`literal`,value:`"profilePersonalSelf"`},{name:`literal`,value:`"profilePersonalSelfDriversLicense"`},{name:`literal`,value:`"profilePersonalSelfOutsideUs"`},{name:`literal`,value:`"profilePersonalSelfTravelOutsideUs"`},{name:`literal`,value:`"profilePersonalSelfPhysician"`},{name:`literal`,value:`"profilePersonalSpouse"`},{name:`literal`,value:`"profilePersonalSpouseDriversLicense"`},{name:`literal`,value:`"profilePersonalSpouseOutsideUs"`},{name:`literal`,value:`"profilePersonalSpouseTravelOutsideUs"`},{name:`literal`,value:`"profilePersonalSpousePhysician"`},{name:`literal`,value:`"profileFinancialSelf"`},{name:`literal`,value:`"profileFinancialQuestionnaireSelf"`},{name:`literal`,value:`"profileFinancialSpouse"`},{name:`literal`,value:`"advisorLoginNew"`},{name:`literal`,value:`"advisorLoginSaved"`}]}],raw:`PageSectionId[]`}],raw:`Record<CoverageCategoryId, PageSectionId[]>`}],raw:`Partial<Record<CoverageCategoryId, PageSectionId[]>>`}],required:!1}},{key:`applicantLabels`,value:{name:`signature`,type:`object`,raw:`{
  member?: string;
  spouse?: string;
  child?: string;
}`,signature:{properties:[{key:`member`,value:{name:`string`,required:!1}},{key:`spouse`,value:{name:`string`,required:!1}},{key:`child`,value:{name:`string`,required:!1}}]},required:!1},description:`Override default applicant section header labels. Max 20 chars each.`},{key:`siteUrls`,value:{name:`signature`,type:`object`,raw:`{
  testing?: string;
  preProduction?: string;
  production?: string;
}`,signature:{properties:[{key:`testing`,value:{name:`string`,required:!1}},{key:`preProduction`,value:{name:`string`,required:!1}},{key:`production`,value:{name:`string`,required:!1}}]},required:!1},description:`Deployment environment links for this client's site. Unset until provisioned.`},{key:`urlParametersInUse`,value:{name:`Array`,elements:[{name:`string`}],raw:`string[]`,required:!1},description:`Query-string parameters (from src/content/docs/urlParameters.ts) this client actually uses in live URLs. Unset/empty until confirmed.`}]}},description:``}}}}));export{w as n,x as t};