import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t}from"./esm-AWQ-KJXU.js";import{n,t as r}from"./getActiveClient-DQgJg1Xd.js";import{n as i,t as a}from"./ClientHelpBanner-BU-ELA1b.js";var o,s,c,l;e((()=>{i(),n(),o=t(),s={title:`Layout/ClientHelpBanner`,component:a,parameters:{layout:`fullscreen`,docs:{description:{component:`ClientHelpBanner is the full-bleed support bar (call/chat/link/schedule)
shown by AppHeader whenever the active client has a support phone
number configured — it returns null entirely otherwise. Uses a
\`100vw\`/negative-margin trick to bleed edge-to-edge regardless of its
parent's max-width. Every action button is conditionally rendered based
on the real active client's \`support\`/\`features\` config, not props of
its own — this story uses the real default client rather than
fabricating a client object, so which buttons show is itself real
information.`}}}},c={render:()=>(0,o.jsx)(a,{client:r()}),parameters:{docs:{description:{story:`Renders with the real active ("demo") client's support config via getActiveClient() — not props of its own. The toolbar's Theme control only swaps createAppTheme's color preset, not the active client, so it won't change which buttons appear here; that's driven by the client resolved from the URL/sessionStorage, which Storybook has no override for.`}}}},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  render: () => <ClientHelpBanner client={getActiveClient()} />,
  parameters: {
    docs: {
      description: {
        story: "Renders with the real active (\\"demo\\") client's support config via getActiveClient() — not props of its own. The toolbar's Theme control only swaps createAppTheme's color preset, not the active client, so it won't change which buttons appear here; that's driven by the client resolved from the URL/sessionStorage, which Storybook has no override for."
      }
    }
  }
}`,...c.parameters?.docs?.source}}},l=[`Default`]}))();export{c as Default,l as __namedExportsOrder,s as default};