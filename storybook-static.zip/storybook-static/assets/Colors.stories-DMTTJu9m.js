import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,S as n,St as r,Tt as i,at as a,c as o,dt as s,f as c,ft as l,t as u}from"./esm-AWQ-KJXU.js";import{a as d,i as f}from"./theme-B3ct2zHf.js";import{i as p,n as m,o as h,r as g,s as _,t as v}from"./DocsBlocks-BEbHO4Nl.js";var y,b,x,S,C;e((()=>{r(),u(),d(),_(),y=t(),b={title:`Foundations/Colors`,parameters:{layout:`padded`}},x=[`default`,`teal`,`purple`,`dark-blue`],S=()=>{let e=i(),t=[{label:`primary.main`,value:e.palette.primary.main,note:`Active client brand color`},{label:`primary.light`,value:e.palette.primary.light},{label:`primary.dark`,value:e.palette.primary.dark},{label:`success.main`,value:e.palette.success.main,note:`Reserved — confirmations only`},{label:`error.main`,value:e.palette.error.main,note:`Reserved — errors only`}],r=[{label:`text.primary`,value:e.palette.text.primary},{label:`text.secondary`,value:e.palette.text.secondary},{label:`text.tertiary`,value:e.palette.text.tertiary},{label:`text.disabled`,value:e.palette.text.disabled},{label:`background.default`,value:e.palette.background.default},{label:`background.paper`,value:e.palette.background.paper},{label:`background.subtle`,value:e.palette.background.subtle},{label:`background.surface`,value:e.palette.background.surface},{label:`background.iconBadge`,value:e.palette.background.iconBadge},{label:`divider`,value:e.palette.divider}],u=[{label:`panel.main`,value:e.palette.panel.main,note:`border ${e.palette.panel.border}`},{label:`notice.main`,value:e.palette.notice.main,note:`border ${e.palette.notice.border}`},{label:`support.main`,value:e.palette.support.main,note:`border ${e.palette.support.border}`}],d=x.map(e=>{let t=f(e);return{id:e,main:t.palette.primary.main,light:t.palette.primary.light,dark:t.palette.primary.dark}});return(0,y.jsxs)(v,{eyebrow:`Foundations`,title:`Colors`,intro:`Palette tokens defined in src/app/theme.ts. Success and error are reserved semantic colors — see the reserved-color rule below. Values on this page are read live from the active theme, so switching the toolbar's Theme control re-renders every swatch against the real per-client palette.`,children:[(0,y.jsxs)(m,{title:`Brand & semantic`,description:`primary is the one token every client theme preset changes. success and error never change per client.`,children:[(0,y.jsx)(h,{swatches:t}),(0,y.jsx)(p,{children:`src/app/theme.ts — palette.primary / palette.success / palette.error`})]}),(0,y.jsxs)(m,{title:`Text & surface neutrals`,description:`Fixed across every client preset.`,children:[(0,y.jsx)(h,{swatches:r}),(0,y.jsx)(p,{children:`src/app/theme.ts — palette.text / palette.background / palette.divider`})]}),(0,y.jsxs)(m,{title:`Contextual containers`,description:`panel = neutral info panels · notice = caution/notice boxes · support = help/support callouts. Custom palette groups added via MUI's Palette module augmentation, not part of MUI's default palette shape.`,children:[(0,y.jsx)(h,{swatches:u}),(0,y.jsx)(p,{children:`src/app/theme.ts — palette.panel / palette.notice / palette.support`})]}),(0,y.jsxs)(m,{title:`Client brand presets (ThemeColorId)`,description:`A preset-configured client selects one approved ID. Only the primary palette changes; all global semantic and neutral tokens stay fixed.`,children:[(0,y.jsx)(g,{columns:[`Preset`,`Main`,`Light`,`Dark`],children:d.map(e=>(0,y.jsxs)(o,{children:[(0,y.jsx)(c,{sx:{fontWeight:700},children:e.id}),[e.main,e.light,e.dark].map(e=>(0,y.jsx)(c,{children:(0,y.jsxs)(n,{direction:`row`,spacing:1,alignItems:`center`,children:[(0,y.jsx)(a,{sx:{width:20,height:20,borderRadius:1,backgroundColor:e,border:`1px solid rgba(0,0,0,0.08)`,flexShrink:0}}),(0,y.jsx)(s,{variant:`caption`,sx:{fontFamily:`monospace`},children:e})]})},e))]},e.id))}),(0,y.jsx)(p,{children:`src/app/theme.ts — createAppTheme({ type: "preset", preset }), themeColorPalettes`})]}),(0,y.jsxs)(m,{title:`Custom client primary`,description:`A custom-configured client supplies one primary hex value. MUI derives light, dark, and contrastText; clients do not configure those values individually.`,children:[(()=>{let e=f({type:`custom`,primary:`#6750a4`}).palette.primary;return(0,y.jsx)(h,{swatches:[{label:`primary.main (input)`,value:e.main},{label:`primary.light (derived)`,value:e.light},{label:`primary.dark (derived)`,value:e.dark},{label:`primary.contrastText (derived)`,value:e.contrastText}]})})(),(0,y.jsx)(p,{children:`src/app/theme.ts — resolvePrimaryPalette; ClientConfig.theme`})]}),(0,y.jsx)(m,{title:`Reserved theme colors`,children:(0,y.jsx)(l,{severity:`warning`,sx:{maxWidth:760},children:`Approved presets are blue/teal/purple tones. Do not approve red, orange, green, or yellow as a custom client primary — those hues carry fixed meaning elsewhere in the UI (error, avoid, success, notice), and a matching brand color would make errors, success confirmations, or notices harder to distinguish from normal brand styling.`})})]})},S.__docgenInfo={description:`Reads every value straight from \`createAppTheme\` at render time — there is
no second hand-typed color list here. Switch the "Theme" control in the
toolbar above and the swatches on this page (and every other story) update
to match, since the whole Storybook preview is themed via the same
\`createAppTheme(context.globals.themeColor)\` preset call used by the
Storybook toolbar.`,methods:[],displayName:`Colors`},S.parameters={...S.parameters,docs:{...S.parameters?.docs,source:{originalSource:`() => {
  const theme = useTheme();
  const semantic: Swatch[] = [{
    label: "primary.main",
    value: theme.palette.primary.main,
    note: "Active client brand color"
  }, {
    label: "primary.light",
    value: theme.palette.primary.light
  }, {
    label: "primary.dark",
    value: theme.palette.primary.dark
  }, {
    label: "success.main",
    value: theme.palette.success.main,
    note: "Reserved — confirmations only"
  }, {
    label: "error.main",
    value: theme.palette.error.main,
    note: "Reserved — errors only"
  }];
  const neutrals: Swatch[] = [{
    label: "text.primary",
    value: theme.palette.text.primary
  }, {
    label: "text.secondary",
    value: theme.palette.text.secondary
  }, {
    label: "text.tertiary",
    value: theme.palette.text.tertiary
  }, {
    label: "text.disabled",
    value: theme.palette.text.disabled
  }, {
    label: "background.default",
    value: theme.palette.background.default
  }, {
    label: "background.paper",
    value: theme.palette.background.paper
  }, {
    label: "background.subtle",
    value: theme.palette.background.subtle
  }, {
    label: "background.surface",
    value: theme.palette.background.surface
  }, {
    label: "background.iconBadge",
    value: theme.palette.background.iconBadge
  }, {
    label: "divider",
    value: theme.palette.divider
  }];
  const containers: Swatch[] = [{
    label: "panel.main",
    value: theme.palette.panel.main,
    note: \`border \${theme.palette.panel.border}\`
  }, {
    label: "notice.main",
    value: theme.palette.notice.main,
    note: \`border \${theme.palette.notice.border}\`
  }, {
    label: "support.main",
    value: theme.palette.support.main,
    note: \`border \${theme.palette.support.border}\`
  }];
  const presets = PRESET_IDS.map(id => {
    const t = createAppTheme(id);
    return {
      id,
      main: t.palette.primary.main,
      light: t.palette.primary.light,
      dark: t.palette.primary.dark
    };
  });
  return <DocsPage eyebrow="Foundations" title="Colors" intro="Palette tokens defined in src/app/theme.ts. Success and error are reserved semantic colors — see the reserved-color rule below. Values on this page are read live from the active theme, so switching the toolbar's Theme control re-renders every swatch against the real per-client palette.">
      <DocsSection title="Brand & semantic" description="primary is the one token every client theme preset changes. success and error never change per client.">
        <SwatchRow swatches={semantic} />
        <SourceNote>src/app/theme.ts — palette.primary / palette.success / palette.error</SourceNote>
      </DocsSection>

      <DocsSection title="Text & surface neutrals" description="Fixed across every client preset.">
        <SwatchRow swatches={neutrals} />
        <SourceNote>src/app/theme.ts — palette.text / palette.background / palette.divider</SourceNote>
      </DocsSection>

      <DocsSection title="Contextual containers" description="panel = neutral info panels · notice = caution/notice boxes · support = help/support callouts. Custom palette groups added via MUI's Palette module augmentation, not part of MUI's default palette shape.">
        <SwatchRow swatches={containers} />
        <SourceNote>src/app/theme.ts — palette.panel / palette.notice / palette.support</SourceNote>
      </DocsSection>

      <DocsSection title="Client brand presets (ThemeColorId)" description="A preset-configured client selects one approved ID. Only the primary palette changes; all global semantic and neutral tokens stay fixed.">
        <DocsTable columns={["Preset", "Main", "Light", "Dark"]}>
          {presets.map(preset => <TableRow key={preset.id}>
              <TableCell sx={{
            fontWeight: 700
          }}>{preset.id}</TableCell>
              {[preset.main, preset.light, preset.dark].map(hex => <TableCell key={hex}>
                  <Stack direction="row" spacing={1} alignItems="center">
                    <Box sx={{
                width: 20,
                height: 20,
                borderRadius: 1,
                backgroundColor: hex,
                border: "1px solid rgba(0,0,0,0.08)",
                flexShrink: 0
              }} />
                    <Typography variant="caption" sx={{
                fontFamily: "monospace"
              }}>{hex}</Typography>
                  </Stack>
                </TableCell>)}
            </TableRow>)}
        </DocsTable>
        <SourceNote>src/app/theme.ts — createAppTheme(&#123; type: "preset", preset &#125;), themeColorPalettes</SourceNote>
      </DocsSection>

      <DocsSection title="Custom client primary" description="A custom-configured client supplies one primary hex value. MUI derives light, dark, and contrastText; clients do not configure those values individually.">
        {(() => {
        const customTheme = createAppTheme({
          type: "custom",
          primary: "#6750a4"
        });
        const custom = customTheme.palette.primary;
        return <SwatchRow swatches={[{
          label: "primary.main (input)",
          value: custom.main
        }, {
          label: "primary.light (derived)",
          value: custom.light
        }, {
          label: "primary.dark (derived)",
          value: custom.dark
        }, {
          label: "primary.contrastText (derived)",
          value: custom.contrastText
        }]} />;
      })()}
        <SourceNote>src/app/theme.ts — resolvePrimaryPalette; ClientConfig.theme</SourceNote>
      </DocsSection>

      <DocsSection title="Reserved theme colors">
        <Alert severity="warning" sx={{
        maxWidth: 760
      }}>
          Approved presets are blue/teal/purple tones. Do not approve red,
          orange, green, or yellow as a custom client primary — those
          hues carry fixed meaning elsewhere in the UI (error, avoid, success,
          notice), and a matching brand color would make errors, success
          confirmations, or notices harder to distinguish from normal brand
          styling.
        </Alert>
      </DocsSection>
    </DocsPage>;
}`,...S.parameters?.docs?.source},description:{story:`Reads every value straight from \`createAppTheme\` at render time — there is
no second hand-typed color list here. Switch the "Theme" control in the
toolbar above and the swatches on this page (and every other story) update
to match, since the whole Storybook preview is themed via the same
\`createAppTheme(context.globals.themeColor)\` preset call used by the
Storybook toolbar.`,...S.parameters?.docs?.description}}},C=[`Colors`]}))();export{S as Colors,C as __namedExportsOrder,b as default};