import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,at as n,t as r}from"./esm-AWQ-KJXU.js";function i({children:e}){return(0,a.jsx)(n,{sx:{ml:1,mt:1,px:2,py:0,borderLeft:`4px solid`,borderLeftColor:`primary.main`},children:e})}var a,o=e((()=>{r(),a=t(),i.__docgenInfo={description:`ConditionalGroup renders a left-bordered, indented container that visually
groups follow-up questions which are conditional on a prior answer.

This is a pure visual wrapper — the parent is responsible for deciding
when to render it. It does not own show/hide logic.`,methods:[],displayName:`ConditionalGroup`,props:{children:{required:!0,tsType:{name:`ReactNode`},description:``}}}}));export{o as n,i as t};