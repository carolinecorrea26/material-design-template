import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r,S as i,at as a,dt as o,t as s}from"./esm-AWQ-KJXU.js";import{i as c,n as l}from"./index.esm-DbA_UsRE.js";import{n as u,t as d}from"./FieldRenderer-DRJtoa2k.js";import{n as f,t as p}from"./ConditionalGroup-CP38wBp6.js";var m,h,g,_,v,y,b;t((()=>{m=e(n(),1),l(),s(),f(),u(),h=r(),g={title:`Forms/ConditionalGroup`,component:p,parameters:{layout:`padded`,docs:{description:{component:`ConditionalGroup is a pure visual wrapper — a left-bordered, indented
container marking follow-up content as conditional on a prior answer. It
owns no show/hide logic itself; the parent decides when to render it (its
parent decides when to render it. Health pages use YesNoDetailList for the
related numbered-question + repeatable-details pattern.`}}}},_={name:`Hidden vs. revealed (interactive)`,render:()=>{let{control:e,formState:t}=c({defaultValues:{"uses-tobacco":`no`,"tobacco-frequency":``}}),[n,r]=(0,m.useState)(`no`);return(0,h.jsxs)(a,{sx:{maxWidth:460},children:[(0,h.jsx)(o,{variant:`body2`,sx:{mb:2},children:`Toggle the question below — the follow-up field only exists in the DOM once "Yes" is selected. There is no hidden/collapsed markup left behind for "No".`}),(0,h.jsxs)(i,{spacing:1,direction:`row`,sx:{mb:2},children:[(0,h.jsx)(`button`,{type:`button`,onClick:()=>r(`no`),"aria-pressed":n===`no`,children:`Answer: No`}),(0,h.jsx)(`button`,{type:`button`,onClick:()=>r(`yes`),"aria-pressed":n===`yes`,children:`Answer: Yes`})]}),(0,h.jsx)(o,{variant:`body1`,sx:{mb:1},children:`Do you use tobacco products?`}),n===`yes`&&(0,h.jsx)(p,{children:(0,h.jsx)(d,{field:{id:`tobacco-frequency`,label:`How often?`,inputType:`dropdown`,required:!0,options:[{value:`daily`,label:`Daily`},{value:`weekly`,label:`A few times a week`},{value:`rarely`,label:`Rarely`}]},control:e,errors:t.errors})})]})}},v={name:`Arbitrary nested content`,render:()=>(0,h.jsxs)(a,{sx:{maxWidth:460},children:[(0,h.jsx)(o,{variant:`body2`,sx:{mb:1},children:`ConditionalGroup accepts any children — not just a single field.`}),(0,h.jsx)(p,{children:(0,h.jsxs)(i,{spacing:1,children:[(0,h.jsx)(o,{variant:`body2`,children:`Multiple related follow-up fields, grouped under one border.`}),(0,h.jsx)(o,{variant:`caption`,color:`text.secondary`,children:`(Placeholder content — a real usage would render several FieldRenderer instances here, as CoverageQuestions.tsx does.)`})]})})]})},y={name:`Accessibility note`,render:()=>(0,h.jsx)(a,{sx:{maxWidth:640},children:(0,h.jsxs)(o,{variant:`body2`,color:`text.secondary`,children:[`ConditionalGroup itself has no ARIA — it's a plain `,(0,h.jsx)(`code`,{children:`Box`}),` `,`with a colored left border, not a live region. Any announcement that new content appeared is the parent's responsibility (e.g. the revealed content should be reachable in tab order immediately after the controlling question, and if the reveal is significant enough to need an explicit announcement, that's a `,(0,h.jsx)(`code`,{children:`role="status"`}),` `,`the parent adds — ConditionalGroup does not add one on its own). This is a real, current limitation, not a design decision to document as a feature.`]})})},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  name: "Hidden vs. revealed (interactive)",
  render: () => {
    const {
      control,
      formState
    } = useForm<DemoValues>({
      defaultValues: {
        "uses-tobacco": "no",
        "tobacco-frequency": ""
      }
    });
    const [answer, setAnswer] = useState<"yes" | "no">("no");
    return <Box sx={{
      maxWidth: 460
    }}>
        <Typography variant="body2" sx={{
        mb: 2
      }}>
          Toggle the question below — the follow-up field only exists in the
          DOM once "Yes" is selected. There is no hidden/collapsed markup
          left behind for "No".
        </Typography>
        <Stack spacing={1} direction="row" sx={{
        mb: 2
      }}>
          <button type="button" onClick={() => setAnswer("no")} aria-pressed={answer === "no"}>
            Answer: No
          </button>
          <button type="button" onClick={() => setAnswer("yes")} aria-pressed={answer === "yes"}>
            Answer: Yes
          </button>
        </Stack>
        <Typography variant="body1" sx={{
        mb: 1
      }}>
          Do you use tobacco products?
        </Typography>
        {answer === "yes" && <ConditionalGroup>
            <FieldRenderer field={{
          id: "tobacco-frequency",
          label: "How often?",
          inputType: "dropdown",
          required: true,
          options: [{
            value: "daily",
            label: "Daily"
          }, {
            value: "weekly",
            label: "A few times a week"
          }, {
            value: "rarely",
            label: "Rarely"
          }]
        }} control={control} errors={formState.errors} />
          </ConditionalGroup>}
      </Box>;
  }
}`,..._.parameters?.docs?.source}}},v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{
  name: "Arbitrary nested content",
  render: () => <Box sx={{
    maxWidth: 460
  }}>
      <Typography variant="body2" sx={{
      mb: 1
    }}>
        ConditionalGroup accepts any children — not just a single field.
      </Typography>
      <ConditionalGroup>
        <Stack spacing={1}>
          <Typography variant="body2">
            Multiple related follow-up fields, grouped under one border.
          </Typography>
          <Typography variant="caption" color="text.secondary">
            (Placeholder content — a real usage would render several
            FieldRenderer instances here, as CoverageQuestions.tsx does.)
          </Typography>
        </Stack>
      </ConditionalGroup>
    </Box>
}`,...v.parameters?.docs?.source}}},y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  name: "Accessibility note",
  render: () => <Box sx={{
    maxWidth: 640
  }}>
      <Typography variant="body2" color="text.secondary">
        ConditionalGroup itself has no ARIA — it's a plain <code>Box</code>{" "}
        with a colored left border, not a live region. Any announcement that
        new content appeared is the parent's responsibility (e.g. the
        revealed content should be reachable in tab order immediately after
        the controlling question, and if the reveal is significant enough to
        need an explicit announcement, that's a <code>role="status"</code>{" "}
        the parent adds — ConditionalGroup does not add one on its own).
        This is a real, current limitation, not a design decision to
        document as a feature.
      </Typography>
    </Box>
}`,...y.parameters?.docs?.source}}},b=[`HiddenAndRevealed`,`NestedContent`,`AccessibilityNote`]}))();export{y as AccessibilityNote,_ as HiddenAndRevealed,v as NestedContent,b as __namedExportsOrder,g as default};