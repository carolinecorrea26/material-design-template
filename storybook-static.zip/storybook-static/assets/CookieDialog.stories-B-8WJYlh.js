import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r,at as i,dt as a,rt as o,t as s}from"./esm-AWQ-KJXU.js";import{n as c,t as l}from"./CookieDialog-cMInT24o.js";var u,d,f,p,m;t((()=>{u=e(n(),1),s(),c(),d=r(),f={title:`Overlays/CookieDialog`,component:l,parameters:{layout:`fullscreen`,docs:{description:{component:`Despite the "Dialog" name, this is a fixed-position banner, not a true
MUI Dialog — no backdrop, no focus trap, no role="dialog". It's rendered
globally by AppShell, gated on a localStorage cookie-consent flag, not
mounted/unmounted like AppModal's children. Documented here as a
clarification of that naming mismatch, not a bug to fix.`}}}},p={render:()=>{function e(){let[e,t]=(0,u.useState)(!0);return(0,d.jsxs)(i,{sx:{position:`relative`,height:320},children:[(0,d.jsx)(a,{variant:`body2`,color:`text.secondary`,sx:{p:2},children:`Page content behind the banner. The banner is fixed to the viewport corner (bottom-left on desktop, full-width bottom on mobile), not positioned relative to this box.`}),!e&&(0,d.jsx)(o,{sx:{position:`absolute`,top:8,right:8},onClick:()=>t(!0),children:`Show again`}),e&&(0,d.jsx)(l,{onClose:()=>t(!1)})]})}return(0,d.jsx)(e,{})}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: () => {
    function Demo() {
      const [visible, setVisible] = useState(true);
      return <Box sx={{
        position: "relative",
        height: 320
      }}>
          <Typography variant="body2" color="text.secondary" sx={{
          p: 2
        }}>
            Page content behind the banner. The banner is fixed to the
            viewport corner (bottom-left on desktop, full-width bottom on
            mobile), not positioned relative to this box.
          </Typography>
          {!visible && <Button sx={{
          position: "absolute",
          top: 8,
          right: 8
        }} onClick={() => setVisible(true)}>
              Show again
            </Button>}
          {visible && <CookieDialog onClose={() => setVisible(false)} />}
        </Box>;
    }
    return <Demo />;
  }
}`,...p.parameters?.docs?.source}}},m=[`Default`]}))();export{p as Default,m as __namedExportsOrder,f as default};