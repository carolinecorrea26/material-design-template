import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r,at as i,rt as a,t as o}from"./esm-AWQ-KJXU.js";import{r as s,t as c}from"./ApplicationFormContext-BU7mcIce.js";import{n as l,t as u}from"./CoverageCart-p37eu7Ve.js";import{n as d,t as f}from"./AppDrawer-BZqEFTP6.js";function p({initialValues:e={},children:t}){let[n,r]=(0,h.useState)(e);return(0,g.jsx)(c.Provider,{value:{values:n,setPageValues:e=>r(t=>({...t,...e})),resetValues:()=>r({})},children:t})}function m({initialValues:e}){let[t,n]=(0,h.useState)(!0);return(0,g.jsxs)(p,{initialValues:e,children:[(0,g.jsx)(i,{sx:{p:2},children:(0,g.jsx)(a,{variant:`outlined`,onClick:()=>n(!0),children:`Reopen cart drawer`})}),(0,g.jsx)(f,{open:t,onClose:()=>n(!1),ariaLabel:`Coverage cart`,children:(0,g.jsx)(u,{variant:`drawer`,onClose:()=>n(!1)})})]})}var h,g,_,v,y,b;t((()=>{h=e(n(),1),o(),l(),d(),s(),g=r(),_={title:`Coverage & Commerce/CoverageCart`,component:u,parameters:{layout:`fullscreen`,docs:{description:{component:`CoverageCart has two variants sharing one component — \`drawer\` (opened
from AppHeader's cart icon; reads raw values directly via its own
useApplicationForm() hook, so no props beyond onClose are needed) and
\`inline\` (rendered at the bottom of ProductCatalog, fully controlled via
props derived from useCoverageState — see Coverage & Commerce/ProductCatalog
for that variant in its real composition, adding a product through the
real catalog UI). This file covers the \`drawer\` variant specifically,
seeded with real coverageSelections/productApplicants/coverageAmounts
shapes rather than the full interactive flow, since the drawer reads that
state directly rather than through handler props.`}}}},v={name:`Empty (no coverage selected)`,render:()=>(0,g.jsx)(m,{})},y={name:`Populated (real coverage config)`,render:()=>(0,g.jsx)(m,{initialValues:{coverageSelections:[`li-term`,`li-10yr`],productApplicants:{"li-term":[`member`],"li-10yr":[`member`]},coverageAmounts:{"li-term:member":1e5,"li-10yr:member":25e4}}}),parameters:{docs:{description:{story:`Seeded with real coverage IDs (li-term, li-10yr) from the default client's actual product catalog — the same IDs ProductCatalog's own story adds through the real UI — so premiums, names, and totals are real, not placeholder text.`}}}},v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{
  name: "Empty (no coverage selected)",
  render: () => <DrawerDemo />
}`,...v.parameters?.docs?.source}}},y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  name: "Populated (real coverage config)",
  render: () => <DrawerDemo initialValues={{
    coverageSelections: ["li-term", "li-10yr"],
    productApplicants: {
      "li-term": ["member"],
      "li-10yr": ["member"]
    },
    coverageAmounts: {
      "li-term:member": 100000,
      "li-10yr:member": 250000
    }
  }} />,
  parameters: {
    docs: {
      description: {
        story: "Seeded with real coverage IDs (li-term, li-10yr) from the default client's actual product catalog — the same IDs ProductCatalog's own story adds through the real UI — so premiums, names, and totals are real, not placeholder text."
      }
    }
  }
}`,...y.parameters?.docs?.source}}},b=[`EmptyDrawer`,`PopulatedDrawer`]}))();export{v as EmptyDrawer,y as PopulatedDrawer,b as __namedExportsOrder,_ as default};