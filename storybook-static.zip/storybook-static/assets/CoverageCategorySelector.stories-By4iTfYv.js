import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r}from"./esm-AWQ-KJXU.js";import{r as i,t as a}from"./coverageCategories-B_zBLMK-.js";import{n as o,t as s}from"./CoverageCategorySelector-DkE6-ssh.js";function c({initialSelectedIds:e=[],legend:t,error:n,errorMessage:r}){let[i,o]=(0,l.useState)(e);return(0,u.jsx)(s,{categories:a,selectedIds:i,onToggle:e=>o(t=>t.includes(e)?t.filter(t=>t!==e):[...t,e]),legend:t,error:n,errorMessage:r})}var l,u,d,f,p,m,h,g;t((()=>{l=e(n(),1),o(),i(),u=r(),d={title:`Coverage & Commerce/CoverageCategorySelector`,component:s,parameters:{layout:`padded`,docs:{description:{component:`CoverageCategorySelector is a multi-select toggle list for coverage
categories, used on the Coverage page, QuoteCalculator, and (formerly)
QuoteModal. It's a controlled component — selection state and toggling
live entirely in the consumer, which is why every story below manages its
own useState. Rows use a custom role="checkbox"/aria-checked SelectionGroup
pattern rather than native checkboxes, matching FieldRenderer's own
checkbox-group convention.`}}}},f={render:()=>(0,u.jsx)(c,{initialSelectedIds:[`LI`]})},p={render:()=>(0,u.jsx)(c,{})},m={name:`error (nothing selected, required)`,render:()=>(0,u.jsx)(c,{error:!0,errorMessage:`Select at least one coverage type.`})},h={render:()=>(0,u.jsx)(c,{initialSelectedIds:[`DI`],legend:`Which coverage would you like a quote for?`})},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  render: () => <SelectorDemo initialSelectedIds={["LI"]} />
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: () => <SelectorDemo />
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  name: "error (nothing selected, required)",
  render: () => <SelectorDemo error errorMessage="Select at least one coverage type." />
}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  render: () => <SelectorDemo initialSelectedIds={["DI"]} legend="Which coverage would you like a quote for?" />
}`,...h.parameters?.docs?.source}}},g=[`Default`,`NoneSelected`,`RequiredError`,`CustomLegend`]}))();export{h as CustomLegend,f as Default,p as NoneSelected,m as RequiredError,g as __namedExportsOrder,d as default};