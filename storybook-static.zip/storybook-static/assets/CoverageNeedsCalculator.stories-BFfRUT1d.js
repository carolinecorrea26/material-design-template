import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,at as n,t as r}from"./esm-AWQ-KJXU.js";import{n as i,t as a}from"./CoverageNeedsCalculator-BC-ANFx4.js";var o,s,c,l;e((()=>{r(),i(),o=t(),s={title:`Coverage & Commerce/CoverageNeedsCalculator`,component:a,parameters:{layout:`padded`,docs:{description:{component:`CoverageNeedsCalculator is an income-replacement needs calculator with no
props — it's self-contained, only reachable via the AppMenu drawer. The
result box only appears once income or debts are entered (hasInput), and
uses role="status"/aria-live="polite" so the recalculated estimate is
announced as the user types, without a separate loading state.`}}}},c={render:()=>(0,o.jsx)(n,{sx:{maxWidth:420},children:(0,o.jsx)(a,{})}),parameters:{docs:{description:{story:`Empty on first render — the result box doesn't appear until income or debts are entered. Try typing an annual income to see it appear live.`}}}},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  render: () => <Box sx={{
    maxWidth: 420
  }}>
      <CoverageNeedsCalculator />
    </Box>,
  parameters: {
    docs: {
      description: {
        story: "Empty on first render — the result box doesn't appear until income or debts are entered. Try typing an annual income to see it appear live."
      }
    }
  }
}`,...c.parameters?.docs?.source}}},l=[`Default`]}))();export{c as Default,l as __namedExportsOrder,s as default};