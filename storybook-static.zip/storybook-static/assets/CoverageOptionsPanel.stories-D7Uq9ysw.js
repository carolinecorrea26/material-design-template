import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,at as n,t as r}from"./esm-AWQ-KJXU.js";import{n as i,t as a}from"./CoverageOptionsPanel-BbYIdkoP.js";var o,s,c,l,u,d;e((()=>{r(),i(),o=t(),s={title:`Coverage & Commerce/CoverageOptionsPanel`,component:a,parameters:{layout:`padded`,docs:{description:{component:`CoverageOptionsPanel is a tabbed "browse what coverage is available"
reader — page variant on the Home page, drawer variant in AppMenu. Real
client coverage config drives the tabs/products; there's no props for
mock data. The Phase 1 audit flagged its product-name links as
placeholder \`href="#"\` anchors that went nowhere — fixed in this pass to
plain (non-interactive) text instead of a fake link, since there's no
real product-detail destination for them to point to.`}}}},c={name:`variant="page" (Home page)`,render:()=>(0,o.jsx)(n,{sx:{maxWidth:900},children:(0,o.jsx)(a,{variant:`page`})})},l={name:`variant="drawer" (AppMenu)`,render:()=>(0,o.jsx)(n,{sx:{maxWidth:420},children:(0,o.jsx)(a,{variant:`drawer`})})},u={name:`initialCategory="DI"`,render:()=>(0,o.jsx)(n,{sx:{maxWidth:900},children:(0,o.jsx)(a,{variant:`page`,initialCategory:`DI`})})},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  name: 'variant="page" (Home page)',
  render: () => <Box sx={{
    maxWidth: 900
  }}>
      <CoverageOptionsPanel variant="page" />
    </Box>
}`,...c.parameters?.docs?.source}}},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  name: 'variant="drawer" (AppMenu)',
  render: () => <Box sx={{
    maxWidth: 420
  }}>
      <CoverageOptionsPanel variant="drawer" />
    </Box>
}`,...l.parameters?.docs?.source}}},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  name: 'initialCategory="DI"',
  render: () => <Box sx={{
    maxWidth: 900
  }}>
      <CoverageOptionsPanel variant="page" initialCategory="DI" />
    </Box>
}`,...u.parameters?.docs?.source}}},d=[`PageVariant`,`DrawerVariant`,`InitialCategory`]}))();export{l as DrawerVariant,u as InitialCategory,c as PageVariant,d as __namedExportsOrder,s as default};