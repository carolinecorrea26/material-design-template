import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r,at as i,rt as a,t as o}from"./esm-AWQ-KJXU.js";import{n as s,t as c}from"./CoveragePortfolioDrawer-Ct3jgUor.js";function l({hasSpouse:e=!1}){let[t,n]=(0,u.useState)(!0);return(0,d.jsxs)(i,{sx:{p:2},children:[(0,d.jsx)(a,{variant:`outlined`,onClick:()=>n(!0),children:`Reopen portfolio drawer`}),(0,d.jsx)(c,{open:t,onClose:()=>n(!1),hasSpouse:e})]})}var u,d,f,p,m,h;t((()=>{u=e(n(),1),o(),s(),d=r(),f={title:`Coverage & Commerce/CoveragePortfolioDrawer`,component:c,parameters:{layout:`fullscreen`,docs:{description:{component:`CoveragePortfolioDrawer is a read-only "existing coverage" summary shown
on the Coverage page to TPA-verified members — its coverage data is
intentionally hardcoded dummy data (DUMMY_PORTFOLIO), not real client
config, since there's no real member-record integration in this
prototype. Missing from componentInventory.ts before this pass — added
now.`}}}},p={name:`hasSpouse=false (member portfolio only)`,render:()=>(0,d.jsx)(l,{})},m={name:`hasSpouse=true (member + spouse portfolios)`,render:()=>(0,d.jsx)(l,{hasSpouse:!0})},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  name: "hasSpouse=false (member portfolio only)",
  render: () => <DrawerDemo />
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  name: "hasSpouse=true (member + spouse portfolios)",
  render: () => <DrawerDemo hasSpouse />
}`,...m.parameters?.docs?.source}}},h=[`MemberOnly`,`WithSpouse`]}))();export{p as MemberOnly,m as WithSpouse,h as __namedExportsOrder,f as default};