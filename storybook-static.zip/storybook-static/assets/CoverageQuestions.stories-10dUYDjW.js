import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,at as n,t as r}from"./esm-AWQ-KJXU.js";import{a as i,i as a,n as o}from"./index.esm-DbA_UsRE.js";import{n as s,t as c}from"./getClientPageFields-B3swclaK.js";import{n as l,t as u}from"./pageSections-CV3JNZJv.js";import{n as d,t as f}from"./CoverageQuestions-DJNhNRLV.js";function p({selectedCategories:e,hasSpouse:t=!1}){let{control:r,formState:o}=a({mode:`onChange`}),s=i({control:r}),c=e.some(e=>e===`LI`||e===`DI`),l=e.some(e=>e===`LI`||e===`SH`),u=e.includes(`DI`),d=e.includes(`OO`),p=u||d;return(0,m.jsx)(n,{sx:{maxWidth:640},children:(0,m.jsx)(f,{control:r,errors:o.errors,watchedValues:s??{},allFields:_,pageSections:g,selectedCategories:e,categoryNeedsGender:c,categoryNeedsSmoker:l,categoryNeedsDi:u,categoryNeedsOo:d,categoryNeedsHours:p,hasSpouse:t})})}var m,h,g,_,v,y,b,x,S;e((()=>{o(),r(),d(),s(),u(),m=t(),h={title:`Coverage & Commerce/CoverageQuestions`,component:f,parameters:{layout:`padded`,docs:{description:{component:`CoverageQuestions orchestrates the category-driven question sections
(tobacco, income, business expenses) shown below CoverageCategorySelector
on the Coverage page — the one real consumer of ConditionalGroup. Section
visibility is data-driven from real page-section config
(getPageSections("coverage")) crossed with which categories are selected,
not a fixed list, so this story uses the real config rather than a
hand-built mock to stay honest about what's actually configured today.`}}}},g=l(`coverage`),_=c(`coverage`,{}),v={name:`No category selected (renders null)`,render:()=>(0,m.jsx)(p,{selectedCategories:[]}),parameters:{docs:{description:{story:`Returns null outright when selectedCategories is empty — there's nothing to ask about yet. This matches the Coverage page's own layout: the divider below this component is also hidden in that state.`}}}},y={name:`Life (gender + tobacco questions)`,render:()=>(0,m.jsx)(p,{selectedCategories:[`LI`]})},b={name:`Disability (gender + work-income questions)`,render:()=>(0,m.jsx)(p,{selectedCategories:[`DI`]})},x={name:`Life + spouse (self and spouse sections)`,render:()=>(0,m.jsx)(p,{selectedCategories:[`LI`],hasSpouse:!0}),parameters:{docs:{description:{story:`With hasSpouse, sections render twice under separate ApplicantSectionDivider wrappers — once for self, once for spouse — and the spouse group is only shown if it actually has visible sections of its own.`}}}},v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{
  name: "No category selected (renders null)",
  render: () => <CoverageQuestionsDemo selectedCategories={[]} />,
  parameters: {
    docs: {
      description: {
        story: "Returns null outright when selectedCategories is empty — there's nothing to ask about yet. This matches the Coverage page's own layout: the divider below this component is also hidden in that state."
      }
    }
  }
}`,...v.parameters?.docs?.source}}},y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  name: "Life (gender + tobacco questions)",
  render: () => <CoverageQuestionsDemo selectedCategories={["LI"]} />
}`,...y.parameters?.docs?.source}}},b.parameters={...b.parameters,docs:{...b.parameters?.docs,source:{originalSource:`{
  name: "Disability (gender + work-income questions)",
  render: () => <CoverageQuestionsDemo selectedCategories={["DI"]} />
}`,...b.parameters?.docs?.source}}},x.parameters={...x.parameters,docs:{...x.parameters?.docs,source:{originalSource:`{
  name: "Life + spouse (self and spouse sections)",
  render: () => <CoverageQuestionsDemo selectedCategories={["LI"]} hasSpouse />,
  parameters: {
    docs: {
      description: {
        story: "With hasSpouse, sections render twice under separate ApplicantSectionDivider wrappers — once for self, once for spouse — and the spouse group is only shown if it actually has visible sections of its own."
      }
    }
  }
}`,...x.parameters?.docs?.source}}},S=[`NoCategorySelected`,`LifeInsuranceSelected`,`DisabilitySelected`,`WithSpouse`]}))();export{b as DisabilitySelected,y as LifeInsuranceSelected,v as NoCategorySelected,x as WithSpouse,S as __namedExportsOrder,h as default};