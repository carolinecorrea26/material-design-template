import{n as e}from"./chunk-BneVvdWh.js";import{n as t,t as n}from"./DetailsTable-C1HbMz0P.js";var r,i,a;e((()=>{t(),r={title:`Application Patterns/DetailsTable`,component:n,parameters:{layout:`padded`}},i={args:{rows:[{label:`Applicant name`,value:`Taylor Morgan`},{label:`Applicant email`,value:`taylor@example.com`},{label:`Sent for signature`,value:`September 18, 2026 at 11:30 AM`}]}},i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`{
  args: {
    rows: [{
      label: "Applicant name",
      value: "Taylor Morgan"
    }, {
      label: "Applicant email",
      value: "taylor@example.com"
    }, {
      label: "Sent for signature",
      value: "September 18, 2026 at 11:30 AM"
    }]
  }
}`,...i.parameters?.docs?.source}}},a=[`ConfirmationDetails`]}))();export{i as ConfirmationDetails,a as __namedExportsOrder,r as default};