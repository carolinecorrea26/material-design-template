import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,at as n,dt as r,t as i}from"./esm-AWQ-KJXU.js";import{i as a,n as o}from"./index.esm-DbA_UsRE.js";import{n as s,t as c}from"./DynamicList-56mOhY9W.js";function l(e){return(0,d.jsxs)(r,{variant:`body2`,children:[(0,d.jsxs)(`strong`,{children:[e.firstName,` `,e.lastName]}),` `,`— `,e.relationship,`, `,e.share,`% share`]})}function u(e){return`${e.firstName} ${e.lastName} (${e.share}%)`}var d,f,p,m,h,g,_,v,y;e((()=>{o(),i(),s(),d=t(),f={title:`Forms/DynamicList`,component:c,parameters:{layout:`padded`,docs:{description:{component:`DynamicList is the shared add/edit/remove repeatable-record pattern
(beneficiaries, dependents, physicians, health-history entries). It hosts
its own isolated react-hook-form instance for the add/edit dialog — item
edits are staged there and only committed to the parent's \`useFieldArray\`
on Save — and a second confirmation dialog before removal. All of this is
real, interactive behavior below: click Add/Edit/Remove rather than
looking at a static screenshot.`}}}},p=[{id:`ds-first-name`,label:`First Name`,inputType:`text`,required:!0},{id:`ds-last-name`,label:`Last Name`,inputType:`text`,required:!0},{id:`ds-relationship`,label:`Relationship`,inputType:`dropdown`,required:!0,options:[{value:`spouse`,label:`Spouse`},{value:`child`,label:`Child`},{value:`parent`,label:`Parent`},{value:`sibling`,label:`Sibling`},{value:`other`,label:`Other`}]},{id:`ds-share`,label:`% Share`,inputType:`number`,required:!0}],m={"ds-first-name":`firstName`,"ds-last-name":`lastName`,"ds-relationship":`relationship`,"ds-share":`share`},h={render:()=>{let{control:e}=a({defaultValues:{beneficiaries:[]}});return(0,d.jsx)(n,{sx:{maxWidth:480},children:(0,d.jsx)(c,{control:e,name:`beneficiaries`,label:`Beneficiary`,mapping:{fields:p,fieldToKey:m},getItemLabel:u,renderItem:l})})}},g={render:()=>{let{control:e}=a({defaultValues:{beneficiaries:[{firstName:`Jordan`,lastName:`Lee`,relationship:`spouse`,share:`60`},{firstName:`Avery`,lastName:`Lee`,relationship:`child`,share:`40`}]}});return(0,d.jsxs)(n,{sx:{maxWidth:480},children:[(0,d.jsx)(c,{control:e,name:`beneficiaries`,label:`Beneficiary`,mapping:{fields:p,fieldToKey:m},getItemLabel:u,renderItem:l}),(0,d.jsxs)(r,{variant:`caption`,color:`text.secondary`,sx:{display:`block`,mt:1.5},children:[`Click `,(0,d.jsx)(`strong`,{children:`Edit`}),` to reopen the dialog pre-filled, or`,` `,(0,d.jsx)(`strong`,{children:`Remove`}),` to see the "This cannot be undone" confirmation dialog (`,(0,d.jsx)(`code`,{children:`role="alertdialog"`}),`) before anything is actually removed.`]})]})}},_={name:`Maximum items reached`,render:()=>{let{control:e}=a({defaultValues:{beneficiaries:[{firstName:`Jordan`,lastName:`Lee`,relationship:`spouse`,share:`50`},{firstName:`Avery`,lastName:`Lee`,relationship:`child`,share:`50`}]}});return(0,d.jsxs)(n,{sx:{maxWidth:480},children:[(0,d.jsx)(c,{control:e,name:`beneficiaries`,label:`Beneficiary`,mapping:{fields:p,fieldToKey:m},getItemLabel:u,renderItem:l,maxItems:2}),(0,d.jsxs)(r,{variant:`caption`,color:`text.secondary`,sx:{display:`block`,mt:1.5},children:[(0,d.jsx)(`code`,{children:`maxItems=2`}),`, 2 items already added — the Add button is hidden entirely rather than shown disabled.`]})]})}},v={name:`Add/Edit dialog — 2-column field layout`,render:()=>{let{control:e}=a({defaultValues:{beneficiaries:[]}});return(0,d.jsxs)(n,{sx:{maxWidth:480},children:[(0,d.jsx)(c,{control:e,name:`beneficiaries`,label:`Beneficiary`,mapping:{fields:p,fieldToKey:m,gridFields:[`ds-first-name`,`ds-last-name`]},getItemLabel:u,renderItem:l}),(0,d.jsxs)(r,{variant:`caption`,color:`text.secondary`,sx:{display:`block`,mt:1.5},children:[`Click Add — First/Last name render side-by-side (`,(0,d.jsx)(`code`,{children:`mapping.gridFields`}),`) while Relationship and % Share stack below, full-width.`]})]})}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  render: () => {
    const {
      control
    } = useForm<Record<string, unknown>>({
      defaultValues: {
        beneficiaries: []
      }
    });
    return <Box sx={{
      maxWidth: 480
    }}>
        <DynamicList control={control} name="beneficiaries" label="Beneficiary" mapping={{
        fields: beneficiaryFields,
        fieldToKey
      }} getItemLabel={getBeneficiaryLabel} renderItem={renderBeneficiary} />
      </Box>;
  }
}`,...h.parameters?.docs?.source}}},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  render: () => {
    const {
      control
    } = useForm<Record<string, unknown>>({
      defaultValues: {
        beneficiaries: [{
          firstName: "Jordan",
          lastName: "Lee",
          relationship: "spouse",
          share: "60"
        }, {
          firstName: "Avery",
          lastName: "Lee",
          relationship: "child",
          share: "40"
        }]
      }
    });
    return <Box sx={{
      maxWidth: 480
    }}>
        <DynamicList control={control} name="beneficiaries" label="Beneficiary" mapping={{
        fields: beneficiaryFields,
        fieldToKey
      }} getItemLabel={getBeneficiaryLabel} renderItem={renderBeneficiary} />
        <Typography variant="caption" color="text.secondary" sx={{
        display: "block",
        mt: 1.5
      }}>
          Click <strong>Edit</strong> to reopen the dialog pre-filled, or{" "}
          <strong>Remove</strong> to see the "This cannot be undone"
          confirmation dialog (<code>role="alertdialog"</code>) before
          anything is actually removed.
        </Typography>
      </Box>;
  }
}`,...g.parameters?.docs?.source}}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  name: "Maximum items reached",
  render: () => {
    const {
      control
    } = useForm<Record<string, unknown>>({
      defaultValues: {
        beneficiaries: [{
          firstName: "Jordan",
          lastName: "Lee",
          relationship: "spouse",
          share: "50"
        }, {
          firstName: "Avery",
          lastName: "Lee",
          relationship: "child",
          share: "50"
        }]
      }
    });
    return <Box sx={{
      maxWidth: 480
    }}>
        <DynamicList control={control} name="beneficiaries" label="Beneficiary" mapping={{
        fields: beneficiaryFields,
        fieldToKey
      }} getItemLabel={getBeneficiaryLabel} renderItem={renderBeneficiary} maxItems={2} />
        <Typography variant="caption" color="text.secondary" sx={{
        display: "block",
        mt: 1.5
      }}>
          <code>maxItems=2</code>, 2 items already added — the Add button is
          hidden entirely rather than shown disabled.
        </Typography>
      </Box>;
  }
}`,..._.parameters?.docs?.source}}},v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{
  name: "Add/Edit dialog — 2-column field layout",
  render: () => {
    const {
      control
    } = useForm<Record<string, unknown>>({
      defaultValues: {
        beneficiaries: []
      }
    });
    return <Box sx={{
      maxWidth: 480
    }}>
        <DynamicList control={control} name="beneficiaries" label="Beneficiary" mapping={{
        fields: beneficiaryFields,
        fieldToKey,
        gridFields: ["ds-first-name", "ds-last-name"]
      }} getItemLabel={getBeneficiaryLabel} renderItem={renderBeneficiary} />
        <Typography variant="caption" color="text.secondary" sx={{
        display: "block",
        mt: 1.5
      }}>
          Click Add — First/Last name render side-by-side (
          <code>mapping.gridFields</code>) while Relationship and % Share
          stack below, full-width.
        </Typography>
      </Box>;
  }
}`,...v.parameters?.docs?.source}}},y=[`Empty`,`Populated`,`MaxItemsReached`,`WithGridFields`]}))();export{h as Empty,_ as MaxItemsReached,g as Populated,v as WithGridFields,y as __namedExportsOrder,f as default};