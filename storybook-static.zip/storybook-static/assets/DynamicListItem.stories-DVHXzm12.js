import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,at as n,dt as r,t as i}from"./esm-AWQ-KJXU.js";import{n as a,t as o}from"./DynamicListItem-lAE-PHNw.js";var s,c,l,u,d,f;e((()=>{i(),a(),s=t(),c={title:`Forms/DynamicListItem`,component:o,parameters:{layout:`padded`,docs:{description:{component:`DynamicListItem is the bordered row DynamicList renders per item — content
on the left, Edit/Remove buttons on the right. It's usable on its own for
any add/edit/remove-style list, not just DynamicList's own field-array
dialog flow.`}}}},l={render:()=>(0,s.jsx)(n,{sx:{maxWidth:420},children:(0,s.jsx)(o,{onEdit:()=>{},onRemove:()=>{},itemLabel:`Jordan Lee (60%)`,children:(0,s.jsxs)(r,{variant:`body2`,children:[(0,s.jsx)(`strong`,{children:`Jordan Lee`}),` — spouse, 60% share`]})})})},u={name:`Without itemLabel (not recommended)`,render:()=>(0,s.jsxs)(n,{sx:{maxWidth:420},children:[(0,s.jsx)(o,{onEdit:()=>{},onRemove:()=>{},children:(0,s.jsxs)(r,{variant:`body2`,children:[(0,s.jsx)(`strong`,{children:`Jordan Lee`}),` — spouse, 60% share`]})}),(0,s.jsxs)(r,{variant:`caption`,color:`text.secondary`,sx:{display:`block`,mt:1.5},children:[`Without `,(0,s.jsx)(`code`,{children:`itemLabel`}),`, Edit/Remove fall back to generic accessible names ("Edit", "Remove") — indistinguishable from a second item's identical buttons for screen reader users. Always pass`,` `,(0,s.jsx)(`code`,{children:`itemLabel`}),` when a list can have more than one item.`]})]})},d={render:()=>(0,s.jsx)(n,{sx:{maxWidth:420},children:(0,s.jsx)(o,{onEdit:()=>{},onRemove:()=>{},itemLabel:`Dr. Alexandra Montgomery-Whitfield (Primary Care Physician)`,children:(0,s.jsxs)(r,{variant:`body2`,children:[(0,s.jsx)(`strong`,{children:`Dr. Alexandra Montgomery-Whitfield`}),(0,s.jsx)(`br`,{}),`123 Long Street Name, Suite 4500, Springfield, IL 62704 — Primary Care Physician`]})})})},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  render: () => <Box sx={{
    maxWidth: 420
  }}>
      <DynamicListItem onEdit={() => {}} onRemove={() => {}} itemLabel="Jordan Lee (60%)">
        <Typography variant="body2">
          <strong>Jordan Lee</strong> — spouse, 60% share
        </Typography>
      </DynamicListItem>
    </Box>
}`,...l.parameters?.docs?.source}}},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  name: "Without itemLabel (not recommended)",
  render: () => <Box sx={{
    maxWidth: 420
  }}>
      <DynamicListItem onEdit={() => {}} onRemove={() => {}}>
        <Typography variant="body2">
          <strong>Jordan Lee</strong> — spouse, 60% share
        </Typography>
      </DynamicListItem>
      <Typography variant="caption" color="text.secondary" sx={{
      display: "block",
      mt: 1.5
    }}>
        Without <code>itemLabel</code>, Edit/Remove fall back to generic
        accessible names ("Edit", "Remove") — indistinguishable from a
        second item's identical buttons for screen reader users. Always pass{" "}
        <code>itemLabel</code> when a list can have more than one item.
      </Typography>
    </Box>
}`,...u.parameters?.docs?.source}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: () => <Box sx={{
    maxWidth: 420
  }}>
      <DynamicListItem onEdit={() => {}} onRemove={() => {}} itemLabel="Dr. Alexandra Montgomery-Whitfield (Primary Care Physician)">
        <Typography variant="body2">
          <strong>Dr. Alexandra Montgomery-Whitfield</strong>
          <br />
          123 Long Street Name, Suite 4500, Springfield, IL 62704 — Primary
          Care Physician
        </Typography>
      </DynamicListItem>
    </Box>
}`,...d.parameters?.docs?.source}}},f=[`Default`,`WithoutAccessibleLabel`,`LongContent`]}))();export{l as Default,d as LongContent,u as WithoutAccessibleLabel,f as __namedExportsOrder,c as default};