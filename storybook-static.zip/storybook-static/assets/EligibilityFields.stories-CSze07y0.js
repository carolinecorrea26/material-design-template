import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r,at as i,t as a}from"./esm-AWQ-KJXU.js";import{n as o,t as s}from"./EligibilityFields-CZPFDxTR.js";function c({initialValues:e={birthday:``,zipCode:``,state:``},attempted:t=!1,ageError:n}){let[r,a]=(0,l.useState)(e);return(0,u.jsx)(i,{sx:{maxWidth:420},children:(0,u.jsx)(s,{values:r,onChange:e=>a(t=>({...t,...e})),attempted:t,ageError:n})})}var l,u,d,f,p,m,h,g;t((()=>{l=e(n(),1),a(),o(),u=r(),d={title:`Coverage & Commerce/EligibilityFields`,component:s,parameters:{layout:`padded`,docs:{description:{component:`EligibilityFields is a shared DOB/ZIP/State trio used by the Home page's
quote entry card and inside QuoteCalculator's eligibility-collection step.
ZIP auto-derives State (deriveStateProvinceFromZipOrPostalCode); editing
ZIP again re-derives it, but a manual State edit isn't overwritten until
the next ZIP change. Unlike FieldRenderer's always-on RHF errors, this
component defers error display behind an explicit \`attempted\` prop — a
deliberate exception worth knowing before assuming FieldRenderer's
validation-display convention applies everywhere.`}}}},f={render:()=>(0,u.jsx)(c,{})},p={name:`ZIP auto-derives State (try editing ZIP)`,render:()=>(0,u.jsx)(c,{initialValues:{birthday:``,zipCode:`10001`,state:`NY`}}),parameters:{docs:{description:{story:`Pre-filled from a real ZIP so State starts correctly derived. Change the ZIP to see State update automatically; a manual State selection afterward survives until ZIP changes again.`}}}},m={name:`attempted=true, all fields empty`,render:()=>(0,u.jsx)(c,{attempted:!0})},h={name:`ageError (age 80+)`,render:()=>(0,u.jsx)(c,{initialValues:{birthday:`1940-01-01`,zipCode:`10001`,state:`NY`},attempted:!0,ageError:`We're sorry, but coverage is not available for applicants age 80 or older.`}),parameters:{docs:{description:{story:`ageError is computed externally by the exported validateEligibility() helper, not by this component — callers own the age >= 80 exclusion rule and pass the resulting message in.`}}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  render: () => <EligibilityDemo />
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  name: "ZIP auto-derives State (try editing ZIP)",
  render: () => <EligibilityDemo initialValues={{
    birthday: "",
    zipCode: "10001",
    state: "NY"
  }} />,
  parameters: {
    docs: {
      description: {
        story: "Pre-filled from a real ZIP so State starts correctly derived. Change the ZIP to see State update automatically; a manual State selection afterward survives until ZIP changes again."
      }
    }
  }
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  name: "attempted=true, all fields empty",
  render: () => <EligibilityDemo attempted />
}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  name: "ageError (age 80+)",
  render: () => <EligibilityDemo initialValues={{
    birthday: "1940-01-01",
    zipCode: "10001",
    state: "NY"
  }} attempted ageError="We're sorry, but coverage is not available for applicants age 80 or older." />,
  parameters: {
    docs: {
      description: {
        story: "ageError is computed externally by the exported validateEligibility() helper, not by this component — callers own the age >= 80 exclusion rule and pass the resulting message in."
      }
    }
  }
}`,...h.parameters?.docs?.source}}},g=[`Default`,`ZipAutoDerivesState`,`RequiredErrors`,`AgeIneligible`]}))();export{h as AgeIneligible,f as Default,m as RequiredErrors,p as ZipAutoDerivesState,g as __namedExportsOrder,d as default};