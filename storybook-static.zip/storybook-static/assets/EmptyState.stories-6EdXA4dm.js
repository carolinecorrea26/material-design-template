import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t}from"./esm-AWQ-KJXU.js";import{n,t as r}from"./ShoppingCartOutlined-CBz2cNAo.js";import{n as i,t as a}from"./EmptyState-CQPGoMMX.js";var o,s,c,l,u,d;e((()=>{n(),i(),o=t(),s={title:`Feedback/EmptyState`,component:a,parameters:{layout:`padded`,docs:{description:{component:`EmptyState is the generic centered icon + title + optional-body block used
wherever a section or panel has nothing to show yet (CoverageCart,
QuoteCalculator, error states).`}}}},c={name:`Default icon (PrivacyTipIcon)`,render:()=>(0,o.jsx)(a,{title:`Nothing to show yet.`})},l={render:()=>(0,o.jsx)(a,{title:`No coverage selected yet.`,body:`Choose a category above to get started.`})},u={render:()=>(0,o.jsx)(a,{icon:r,title:`Your cart is empty.`,body:`Select coverage to see your estimated cost here.`})},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  name: "Default icon (PrivacyTipIcon)",
  render: () => <EmptyState title="Nothing to show yet." />
}`,...c.parameters?.docs?.source}}},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  render: () => <EmptyState title="No coverage selected yet." body="Choose a category above to get started." />
}`,...l.parameters?.docs?.source}}},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  render: () => <EmptyState icon={ShoppingCartOutlinedIcon} title="Your cart is empty." body="Select coverage to see your estimated cost here." />
}`,...u.parameters?.docs?.source}}},d=[`Default`,`WithBody`,`CustomIcon`]}))();export{u as CustomIcon,c as Default,l as WithBody,d as __namedExportsOrder,s as default};