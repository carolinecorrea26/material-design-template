import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r,at as i,t as a}from"./esm-AWQ-KJXU.js";import{n as o,t as s}from"./EstimatorProductCard-BYBwmBJM.js";function c({product:e=f,isCalculating:t=!1,initialSelected:n=!1,initialAmount:r=1e5}){let[a,o]=(0,l.useState)(n),[c,d]=(0,l.useState)(r);return(0,u.jsx)(i,{sx:{maxWidth:360},children:(0,u.jsx)(s,{product:e,currentAmount:c,amountChoices:[5e4,1e5,25e4,5e5],selected:a,isCalculating:t,displayedPremium:c*35e-5,rateSuffix:`/mo`,onToggleSelected:()=>o(e=>!e),onAmountChange:d})})}var l,u,d,f,p,m,h,g,_,v;t((()=>{l=e(n(),1),a(),o(),u=r(),d={title:`Coverage & Commerce/EstimatorProductCard`,component:s,parameters:{layout:`padded`,docs:{description:{component:`EstimatorProductCard is the quote-estimator's deliberately simplified
product card — member-only (no spouse/child toggles), no riders, no
waiting periods — used inside QuoteCalculator (and formerly QuoteModal).
It's a controlled component: selection and amount live in the consumer,
and displayedPremium/isCalculating are computed externally rather than
derived internally, so every story below wires that up locally. See
Layout/ProductCard for the full-featured card this deliberately omits
from — compare them side by side to see exactly what's simplified.`}}}},f={id:`term-life`,name:`Term Life Insurance`,description:`Affordable coverage for a set period of time.`,categoryId:`LI`},p={render:()=>(0,u.jsx)(c,{})},m={render:()=>(0,u.jsx)(c,{initialSelected:!0})},h={render:()=>(0,u.jsx)(c,{product:{...f,featured:!0}})},g={name:`underwritingType="QD"`,render:()=>(0,u.jsx)(c,{product:{...f,underwritingType:`QD`},initialSelected:!0})},_={name:`isCalculating (recalculating estimate)`,render:()=>(0,u.jsx)(c,{initialSelected:!0,isCalculating:!0})},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: () => <EstimatorProductCardDemo />
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  render: () => <EstimatorProductCardDemo initialSelected />
}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  render: () => <EstimatorProductCardDemo product={{
    ...baseProduct,
    featured: true
  }} />
}`,...h.parameters?.docs?.source}}},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  name: 'underwritingType="QD"',
  render: () => <EstimatorProductCardDemo product={{
    ...baseProduct,
    underwritingType: "QD"
  }} initialSelected />
}`,...g.parameters?.docs?.source}}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  name: "isCalculating (recalculating estimate)",
  render: () => <EstimatorProductCardDemo initialSelected isCalculating />
}`,..._.parameters?.docs?.source}}},v=[`Unselected`,`Selected`,`Featured`,`QuickDecisionEligible`,`Calculating`]}))();export{_ as Calculating,h as Featured,g as QuickDecisionEligible,m as Selected,p as Unselected,v as __namedExportsOrder,d as default};