import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,o as n,t as r}from"./esm-AWQ-KJXU.js";import{n as i,t as a}from"./FieldGrid-Bn8DjEk-.js";var o,s,c,l,u,d;e((()=>{r(),i(),o=t(),s={title:`Layout/FieldGrid`,component:a,parameters:{layout:`padded`}},c=()=>(0,o.jsxs)(a,{children:[(0,o.jsx)(n,{label:`First name`}),(0,o.jsx)(n,{label:`Last name`})]}),l=()=>(0,o.jsxs)(a,{columns:`wide-narrow`,children:[(0,o.jsx)(n,{label:`Street address`}),(0,o.jsx)(n,{label:`Apt / Suite`})]}),u=()=>(0,o.jsxs)(a,{columns:`wide-two-narrow`,children:[(0,o.jsx)(n,{label:`City`}),(0,o.jsx)(n,{label:`State`}),(0,o.jsx)(n,{label:`ZIP`})]}),c.__docgenInfo={description:``,methods:[],displayName:`EqualColumns`},l.__docgenInfo={description:``,methods:[],displayName:`WideAndNarrow`},u.__docgenInfo={description:``,methods:[],displayName:`WideAndTwoNarrow`},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`() => <FieldGrid>
    <TextField label="First name" />
    <TextField label="Last name" />
  </FieldGrid>`,...c.parameters?.docs?.source}}},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`() => <FieldGrid columns="wide-narrow">
    <TextField label="Street address" />
    <TextField label="Apt / Suite" />
  </FieldGrid>`,...l.parameters?.docs?.source}}},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`() => <FieldGrid columns="wide-two-narrow">
    <TextField label="City" />
    <TextField label="State" />
    <TextField label="ZIP" />
  </FieldGrid>`,...u.parameters?.docs?.source}}},d=[`EqualColumns`,`WideAndNarrow`,`WideAndTwoNarrow`]}))();export{c as EqualColumns,l as WideAndNarrow,u as WideAndTwoNarrow,d as __namedExportsOrder,s as default};