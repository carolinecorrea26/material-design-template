import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r,at as i,dt as a,t as o}from"./esm-AWQ-KJXU.js";import{i as s,n as c}from"./index.esm-DbA_UsRE.js";import{n as l,t as u}from"./FieldRenderer-DRJtoa2k.js";function d({field:e,forceError:t=!1,maxWidth:n=420}){let{control:r,trigger:a,formState:{errors:o}}=s({mode:`onChange`,defaultValues:{[e.id]:e.inputType===`checkbox`?!1:e.inputType===`checkbox-group`||e.inputType===`multi-select`?[]:``,"phone-type":`mobile`}});return(0,f.useEffect)(()=>{t&&a()},[t,a]),(0,p.jsx)(i,{sx:{maxWidth:n},children:(0,p.jsx)(u,{field:e,control:r,errors:o})})}var f,p,m,h,g,_,v,y,b,x,S,C,w,T,E,D,O,k,A,j,M,N,P,F,I,L,R,z,B,V,H,U;t((()=>{f=e(n(),1),c(),o(),l(),p=r(),m={title:`Forms/FieldRenderer`,component:u,parameters:{layout:`padded`,docs:{description:{component:`FieldRenderer is the single dispatcher every application page routes its
fields through — it owns validation rules, error/helper-text wiring, and
accessibility association (aria-describedby, radiogroup/group roles,
labelId) for every field type in the app. There is no per-type wrapper
component; this file demonstrates the real component with a real
react-hook-form context, not a mock.`}}}},h=new Set([`dropdown`,`radio`,`searchable-select`,`checkbox-group`,`multi-select`]),g=[{value:`a`,label:`Option A`},{value:`b`,label:`Option B`},{value:`c`,label:`Option C`}],_={args:{label:`First name`,inputType:`text`,required:!0,disabled:!1,labelVariant:`floating`,helperText:``,tooltip:``},argTypes:{inputType:{control:`select`,options:[`text`,`number`,`date`,`dropdown`,`radio`,`checkbox`,`checkbox-group`,`multi-select`,`searchable-select`]},labelVariant:{control:`select`,options:[`floating`,`standard`]},required:{control:`boolean`},disabled:{control:`boolean`},helperText:{control:`text`},tooltip:{control:`text`}},render:e=>(0,p.jsx)(d,{field:{id:`playground-field`,label:e.label,inputType:e.inputType,required:e.required,disabled:e.disabled,labelVariant:e.labelVariant,helperText:e.helperText||void 0,tooltip:e.tooltip||void 0,options:h.has(e.inputType)?g:void 0},maxWidth:480})},v={render:()=>(0,p.jsx)(d,{field:{id:`text-floating`,label:`First name`,inputType:`text`,required:!0,autoComplete:`given-name`}})},y={name:`Text — standard label`,render:()=>(0,p.jsx)(d,{field:{id:`text-standard`,label:`Last name`,inputType:`text`,labelVariant:`standard`,required:!0,autoComplete:`family-name`}})},b={render:()=>(0,p.jsx)(d,{field:{id:`email`,label:`Email address`,inputType:`text`,format:`email`,required:!0,autoComplete:`email`}})},x={name:`Phone — with type selector`,render:()=>(0,p.jsx)(d,{field:{id:`phone`,label:`Phone number`,inputType:`text`,format:`phone`,required:!0}})},S={name:`Phone — no type selector`,render:()=>(0,p.jsx)(d,{field:{id:`phone-plain`,label:`Business phone`,inputType:`text`,format:`phone`,showPhoneTypeSelector:!1}})},C={name:`Number`,render:()=>(0,p.jsx)(d,{field:{id:`number`,label:`Years self-employed`,inputType:`number`}})},w={render:()=>(0,p.jsx)(d,{field:{id:`currency`,label:`Average monthly income`,inputType:`text`,format:`currency`}})},T={render:()=>(0,p.jsx)(d,{field:{id:`percent`,label:`Ownership share`,inputType:`text`,format:`percent`}})},E={name:`SSN`,render:()=>(0,p.jsx)(d,{field:{id:`ssn`,label:`Social Security Number`,inputType:`text`,format:`ssn`,required:!0}})},D={name:`Date`,render:()=>(0,p.jsx)(d,{field:{id:`date`,label:`Date of birth`,inputType:`date`,required:!0,autoComplete:`bday`}})},O={render:()=>(0,p.jsxs)(p.Fragment,{children:[(0,p.jsx)(d,{field:{id:`month-year`,label:`Coverage start`,inputType:`text`,format:`month-year`}}),(0,p.jsxs)(a,{variant:`caption`,color:`text.secondary`,sx:{display:`block`,mt:1},children:[`Fully implemented but not currently used by any real field config in`,` `,(0,p.jsx)(`code`,{children:`src/config/fields/index.ts`}),` — kept documented so the code path stays covered.`]})]})},k={render:()=>(0,p.jsx)(d,{field:{id:`textarea`,label:`Additional details`,inputType:`text`,multiline:!0,minRows:3,placeholder:`Add any additional context here…`}})},A={name:`Dropdown — floating label`,render:()=>(0,p.jsx)(d,{field:{id:`dropdown-floating`,label:`State`,inputType:`dropdown`,required:!0,options:[{value:`ny`,label:`New York`},{value:`ca`,label:`California`},{value:`tx`,label:`Texas`}]}})},j={name:`Dropdown — standard label`,render:()=>(0,p.jsx)(d,{field:{id:`dropdown-standard`,label:`Business type`,inputType:`dropdown`,labelVariant:`standard`,options:[{value:`sole-prop`,label:`Sole Proprietor`},{value:`corp`,label:`Professional Corporation`},{value:`llc`,label:`LLC`}]}})},M={render:()=>(0,p.jsxs)(p.Fragment,{children:[(0,p.jsx)(d,{field:{id:`searchable-select`,label:`AVMA graduation year`,inputType:`searchable-select`,options:Array.from({length:6},(e,t)=>{let n=String(2024-t);return{value:n,label:n}})}}),(0,p.jsxs)(a,{variant:`caption`,color:`text.secondary`,sx:{display:`block`,mt:1},children:[`Any `,(0,p.jsx)(`code`,{children:`dropdown`}),` field is automatically promoted to a searchable select once it has 10+ options (e.g. the WAEPA federal agency list), unless it opts out.`]})]})},N={render:()=>(0,p.jsx)(d,{field:{id:`multi-select`,label:`Tobacco products used`,inputType:`multi-select`,options:[{value:`cigarettes`,label:`Cigarettes`},{value:`cigars`,label:`Cigars`},{value:`vaping`,label:`Vaping / e-cigarettes`},{value:`chewing`,label:`Chewing tobacco`}]}})},P={render:()=>(0,p.jsx)(d,{field:{id:`radio`,label:`Do you use tobacco products?`,inputType:`radio`,required:!0,options:[{value:`yes`,label:`Yes`},{value:`no`,label:`No`}]}})},F={name:`Checkbox — single`,render:()=>(0,p.jsx)(d,{field:{id:`checkbox`,label:`I authorize this bank account for premium payments.`,inputType:`checkbox`,required:!0}})},I={render:()=>(0,p.jsx)(d,{field:{id:`checkbox-group`,label:`Which of these apply to you?`,inputType:`checkbox-group`,options:[{value:`self-employed`,label:`Self-employed`},{value:`work-from-home`,label:`Work from home`},{value:`travel-often`,label:`Travel outside the US often`}]}})},L={render:()=>(0,p.jsxs)(p.Fragment,{children:[(0,p.jsx)(d,{field:{id:`disabled-text`,label:`Locked field`,inputType:`text`,disabled:!0}}),(0,p.jsx)(a,{variant:`caption`,color:`text.secondary`,sx:{display:`block`,mt:1},children:`Not previously demonstrated anywhere in the app's own documentation — added in this pass.`})]})},R={name:`Error — required text`,render:()=>(0,p.jsx)(d,{forceError:!0,field:{id:`error-text`,label:`Email address`,inputType:`text`,format:`email`,required:!0}})},z={name:`Error — required dropdown`,render:()=>(0,p.jsx)(d,{forceError:!0,field:{id:`error-dropdown`,label:`State`,inputType:`dropdown`,required:!0,options:[{value:`ny`,label:`New York`},{value:`ca`,label:`California`}]}})},B={name:`Error — required radio group`,render:()=>(0,p.jsx)(d,{forceError:!0,field:{id:`error-radio`,label:`Do you use tobacco products?`,inputType:`radio`,required:!0,options:[{value:`yes`,label:`Yes`},{value:`no`,label:`No`}]}})},V={name:`Error — required checkbox`,render:()=>(0,p.jsx)(d,{forceError:!0,field:{id:`error-checkbox`,label:`I authorize this bank account for premium payments.`,inputType:`checkbox`,required:!0}})},H={name:`Completion icons (debug — ?inputChecks)`,render:()=>{let e=new URLSearchParams(window.location.search).has(`inputChecks`);return(0,p.jsxs)(i,{sx:{maxWidth:480},children:[(0,p.jsxs)(a,{variant:`body2`,sx:{mb:1.5},children:[`FieldRenderer shows a green check / red X end-adornment per field only when the URL contains `,(0,p.jsx)(`code`,{children:`?inputChecks`}),`. It is off by default and not exposed anywhere in the UI — this is the only place it's documented as a toggle.`]}),(0,p.jsxs)(`button`,{onClick:()=>{let t=new URL(window.location.href);e?t.searchParams.delete(`inputChecks`):t.searchParams.set(`inputChecks`,`1`),window.location.href=t.toString()},type:`button`,style:{marginBottom:16},children:[e?`Disable`:`Enable`,` completion icons (reloads the preview)`]}),(0,p.jsx)(d,{field:{id:`completion-demo`,label:`First name`,inputType:`text`,required:!0}}),(0,p.jsxs)(a,{variant:`caption`,color:`text.secondary`,sx:{display:`block`,mt:1},children:[`Currently: `,e?`enabled`:`disabled`,`. Type a value to see the completed-state icon when enabled.`]})]})}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  args: {
    label: "First name",
    inputType: "text",
    required: true,
    disabled: false,
    labelVariant: "floating",
    helperText: "",
    tooltip: ""
  },
  argTypes: {
    inputType: {
      control: "select",
      options: ["text", "number", "date", "dropdown", "radio", "checkbox", "checkbox-group", "multi-select", "searchable-select"] satisfies FieldInputType[]
    },
    labelVariant: {
      control: "select",
      options: ["floating", "standard"]
    },
    required: {
      control: "boolean"
    },
    disabled: {
      control: "boolean"
    },
    helperText: {
      control: "text"
    },
    tooltip: {
      control: "text"
    }
  },
  render: args => {
    const field: FieldDefinition = {
      id: "playground-field",
      label: args.label,
      inputType: args.inputType,
      required: args.required,
      disabled: args.disabled,
      labelVariant: args.labelVariant,
      helperText: args.helperText || undefined,
      tooltip: args.tooltip || undefined,
      options: OPTION_TYPES.has(args.inputType) ? PLAYGROUND_OPTIONS : undefined
    };
    return <FieldHarness field={field} maxWidth={480} />;
  }
}`,..._.parameters?.docs?.source}}},v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{
  render: () => <FieldHarness field={{
    id: "text-floating",
    label: "First name",
    inputType: "text",
    required: true,
    autoComplete: "given-name"
  }} />
}`,...v.parameters?.docs?.source}}},y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  name: "Text — standard label",
  render: () => <FieldHarness field={{
    id: "text-standard",
    label: "Last name",
    inputType: "text",
    labelVariant: "standard",
    required: true,
    autoComplete: "family-name"
  }} />
}`,...y.parameters?.docs?.source}}},b.parameters={...b.parameters,docs:{...b.parameters?.docs,source:{originalSource:`{
  render: () => <FieldHarness field={{
    id: "email",
    label: "Email address",
    inputType: "text",
    format: "email",
    required: true,
    autoComplete: "email"
  }} />
}`,...b.parameters?.docs?.source}}},x.parameters={...x.parameters,docs:{...x.parameters?.docs,source:{originalSource:`{
  name: "Phone — with type selector",
  render: () => <FieldHarness field={{
    id: "phone",
    label: "Phone number",
    inputType: "text",
    format: "phone",
    required: true
  }} />
}`,...x.parameters?.docs?.source}}},S.parameters={...S.parameters,docs:{...S.parameters?.docs,source:{originalSource:`{
  name: "Phone — no type selector",
  render: () => <FieldHarness field={{
    id: "phone-plain",
    label: "Business phone",
    inputType: "text",
    format: "phone",
    showPhoneTypeSelector: false
  }} />
}`,...S.parameters?.docs?.source}}},C.parameters={...C.parameters,docs:{...C.parameters?.docs,source:{originalSource:`{
  name: "Number",
  render: () => <FieldHarness field={{
    id: "number",
    label: "Years self-employed",
    inputType: "number"
  }} />
}`,...C.parameters?.docs?.source}}},w.parameters={...w.parameters,docs:{...w.parameters?.docs,source:{originalSource:`{
  render: () => <FieldHarness field={{
    id: "currency",
    label: "Average monthly income",
    inputType: "text",
    format: "currency"
  }} />
}`,...w.parameters?.docs?.source}}},T.parameters={...T.parameters,docs:{...T.parameters?.docs,source:{originalSource:`{
  render: () => <FieldHarness field={{
    id: "percent",
    label: "Ownership share",
    inputType: "text",
    format: "percent"
  }} />
}`,...T.parameters?.docs?.source}}},E.parameters={...E.parameters,docs:{...E.parameters?.docs,source:{originalSource:`{
  name: "SSN",
  render: () => <FieldHarness field={{
    id: "ssn",
    label: "Social Security Number",
    inputType: "text",
    format: "ssn",
    required: true
  }} />
}`,...E.parameters?.docs?.source}}},D.parameters={...D.parameters,docs:{...D.parameters?.docs,source:{originalSource:`{
  name: "Date",
  render: () => <FieldHarness field={{
    id: "date",
    label: "Date of birth",
    inputType: "date",
    required: true,
    autoComplete: "bday"
  }} />
}`,...D.parameters?.docs?.source}}},O.parameters={...O.parameters,docs:{...O.parameters?.docs,source:{originalSource:`{
  render: () => <>
      <FieldHarness field={{
      id: "month-year",
      label: "Coverage start",
      inputType: "text",
      format: "month-year"
    }} />
      <Typography variant="caption" color="text.secondary" sx={{
      display: "block",
      mt: 1
    }}>
        Fully implemented but not currently used by any real field config in{" "}
        <code>src/config/fields/index.ts</code> — kept documented so the code
        path stays covered.
      </Typography>
    </>
}`,...O.parameters?.docs?.source}}},k.parameters={...k.parameters,docs:{...k.parameters?.docs,source:{originalSource:`{
  render: () => <FieldHarness field={{
    id: "textarea",
    label: "Additional details",
    inputType: "text",
    multiline: true,
    minRows: 3,
    placeholder: "Add any additional context here…"
  }} />
}`,...k.parameters?.docs?.source}}},A.parameters={...A.parameters,docs:{...A.parameters?.docs,source:{originalSource:`{
  name: "Dropdown — floating label",
  render: () => <FieldHarness field={{
    id: "dropdown-floating",
    label: "State",
    inputType: "dropdown",
    required: true,
    options: [{
      value: "ny",
      label: "New York"
    }, {
      value: "ca",
      label: "California"
    }, {
      value: "tx",
      label: "Texas"
    }]
  }} />
}`,...A.parameters?.docs?.source}}},j.parameters={...j.parameters,docs:{...j.parameters?.docs,source:{originalSource:`{
  name: "Dropdown — standard label",
  render: () => <FieldHarness field={{
    id: "dropdown-standard",
    label: "Business type",
    inputType: "dropdown",
    labelVariant: "standard",
    options: [{
      value: "sole-prop",
      label: "Sole Proprietor"
    }, {
      value: "corp",
      label: "Professional Corporation"
    }, {
      value: "llc",
      label: "LLC"
    }]
  }} />
}`,...j.parameters?.docs?.source}}},M.parameters={...M.parameters,docs:{...M.parameters?.docs,source:{originalSource:`{
  render: () => <>
      <FieldHarness field={{
      id: "searchable-select",
      label: "AVMA graduation year",
      inputType: "searchable-select",
      options: Array.from({
        length: 6
      }, (_, i) => {
        const year = String(2024 - i);
        return {
          value: year,
          label: year
        };
      })
    }} />
      <Typography variant="caption" color="text.secondary" sx={{
      display: "block",
      mt: 1
    }}>
        Any <code>dropdown</code> field is automatically promoted to a
        searchable select once it has 10+ options (e.g. the WAEPA federal
        agency list), unless it opts out.
      </Typography>
    </>
}`,...M.parameters?.docs?.source}}},N.parameters={...N.parameters,docs:{...N.parameters?.docs,source:{originalSource:`{
  render: () => <FieldHarness field={{
    id: "multi-select",
    label: "Tobacco products used",
    inputType: "multi-select",
    options: [{
      value: "cigarettes",
      label: "Cigarettes"
    }, {
      value: "cigars",
      label: "Cigars"
    }, {
      value: "vaping",
      label: "Vaping / e-cigarettes"
    }, {
      value: "chewing",
      label: "Chewing tobacco"
    }]
  }} />
}`,...N.parameters?.docs?.source}}},P.parameters={...P.parameters,docs:{...P.parameters?.docs,source:{originalSource:`{
  render: () => <FieldHarness field={{
    id: "radio",
    label: "Do you use tobacco products?",
    inputType: "radio",
    required: true,
    options: [{
      value: "yes",
      label: "Yes"
    }, {
      value: "no",
      label: "No"
    }]
  }} />
}`,...P.parameters?.docs?.source}}},F.parameters={...F.parameters,docs:{...F.parameters?.docs,source:{originalSource:`{
  name: "Checkbox — single",
  render: () => <FieldHarness field={{
    id: "checkbox",
    label: "I authorize this bank account for premium payments.",
    inputType: "checkbox",
    required: true
  }} />
}`,...F.parameters?.docs?.source}}},I.parameters={...I.parameters,docs:{...I.parameters?.docs,source:{originalSource:`{
  render: () => <FieldHarness field={{
    id: "checkbox-group",
    label: "Which of these apply to you?",
    inputType: "checkbox-group",
    options: [{
      value: "self-employed",
      label: "Self-employed"
    }, {
      value: "work-from-home",
      label: "Work from home"
    }, {
      value: "travel-often",
      label: "Travel outside the US often"
    }]
  }} />
}`,...I.parameters?.docs?.source}}},L.parameters={...L.parameters,docs:{...L.parameters?.docs,source:{originalSource:`{
  render: () => <>
      <FieldHarness field={{
      id: "disabled-text",
      label: "Locked field",
      inputType: "text",
      disabled: true
    }} />
      <Typography variant="caption" color="text.secondary" sx={{
      display: "block",
      mt: 1
    }}>
        Not previously demonstrated anywhere in the app's own documentation —
        added in this pass.
      </Typography>
    </>
}`,...L.parameters?.docs?.source}}},R.parameters={...R.parameters,docs:{...R.parameters?.docs,source:{originalSource:`{
  name: "Error — required text",
  render: () => <FieldHarness forceError field={{
    id: "error-text",
    label: "Email address",
    inputType: "text",
    format: "email",
    required: true
  }} />
}`,...R.parameters?.docs?.source}}},z.parameters={...z.parameters,docs:{...z.parameters?.docs,source:{originalSource:`{
  name: "Error — required dropdown",
  render: () => <FieldHarness forceError field={{
    id: "error-dropdown",
    label: "State",
    inputType: "dropdown",
    required: true,
    options: [{
      value: "ny",
      label: "New York"
    }, {
      value: "ca",
      label: "California"
    }]
  }} />
}`,...z.parameters?.docs?.source}}},B.parameters={...B.parameters,docs:{...B.parameters?.docs,source:{originalSource:`{
  name: "Error — required radio group",
  render: () => <FieldHarness forceError field={{
    id: "error-radio",
    label: "Do you use tobacco products?",
    inputType: "radio",
    required: true,
    options: [{
      value: "yes",
      label: "Yes"
    }, {
      value: "no",
      label: "No"
    }]
  }} />
}`,...B.parameters?.docs?.source}}},V.parameters={...V.parameters,docs:{...V.parameters?.docs,source:{originalSource:`{
  name: "Error — required checkbox",
  render: () => <FieldHarness forceError field={{
    id: "error-checkbox",
    label: "I authorize this bank account for premium payments.",
    inputType: "checkbox",
    required: true
  }} />
}`,...V.parameters?.docs?.source}}},H.parameters={...H.parameters,docs:{...H.parameters?.docs,source:{originalSource:`{
  name: "Completion icons (debug — ?inputChecks)",
  render: () => {
    const hasParam = new URLSearchParams(window.location.search).has("inputChecks");
    const toggle = () => {
      const url = new URL(window.location.href);
      if (hasParam) url.searchParams.delete("inputChecks");else url.searchParams.set("inputChecks", "1");
      window.location.href = url.toString();
    };
    return <Box sx={{
      maxWidth: 480
    }}>
        <Typography variant="body2" sx={{
        mb: 1.5
      }}>
          FieldRenderer shows a green check / red X end-adornment per field
          only when the URL contains <code>?inputChecks</code>. It is off by
          default and not exposed anywhere in the UI — this is the only place
          it's documented as a toggle.
        </Typography>
        <button onClick={toggle} type="button" style={{
        marginBottom: 16
      }}>
          {hasParam ? "Disable" : "Enable"} completion icons (reloads the preview)
        </button>
        <FieldHarness field={{
        id: "completion-demo",
        label: "First name",
        inputType: "text",
        required: true
      }} />
        <Typography variant="caption" color="text.secondary" sx={{
        display: "block",
        mt: 1
      }}>
          Currently: {hasParam ? "enabled" : "disabled"}. Type a value to see
          the completed-state icon when enabled.
        </Typography>
      </Box>;
  }
}`,...H.parameters?.docs?.source}}},U=`Playground.TextFloatingLabel.TextStandardLabel.Email.PhoneWithTypeSelector.PhonePlain.NumberInput.Currency.Percent.Ssn.DateInput.MonthYear.Textarea.DropdownFloatingLabel.DropdownStandardLabel.SearchableSelect.MultiSelect.Radio.CheckboxSingle.CheckboxGroup.Disabled.TextErrorRequired.DropdownErrorRequired.RadioErrorRequired.CheckboxErrorRequired.CompletionIconsDebugMode`.split(`.`)}))();export{V as CheckboxErrorRequired,I as CheckboxGroup,F as CheckboxSingle,H as CompletionIconsDebugMode,w as Currency,D as DateInput,L as Disabled,z as DropdownErrorRequired,A as DropdownFloatingLabel,j as DropdownStandardLabel,b as Email,O as MonthYear,N as MultiSelect,C as NumberInput,T as Percent,S as PhonePlain,x as PhoneWithTypeSelector,_ as Playground,P as Radio,B as RadioErrorRequired,M as SearchableSelect,E as Ssn,R as TextErrorRequired,v as TextFloatingLabel,y as TextStandardLabel,k as Textarea,U as __namedExportsOrder,m as default};