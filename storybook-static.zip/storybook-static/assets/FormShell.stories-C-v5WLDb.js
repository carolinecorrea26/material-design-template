import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,dt as n,t as r}from"./esm-AWQ-KJXU.js";import{n as i,t as a}from"./FormShell-C4OXUhsM.js";var o,s,c,l,u;e((()=>{r(),i(),o=t(),s={title:`Layout/FormShell`,component:a,parameters:{layout:`padded`,docs:{description:{component:`FormShell is the rounded, elevated Paper container every FormRoutePage-
based page renders its content inside. Resume, ResumeCode, and ResumeMethod
now compose it with PageShell and PageHeader as well.`}}}},c={render:()=>(0,o.jsx)(a,{sx:{px:{xs:2,sm:`48px`},py:{xs:2,sm:`32px`},maxWidth:480},children:(0,o.jsx)(n,{variant:`body1`,children:`Any page content — FormShell only supplies the radius, shadow, and background surface.`})})},l={name:`Custom sx (PaperProps passthrough)`,render:()=>(0,o.jsx)(a,{sx:{p:4,maxWidth:480},children:(0,o.jsxs)(n,{variant:`body2`,color:`text.secondary`,children:[`FormShell forwards any `,(0,o.jsx)(`code`,{children:`PaperProps`}),` and merges caller`,` `,(0,o.jsx)(`code`,{children:`sx`}),` with its own base styles (radius + shadow), rather than overwriting them.`]})})},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  render: () => <FormShell sx={{
    px: {
      xs: 2,
      sm: "48px"
    },
    py: {
      xs: 2,
      sm: "32px"
    },
    maxWidth: 480
  }}>
      <Typography variant="body1">
        Any page content — FormShell only supplies the radius, shadow, and
        background surface.
      </Typography>
    </FormShell>
}`,...c.parameters?.docs?.source}}},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  name: "Custom sx (PaperProps passthrough)",
  render: () => <FormShell sx={{
    p: 4,
    maxWidth: 480
  }}>
      <Typography variant="body2" color="text.secondary">
        FormShell forwards any <code>PaperProps</code> and merges caller{" "}
        <code>sx</code> with its own base styles (radius + shadow), rather
        than overwriting them.
      </Typography>
    </FormShell>
}`,...l.parameters?.docs?.source}}},u=[`Default`,`CustomPadding`]}))();export{l as CustomPadding,c as Default,u as __namedExportsOrder,s as default};