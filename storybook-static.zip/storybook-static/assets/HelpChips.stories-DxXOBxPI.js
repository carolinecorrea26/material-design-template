import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,at as n,dt as r,ft as i,t as a}from"./esm-AWQ-KJXU.js";import{n as o,t as s}from"./HelpChips-DiYg6vpi.js";var c,l,u,d,f,p,m,h;e((()=>{a(),o(),c=t(),l={title:`Content/HelpChips`,component:s,parameters:{layout:`padded`,docs:{description:{component:`FormHelpChips is the most broadly reused component found in the Phase 1
audit — a horizontally scrollable row of clickable "help topic" chips
that open contextual help drawers. Used on Beneficiary, Coverage,
Membership, HealthDi, HealthSi, and Payment.`}}}},u=[{id:`how-much`,label:`How much does it cost?`},{id:`quick-decision`,label:`About QuickDecision`},{id:`coverage-options`,label:`Coverage options`}],d={render:()=>(0,c.jsx)(s,{items:u,onSelect:()=>{}})},f={name:`Empty (renders null)`,render:()=>(0,c.jsxs)(c.Fragment,{children:[(0,c.jsx)(s,{items:[],onSelect:()=>{}}),(0,c.jsxs)(r,{variant:`caption`,color:`text.secondary`,children:[`No chips, no wrapper markup — the component returns`,` `,(0,c.jsx)(`code`,{children:`null`}),` when `,(0,c.jsx)(`code`,{children:`items.length === 0`}),`.`]})]})},p={name:`Narrow container (overflow-fade, mobile-only)`,render:()=>(0,c.jsxs)(n,{sx:{maxWidth:280,border:`1px dashed`,borderColor:`divider`,p:1},children:[(0,c.jsx)(s,{items:[{id:`1`,label:`How much does it cost?`},{id:`2`,label:`About QuickDecision`},{id:`3`,label:`Coverage options`},{id:`4`,label:`Application review`},{id:`5`,label:`Need help?`}],onSelect:()=>{}}),(0,c.jsxs)(r,{variant:`caption`,color:`text.secondary`,sx:{display:`block`,mt:1},children:[`The right-edge fade only renders below the `,(0,c.jsx)(`code`,{children:`md`}),` `,`breakpoint and only once the row actually overflows — resize the viewport to see it appear/disappear.`]})]})},m={render:()=>(0,c.jsxs)(i,{severity:`warning`,sx:{maxWidth:700},children:[`The scroll container hides its native scrollbar (`,(0,c.jsx)(`code`,{children:`scrollbarWidth: "none"`}),`) on every browser. On mobile this is compensated for by the fade affordance above; on desktop, with no fade and no visible scrollbar, a user relying on a visible scrollbar has no indication the row scrolls. Flagged in the Phase 1 audit, not fixed here.`]})},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: () => <FormHelpChips items={items} onSelect={() => {}} />
}`,...d.parameters?.docs?.source}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  name: "Empty (renders null)",
  render: () => <>
      <FormHelpChips items={[]} onSelect={() => {}} />
      <Typography variant="caption" color="text.secondary">
        No chips, no wrapper markup — the component returns{" "}
        <code>null</code> when <code>items.length === 0</code>.
      </Typography>
    </>
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  name: "Narrow container (overflow-fade, mobile-only)",
  render: () => <Box sx={{
    maxWidth: 280,
    border: "1px dashed",
    borderColor: "divider",
    p: 1
  }}>
      <FormHelpChips items={[{
      id: "1",
      label: "How much does it cost?"
    }, {
      id: "2",
      label: "About QuickDecision"
    }, {
      id: "3",
      label: "Coverage options"
    }, {
      id: "4",
      label: "Application review"
    }, {
      id: "5",
      label: "Need help?"
    }]} onSelect={() => {}} />
      <Typography variant="caption" color="text.secondary" sx={{
      display: "block",
      mt: 1
    }}>
        The right-edge fade only renders below the <code>md</code>{" "}
        breakpoint and only once the row actually overflows — resize the
        viewport to see it appear/disappear.
      </Typography>
    </Box>
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  render: () => <Alert severity="warning" sx={{
    maxWidth: 700
  }}>
      The scroll container hides its native scrollbar (
      <code>scrollbarWidth: "none"</code>) on every browser. On mobile this
      is compensated for by the fade affordance above; on desktop, with no
      fade and no visible scrollbar, a user relying on a visible scrollbar
      has no indication the row scrolls. Flagged in the Phase 1 audit, not
      fixed here.
    </Alert>
}`,...m.parameters?.docs?.source}}},h=[`Default`,`Empty`,`NarrowContainerWithOverflow`,`AccessibilityNote`]}))();export{m as AccessibilityNote,d as Default,f as Empty,p as NarrowContainerWithOverflow,h as __namedExportsOrder,l as default};