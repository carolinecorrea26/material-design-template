import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r,P as i,S as a,at as o,dt as s,t as c}from"./esm-AWQ-KJXU.js";import{i as l,n as u,r as d}from"./content-CYNdyLgC.js";import{a as f,c as p,i as m,l as h,n as g,o as _,r as v,s as y,t as b,u as x}from"./TuneRounded-CTq1_FzP.js";import{n as S,t as C}from"./InfoOutlined-DtVmt2CM.js";import{n as w,t as T}from"./LockOutlined-D8Z7qcNW.js";import{a as E,c as D,i as O,r as k}from"./QuickDecisionInfoBox-BV0I0PiQ.js";import{n as A}from"./CoverageNeedsCalculator-BC-ANFx4.js";import{n as j,t as M}from"./AppDrawer-BZqEFTP6.js";import{n as N,t as P}from"./CoverageOptionsPanel-BbYIdkoP.js";function F({onOpenQuickDecision:e}){let t=u().help.applicationReview;return(0,z.jsxs)(a,{spacing:2,children:[(0,z.jsx)(s,{variant:`body2`,color:`text.secondary`,children:t.intro}),(0,z.jsxs)(o,{children:[(0,z.jsx)(s,{variant:`subtitle2`,sx:{fontWeight:700,mb:1},children:t.whatToExpectTitle}),(0,z.jsx)(a,{component:`ul`,spacing:1,sx:{m:0,pl:2.5},children:t.whatToExpectItems.map((e,t)=>(0,z.jsx)(s,{component:`li`,variant:`body2`,color:`text.secondary`,children:e},t))})]}),(0,z.jsxs)(s,{variant:`body2`,color:`text.secondary`,children:[t.closingNote.split(`QuickDecision`)[0],(0,z.jsx)(k,{onClick:e,children:(0,z.jsx)(E,{})}),t.closingNote.split(`QuickDecision`).slice(1).join(`QuickDecision`)]})]})}function I({associationName:e}){let t=u().help.groupInsurance;return(0,z.jsxs)(a,{spacing:2,children:[(0,z.jsx)(s,{variant:`body2`,color:`text.secondary`,children:l(t.intro)}),(0,z.jsxs)(o,{children:[(0,z.jsx)(s,{variant:`subtitle2`,sx:{fontWeight:700,mb:1},children:t.exploreTitle}),(0,z.jsx)(a,{component:`ul`,spacing:1,sx:{m:0,pl:2.5},children:t.exploreItems.map((e,t)=>(0,z.jsx)(s,{component:`li`,variant:`body2`,color:`text.secondary`,children:e},t))})]})]})}function L({productsByCategory:e}){return(0,z.jsxs)(a,{spacing:2.25,children:[(0,z.jsx)(s,{variant:`body2`,color:`text.secondary`,children:`These products are available through this group. You can review and select coverage options later in the application.`}),(0,z.jsx)(a,{spacing:2,children:e.map(({category:e,products:t})=>(0,z.jsxs)(o,{children:[(0,z.jsx)(s,{variant:`subtitle2`,sx:{fontWeight:700,mb:.75},children:e.label}),(0,z.jsx)(a,{spacing:.75,children:t.map(e=>(0,z.jsx)(i,{href:`#`,underline:`hover`,onClick:e=>e.preventDefault(),sx:{width:`fit-content`,color:`primary.main`,fontSize:`0.875rem`,fontWeight:600,lineHeight:1.35,textUnderlineOffset:`0.15em`},children:e.name},e.id))})]},e.id))})]})}function R({initialCategory:e}={}){return(0,z.jsx)(P,{variant:`drawer`,initialCategory:e})}var z,B,V,H,U,W=t((()=>{c(),S(),x(),g(),w(),p(),m(),_(),A(),D(),N(),Y(),d(),z=r(),B={id:`application-process`,label:`How does applying work?`,title:`How does applying work?`,content:(0,z.jsx)(G,{variant:`drawer`})},V={id:`coverage-options-available`,label:`What are my coverage options?`,title:`What are my coverage options?`,content:(0,z.jsx)(R,{})},H=(()=>{let{whatIs:e,percentageShare:t}=u().help.beneficiary;return[{id:`beneficiary-basics`,label:`What is a beneficiary?`,title:`What is a beneficiary?`,content:(0,z.jsx)(a,{spacing:2,children:e.paragraphs.map((e,t)=>(0,z.jsx)(s,{variant:`body2`,children:e},t))})},{id:`beneficiary-share`,label:`What is the % share?`,title:`What is the % share?`,content:(0,z.jsx)(a,{spacing:2,children:t.paragraphs.map((e,t)=>(0,z.jsx)(s,{variant:`body2`,children:e},t))})}]})(),(()=>{let e=u().help.whyAsked,t=[h,b,C];return{id:`why-asked`,label:`Why is this information being asked?`,title:`Why is this information being asked?`,content:(0,z.jsxs)(a,{spacing:3,children:[(0,z.jsx)(s,{variant:`body2`,color:`text.secondary`,children:e.intro}),e.sections.map((e,n)=>(0,z.jsxs)(o,{sx:{display:`flex`,gap:2},children:[(0,z.jsx)(t[n]??C,{sx:{color:`primary.main`,fontSize:`2.5rem`,flexShrink:0}}),(0,z.jsxs)(o,{sx:{flex:1},children:[(0,z.jsx)(s,{variant:`subtitle1`,sx:{fontWeight:600,mb:.5},children:e.title}),(0,z.jsx)(s,{variant:`body2`,color:`text.secondary`,children:e.description})]})]},n))]})}})(),U=(()=>{let e=u().help.paymentHandling,t=[y,T,v,f];return{id:`payment-handling`,label:`How is my payment information handled?`,title:`How is my payment information handled?`,content:(0,z.jsxs)(a,{spacing:3,children:[(0,z.jsx)(s,{variant:`body2`,color:`text.secondary`,children:e.intro}),e.sections.map((e,n)=>(0,z.jsxs)(o,{sx:{display:`flex`,gap:2},children:[(0,z.jsx)(t[n]??C,{sx:{color:`primary.main`,fontSize:`2.5rem`,flexShrink:0}}),(0,z.jsxs)(o,{sx:{flex:1},children:[(0,z.jsx)(s,{variant:`subtitle1`,sx:{fontWeight:600,mb:.5},children:e.title}),(0,z.jsx)(s,{variant:`body2`,color:`text.secondary`,children:e.description})]})]},n))]})}})(),F.__docgenInfo={description:``,methods:[],displayName:`ApplicationReviewDrawerContent`,props:{onOpenQuickDecision:{required:!0,tsType:{name:`signature`,type:`function`,raw:`() => void`,signature:{arguments:[],return:{name:`void`}}},description:``}}},I.__docgenInfo={description:``,methods:[],displayName:`GroupInsuranceDrawerContent`,props:{associationName:{required:!0,tsType:{name:`string`},description:``}}},L.__docgenInfo={description:``,methods:[],displayName:`CoverageProductsDrawerContent`,props:{productsByCategory:{required:!0,tsType:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  category: (typeof coverageCategories)[number];
  products: CoverageDefinition[];
}`,signature:{properties:[{key:`category`,value:{name:`unknown[number]`,raw:`(typeof coverageCategories)[number]`,required:!0}},{key:`products`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  id: string;
  code: string;
  categoryId: CoverageCategoryId;
  name: string;
  /** External product brochure or certificate URL. */
  brochureUrl?: string;
  featured?: boolean;
  underwritingType: CoverageUnderwritingType;
  definition: string;
  description?: string;
  /** Note displayed per-applicant inside the product card (supports {maxAmount} placeholder) */
  coverageNote?: string;
  /** Per-applicant info notes displayed above the applicant fields */
  applicantNotes?: Partial<Record<CoverageApplicantId, string>>;
  /** Product-level alert displayed below the product description */
  productWarning?: {
    severity: "warning" | "info";
    title?: string;
    message: string;
  };
  /** Structured content block displayed below the product warning */
  productContent?: Array<
    | { type: "heading"; text: string }
    | { type: "paragraph"; text: string }
    | { type: "list"; items: string[] }
    | { type: "section"; heading: string; body: string[] }
  >;
  applicants: CoverageApplicantId[];
  minAmount?: number;
  maxAmount?: number;
  amountStep?: number;
  spouseMinAmount?: number;
  spouseMaxAmount?: number;
  spouseAmountStep?: number;
  childMinAmount?: number;
  childMaxAmount?: number;
  childAmountStep?: number;
  options: {
    id: string;
    type: string;
    choices: unknown[];
  }[];
  riders?: RiderDefinition[];
  waitingPeriodOptions?: WaitingPeriodOption[];
  waitingPeriodOptionsByApplicant?: Partial<
    Record<CoverageApplicantId, WaitingPeriodOption[]>
  >;
  maxBenefitPeriodOptions?: MaxBenefitPeriodOption[];
  maxBenefitPeriodOptionsByApplicant?: Partial<
    Record<CoverageApplicantId, MaxBenefitPeriodOption[]>
  >;
}`,signature:{properties:[{key:`id`,value:{name:`string`,required:!0}},{key:`code`,value:{name:`string`,required:!0}},{key:`categoryId`,value:{name:`union`,raw:`"LI" | "AD" | "DI" | "OO" | "SH"`,elements:[{name:`literal`,value:`"LI"`},{name:`literal`,value:`"AD"`},{name:`literal`,value:`"DI"`},{name:`literal`,value:`"OO"`},{name:`literal`,value:`"SH"`}],required:!0}},{key:`name`,value:{name:`string`,required:!0}},{key:`brochureUrl`,value:{name:`string`,required:!1},description:`External product brochure or certificate URL.`},{key:`featured`,value:{name:`boolean`,required:!1}},{key:`underwritingType`,value:{name:`union`,raw:`| "FUW"
| "GI"
| "NA"
| "QD"
| "SI"
| "TELE"`,elements:[{name:`literal`,value:`"FUW"`},{name:`literal`,value:`"GI"`},{name:`literal`,value:`"NA"`},{name:`literal`,value:`"QD"`},{name:`literal`,value:`"SI"`},{name:`literal`,value:`"TELE"`}],required:!0}},{key:`definition`,value:{name:`string`,required:!0}},{key:`description`,value:{name:`string`,required:!1}},{key:`coverageNote`,value:{name:`string`,required:!1},description:`Note displayed per-applicant inside the product card (supports {maxAmount} placeholder)`},{key:`applicantNotes`,value:{name:`Partial`,elements:[{name:`Record`,elements:[{name:`union`,raw:`"member" | "spouse" | "child"`,elements:[{name:`literal`,value:`"member"`},{name:`literal`,value:`"spouse"`},{name:`literal`,value:`"child"`}]},{name:`string`}],raw:`Record<CoverageApplicantId, string>`}],raw:`Partial<Record<CoverageApplicantId, string>>`,required:!1},description:`Per-applicant info notes displayed above the applicant fields`},{key:`productWarning`,value:{name:`signature`,type:`object`,raw:`{
  severity: "warning" | "info";
  title?: string;
  message: string;
}`,signature:{properties:[{key:`severity`,value:{name:`union`,raw:`"warning" | "info"`,elements:[{name:`literal`,value:`"warning"`},{name:`literal`,value:`"info"`}],required:!0}},{key:`title`,value:{name:`string`,required:!1}},{key:`message`,value:{name:`string`,required:!0}}]},required:!1},description:`Product-level alert displayed below the product description`},{key:`productContent`,value:{name:`Array`,elements:[{name:`union`,raw:`| { type: "heading"; text: string }
| { type: "paragraph"; text: string }
| { type: "list"; items: string[] }
| { type: "section"; heading: string; body: string[] }`,elements:[{name:`signature`,type:`object`,raw:`{ type: "heading"; text: string }`,signature:{properties:[{key:`type`,value:{name:`literal`,value:`"heading"`,required:!0}},{key:`text`,value:{name:`string`,required:!0}}]}},{name:`signature`,type:`object`,raw:`{ type: "paragraph"; text: string }`,signature:{properties:[{key:`type`,value:{name:`literal`,value:`"paragraph"`,required:!0}},{key:`text`,value:{name:`string`,required:!0}}]}},{name:`signature`,type:`object`,raw:`{ type: "list"; items: string[] }`,signature:{properties:[{key:`type`,value:{name:`literal`,value:`"list"`,required:!0}},{key:`items`,value:{name:`Array`,elements:[{name:`string`}],raw:`string[]`,required:!0}}]}},{name:`signature`,type:`object`,raw:`{ type: "section"; heading: string; body: string[] }`,signature:{properties:[{key:`type`,value:{name:`literal`,value:`"section"`,required:!0}},{key:`heading`,value:{name:`string`,required:!0}},{key:`body`,value:{name:`Array`,elements:[{name:`string`}],raw:`string[]`,required:!0}}]}}]}],raw:`Array<
  | { type: "heading"; text: string }
  | { type: "paragraph"; text: string }
  | { type: "list"; items: string[] }
  | { type: "section"; heading: string; body: string[] }
>`,required:!1},description:`Structured content block displayed below the product warning`},{key:`applicants`,value:{name:`Array`,elements:[{name:`union`,raw:`"member" | "spouse" | "child"`,elements:[{name:`literal`,value:`"member"`},{name:`literal`,value:`"spouse"`},{name:`literal`,value:`"child"`}]}],raw:`CoverageApplicantId[]`,required:!0}},{key:`minAmount`,value:{name:`number`,required:!1}},{key:`maxAmount`,value:{name:`number`,required:!1}},{key:`amountStep`,value:{name:`number`,required:!1}},{key:`spouseMinAmount`,value:{name:`number`,required:!1}},{key:`spouseMaxAmount`,value:{name:`number`,required:!1}},{key:`spouseAmountStep`,value:{name:`number`,required:!1}},{key:`childMinAmount`,value:{name:`number`,required:!1}},{key:`childMaxAmount`,value:{name:`number`,required:!1}},{key:`childAmountStep`,value:{name:`number`,required:!1}},{key:`options`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  id: string;
  type: string;
  choices: unknown[];
}`,signature:{properties:[{key:`id`,value:{name:`string`,required:!0}},{key:`type`,value:{name:`string`,required:!0}},{key:`choices`,value:{name:`Array`,elements:[{name:`unknown`}],raw:`unknown[]`,required:!0}}]}}],raw:`{
  id: string;
  type: string;
  choices: unknown[];
}[]`,required:!0}},{key:`riders`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  id: string;
  name: string;
  description: string;
  /** If true, the rider also has a coverage amount selection */
  hasAmount?: boolean;
  minAmount?: number;
  maxAmount?: number;
  spouseMinAmount?: number;
  spouseMaxAmount?: number;
  childMinAmount?: number;
  childMaxAmount?: number;
  applicants?: CoverageApplicantId[];
  /** Multiplier applied to the base premium when this rider is selected (e.g. 0.05 = +5%) */
  premiumFactor: number;
}`,signature:{properties:[{key:`id`,value:{name:`string`,required:!0}},{key:`name`,value:{name:`string`,required:!0}},{key:`description`,value:{name:`string`,required:!0}},{key:`hasAmount`,value:{name:`boolean`,required:!1},description:`If true, the rider also has a coverage amount selection`},{key:`minAmount`,value:{name:`number`,required:!1}},{key:`maxAmount`,value:{name:`number`,required:!1}},{key:`spouseMinAmount`,value:{name:`number`,required:!1}},{key:`spouseMaxAmount`,value:{name:`number`,required:!1}},{key:`childMinAmount`,value:{name:`number`,required:!1}},{key:`childMaxAmount`,value:{name:`number`,required:!1}},{key:`applicants`,value:{name:`Array`,elements:[{name:`union`,raw:`"member" | "spouse" | "child"`,elements:[{name:`literal`,value:`"member"`},{name:`literal`,value:`"spouse"`},{name:`literal`,value:`"child"`}]}],raw:`CoverageApplicantId[]`,required:!1}},{key:`premiumFactor`,value:{name:`number`,required:!0},description:`Multiplier applied to the base premium when this rider is selected (e.g. 0.05 = +5%)`}]}}],raw:`RiderDefinition[]`,required:!1}},{key:`waitingPeriodOptions`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  label: string;
  value: string;
  days: number;
}`,signature:{properties:[{key:`label`,value:{name:`string`,required:!0}},{key:`value`,value:{name:`string`,required:!0}},{key:`days`,value:{name:`number`,required:!0}}]}}],raw:`WaitingPeriodOption[]`,required:!1}},{key:`waitingPeriodOptionsByApplicant`,value:{name:`Partial`,elements:[{name:`Record`,elements:[{name:`union`,raw:`"member" | "spouse" | "child"`,elements:[{name:`literal`,value:`"member"`},{name:`literal`,value:`"spouse"`},{name:`literal`,value:`"child"`}]},{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  label: string;
  value: string;
  days: number;
}`,signature:{properties:[{key:`label`,value:{name:`string`,required:!0}},{key:`value`,value:{name:`string`,required:!0}},{key:`days`,value:{name:`number`,required:!0}}]}}],raw:`WaitingPeriodOption[]`}],raw:`Record<CoverageApplicantId, WaitingPeriodOption[]>`}],raw:`Partial<
  Record<CoverageApplicantId, WaitingPeriodOption[]>
>`,required:!1}},{key:`maxBenefitPeriodOptions`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  label: string;
  value: string;
}`,signature:{properties:[{key:`label`,value:{name:`string`,required:!0}},{key:`value`,value:{name:`string`,required:!0}}]}}],raw:`MaxBenefitPeriodOption[]`,required:!1}},{key:`maxBenefitPeriodOptionsByApplicant`,value:{name:`Partial`,elements:[{name:`Record`,elements:[{name:`union`,raw:`"member" | "spouse" | "child"`,elements:[{name:`literal`,value:`"member"`},{name:`literal`,value:`"spouse"`},{name:`literal`,value:`"child"`}]},{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  label: string;
  value: string;
}`,signature:{properties:[{key:`label`,value:{name:`string`,required:!0}},{key:`value`,value:{name:`string`,required:!0}}]}}],raw:`MaxBenefitPeriodOption[]`}],raw:`Record<CoverageApplicantId, MaxBenefitPeriodOption[]>`}],raw:`Partial<
  Record<CoverageApplicantId, MaxBenefitPeriodOption[]>
>`,required:!1}}]}}],raw:`CoverageDefinition[]`,required:!0}}]}}],raw:`CoverageProductGroup[]`},description:``}}},R.__docgenInfo={description:``,methods:[],displayName:`CoverageOptionsDrawerContent`}}));function G({variant:e,onOpenApplicationReview:t,onOpenQuickDecision:n}){let[r,i]=(0,K.useState)(null),c=J.home.applyingSteps,l=e===`drawer`,u=e===`drawer`?()=>i(`application-review`):t,d=e===`drawer`?()=>i(`quick-decision`):n;function f(e){return e===1&&u?(0,q.jsxs)(q.Fragment,{children:[` `,(0,q.jsx)(k,{onClick:u,children:J.home.reviewProcessLinkLabel})]}):e===2&&d?(0,q.jsxs)(q.Fragment,{children:[` `,`When`,` `,(0,q.jsx)(k,{onClick:d,children:(0,q.jsx)(E,{})}),J.home.quickDecisionAvailableSuffix]}):null}return(0,q.jsxs)(q.Fragment,{children:[(0,q.jsxs)(a,{spacing:4,children:[e===`page`?(0,q.jsxs)(a,{spacing:1,sx:{textAlign:{xs:`center`,md:`left`}},children:[(0,q.jsx)(s,{variant:`h2`,children:J.home.howApplyingWorks.title}),(0,q.jsx)(s,{variant:`body1`,color:`text.secondary`,children:J.home.howApplyingWorks.description})]}):(0,q.jsx)(s,{variant:`body2`,color:`text.secondary`,children:J.help.howApplyingWorks.intro}),(0,q.jsx)(a,{spacing:6,children:c.map((e,t)=>(0,q.jsx)(o,{sx:{padding:l?`0 1.5rem`:{xs:`0 1.5rem`,md:`0 2rem`}},children:(0,q.jsxs)(a,{direction:l?`column`:{xs:`column`,sm:`row`},spacing:l?3:{xs:3,sm:5},alignItems:l?`flex-start`:{xs:`flex-start`,sm:`center`},children:[(0,q.jsx)(o,{sx:{flexShrink:0,alignSelf:l?`center`:{xs:`center`,sm:`auto`}},children:(0,q.jsx)(o,{component:`img`,src:e.imageSrc,alt:e.imageAlt,sx:{display:`block`,width:l?`96px`:{xs:`120px`,sm:`100px`,md:`120px`},height:l?`96px`:{xs:`120px`,sm:`100px`,md:`120px`},objectFit:`contain`}})}),(0,q.jsx)(o,{sx:{width:`100%`},children:(0,q.jsxs)(a,{spacing:1,children:[(0,q.jsxs)(a,{direction:`row`,spacing:1.5,alignItems:`center`,justifyContent:l?`center`:{xs:`center`,sm:`flex-start`},children:[(0,q.jsx)(o,{sx:{width:28,height:28,borderRadius:`50%`,bgcolor:`primary.main`,color:`#fff`,display:`flex`,alignItems:`center`,justifyContent:`center`,fontSize:`0.85rem`,fontWeight:700,flexShrink:0},children:t+1}),(0,q.jsx)(s,{variant:l?`h5`:`h4`,children:e.title})]}),(0,q.jsxs)(s,{variant:`body1`,color:`text.secondary`,sx:{textAlign:l?`justify`:{xs:`justify`,sm:`left`}},children:[e.body,f(t)]})]})})]})},t))})]}),e===`drawer`&&(0,q.jsx)(M,{open:r!==null,title:r===`application-review`?J.help.howApplyingWorks.subDrawerTitles.applicationReview:J.help.howApplyingWorks.subDrawerTitles.quickDecision,onClose:()=>i(null),children:r===`application-review`?(0,q.jsx)(F,{onOpenQuickDecision:()=>i(`quick-decision`)}):(0,q.jsx)(O,{})})]})}var K,q,J,Y=t((()=>{K=e(n(),1),c(),j(),D(),W(),d(),q=r(),J=u(),G.__docgenInfo={description:``,methods:[],displayName:`HowApplyingWorksPanel`,props:{variant:{required:!0,tsType:{name:`union`,raw:`"page" | "drawer"`,elements:[{name:`literal`,value:`"page"`},{name:`literal`,value:`"drawer"`}]},description:``},onOpenApplicationReview:{required:!1,tsType:{name:`signature`,type:`function`,raw:`() => void`,signature:{arguments:[],return:{name:`void`}}},description:``},onOpenQuickDecision:{required:!1,tsType:{name:`signature`,type:`function`,raw:`() => void`,signature:{arguments:[],return:{name:`void`}}},description:``}}}}));export{V as a,U as c,H as i,Y as n,B as o,F as r,W as s,G as t};