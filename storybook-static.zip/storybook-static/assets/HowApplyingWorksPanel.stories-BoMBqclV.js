import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,at as n,t as r}from"./esm-AWQ-KJXU.js";import{n as i,t as a}from"./HowApplyingWorksPanel-7zuNKZxF.js";var o,s,c,l,u;e((()=>{r(),i(),o=t(),s={title:`Coverage & Commerce/HowApplyingWorksPanel`,component:a,parameters:{layout:`padded`,docs:{description:{component:`HowApplyingWorksPanel renders the step-by-step "how applying works"
explainer in two shapes: full-width \`page\` variant (Home page) or a
narrower \`drawer\` variant (AppMenu), which also manages its own
QuickDecision/Application-Review sub-drawers when the step text contains
a linked term. The Phase 1 audit flagged the decorative numbered-circle
badges (1, 2, 3...) as not \`aria-hidden\` — left as-is here, since fixing
it wasn't in this component's assigned scope ("Document," not
"Fix-then-document," per the audit's action key).`}}}},c={name:`variant="page" (Home page)`,render:()=>(0,o.jsx)(n,{sx:{maxWidth:900},children:(0,o.jsx)(a,{variant:`page`})})},l={name:`variant="drawer" (AppMenu, with sub-drawers)`,render:()=>(0,o.jsx)(n,{sx:{maxWidth:420},children:(0,o.jsx)(a,{variant:`drawer`})}),parameters:{docs:{description:{story:`In drawer variant, the "review your application" and QuickDecision℠ links inside step text open their own nested AppDrawer sub-panels — try clicking one.`}}}},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  name: 'variant="page" (Home page)',
  render: () => <Box sx={{
    maxWidth: 900
  }}>
      <HowApplyingWorksPanel variant="page" />
    </Box>
}`,...c.parameters?.docs?.source}}},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  name: 'variant="drawer" (AppMenu, with sub-drawers)',
  render: () => <Box sx={{
    maxWidth: 420
  }}>
      <HowApplyingWorksPanel variant="drawer" />
    </Box>,
  parameters: {
    docs: {
      description: {
        story: 'In drawer variant, the "review your application" and QuickDecision℠ links inside step text open their own nested AppDrawer sub-panels — try clicking one.'
      }
    }
  }
}`,...l.parameters?.docs?.source}}},u=[`PageVariant`,`DrawerVariant`]}))();export{l as DrawerVariant,c as PageVariant,u as __namedExportsOrder,s as default};