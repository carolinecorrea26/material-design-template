import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,S as n,dt as r,t as i}from"./esm-AWQ-KJXU.js";import{n as a,s as o,t as s}from"./DocsBlocks-BEbHO4Nl.js";var c,l,u,d;e((()=>{i(),o(),c=t(),l={title:`Overview/How to Use Storybook`,parameters:{layout:`padded`}},u=()=>(0,c.jsxs)(s,{title:`How to Use Storybook`,intro:`Conventions this Storybook follows, so stories stay consistent as more get added.`,children:[(0,c.jsx)(a,{title:`Theme switcher (toolbar)`,children:(0,c.jsxs)(r,{variant:`body2`,color:`text.secondary`,children:[`The paintbrush icon in the toolbar switches between the four client theme presets (`,(0,c.jsx)(`code`,{children:`default`}),`, `,(0,c.jsx)(`code`,{children:`teal`}),`,`,` `,(0,c.jsx)(`code`,{children:`purple`}),`, `,(0,c.jsx)(`code`,{children:`dark-blue`}),`). Every story is themed via `,(0,c.jsx)(`code`,{children:`createAppTheme(context.globals.themeColor)`}),` — the preset-compatible call used by the real theme resolver, so switching it re-themes the whole preview, not just a color swatch. Custom-primary derivation is demonstrated in `,(0,c.jsx)(`code`,{children:`Foundations / Colors`}),`.`]})}),(0,c.jsx)(a,{title:`Accessibility panel`,children:(0,c.jsxs)(r,{variant:`body2`,color:`text.secondary`,children:[`The Accessibility tab (powered by `,(0,c.jsx)(`code`,{children:`@storybook/addon-a11y`}),`) runs an automated axe-core scan against every story and is non-blocking by default (`,(0,c.jsx)(`code`,{children:`a11y.test: "todo"`}),` in`,` `,(0,c.jsx)(`code`,{children:`.storybook/preview.tsx`}),`). Automated scans catch roughly a third of real accessibility issues — treat a clean panel as a floor, not proof of conformance. See `,(0,c.jsx)(`code`,{children:`Guidelines / Accessibility`}),` `,`for what still requires manual/production verification.`]})}),(0,c.jsx)(a,{title:`Viewport & responsive testing`,children:(0,c.jsxs)(r,{variant:`body2`,color:`text.secondary`,children:[`Use the viewport control in the toolbar to preview a story at different widths. For breakpoint-specific behavior that depends on the app's `,(0,c.jsx)(`code`,{children:`forceMobileLayout`}),` theme option (not just physical viewport width), see the live side-by-side comparison on`,` `,(0,c.jsx)(`code`,{children:`Foundations / Breakpoints & Responsive Design`}),` — resizing alone won't reproduce that behavior.`]})}),(0,c.jsx)(a,{title:`Story organization`,children:(0,c.jsxs)(n,{spacing:1,children:[(0,c.jsxs)(r,{variant:`body2`,children:[`Top-level sections follow UI purpose, not source folder — e.g.`,` `,(0,c.jsx)(`code`,{children:`Overlays`}),` groups dialogs/drawers/modals together even though those files physically live under`,` `,(0,c.jsx)(`code`,{children:`src/components/layout/`}),`.`]}),(0,c.jsxs)(r,{variant:`body2`,children:[`The sidebar order is fixed via`,` `,(0,c.jsx)(`code`,{children:`parameters.options.storySort`}),` in`,` `,(0,c.jsx)(`code`,{children:`.storybook/preview.tsx`}),`: Overview → Foundations → Guidelines → Forms → Layout → Navigation → Content → Feedback → Overlays → Coverage & Commerce → Application Patterns → Project.`]}),(0,c.jsxs)(r,{variant:`body2`,children:[`The full target hierarchy and what's built vs. pending is in`,` `,(0,c.jsx)(`code`,{children:`src/docs/StorybookAudit.md`}),`.`]})]})}),(0,c.jsx)(a,{title:`Docs-style pages vs. component stories`,children:(0,c.jsxs)(r,{variant:`body2`,color:`text.secondary`,children:[`Pages under `,(0,c.jsx)(`code`,{children:`Foundations`}),`, `,(0,c.jsx)(`code`,{children:`Guidelines`}),`, and`,` `,(0,c.jsx)(`code`,{children:`Overview`}),` are documentation pages built from shared blocks in `,(0,c.jsx)(`code`,{children:`src/docs/shared/DocsBlocks.tsx`}),` (`,(0,c.jsx)(`code`,{children:`DocsPage`}),`, `,(0,c.jsx)(`code`,{children:`DocsSection`}),`,`,` `,(0,c.jsx)(`code`,{children:`DocsTable`}),`, etc.) — they read live values from the real theme rather than hand-typed specs wherever possible. Component stories (once built) will instead mount the real component directly with Storybook controls exposed for its props, per the component documentation standard in the Phase 2 spec.`]})}),(0,c.jsx)(a,{title:`Adding a new Foundations/Guidelines page`,children:(0,c.jsxs)(r,{variant:`body2`,color:`text.secondary`,children:[`Create a `,(0,c.jsx)(`code`,{children:`*.stories.tsx`}),` file, import the shared blocks from `,(0,c.jsx)(`code`,{children:`src/docs/shared/DocsBlocks.tsx`}),`, and read values from`,` `,(0,c.jsx)(`code`,{children:`useTheme()`}),` or `,(0,c.jsx)(`code`,{children:`createAppTheme()`}),` rather than retyping a value that already exists in `,(0,c.jsx)(`code`,{children:`theme.ts`}),`, so the documentation cannot drift from the running application.`]})})]}),u.__docgenInfo={description:``,methods:[],displayName:`HowToUseStorybook`},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`() => <DocsPage title="How to Use Storybook" intro="Conventions this Storybook follows, so stories stay consistent as more get added.">
    <DocsSection title="Theme switcher (toolbar)">
      <Typography variant="body2" color="text.secondary">
        The paintbrush icon in the toolbar switches between the four client
        theme presets (<code>default</code>, <code>teal</code>,{" "}
        <code>purple</code>, <code>dark-blue</code>). Every story is themed
        via <code>createAppTheme(context.globals.themeColor)</code> — the
        preset-compatible call used by the real theme resolver, so switching
        it re-themes the whole preview, not just a color swatch. Custom-primary
        derivation is demonstrated in <code>Foundations / Colors</code>.
      </Typography>
    </DocsSection>

    <DocsSection title="Accessibility panel">
      <Typography variant="body2" color="text.secondary">
        The Accessibility tab (powered by <code>@storybook/addon-a11y</code>)
        runs an automated axe-core scan against every story and is
        non-blocking by default (<code>a11y.test: "todo"</code> in{" "}
        <code>.storybook/preview.tsx</code>). Automated scans catch roughly a
        third of real accessibility issues — treat a clean panel as a floor,
        not proof of conformance. See <code>Guidelines / Accessibility</code>{" "}
        for what still requires manual/production verification.
      </Typography>
    </DocsSection>

    <DocsSection title="Viewport & responsive testing">
      <Typography variant="body2" color="text.secondary">
        Use the viewport control in the toolbar to preview a story at
        different widths. For breakpoint-specific behavior that depends on
        the app's <code>forceMobileLayout</code> theme option (not just
        physical viewport width), see the live side-by-side comparison on{" "}
        <code>Foundations / Breakpoints & Responsive Design</code> — resizing
        alone won't reproduce that behavior.
      </Typography>
    </DocsSection>

    <DocsSection title="Story organization">
      <Stack spacing={1}>
        <Typography variant="body2">
          Top-level sections follow UI purpose, not source folder — e.g.{" "}
          <code>Overlays</code> groups dialogs/drawers/modals together even
          though those files physically live under{" "}
          <code>src/components/layout/</code>.
        </Typography>
        <Typography variant="body2">
          The sidebar order is fixed via{" "}
          <code>parameters.options.storySort</code> in{" "}
          <code>.storybook/preview.tsx</code>: Overview → Foundations →
          Guidelines → Forms → Layout → Navigation → Content → Feedback →
          Overlays → Coverage & Commerce → Application Patterns → Project.
        </Typography>
        <Typography variant="body2">
          The full target hierarchy and what's built vs. pending is in{" "}
          <code>src/docs/StorybookAudit.md</code>.
        </Typography>
      </Stack>
    </DocsSection>

    <DocsSection title="Docs-style pages vs. component stories">
      <Typography variant="body2" color="text.secondary">
        Pages under <code>Foundations</code>, <code>Guidelines</code>, and{" "}
        <code>Overview</code> are documentation pages built from shared
        blocks in <code>src/docs/shared/DocsBlocks.tsx</code> (
        <code>DocsPage</code>, <code>DocsSection</code>,{" "}
        <code>DocsTable</code>, etc.) — they read live values from the real
        theme rather than hand-typed specs wherever possible. Component
        stories (once built) will instead mount the real component directly
        with Storybook controls exposed for its props, per the component
        documentation standard in the Phase 2 spec.
      </Typography>
    </DocsSection>

    <DocsSection title="Adding a new Foundations/Guidelines page">
      <Typography variant="body2" color="text.secondary">
        Create a <code>*.stories.tsx</code> file, import the shared blocks
        from <code>src/docs/shared/DocsBlocks.tsx</code>, and read values from{" "}
        <code>useTheme()</code> or <code>createAppTheme()</code> rather than
        retyping a value that already exists in <code>theme.ts</code>, so the
        documentation cannot drift from the running application.
      </Typography>
    </DocsSection>
  </DocsPage>`,...u.parameters?.docs?.source}}},d=[`HowToUseStorybook`]}))();export{u as HowToUseStorybook,d as __namedExportsOrder,l as default};