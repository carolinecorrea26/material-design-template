import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r,R as ee,S as i,at as te,dt as a,ft as ne,o as re,t as ie}from"./esm-AWQ-KJXU.js";import{a as ae,i as oe,n as se,o as ce,r as o,t as s}from"./EscalatorWarningRounded-BSPrRzLn.js";import{n as c,t as l}from"./ArrowBackIosRounded-C7k2-OWY.js";import{n as u,t as d}from"./ArrowForwardRounded-xt7iap2D.js";import{A as f,C as p,D as m,E as h,F as g,I as _,M as v,N as y,O as b,P as x,S,T as C,_ as w,a as T,b as E,c as D,d as O,f as k,g as A,h as j,i as M,j as N,k as P,l as F,m as I,n as L,o as R,p as z,r as B,s as V,t as H,u as U,v as W,w as G,x as le,y as ue}from"./VerifiedUserOutlined-BMixS34U.js";import{n as de,t as fe}from"./CheckCircleRounded-Cl7BxcE0.js";import{a as pe,c as me,i as he,n as ge,o as _e,r as ve,s as ye,t as be}from"./PhoneOutlined-CzAuazeH.js";import{a as xe,i as Se,n as Ce,o as we,r as Te,t as Ee}from"./PersonalInjuryOutlined-BUinep94.js";import{n as De,t as Oe}from"./Add-BNc6XoYh.js";import{n as ke,t as K}from"./ArrowRightAltRounded-CSWU0efy.js";import{n as Ae,t as je}from"./BusinessOutlined-BMP968Mc.js";import{a as Me,c as Ne,i as Pe,l as Fe,n as Ie,o as Le,r as Re,s as ze,t as Be,u as Ve}from"./TuneRounded-CTq1_FzP.js";import{a as He,i as Ue,n as We,o as Ge,r as Ke,t as qe}from"./Phone-BAG3KphE.js";import{n as Je,t as Ye}from"./Close-DDY3CvKm.js";import{n as Xe,t as Ze}from"./CloseRounded-D1gwt0tE.js";import{a as Qe,i as $e,n as et,o as tt,r as nt,t as rt}from"./TaskAlt-CoDQiRN9.js";import{n as it,t as at}from"./Diversity1Rounded-DB0NGYtJ.js";import{n as ot,t as st}from"./HighlightOffRounded-CuRQlD0y.js";import{n as ct,t as lt}from"./InfoOutlined-DtVmt2CM.js";import{n as ut,t as dt}from"./LockOutlined-D8Z7qcNW.js";import{i as ft,n as pt,r as mt,t as ht}from"./RefreshRounded-CGBKY5dT.js";import{n as gt,t as _t}from"./OfflineBolt-DJbsj_yP.js";import{n as vt,t as yt}from"./PrivacyTip-D3JKmCae.js";import{n as bt,t as xt}from"./SendRounded-DWudtlzn.js";import{n as St,t as Ct}from"./ShoppingCartOutlined-CBz2cNAo.js";import{n as wt,t as Tt}from"./StarsRounded-DrGX3irb.js";import{i as Et,n as q,s as Dt,t as Ot}from"./DocsBlocks-BEbHO4Nl.js";var J,Y,X,Z,Q,$;t((()=>{J=e(n(),1),ie(),D(),c(),u(),ke(),_(),A(),pt(),Pe(),De(),x(),Je(),Xe(),tt(),Le(),$e(),bt(),E(),I(),b(),de(),h(),G(),k(),ot(),ct(),U(),et(),wt(),f(),Ue(),_e(),W(),We(),ge(),M(),S(),ft(),ut(),L(),vt(),oe(),we(),Ae(),Ve(),v(),Ge(),Ne(),it(),se(),Se(),gt(),Ce(),ce(),R(),St(),Ie(),he(),me(),Dt(),Y=r(),X={title:`Foundations/Icons`,parameters:{layout:`padded`}},Z=[{id:`navigation-icons`,title:`Navigation & actions`,icons:[{Icon:j,label:`Menu`,usedIn:`AppHeader`},{Icon:l,label:`Back`,usedIn:`Back navigation`},{Icon:d,label:`Forward`,usedIn:`TOC / links`},{Icon:K,label:`Continue`,usedIn:`Primary CTA buttons`},{Icon:g,label:`Next`,usedIn:`Inline navigation`},{Icon:ht,label:`Refresh`,usedIn:`Retry actions`},{Icon:Re,label:`Loop`,usedIn:`Retry / resend actions`},{Icon:Oe,label:`Add`,usedIn:`DynamicList`},{Icon:y,label:`Add (outline)`,usedIn:`DynamicList`},{Icon:Ye,label:`Close`,usedIn:`Dialogs`},{Icon:Ze,label:`Close (rounded)`,usedIn:`Modals, drawers`},{Icon:Qe,label:`Delete`,usedIn:`DynamicListItem`},{Icon:Me,label:`Delete (rounded)`,usedIn:`DynamicListItem`},{Icon:nt,label:`Edit`,usedIn:`DynamicListItem`},{Icon:xt,label:`Send`,usedIn:`Resume / advisor send`},{Icon:ue,label:`Download`,usedIn:`Receipt`},{Icon:z,label:`Print`,usedIn:`Review`},{Icon:V,label:`Search`,usedIn:`Filter fields`}]},{id:`status-icons`,title:`Status & feedback`,icons:[{Icon:m,label:`Check`,usedIn:`Selection states`},{Icon:fe,label:`Check circle`,usedIn:`Success states`},{Icon:C,label:`Check (rounded)`,usedIn:`Selection states`},{Icon:p,label:`Circle outline`,usedIn:`Unselected radio`},{Icon:O,label:`Radio checked`,usedIn:`Selected radio`},{Icon:st,label:`Highlight off`,usedIn:`Error / remove states`},{Icon:lt,label:`Info`,usedIn:`PageAlert info, CoverageCart`},{Icon:F,label:`Report`,usedIn:`Review page alerts`},{Icon:rt,label:`Task complete`,usedIn:`CoverageCart`},{Icon:Tt,label:`Featured`,usedIn:`FeaturedBadge`}]},{id:`communication-icons`,title:`Communication & support`,icons:[{Icon:P,label:`Chat`,usedIn:`AppHeader`},{Icon:Ke,label:`Chat bubble`,usedIn:`ClientHelpBanner`},{Icon:pe,label:`Email`,usedIn:`AppMenu, AppFooter`},{Icon:w,label:`Headset`,usedIn:`Receipt support section`},{Icon:qe,label:`Phone`,usedIn:`ClientHelpBanner`},{Icon:be,label:`Phone (outline)`,usedIn:`AppMenu, AppFooter`},{Icon:B,label:`Support agent`,usedIn:`AdvisorLogin`},{Icon:le,label:`Drafts`,usedIn:`MockEmailPreview`},{Icon:mt,label:`Secure mail`,usedIn:`Resume flow`}]},{id:`trust-icons`,title:`Security & trust`,icons:[{Icon:dt,label:`Lock`,usedIn:`SSN field, AdvisorLogin`},{Icon:H,label:`Verified`,usedIn:`Home hero tagline`},{Icon:yt,label:`Privacy tip`,usedIn:`Cart / quote drawers`},{Icon:o,label:`Spouse section`,usedIn:`formSectionTitle`},{Icon:xe,label:`Disability coverage`,usedIn:`coverageCategories (DI)`}]},{id:`coverage-icons`,title:`Coverage & content`,icons:[{Icon:T,label:`Cart`,usedIn:`AppHeader`},{Icon:Ct,label:`Cart (outline)`,usedIn:`TotalCostSummary, CoverageCart`},{Icon:Fe,label:`Calculate`,usedIn:`helpContent`},{Icon:N,label:`Calculate (rounded)`,usedIn:`Quote calculator`},{Icon:He,label:`Calendar`,usedIn:`ClientHelpBanner`},{Icon:ze,label:`Card declined`,usedIn:`helpContent`},{Icon:at,label:`Life coverage`,usedIn:`coverageCategories (LI)`},{Icon:je,label:`Business coverage`,usedIn:`coverageCategories (BOE)`},{Icon:s,label:`Child section`,usedIn:`formSectionTitle`},{Icon:Te,label:`Health coverage`,usedIn:`coverageCategories (Health)`},{Icon:_t,label:`Quick Decision`,usedIn:`QuickDecisionIndicator/Explainer`},{Icon:Ee,label:`Disability/OO coverage`,usedIn:`coverageCategories`},{Icon:ae,label:`Person`,usedIn:`Applicant sections`},{Icon:Be,label:`Tune`,usedIn:`helpContent`},{Icon:ve,label:`Language / website`,usedIn:`AppMenu, AppFooter`},{Icon:ye,label:`Hours`,usedIn:`AppMenu, AppFooter`}]}],Q=()=>{let[e,t]=(0,J.useState)(``),n=(0,J.useMemo)(()=>{if(!e)return Z;let t=e.toLowerCase();return Z.map(e=>({...e,icons:e.icons.filter(e=>`${e.label} ${e.usedIn}`.toLowerCase().includes(t))})).filter(e=>e.icons.length>0)},[e]);return(0,Y.jsxs)(Ot,{eyebrow:`Foundations`,title:`Icons`,intro:`Icons currently used across the site, grouped by purpose rather than by page.`,maxWidth:1200,children:[(0,Y.jsx)(re,{size:`small`,placeholder:`Filter icons…`,value:e,onChange:e=>t(e.target.value),slotProps:{input:{startAdornment:(0,Y.jsx)(ee,{position:`start`,children:(0,Y.jsx)(V,{fontSize:`small`})})}},sx:{minWidth:220,maxWidth:360,mb:1}}),n.map(e=>(0,Y.jsx)(q,{title:e.title,children:(0,Y.jsx)(i,{direction:`row`,flexWrap:`wrap`,gap:1.5,children:e.icons.map(({Icon:e,label:t,usedIn:n})=>(0,Y.jsxs)(i,{spacing:.5,alignItems:`center`,sx:{width:128,p:1.5,border:`1px solid`,borderColor:`divider`,borderRadius:3},title:n,children:[(0,Y.jsx)(e,{color:`primary`}),(0,Y.jsx)(a,{variant:`caption`,sx:{textAlign:`center`,fontWeight:600},children:t}),(0,Y.jsx)(a,{variant:`caption`,color:`text.secondary`,sx:{textAlign:`center`,fontSize:`0.65rem`},children:n})]},t))})},e.id)),(0,Y.jsx)(q,{title:`Rounded vs. non-rounded — open question`,children:(0,Y.jsxs)(ne,{severity:`info`,sx:{maxWidth:760},children:[`Rounded variants (e.g. `,(0,Y.jsx)(`code`,{children:`CheckRoundedIcon`}),`) are the general preference, but 6 non-rounded icons coexist with rounded counterparts today (`,(0,Y.jsx)(`code`,{children:`CheckIcon`}),`, `,(0,Y.jsx)(`code`,{children:`CloseIcon`}),`,`,` `,(0,Y.jsx)(`code`,{children:`AddIcon`}),`, `,(0,Y.jsx)(`code`,{children:`PhoneIcon`}),`, `,(0,Y.jsx)(`code`,{children:`ChatIcon`}),`,`,` `,(0,Y.jsx)(`code`,{children:`ShoppingCartIcon`}),`) with no documented rule for when to use which. Flagged as an open design question, not presented as a settled convention.`]})}),(0,Y.jsx)(te,{sx:{mt:2},children:(0,Y.jsx)(Et,{children:`Manually maintained snapshot — will drift as icons are added/removed elsewhere in the app. Source: the components/pages named in "Used in".`})})]})},Q.__docgenInfo={description:``,methods:[],displayName:`Icons`},Q.parameters={...Q.parameters,docs:{...Q.parameters?.docs,source:{originalSource:`() => {
  const [filter, setFilter] = useState("");
  const filteredGroups = useMemo(() => {
    if (!filter) return iconGroups;
    const lc = filter.toLowerCase();
    return iconGroups.map(group => ({
      ...group,
      icons: group.icons.filter(icon => \`\${icon.label} \${icon.usedIn}\`.toLowerCase().includes(lc))
    })).filter(group => group.icons.length > 0);
  }, [filter]);
  return <DocsPage eyebrow="Foundations" title="Icons" intro="Icons currently used across the site, grouped by purpose rather than by page." maxWidth={1200}>
      <TextField size="small" placeholder="Filter icons…" value={filter} onChange={e => setFilter(e.target.value)} slotProps={{
      input: {
        startAdornment: <InputAdornment position="start">
                <SearchRoundedIcon fontSize="small" />
              </InputAdornment>
      }
    }} sx={{
      minWidth: 220,
      maxWidth: 360,
      mb: 1
    }} />

      {filteredGroups.map(group => <DocsSection key={group.id} title={group.title}>
          <Stack direction="row" flexWrap="wrap" gap={1.5}>
            {group.icons.map(({
          Icon,
          label,
          usedIn
        }) => <Stack key={label} spacing={0.5} alignItems="center" sx={{
          width: 128,
          p: 1.5,
          border: "1px solid",
          borderColor: "divider",
          borderRadius: 3
        }} title={usedIn}>
                <Icon color="primary" />
                <Typography variant="caption" sx={{
            textAlign: "center",
            fontWeight: 600
          }}>{label}</Typography>
                <Typography variant="caption" color="text.secondary" sx={{
            textAlign: "center",
            fontSize: "0.65rem"
          }}>{usedIn}</Typography>
              </Stack>)}
          </Stack>
        </DocsSection>)}

      <DocsSection title="Rounded vs. non-rounded — open question">
        <Alert severity="info" sx={{
        maxWidth: 760
      }}>
          Rounded variants (e.g. <code>CheckRoundedIcon</code>) are the
          general preference, but 6 non-rounded icons coexist with rounded
          counterparts today (<code>CheckIcon</code>, <code>CloseIcon</code>,{" "}
          <code>AddIcon</code>, <code>PhoneIcon</code>, <code>ChatIcon</code>,{" "}
          <code>ShoppingCartIcon</code>) with no documented rule for when to
          use which. Flagged as an open design question, not presented as a
          settled convention.
        </Alert>
      </DocsSection>

      <Box sx={{
      mt: 2
    }}>
        <SourceNote>
          Manually maintained snapshot — will drift as icons are added/removed
          elsewhere in the app. Source: the components/pages named in "Used in".
        </SourceNote>
      </Box>
    </DocsPage>;
}`,...Q.parameters?.docs?.source}}},$=[`Icons`]}))();export{Q as Icons,$ as __namedExportsOrder,X as default};