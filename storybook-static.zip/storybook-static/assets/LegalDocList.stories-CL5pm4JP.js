import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,at as n,t as r}from"./esm-AWQ-KJXU.js";import{n as i,r as a}from"./content-CYNdyLgC.js";import{n as o,t as s}from"./LegalDocList-CnHpxkS2.js";var c,l,u,d,f,p;e((()=>{r(),o(),a(),c=t(),l={title:`Content/LegalDocList`,component:s,parameters:{layout:`padded`,docs:{description:{component:`LegalDocList is a generic renderer for structured legal-document bodies
(heading/paragraph/list/address/note section types) — used by AppFooter
for both the Terms of Use and Privacy Notice modals. Every story below
renders the real client content, not placeholder text, since the whole
point of documenting a content renderer is to see real section-type
variety.`}}}},u=i().footer,d={render:()=>(0,c.jsx)(n,{sx:{maxWidth:640},children:(0,c.jsx)(s,{doc:u.termsOfUseContent})})},f={render:()=>(0,c.jsx)(n,{sx:{maxWidth:640},children:(0,c.jsx)(s,{doc:u.privacyNoticeContent})}),parameters:{docs:{description:{story:`Demonstrates the address section type (component="address", semantic HTML) alongside headings/paragraphs/lists, if the real Privacy Notice content includes one.`}}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: () => <Box sx={{
    maxWidth: 640
  }}>
      <LegalDocList doc={footerContent.termsOfUseContent} />
    </Box>
}`,...d.parameters?.docs?.source}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  render: () => <Box sx={{
    maxWidth: 640
  }}>
      <LegalDocList doc={footerContent.privacyNoticeContent} />
    </Box>,
  parameters: {
    docs: {
      description: {
        story: "Demonstrates the address section type (component=\\"address\\", semantic HTML) alongside headings/paragraphs/lists, if the real Privacy Notice content includes one."
      }
    }
  }
}`,...f.parameters?.docs?.source}}},p=[`TermsOfUse`,`PrivacyNotice`]}))();export{f as PrivacyNotice,d as TermsOfUse,p as __namedExportsOrder,l as default};