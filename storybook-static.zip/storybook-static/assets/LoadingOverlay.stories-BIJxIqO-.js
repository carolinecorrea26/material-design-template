import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,at as n,dt as r,mt as i,t as a}from"./esm-AWQ-KJXU.js";function o({size:e=`md`,message:t}){let{spinner:a,minHeight:o,position:l}=c[e],u=e===`fullscreen`;return(0,s.jsxs)(n,{role:`status`,"aria-live":`polite`,"aria-label":t??`Loading`,sx:{position:l,...u?{inset:0,zIndex:1400}:{width:`100%`,minHeight:o},display:`flex`,flexDirection:`column`,alignItems:`center`,justifyContent:`center`,gap:2,bgcolor:u?`rgba(255, 255, 255, 0.85)`:`transparent`,backdropFilter:u?`blur(2px)`:`none`},children:[(0,s.jsx)(i,{size:a,"aria-hidden":`true`}),t&&(0,s.jsx)(r,{variant:`body2`,color:`text.secondary`,sx:{textAlign:`center`},children:t})]})}var s,c,l=e((()=>{a(),s=t(),c={sm:{spinner:20,minHeight:`auto`,position:`relative`},md:{spinner:36,minHeight:160,position:`relative`},lg:{spinner:48,minHeight:320,position:`relative`},fullscreen:{spinner:56,minHeight:`100vh`,position:`fixed`}},o.__docgenInfo={description:``,methods:[],displayName:`LoadingOverlay`,props:{size:{required:!1,tsType:{name:`union`,raw:`"sm" | "md" | "lg" | "fullscreen"`,elements:[{name:`literal`,value:`"sm"`},{name:`literal`,value:`"md"`},{name:`literal`,value:`"lg"`},{name:`literal`,value:`"fullscreen"`}]},description:`Size variant:
- "sm"         Small inline spinner; use inside a button or tight UI region.
- "md"         Section-level spinner; overlays a card or form section.
- "lg"         Page-level spinner; fills the content area.
- "fullscreen" Blocks the entire viewport; use for navigation to external
               pages (E-Sign, QuickDecision) or global submission flows.`,defaultValue:{value:`"md"`,computed:!1}},message:{required:!1,tsType:{name:`string`},description:`Optional status message shown below the spinner.`}}}})),u,d,f,p,m,h,g,_;e((()=>{a(),l(),u=t(),d={title:`Feedback/LoadingOverlay`,component:o,parameters:{layout:`padded`,docs:{description:{component:`LoadingOverlay has 4 size variants for 4 different contexts — sm (inline,
e.g. inside a button), md (section-level), lg (page-level), and
fullscreen (blocks the whole viewport for external-redirect/global-
submission flows). Rich spinner+mark+heading+body processing screens use
ProcessingStatusPage instead.`}}}},f={name:`size="sm" (inline, e.g. inside a button)`,render:()=>(0,u.jsx)(o,{size:`sm`})},p={name:`size="md" (default — section-level)`,render:()=>(0,u.jsx)(o,{message:`Loading your coverage options…`})},m={name:`size="lg" (page-level)`,render:()=>(0,u.jsx)(o,{size:`lg`,message:`Loading…`})},h={name:`size="fullscreen" (blocks the viewport)`,render:()=>(0,u.jsxs)(n,{sx:{position:`relative`,height:320,border:`1px dashed`,borderColor:`divider`},children:[(0,u.jsxs)(r,{variant:`body2`,sx:{p:2},children:[`Page content behind the overlay (for demo purposes this story contains the overlay in a bounded box instead of a real`,` `,(0,u.jsx)(`code`,{children:`position: fixed`}),` full-viewport takeover).`]}),(0,u.jsx)(n,{sx:{position:`absolute`,inset:0,overflow:`hidden`},children:(0,u.jsx)(o,{size:`fullscreen`,message:`Redirecting to DocuSign…`})})]})},g={render:()=>(0,u.jsx)(o,{})},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  name: 'size="sm" (inline, e.g. inside a button)',
  render: () => <LoadingOverlay size="sm" />
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  name: 'size="md" (default — section-level)',
  render: () => <LoadingOverlay message="Loading your coverage options…" />
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  name: 'size="lg" (page-level)',
  render: () => <LoadingOverlay size="lg" message="Loading…" />
}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  name: 'size="fullscreen" (blocks the viewport)',
  render: () => <Box sx={{
    position: "relative",
    height: 320,
    border: "1px dashed",
    borderColor: "divider"
  }}>
      <Typography variant="body2" sx={{
      p: 2
    }}>
        Page content behind the overlay (for demo purposes this story
        contains the overlay in a bounded box instead of a real{" "}
        <code>position: fixed</code> full-viewport takeover).
      </Typography>
      <Box sx={{
      position: "absolute",
      inset: 0,
      overflow: "hidden"
    }}>
        <LoadingOverlay size="fullscreen" message="Redirecting to DocuSign…" />
      </Box>
    </Box>
}`,...h.parameters?.docs?.source}}},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  render: () => <LoadingOverlay />
}`,...g.parameters?.docs?.source}}},_=[`Small`,`Medium`,`Large`,`Fullscreen`,`NoMessage`]}))();export{h as Fullscreen,m as Large,p as Medium,g as NoMessage,f as Small,_ as __namedExportsOrder,d as default};