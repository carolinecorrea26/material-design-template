import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r,rt as i,t as a}from"./esm-AWQ-KJXU.js";import{n as o,t as s}from"./MemberVerification-CVxobJUP.js";function c(){let[e,t]=(0,l.useState)(!0),[n,r]=(0,l.useState)(null);return(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(i,{variant:`outlined`,onClick:()=>t(!0),sx:{m:2},children:`Reopen verification`}),n!==null&&(0,u.jsxs)(`span`,{style:{marginLeft:8},children:[`Last result: verified = `,String(n)]}),(0,u.jsx)(s,{open:e,onClose:e=>{t(!1),r(e)}})]})}var l,u,d,f,p;t((()=>{l=e(n(),1),a(),o(),u=r(),d={title:`Coverage & Commerce/MemberVerification`,component:s,parameters:{layout:`fullscreen`,docs:{description:{component:`MemberVerification is a multi-step identity-verification modal shown on
the Eligibility page for TPA-verified members — dummy LexisNexis-style
security questions, not a real identity-verification integration.
Full-screen on mobile, centered dialog on desktop. The "text"/"voice"
code paths skip straight to a passed result (no real code delivery
exists in this prototype); only "security-questions" has a real
pass/fail branch, and "skip" reports unverified without asking anything.`}}}},f={render:()=>(0,u.jsx)(c,{}),parameters:{docs:{description:{story:`Try each path: "Send text code" or "Send voice code" jump straight to a passed result; "Answer security questions" has a real pass/fail outcome (answering any question with "None of the answers apply to me" fails verification); "Proceed without member verification" reports unverified immediately.`}}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  render: () => <MemberVerificationDemo />,
  parameters: {
    docs: {
      description: {
        story: 'Try each path: "Send text code" or "Send voice code" jump straight to a passed result; "Answer security questions" has a real pass/fail outcome (answering any question with "None of the answers apply to me" fails verification); "Proceed without member verification" reports unverified immediately.'
      }
    }
  }
}`,...f.parameters?.docs?.source}}},p=[`Interactive`]}))();export{f as Interactive,p as __namedExportsOrder,d as default};