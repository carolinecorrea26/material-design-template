import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,S as n,dt as r,lt as i,t as a}from"./esm-AWQ-KJXU.js";import{n as o,s,t as c}from"./DocsBlocks-BEbHO4Nl.js";var l,u,d,f;e((()=>{a(),s(),l=t(),u={title:`Foundations/Overview`,parameters:{layout:`padded`}},d=()=>(0,l.jsxs)(c,{eyebrow:`Foundations`,title:`Design foundations`,intro:`The tokens and conventions every component in this app is built from — colors, typography, spacing, shape, breakpoints, and the MUI theme overrides that make Material UI's defaults look like this app. Every page in this section reads its values live from src/app/theme.ts (via createAppTheme) rather than a second hand-typed specification, so it cannot silently drift from the running app.`,children:[(0,l.jsx)(o,{title:`What lives here vs. elsewhere`,children:(0,l.jsxs)(n,{spacing:1.5,children:[(0,l.jsxs)(r,{variant:`body2`,children:[(0,l.jsx)(`strong`,{children:`Foundations (this section)`}),` — reusable design tokens and theme-level conventions: what a color/type-scale/spacing-unit`,` `,(0,l.jsx)(`em`,{children:`is`}),`, not which page uses it.`]}),(0,l.jsxs)(r,{variant:`body2`,children:[(0,l.jsx)(`strong`,{children:`Guidelines`}),` — how those tokens should be applied: accessibility implementation patterns, form validation/error presentation, responsive UI rules, feedback/status conventions.`]}),(0,l.jsxs)(r,{variant:`body2`,children:[(0,l.jsx)(`strong`,{children:`Forms / Layout / Navigation / Content / Feedback / Overlays / Coverage & Commerce`}),` — the actual reusable components, documented in isolation with their variants, states, and API.`]}),(0,l.jsxs)(r,{variant:`body2`,children:[(0,l.jsx)(`strong`,{children:`Portal Admin → Information Architecture`}),` (in the running app, not Storybook) — pages, fields by page, application flows, business rules, client configuration, and other application-specific/requirements documentation. It does not duplicate the reusable UI documentation that lives here.`]})]})}),(0,l.jsxs)(o,{title:`Status`,children:[(0,l.jsxs)(n,{direction:`row`,spacing:1,flexWrap:`wrap`,useFlexGap:!0,children:[(0,l.jsx)(i,{label:`Storybook is the visual source of truth`,color:`primary`,size:`small`}),(0,l.jsx)(i,{label:`Coverage tracked in Page Coverage Audit`,variant:`outlined`,size:`small`})]}),(0,l.jsxs)(r,{variant:`body2`,color:`text.secondary`,sx:{mt:1.5},children:[`See `,(0,l.jsx)(`code`,{children:`src/docs/StorybookAudit.md`}),` for the full migration matrix, information architecture, and prioritized build sequence. The in-app `,(0,l.jsx)(`code`,{children:`Design System`}),` page links back here and provides a temporary client-theme preview tool.`]})]})]}),d.__docgenInfo={description:``,methods:[],displayName:`Overview`},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`() => <DocsPage eyebrow="Foundations" title="Design foundations" intro="The tokens and conventions every component in this app is built from — colors, typography, spacing, shape, breakpoints, and the MUI theme overrides that make Material UI's defaults look like this app. Every page in this section reads its values live from src/app/theme.ts (via createAppTheme) rather than a second hand-typed specification, so it cannot silently drift from the running app.">
    <DocsSection title="What lives here vs. elsewhere">
      <Stack spacing={1.5}>
        <Typography variant="body2">
          <strong>Foundations (this section)</strong> — reusable design tokens
          and theme-level conventions: what a color/type-scale/spacing-unit{" "}
          <em>is</em>, not which page uses it.
        </Typography>
        <Typography variant="body2">
          <strong>Guidelines</strong> — how those tokens should be applied:
          accessibility implementation patterns, form validation/error
          presentation, responsive UI rules, feedback/status conventions.
        </Typography>
        <Typography variant="body2">
          <strong>Forms / Layout / Navigation / Content / Feedback / Overlays
          / Coverage & Commerce</strong> — the actual reusable components,
          documented in isolation with their variants, states, and API.
        </Typography>
        <Typography variant="body2">
          <strong>Portal Admin → Information Architecture</strong> (in the
          running app, not Storybook) — pages, fields by page, application
          flows, business rules, client configuration, and other
          application-specific/requirements documentation. It does not
          duplicate the reusable UI documentation that lives here.
        </Typography>
      </Stack>
    </DocsSection>

    <DocsSection title="Status">
      <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
        <Chip label="Storybook is the visual source of truth" color="primary" size="small" />
        <Chip label="Coverage tracked in Page Coverage Audit" variant="outlined" size="small" />
      </Stack>
      <Typography variant="body2" color="text.secondary" sx={{
      mt: 1.5
    }}>
        See <code>src/docs/StorybookAudit.md</code> for the full migration
        matrix, information architecture, and prioritized build sequence.
        The in-app <code>Design System</code> page links back here and provides
        a temporary client-theme preview tool.
      </Typography>
    </DocsSection>
  </DocsPage>`,...d.parameters?.docs?.source}}},f=[`Overview`]}))();export{d as Overview,f as __namedExportsOrder,u as default};