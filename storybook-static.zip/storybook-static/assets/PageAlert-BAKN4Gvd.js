import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,at as n,ft as r,t as i}from"./esm-AWQ-KJXU.js";function a({severity:e=`error`,message:t,onDismiss:i}){return t?(0,o.jsx)(n,{sx:{mb:2},children:(0,o.jsx)(r,{severity:e,onClose:i,sx:{width:`100%`},role:e===`error`||e===`warning`?`alert`:`status`,children:t})}):null}var o,s=e((()=>{i(),o=t(),a.__docgenInfo={description:`Full-width contextual alert rendered above the form content area.
Replaces the former PageErrorAlert with support for all severity variants.

Usage:
  <PageAlert severity="error" message={pageError} />
  <PageAlert severity="success" message="Your progress has been saved." />
  <PageAlert severity="warning" message="This plan is not available in your state." />
  <PageAlert severity="info" message="Membership verification is in progress." />`,methods:[],displayName:`PageAlert`,props:{severity:{required:!1,tsType:{name:`AlertColor`},description:`Alert severity. Defaults to "error".`,defaultValue:{value:`"error"`,computed:!1}},message:{required:!1,tsType:{name:`ReactNode`},description:`The message to display. Can be a string or JSX (e.g. a list of errors).
Component renders nothing when this is undefined or null.`},onDismiss:{required:!1,tsType:{name:`signature`,type:`function`,raw:`() => void`,signature:{arguments:[],return:{name:`void`}}},description:`Show a dismiss button. Caller manages open state.`}}}}));export{s as n,a as t};