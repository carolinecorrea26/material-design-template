import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,S as n,dt as r,t as i}from"./esm-AWQ-KJXU.js";import{n as a,t as o}from"./PageAlert-BAKN4Gvd.js";var s,c,l,u,d,f,p,m,h,g;e((()=>{i(),a(),s=t(),c={title:`Feedback/PageAlert`,component:o,parameters:{layout:`padded`,docs:{description:{component:`PageAlert is the canonical full-width contextual alert rendered above form
content — it supersedes the now-deprecated PageErrorAlert (a 5-line
re-export kept only for old imports; see Guidelines/Dynamic Feedback &
Status). Renders nothing when \`message\` is falsy.`}}}},l={render:()=>(0,s.jsx)(o,{severity:`error`,message:`Please complete the required fields before continuing.`})},u={render:()=>(0,s.jsx)(o,{severity:`warning`,message:`This plan is not available in your state.`})},d={render:()=>(0,s.jsx)(o,{severity:`info`,message:`Membership verification is in progress.`})},f={render:()=>(0,s.jsx)(o,{severity:`success`,message:`Your progress has been saved.`})},p={render:()=>(0,s.jsx)(o,{severity:`info`,message:`You can dismiss this message.`,onDismiss:()=>{}})},m={name:`No message (renders nothing)`,render:()=>(0,s.jsxs)(n,{spacing:1,children:[(0,s.jsx)(o,{}),(0,s.jsxs)(r,{variant:`caption`,color:`text.secondary`,children:[`Nothing rendered above this line — the component returns`,` `,(0,s.jsx)(`code`,{children:`null`}),` when `,(0,s.jsx)(`code`,{children:`message`}),` is undefined, so callers don't need to conditionally render `,(0,s.jsx)(`code`,{children:`PageAlert`}),` themselves.`]})]})},h={render:()=>(0,s.jsxs)(n,{spacing:2,children:[(0,s.jsx)(o,{severity:`error`,message:`Error — blocking problem the user must resolve.`}),(0,s.jsx)(o,{severity:`warning`,message:`Warning — not blocking, but needs attention.`}),(0,s.jsx)(o,{severity:`info`,message:`Info — contextual, non-urgent detail.`}),(0,s.jsx)(o,{severity:`success`,message:`Success — confirms a completed action.`})]})},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  render: () => <PageAlert severity="error" message="Please complete the required fields before continuing." />
}`,...l.parameters?.docs?.source}}},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  render: () => <PageAlert severity="warning" message="This plan is not available in your state." />
}`,...u.parameters?.docs?.source}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: () => <PageAlert severity="info" message="Membership verification is in progress." />
}`,...d.parameters?.docs?.source}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  render: () => <PageAlert severity="success" message="Your progress has been saved." />
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: () => <PageAlert severity="info" message="You can dismiss this message." onDismiss={() => {}} />
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  name: "No message (renders nothing)",
  render: () => <Stack spacing={1}>
      <PageAlert />
      <Typography variant="caption" color="text.secondary">
        Nothing rendered above this line — the component returns{" "}
        <code>null</code> when <code>message</code> is undefined, so callers
        don't need to conditionally render <code>PageAlert</code> themselves.
      </Typography>
    </Stack>
}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  render: () => <Stack spacing={2}>
      <PageAlert severity="error" message="Error — blocking problem the user must resolve." />
      <PageAlert severity="warning" message="Warning — not blocking, but needs attention." />
      <PageAlert severity="info" message="Info — contextual, non-urgent detail." />
      <PageAlert severity="success" message="Success — confirms a completed action." />
    </Stack>
}`,...h.parameters?.docs?.source}}},g=[`Error`,`Warning`,`Info`,`Success`,`Dismissible`,`NoMessage`,`AllSeverities`]}))();export{h as AllSeverities,p as Dismissible,l as Error,d as Info,m as NoMessage,f as Success,u as Warning,g as __namedExportsOrder,c as default};