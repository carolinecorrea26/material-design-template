import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t}from"./esm-AWQ-KJXU.js";import{n,t as r}from"./PageHeader-BIhFxM6S.js";import{n as i,t as a}from"./HelpChips-DiYg6vpi.js";var o,s,c,l,u,d,f;e((()=>{n(),i(),o=t(),s={title:`Layout/PageHeader`,component:r,parameters:{layout:`padded`,docs:{description:{component:`PageHeader composes PageTitle with optional help content. It's rendered
automatically by FormRoutePage for every application page — no page file
calls it directly.`}}}},c={render:()=>(0,o.jsx)(r,{title:`Contact`,subhead:`How can we reach you?`})},l={render:()=>(0,o.jsx)(r,{title:`Contact`,onBack:()=>{}})},u={render:()=>(0,o.jsx)(r,{title:`Coverage`,subhead:`Choose the coverage you'd like to apply for.`,help:(0,o.jsx)(a,{items:[{id:`how-much`,label:`How much does it cost?`},{id:`quick-decision`,label:`About QuickDecision`}],onSelect:()=>{}})})},d={render:()=>(0,o.jsx)(r,{title:`Review`})},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  render: () => <PageHeader title="Contact" subhead="How can we reach you?" />
}`,...c.parameters?.docs?.source}}},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  render: () => <PageHeader title="Contact" onBack={() => {}} />
}`,...l.parameters?.docs?.source}}},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  render: () => <PageHeader title="Coverage" subhead="Choose the coverage you'd like to apply for." help={<FormHelpChips items={[{
    id: "how-much",
    label: "How much does it cost?"
  }, {
    id: "quick-decision",
    label: "About QuickDecision"
  }]} onSelect={() => {}} />} />
}`,...u.parameters?.docs?.source}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: () => <PageHeader title="Review" />
}`,...d.parameters?.docs?.source}}},f=[`Default`,`WithBackButton`,`WithHelpChips`,`TitleOnly`]}))();export{c as Default,d as TitleOnly,l as WithBackButton,u as WithHelpChips,f as __namedExportsOrder,s as default};