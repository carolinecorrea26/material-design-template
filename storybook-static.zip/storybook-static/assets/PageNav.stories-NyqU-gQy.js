import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,at as n,dt as r,t as i}from"./esm-AWQ-KJXU.js";import{n as a,t as o}from"./PageNav-rqugKBhz.js";var s,c,l,u,d,f,p;e((()=>{i(),a(),s=t(),c={title:`Navigation/PageNav`,component:o,parameters:{layout:`padded`,docs:{description:{component:"PageNav renders the single forward action (Next / Submit) at the bottom of\nevery FormRoutePage-based page. It has no back-navigation of its own — that\nlives in PageHeader via PageTitle's onBack — so this component only ever\nowns the `type=\"submit\"` button tied to the page's `<form id={formId}>` via\nthe `form` attribute (not by DOM nesting), which is why every story below\nwraps it in a real `<form>` with a matching id."}}},decorators:[e=>(0,s.jsxs)(n,{sx:{maxWidth:480},children:[(0,s.jsx)(`form`,{id:`demo-form`,onSubmit:e=>e.preventDefault(),children:(0,s.jsx)(r,{variant:`body2`,color:`text.secondary`,sx:{mb:2},children:`Form content would go here.`})}),(0,s.jsx)(e,{})]})]},l={args:{formId:`demo-form`}},u={args:{formId:`demo-form`,nextLabel:`Submit application`}},d={name:`isTransitioning (submit in flight)`,args:{formId:`demo-form`,isTransitioning:!0},parameters:{docs:{description:{story:"Shows a spinner in place of the label and disables the button. The accessible name switches to `\"{label} — submitting\"` (via `aria-label`) so assistive tech still announces what's happening instead of losing the button's name entirely."}}}},f={name:`disabled (validation not met)`,args:{formId:`demo-form`,disabled:!0},parameters:{docs:{description:{story:"The theme's `.Mui-disabled` override keeps full brand-color contrast (not MUI's default washed-out disabled look) so the button stays legible — this is a deliberate contrast fix, not an oversight, per the component's sx override."}}}},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  args: {
    formId: "demo-form"
  }
}`,...l.parameters?.docs?.source}}},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  args: {
    formId: "demo-form",
    nextLabel: "Submit application"
  }
}`,...u.parameters?.docs?.source}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  name: "isTransitioning (submit in flight)",
  args: {
    formId: "demo-form",
    isTransitioning: true
  },
  parameters: {
    docs: {
      description: {
        story: "Shows a spinner in place of the label and disables the button. The accessible name switches to \`\\"{label} — submitting\\"\` (via \`aria-label\`) so assistive tech still announces what's happening instead of losing the button's name entirely."
      }
    }
  }
}`,...d.parameters?.docs?.source}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  name: "disabled (validation not met)",
  args: {
    formId: "demo-form",
    disabled: true
  },
  parameters: {
    docs: {
      description: {
        story: "The theme's \`.Mui-disabled\` override keeps full brand-color contrast (not MUI's default washed-out disabled look) so the button stays legible — this is a deliberate contrast fix, not an oversight, per the component's sx override."
      }
    }
  }
}`,...f.parameters?.docs?.source}}},p=[`Default`,`CustomLabel`,`Transitioning`,`Disabled`]}))();export{u as CustomLabel,l as Default,f as Disabled,d as Transitioning,p as __namedExportsOrder,c as default};