import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,dt as n,o as r,rt as i,t as a}from"./esm-AWQ-KJXU.js";import{n as o,t as s}from"./PageShell-YUtjXUwe.js";var c,l,u,d,f,p,m,h,g,_;e((()=>{a(),o(),c=t(),l={title:`Layout/PageShell`,component:s,parameters:{layout:`fullscreen`,docs:{description:{component:`PageShell is the generic centered page wrapper (title, error banner, help
content, max-width, action row) underneath the shared FormRoutePage
template. In practice it's only ever used through FormRoutePage — no page
file calls it directly — but it's documented standalone here since it's
the real reusable primitive.`}}}},u={render:()=>(0,c.jsxs)(s,{title:`Profile`,subhead:`Tell us a bit about yourself.`,children:[(0,c.jsx)(r,{label:`First name`,fullWidth:!0,sx:{mb:2}}),(0,c.jsx)(r,{label:`Last name`,fullWidth:!0})]})},d={render:()=>(0,c.jsx)(s,{title:`Profile`,onBack:()=>{},children:(0,c.jsx)(r,{label:`First name`,fullWidth:!0})})},f={render:()=>(0,c.jsx)(s,{title:`Profile`,error:`Please complete the required fields before continuing.`,children:(0,c.jsx)(r,{label:`First name`,fullWidth:!0,error:!0,required:!0})})},p={render:()=>(0,c.jsx)(s,{title:`Coverage`,subhead:`Choose the coverage you'd like to apply for.`,help:(0,c.jsx)(n,{variant:`caption`,color:`text.secondary`,children:`Need help? Contact support.`}),actions:(0,c.jsx)(i,{variant:`contained`,children:`Continue`}),children:(0,c.jsx)(n,{variant:`body2`,children:`Page content goes here.`})})},m={name:`noTitle (title/back/error/help suppressed)`,render:()=>(0,c.jsx)(s,{title:`This title is not rendered`,noTitle:!0,children:(0,c.jsx)(n,{variant:`body2`,children:`Used by FormRoutePage, which renders its own PageHeader inside FormShell instead — PageShell's own title branch is intentionally unused in that composition.`})})},h={name:`maxWidth — narrow (resume-style pages)`,render:()=>(0,c.jsx)(s,{title:`Verify your email`,maxWidth:480,children:(0,c.jsx)(r,{label:`Email`,fullWidth:!0})})},g={name:`maxWidth="100%" (vertical-stepper pages)`,render:()=>(0,c.jsx)(s,{title:`Coverage`,maxWidth:`100%`,children:(0,c.jsxs)(n,{variant:`body2`,color:`text.secondary`,children:[`FormRoutePage passes `,(0,c.jsx)(`code`,{children:`maxWidth="100%"`}),` whenever the page has an active progress step, since the sidebar-stepper layout supplies its own width constraint.`]})})},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  render: () => <PageShell title="Profile" subhead="Tell us a bit about yourself.">
      <TextField label="First name" fullWidth sx={{
      mb: 2
    }} />
      <TextField label="Last name" fullWidth />
    </PageShell>
}`,...u.parameters?.docs?.source}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: () => <PageShell title="Profile" onBack={() => {}}>
      <TextField label="First name" fullWidth />
    </PageShell>
}`,...d.parameters?.docs?.source}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  render: () => <PageShell title="Profile" error="Please complete the required fields before continuing.">
      <TextField label="First name" fullWidth error required />
    </PageShell>
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: () => <PageShell title="Coverage" subhead="Choose the coverage you'd like to apply for." help={<Typography variant="caption" color="text.secondary">Need help? Contact support.</Typography>} actions={<Button variant="contained">Continue</Button>}>
      <Typography variant="body2">Page content goes here.</Typography>
    </PageShell>
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  name: "noTitle (title/back/error/help suppressed)",
  render: () => <PageShell title="This title is not rendered" noTitle>
      <Typography variant="body2">
        Used by FormRoutePage, which renders its own PageHeader inside
        FormShell instead — PageShell's own title branch is intentionally
        unused in that composition.
      </Typography>
    </PageShell>
}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  name: "maxWidth — narrow (resume-style pages)",
  render: () => <PageShell title="Verify your email" maxWidth={480}>
      <TextField label="Email" fullWidth />
    </PageShell>
}`,...h.parameters?.docs?.source}}},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  name: 'maxWidth="100%" (vertical-stepper pages)',
  render: () => <PageShell title="Coverage" maxWidth="100%">
      <Typography variant="body2" color="text.secondary">
        FormRoutePage passes <code>maxWidth="100%"</code> whenever the page
        has an active progress step, since the sidebar-stepper layout
        supplies its own width constraint.
      </Typography>
    </PageShell>
}`,...g.parameters?.docs?.source}}},_=[`Default`,`WithBackButton`,`WithError`,`WithHelpAndActions`,`NoTitle`,`NarrowMaxWidth`,`FullWidth`]}))();export{u as Default,g as FullWidth,h as NarrowMaxWidth,m as NoTitle,d as WithBackButton,f as WithError,p as WithHelpAndActions,_ as __namedExportsOrder,l as default};