import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t}from"./esm-AWQ-KJXU.js";import{n,t as r}from"./PageTitle-32wQJl8B.js";var i,a,o,s,c,l;e((()=>{n(),i=t(),a={title:`Layout/PageTitle`,component:r,parameters:{layout:`padded`,docs:{description:{component:`PageTitle is the title + optional subhead + optional back-button
primitive underneath both PageHeader (used automatically by
FormRoutePage) and PageShell's own title branch. It's also called
directly by pages outside the FormRoutePage flow: Resume, ResumeCode,
ResumeMethod, Receipt, AdvisorLogin.`}}}},o={render:()=>(0,i.jsx)(r,{title:`Receipt`})},s={render:()=>(0,i.jsx)(r,{title:`Contact`,subhead:`How can we reach you?`})},c={render:()=>(0,i.jsx)(r,{title:`Contact`,subhead:`How can we reach you?`,onBack:()=>{}})},o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  render: () => <PageTitle title="Receipt" />
}`,...o.parameters?.docs?.source}}},s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  render: () => <PageTitle title="Contact" subhead="How can we reach you?" />
}`,...s.parameters?.docs?.source}}},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  render: () => <PageTitle title="Contact" subhead="How can we reach you?" onBack={() => {}} />
}`,...c.parameters?.docs?.source}}},l=[`TitleOnly`,`WithSubhead`,`WithBackButton`]}))();export{o as TitleOnly,c as WithBackButton,s as WithSubhead,l as __namedExportsOrder,a as default};