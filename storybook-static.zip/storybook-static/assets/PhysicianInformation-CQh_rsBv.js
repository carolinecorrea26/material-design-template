import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,at as n,t as r}from"./esm-AWQ-KJXU.js";import{n as i,t as a}from"./FieldRenderer-DRJtoa2k.js";import{n as o,t as s}from"./SectionDivider-BZXqr3do.js";function c({fieldIds:e,allFields:t,control:r,errors:i,nameRow:o,streetRow:c,cityStateZipRow:u}){let d=e.find(e=>e.includes(`physician-phone`)),f=e.find(e=>e.includes(`facility-name`));function p(e){let n=t.find(t=>t.id===e);return n?(0,l.jsx)(a,{field:n,control:r,errors:i},n.id):null}return(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(s,{label:`Physician information`,variant:`subsection`,sx:{mb:1}}),(0,l.jsx)(n,{sx:{display:`grid`,gridTemplateColumns:{xs:`1fr`,sm:`1fr 1fr`},gap:{xs:0,sm:2}},children:e.filter(e=>o.has(e)).map(e=>p(e))}),d?p(d):null,f?p(f):null,(0,l.jsx)(n,{sx:{display:`grid`,gridTemplateColumns:{xs:`1fr`,sm:`1fr 1fr`},gap:{xs:0,sm:2}},children:e.filter(e=>c.has(e)).map(e=>p(e))}),(0,l.jsx)(n,{sx:{display:`grid`,gridTemplateColumns:{xs:`1fr`,sm:`1fr 1fr 1fr`},gap:{xs:0,sm:2}},children:e.filter(e=>u.has(e)).map(e=>p(e))})]})}var l,u=e((()=>{r(),i(),o(),l=t(),c.__docgenInfo={description:``,methods:[],displayName:`PhysicianInformation`,props:{fieldIds:{required:!0,tsType:{name:`Array`,elements:[{name:`string`}],raw:`string[]`},description:``},allFields:{required:!0,tsType:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  id: string;
  label: string;
  tooltip?: string;
  inputType: FieldInputType;
  required?: boolean;
  placeholder?: string;
  helperText?: string;
  options?: FieldOption[];
  autoComplete?: string;
  inputMode?: "text" | "email" | "tel" | "numeric";
  format?: "email" | "phone" | "ssn" | "currency" | "percent" | "month-year";
  labelVariant?: "floating" | "standard";
  multiline?: boolean;
  minRows?: number;
  disabled?: boolean;
  /** Override the companion phone-type field name (default: "phone-type") */
  phoneTypeFieldId?: string;
  /** Whether to show the companion phone type selector (default: true) */
  showPhoneTypeSelector?: boolean;
}`,signature:{properties:[{key:`id`,value:{name:`string`,required:!0}},{key:`label`,value:{name:`string`,required:!0}},{key:`tooltip`,value:{name:`string`,required:!1}},{key:`inputType`,value:{name:`union`,raw:`| "text"
| "number"
| "date"
| "radio"
| "dropdown"
| "searchable-select"
| "checkbox"
| "checkbox-group"
| "multi-select"
| "percent"`,elements:[{name:`literal`,value:`"text"`},{name:`literal`,value:`"number"`},{name:`literal`,value:`"date"`},{name:`literal`,value:`"radio"`},{name:`literal`,value:`"dropdown"`},{name:`literal`,value:`"searchable-select"`},{name:`literal`,value:`"checkbox"`},{name:`literal`,value:`"checkbox-group"`},{name:`literal`,value:`"multi-select"`},{name:`literal`,value:`"percent"`}],required:!0}},{key:`required`,value:{name:`boolean`,required:!1}},{key:`placeholder`,value:{name:`string`,required:!1}},{key:`helperText`,value:{name:`string`,required:!1}},{key:`options`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  value: string;
  label: string;
}`,signature:{properties:[{key:`value`,value:{name:`string`,required:!0}},{key:`label`,value:{name:`string`,required:!0}}]}}],raw:`FieldOption[]`,required:!1}},{key:`autoComplete`,value:{name:`string`,required:!1}},{key:`inputMode`,value:{name:`union`,raw:`"text" | "email" | "tel" | "numeric"`,elements:[{name:`literal`,value:`"text"`},{name:`literal`,value:`"email"`},{name:`literal`,value:`"tel"`},{name:`literal`,value:`"numeric"`}],required:!1}},{key:`format`,value:{name:`union`,raw:`"email" | "phone" | "ssn" | "currency" | "percent" | "month-year"`,elements:[{name:`literal`,value:`"email"`},{name:`literal`,value:`"phone"`},{name:`literal`,value:`"ssn"`},{name:`literal`,value:`"currency"`},{name:`literal`,value:`"percent"`},{name:`literal`,value:`"month-year"`}],required:!1}},{key:`labelVariant`,value:{name:`union`,raw:`"floating" | "standard"`,elements:[{name:`literal`,value:`"floating"`},{name:`literal`,value:`"standard"`}],required:!1}},{key:`multiline`,value:{name:`boolean`,required:!1}},{key:`minRows`,value:{name:`number`,required:!1}},{key:`disabled`,value:{name:`boolean`,required:!1}},{key:`phoneTypeFieldId`,value:{name:`string`,required:!1},description:`Override the companion phone-type field name (default: "phone-type")`},{key:`showPhoneTypeSelector`,value:{name:`boolean`,required:!1},description:`Whether to show the companion phone type selector (default: true)`}]}}],raw:`FieldDefinition[]`},description:``},control:{required:!0,tsType:{name:`unknown`},description:``},errors:{required:!0,tsType:{name:`unknown`},description:``},nameRow:{required:!0,tsType:{name:`Set`,elements:[{name:`string`}],raw:`Set<string>`},description:``},streetRow:{required:!0,tsType:{name:`Set`,elements:[{name:`string`}],raw:`Set<string>`},description:``},cityStateZipRow:{required:!0,tsType:{name:`Set`,elements:[{name:`string`}],raw:`Set<string>`},description:``}}}}));export{u as n,c as t};