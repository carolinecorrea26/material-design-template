import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,at as n,t as r}from"./esm-AWQ-KJXU.js";import{i,n as a}from"./index.esm-DbA_UsRE.js";import{n as o,t as s}from"./getClientPageFields-B3swclaK.js";import{n as c,t as l}from"./pageSections-CV3JNZJv.js";import{n as u,t as d}from"./PhysicianInformation-CQh_rsBv.js";function f(){let{control:e,formState:t}=i({mode:`onChange`});return(0,p.jsx)(n,{sx:{maxWidth:640},children:(0,p.jsx)(d,{fieldIds:h.fieldIds,allFields:g,control:e,errors:t.errors,nameRow:_,streetRow:v,cityStateZipRow:y})})}var p,m,h,g,_,v,y,b,x;e((()=>{a(),r(),u(),l(),o(),p=t(),m={title:`Coverage & Commerce/PhysicianInformation`,component:d,parameters:{layout:`padded`,docs:{description:{component:`PhysicianInformation is a pure layout helper — it arranges physician
name/street/city-state-zip fields into responsive rows and delegates
every field to FieldRenderer, with no validation or state of its own.
Real Profile-page config (getPageSections("profile")'s
profilePersonalSelfPhysician section) drives which fields render, so this
story uses that config directly rather than a hand-built field list.`}}}},h=c(`profile`).find(e=>e.id===`profilePersonalSelfPhysician`),g=s(`profile`,{}),_=new Set([`physician-first-name`,`physician-last-name`]),v=new Set([`medical-facility-street-address`,`medical-facility-apt-suite`]),y=new Set([`medical-city`,`medical-state`,`medical-zip-code`]),b={render:()=>(0,p.jsx)(f,{}),parameters:{docs:{description:{story:`The real physician field set from Profile.tsx (self applicant): name row (2-col), phone, facility name, street row (2-col), then a city/state/zip row (3-col) — all responsive to 1 column below sm.`}}}},b.parameters={...b.parameters,docs:{...b.parameters?.docs,source:{originalSource:`{
  render: () => <PhysicianInformationDemo />,
  parameters: {
    docs: {
      description: {
        story: "The real physician field set from Profile.tsx (self applicant): name row (2-col), phone, facility name, street row (2-col), then a city/state/zip row (3-col) — all responsive to 1 column below sm."
      }
    }
  }
}`,...b.parameters?.docs?.source}}},x=[`Default`]}))();export{b as Default,x as __namedExportsOrder,m as default};