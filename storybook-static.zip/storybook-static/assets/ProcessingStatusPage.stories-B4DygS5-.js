import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t}from"./esm-AWQ-KJXU.js";import{n,t as r}from"./OfflineBolt-DJbsj_yP.js";import{n as i,t as a}from"./ProcessingStatusPage-CIh01xsi.js";var o,s,c,l;e((()=>{n(),i(),o=t(),s={title:`Feedback/ProcessingStatusPage`,component:a,parameters:{layout:`padded`}},c={args:{mark:(0,o.jsx)(r,{color:`success`}),heading:`Processing your application`,body:`Please wait while we securely prepare the next step.`}},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  args: {
    mark: <OfflineBoltIcon color="success" />,
    heading: "Processing your application",
    body: "Please wait while we securely prepare the next step."
  }
}`,...c.parameters?.docs?.source}}},l=[`ExternalService`]}))();export{c as ExternalService,l as __namedExportsOrder,s as default};