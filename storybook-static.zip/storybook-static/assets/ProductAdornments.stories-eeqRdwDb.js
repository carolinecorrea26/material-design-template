import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,S as n,dt as r,t as i}from"./esm-AWQ-KJXU.js";import{n as a,t as o}from"./QuickDecisionIndicator-8NxT_9Om.js";import{n as s,t as c}from"./FeaturedBadge-DCGvLT9j.js";var l,u,d,f;e((()=>{i(),s(),a(),l=t(),u={title:`Coverage & Commerce/Product Adornments`,parameters:{layout:`padded`,docs:{description:{component:`FeaturedBadge and QuickDecisionIndicator are the two small badges shown on
product cards (ProductCard, EstimatorProductCard, ProductCatalog). They're
documented together deliberately, not because they're related components,
but because they're visually inconsistent with each other in a way worth
flagging: FeaturedBadge is a filled text+icon Chip, QuickDecisionIndicator
is a bare, unlabeled icon relying only on its \`titleAccess\` tooltip text
for an accessible name. Neither has props/variants — this page exists to
show them side by side, not to exercise controls.`}}}},d={render:()=>(0,l.jsxs)(n,{spacing:3,sx:{maxWidth:420},children:[(0,l.jsxs)(n,{spacing:1,children:[(0,l.jsx)(r,{variant:`subtitle2`,children:`FeaturedBadge`}),(0,l.jsx)(c,{}),(0,l.jsx)(r,{variant:`caption`,color:`text.secondary`,children:`Filled Chip with a label and icon — its own visible text is the accessible name.`})]}),(0,l.jsxs)(n,{spacing:1,children:[(0,l.jsx)(r,{variant:`subtitle2`,children:`QuickDecisionIndicator`}),(0,l.jsx)(o,{}),(0,l.jsx)(r,{variant:`caption`,color:`text.secondary`,children:'A bare icon with no visible label — only a `titleAccess` tooltip ("QuickDecision") gives it an accessible name. Same underlying concept (a callout badge on a product card) rendered in two different visual languages.'})]})]})},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: () => <Stack spacing={3} sx={{
    maxWidth: 420
  }}>
      <Stack spacing={1}>
        <Typography variant="subtitle2">FeaturedBadge</Typography>
        <FeaturedBadge />
        <Typography variant="caption" color="text.secondary">
          Filled Chip with a label and icon — its own visible text is the
          accessible name.
        </Typography>
      </Stack>
      <Stack spacing={1}>
        <Typography variant="subtitle2">QuickDecisionIndicator</Typography>
        <QuickDecisionIndicator />
        <Typography variant="caption" color="text.secondary">
          A bare icon with no visible label — only a \`titleAccess\` tooltip
          ("QuickDecision") gives it an accessible name. Same underlying
          concept (a callout badge on a product card) rendered in two
          different visual languages.
        </Typography>
      </Stack>
    </Stack>
}`,...d.parameters?.docs?.source}}},f=[`SideBySide`]}))();export{d as SideBySide,f as __namedExportsOrder,u as default};