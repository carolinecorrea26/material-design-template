import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,S as n,dt as r,t as i}from"./esm-AWQ-KJXU.js";import{n as a,t as o}from"./ProductCard-B6o9ol1p.js";var s,c,l,u,d,f;e((()=>{i(),a(),s=t(),c={title:`Layout/ProductCard`,component:o,parameters:{layout:`padded`,docs:{description:{component:`ProductCard is the bordered card wrapper underneath every product row —
ProductCatalog's full card, EstimatorProductCard's simplified card,
QuoteModal, Beneficiary, Payment, Receipt. \`selected\` swaps the border and
background tint to a green "chosen" treatment.`}}}},l={render:()=>(0,s.jsxs)(o,{sx:{maxWidth:360},children:[(0,s.jsx)(r,{variant:`productNameLabel`,children:`Term Life Insurance`}),(0,s.jsx)(r,{variant:`body2`,color:`text.secondary`,children:`$250,000 coverage`})]})},u={render:()=>(0,s.jsxs)(o,{selected:!0,sx:{maxWidth:360},children:[(0,s.jsx)(r,{variant:`productNameLabel`,children:`Term Life Insurance`}),(0,s.jsx)(r,{variant:`body2`,color:`text.secondary`,children:`$250,000 coverage`})]})},d={render:()=>(0,s.jsxs)(n,{direction:`row`,spacing:2,children:[(0,s.jsx)(o,{sx:{maxWidth:280},children:(0,s.jsx)(r,{variant:`productNameLabel`,children:`Unselected`})}),(0,s.jsx)(o,{selected:!0,sx:{maxWidth:280},children:(0,s.jsx)(r,{variant:`productNameLabel`,children:`Selected`})})]})},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  render: () => <ProductCard sx={{
    maxWidth: 360
  }}>
      <Typography variant="productNameLabel">Term Life Insurance</Typography>
      <Typography variant="body2" color="text.secondary">$250,000 coverage</Typography>
    </ProductCard>
}`,...l.parameters?.docs?.source}}},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  render: () => <ProductCard selected sx={{
    maxWidth: 360
  }}>
      <Typography variant="productNameLabel">Term Life Insurance</Typography>
      <Typography variant="body2" color="text.secondary">$250,000 coverage</Typography>
    </ProductCard>
}`,...u.parameters?.docs?.source}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: () => <Stack direction="row" spacing={2}>
      <ProductCard sx={{
      maxWidth: 280
    }}>
        <Typography variant="productNameLabel">Unselected</Typography>
      </ProductCard>
      <ProductCard selected sx={{
      maxWidth: 280
    }}>
        <Typography variant="productNameLabel">Selected</Typography>
      </ProductCard>
    </Stack>
}`,...d.parameters?.docs?.source}}},f=[`Unselected`,`Selected`,`SideBySide`]}))();export{u as Selected,d as SideBySide,l as Unselected,f as __namedExportsOrder,c as default};