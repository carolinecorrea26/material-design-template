import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r,S as i,dt as a,ft as o,rt as s,t as c}from"./esm-AWQ-KJXU.js";import{l,r as u,t as d,u as f}from"./ApplicationFormContext-BU7mcIce.js";import{r as p,t as m}from"./coverageCategories-B_zBLMK-.js";import{n as h,t as g}from"./CoverageCategorySelector-DkE6-ssh.js";import{i as _,r as v}from"./useCoverageState-BzCpRm6l.js";import{n as y,t as b}from"./ProductCatalog-D6ucEu0d.js";function x({children:e}){let[t,n]=(0,C.useState)({});return(0,w.jsx)(d.Provider,{value:{values:t,setPageValues:e=>n(t=>f({...t,...e})),resetValues:()=>n({})},children:e})}function S(){let e=_();return(0,w.jsxs)(i,{spacing:3,children:[(0,w.jsx)(o,{severity:`info`,children:`This is the real useCoverageState() hook driving the real ProductCatalog component — select a category below, then reveal products. Rate frequency, amount pickers, and "Add coverage" are all live.`}),(0,w.jsx)(g,{categories:m,selectedIds:e.selectedCategories,onToggle:e.handleCategoryToggle}),e.selectedCategories.length>0&&!e.showProducts&&(0,w.jsx)(s,{variant:`contained`,onClick:()=>e.revealProducts(),sx:{alignSelf:`flex-start`},children:`See my coverage options`}),e.showProducts&&(0,w.jsx)(b,{availableCategories:e.availableCategories,selectedCategories:e.selectedCategories,categoryProducts:e.categoryProducts,categoryEligibility:e.categoryEligibility,allCategoriesIneligible:e.allCategoriesIneligible,hasQdCategorySelected:e.hasQdCategorySelected,selectedCoverageIds:e.selectedCoverageIds,productApplicants:e.productApplicants,storedAmounts:e.storedAmounts,storedRiders:e.storedRiders,storedRiderAmounts:e.storedRiderAmounts,storedWaitingPeriods:e.storedWaitingPeriods,storedMaxBenefitPeriods:e.storedMaxBenefitPeriods,calculatingRateKeys:e.calculatingRateKeys,rateFrequency:e.rateFrequency,frequencyCalculating:e.frequencyCalculating,selectionCalculating:e.selectionCalculating,showRateFrequencyToggle:e.showRateFrequencyToggle,showProducts:e.showProducts,productsLoading:e.productsLoading,grandTotal:e.grandTotal,activeClient:e.activeClient,onToggleApplicant:e.toggleApplicantForProduct,onAmountChange:e.handleAmountChange,onFrequencyToggle:e.handleFrequencyToggle,onRiderToggle:e.handleRiderToggle,onRiderAmountChange:e.handleRiderAmountChange,onWaitingPeriodChange:e.handleWaitingPeriodChange,onMaxBenefitPeriodChange:e.handleMaxBenefitPeriodChange,getVisibleApplicants:e.getVisibleApplicants,calcApplicantPremium:e.calcApplicantPremium,generateAmountChoices:e.generateAmountChoices,hasSpouse:e.hasSpouse})]})}var C,w,T,E,D,O;t((()=>{C=e(n(),1),c(),y(),h(),v(),u(),l(),p(),w=r(),T={title:`Coverage & Commerce/ProductCatalog`,component:b,parameters:{layout:`padded`,docs:{description:{component:`ProductCatalog is the main coverage-shopping surface: category sections →
product cards → an inline CoverageCart at the end. It has no props of its
own state machine — everything (selected categories, revealed/loading
products, rate frequency, per-product amounts/riders, the running total)
comes from useCoverageState(), the same hook the real Coverage page uses.
Rather than fabricate 25+ props by hand, this story calls that real hook
inside a locally-scoped ApplicationFormContext (isolated from the app's
own sessionStorage-backed values, so this story never leaks state into or
out of the running app), and drives it through the same real interactions
a user would: pick a category, then reveal products. Every price, product
name, and eligibility rule shown is the real client config, not mocked
data — this is intentionally the least "fake" story in the whole
Storybook instance.`}}}},E={render:()=>(0,w.jsx)(x,{children:(0,w.jsx)(S,{})}),parameters:{docs:{description:{story:`Revealing products always shows a ~2 second loading state first (the real RATE_CALCULATION_DELAY_MS), not a mocked-away instant transition — that's the actual behavior a user sees.`}}}},D={name:`Empty state (nothing selected yet)`,render:()=>(0,w.jsx)(x,{children:(0,w.jsxs)(i,{spacing:2,children:[(0,w.jsx)(a,{variant:`body2`,color:`text.secondary`,children:`Before any category is selected, ProductCatalog itself never mounts — the Coverage page shows only CoverageCategorySelector.`}),(0,w.jsx)(g,{categories:m,selectedIds:[],onToggle:()=>{}})]})})},E.parameters={...E.parameters,docs:{...E.parameters?.docs,source:{originalSource:`{
  render: () => <LocalFormProvider>
      <ProductCatalogDemo />
    </LocalFormProvider>,
  parameters: {
    docs: {
      description: {
        story: "Revealing products always shows a ~2 second loading state first (the real RATE_CALCULATION_DELAY_MS), not a mocked-away instant transition — that's the actual behavior a user sees."
      }
    }
  }
}`,...E.parameters?.docs?.source}}},D.parameters={...D.parameters,docs:{...D.parameters?.docs,source:{originalSource:`{
  name: "Empty state (nothing selected yet)",
  render: () => <LocalFormProvider>
      <Stack spacing={2}>
        <Typography variant="body2" color="text.secondary">
          Before any category is selected, ProductCatalog itself never
          mounts — the Coverage page shows only CoverageCategorySelector.
        </Typography>
        <CoverageCategorySelector categories={coverageCategories} selectedIds={[]} onToggle={() => {}} />
      </Stack>
    </LocalFormProvider>
}`,...D.parameters?.docs?.source}}},O=[`Interactive`,`NoCategorySelected`]}))();export{E as Interactive,D as NoCategorySelected,O as __namedExportsOrder,T as default};