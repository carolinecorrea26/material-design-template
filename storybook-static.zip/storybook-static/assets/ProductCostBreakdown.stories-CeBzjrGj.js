import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,at as n,t as r}from"./esm-AWQ-KJXU.js";import{n as i,t as a}from"./ProductCostBreakdown-LfIbJ9OY.js";var o,s,c,l,u,d,f;e((()=>{r(),i(),o=t(),s={title:`Coverage & Commerce/ProductCostBreakdown`,component:a,parameters:{layout:`padded`,docs:{description:{component:`ProductCostBreakdown is the itemized premium + rider + policy-fee
line-item list shown inside ProductCatalog's inline card (client-config
gated). It's stateless/pure — every value comes from props — and switches
its displayed numbers between monthly and annual via the shared
getDisplayedPremium() helper (the same one CoverageCart/QuoteCalculator
use), not its own math.`}}}},c={render:()=>(0,o.jsx)(n,{sx:{maxWidth:360},children:(0,o.jsx)(a,{premiumCost:42.5,riderItems:[{label:`Accidental Death Rider`,amount:3.25}],policyFee:{label:`Policy Fee`,amount:2},rateFrequency:`monthly`})})},l={render:()=>(0,o.jsx)(n,{sx:{maxWidth:360},children:(0,o.jsx)(a,{premiumCost:42.5,riderItems:[{label:`Accidental Death Rider`,amount:3.25}],policyFee:{label:`Policy Fee`,amount:2},rateFrequency:`annual`})}),parameters:{docs:{description:{story:`Every row (including riders and the policy fee) is converted to annual via getDisplayedPremium — not just the total — so per-line and total figures stay internally consistent.`}}}},u={name:`No riders, no policy fee`,render:()=>(0,o.jsx)(n,{sx:{maxWidth:360},children:(0,o.jsx)(a,{premiumCost:28,riderItems:[],rateFrequency:`monthly`})})},d={render:()=>(0,o.jsx)(n,{sx:{maxWidth:360},children:(0,o.jsx)(a,{premiumCost:65,riderItems:[{label:`Accidental Death Rider`,amount:3.25},{label:`Waiver of Premium Rider`,amount:4.1},{label:`Child Term Rider`,amount:1.5}],policyFee:{label:`Policy Fee`,amount:2},rateFrequency:`monthly`})})},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  render: () => <Box sx={{
    maxWidth: 360
  }}>
      <ProductCostBreakdown premiumCost={42.5} riderItems={[{
      label: "Accidental Death Rider",
      amount: 3.25
    }]} policyFee={{
      label: "Policy Fee",
      amount: 2
    }} rateFrequency="monthly" />
    </Box>
}`,...c.parameters?.docs?.source}}},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  render: () => <Box sx={{
    maxWidth: 360
  }}>
      <ProductCostBreakdown premiumCost={42.5} riderItems={[{
      label: "Accidental Death Rider",
      amount: 3.25
    }]} policyFee={{
      label: "Policy Fee",
      amount: 2
    }} rateFrequency="annual" />
    </Box>,
  parameters: {
    docs: {
      description: {
        story: "Every row (including riders and the policy fee) is converted to annual via getDisplayedPremium — not just the total — so per-line and total figures stay internally consistent."
      }
    }
  }
}`,...l.parameters?.docs?.source}}},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  name: "No riders, no policy fee",
  render: () => <Box sx={{
    maxWidth: 360
  }}>
      <ProductCostBreakdown premiumCost={28} riderItems={[]} rateFrequency="monthly" />
    </Box>
}`,...u.parameters?.docs?.source}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: () => <Box sx={{
    maxWidth: 360
  }}>
      <ProductCostBreakdown premiumCost={65} riderItems={[{
      label: "Accidental Death Rider",
      amount: 3.25
    }, {
      label: "Waiver of Premium Rider",
      amount: 4.1
    }, {
      label: "Child Term Rider",
      amount: 1.5
    }]} policyFee={{
      label: "Policy Fee",
      amount: 2
    }} rateFrequency="monthly" />
    </Box>
}`,...d.parameters?.docs?.source}}},f=[`Monthly`,`Annual`,`NoRidersOrFee`,`MultipleRiders`]}))();export{l as Annual,c as Monthly,d as MultipleRiders,u as NoRidersOrFee,f as __namedExportsOrder,s as default};