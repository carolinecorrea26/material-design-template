import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,S as n,at as r,dt as i,t as a}from"./esm-AWQ-KJXU.js";import{a as o,c as s,i as c,n as l,o as u,s as d,t as f}from"./QuickDecisionInfoBox-BV0I0PiQ.js";import{n as p,t as m}from"./QuickDecisionIndicator-8NxT_9Om.js";var h,g,_,v,y,b;e((()=>{a(),s(),l(),p(),h=t(),g={title:`Content/QuickDecision`,parameters:{layout:`padded`,docs:{description:{component:`The same QuickDecision℠ explainer content rendered through two different
chrome patterns — HowApplyingWorksPanel's drawer (QuickDecisionDrawerContent,
a full explainer body) and ProductCatalog/CoverageOptionsPanel's inline
collapsible banner (QuickDecisionInfoBox, which reuses the same content
component internally with plainMark). Documented together deliberately,
per the Phase 1 audit's explicit recommendation, rather than as unrelated
components — along with the third, visually inconsistent sibling
(QuickDecisionIndicator, a bare icon with no text) shown for comparison.`}}}},_={name:`QuickDecisionInfoBox (inline collapsible banner)`,render:()=>(0,h.jsx)(r,{sx:{maxWidth:640},children:(0,h.jsx)(f,{})}),parameters:{docs:{description:{story:`"Show more" expands the same explainer content shown in the drawer surface below, inline, via aria-expanded/aria-controls on a role="button" span rather than a native button — click it to see both.`}}}},v={name:`QuickDecisionDrawerContent (full explainer body)`,render:()=>(0,h.jsx)(r,{sx:{maxWidth:420},children:(0,h.jsx)(c,{})}),parameters:{docs:{description:{story:`The same content HowApplyingWorksPanel's drawer variant mounts inside its own AppDrawer sub-panel — shown here standalone, without that chrome.`}}}},y={name:`QuickDecisionMark family (styled / plain / bare)`,render:()=>(0,h.jsxs)(n,{spacing:2,sx:{maxWidth:420},children:[(0,h.jsxs)(n,{spacing:.5,children:[(0,h.jsx)(i,{variant:`caption`,color:`text.secondary`,children:`QuickDecisionMarkStyled — bold, success green, lightning icon`}),(0,h.jsxs)(i,{variant:`body2`,children:[(0,h.jsx)(d,{}),` available!`]})]}),(0,h.jsxs)(n,{spacing:.5,children:[(0,h.jsx)(i,{variant:`caption`,color:`text.secondary`,children:`QuickDecisionMarkPlain — bold weight only, no color/icon`}),(0,h.jsxs)(i,{variant:`body2`,children:[(0,h.jsx)(u,{}),` available!`]})]}),(0,h.jsxs)(n,{spacing:.5,children:[(0,h.jsx)(i,{variant:`caption`,color:`text.secondary`,children:`QuickDecisionMark — bare text + superscript, no styling at all`}),(0,h.jsxs)(i,{variant:`body2`,children:[(0,h.jsx)(o,{}),` available!`]})]}),(0,h.jsxs)(n,{spacing:.5,children:[(0,h.jsx)(i,{variant:`caption`,color:`text.secondary`,children:`QuickDecisionIndicator — the visually inconsistent sibling: a bare icon, no visible text at all (only a titleAccess tooltip)`}),(0,h.jsxs)(i,{variant:`body2`,children:[(0,h.jsx)(m,{}),` (icon only, no label)`]})]})]})},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  name: "QuickDecisionInfoBox (inline collapsible banner)",
  render: () => <Box sx={{
    maxWidth: 640
  }}>
      <QuickDecisionInfoBox />
    </Box>,
  parameters: {
    docs: {
      description: {
        story: '"Show more" expands the same explainer content shown in the drawer surface below, inline, via aria-expanded/aria-controls on a role="button" span rather than a native button — click it to see both.'
      }
    }
  }
}`,..._.parameters?.docs?.source}}},v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{
  name: "QuickDecisionDrawerContent (full explainer body)",
  render: () => <Box sx={{
    maxWidth: 420
  }}>
      <QuickDecisionDrawerContent />
    </Box>,
  parameters: {
    docs: {
      description: {
        story: "The same content HowApplyingWorksPanel's drawer variant mounts inside its own AppDrawer sub-panel — shown here standalone, without that chrome."
      }
    }
  }
}`,...v.parameters?.docs?.source}}},y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  name: "QuickDecisionMark family (styled / plain / bare)",
  render: () => <Stack spacing={2} sx={{
    maxWidth: 420
  }}>
      <Stack spacing={0.5}>
        <Typography variant="caption" color="text.secondary">
          QuickDecisionMarkStyled — bold, success green, lightning icon
        </Typography>
        <Typography variant="body2">
          <QuickDecisionMarkStyled /> available!
        </Typography>
      </Stack>
      <Stack spacing={0.5}>
        <Typography variant="caption" color="text.secondary">
          QuickDecisionMarkPlain — bold weight only, no color/icon
        </Typography>
        <Typography variant="body2">
          <QuickDecisionMarkPlain /> available!
        </Typography>
      </Stack>
      <Stack spacing={0.5}>
        <Typography variant="caption" color="text.secondary">
          QuickDecisionMark — bare text + superscript, no styling at all
        </Typography>
        <Typography variant="body2">
          <QuickDecisionMark /> available!
        </Typography>
      </Stack>
      <Stack spacing={0.5}>
        <Typography variant="caption" color="text.secondary">
          QuickDecisionIndicator — the visually inconsistent sibling: a bare
          icon, no visible text at all (only a titleAccess tooltip)
        </Typography>
        <Typography variant="body2">
          <QuickDecisionIndicator /> (icon only, no label)
        </Typography>
      </Stack>
    </Stack>
}`,...y.parameters?.docs?.source}}},b=[`InfoBoxInlineCollapse`,`DrawerExplainerContent`,`MarkVariants`]}))();export{v as DrawerExplainerContent,_ as InfoBoxInlineCollapse,y as MarkVariants,b as __namedExportsOrder,g as default};