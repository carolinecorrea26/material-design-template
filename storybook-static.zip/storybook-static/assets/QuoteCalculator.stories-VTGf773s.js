import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r,at as i,rt as a,t as o}from"./esm-AWQ-KJXU.js";import{n as s,t as c}from"./QuoteCalculator-DAwO6yJz.js";function l(e){let[t,n]=(0,u.useState)(!0);return(0,d.jsxs)(i,{sx:{p:2},children:[(0,d.jsx)(a,{variant:`outlined`,onClick:()=>n(!0),children:`Reopen quote calculator`}),(0,d.jsx)(c,{...e,open:t,onClose:()=>n(!1)})]})}var u,d,f,p,m,h,g;t((()=>{u=e(n(),1),o(),s(),d=r(),f={title:`Coverage & Commerce/QuoteCalculator`,component:c,parameters:{layout:`fullscreen`,docs:{description:{component:`QuoteCalculator is a self-contained drawer quote tool (it wraps its own
AppDrawer, unlike ProductCatalog which is fully prop-driven) — category
selection → eligibility → coverage questions → per-product estimate →
"Apply" hands off to the Membership page via sessionStorage. Triggered
from the Home page and Membership page. \`collectEligibility\` toggles
whether DOB/ZIP/State fields are collected inside the drawer itself
(Membership trigger) versus assumed already known and passed via
\`initialEligibility\` (Home page trigger, where a card collects them
first).`}}}},p={name:`collectEligibility=true (Membership page trigger)`,render:()=>(0,d.jsx)(l,{collectEligibility:!0})},m={name:`collectEligibility=false + initialEligibility (Home page trigger)`,render:()=>(0,d.jsx)(l,{initialEligibility:{birthday:`1990-05-14`,zipCode:`10001`,state:`NY`}}),parameters:{docs:{description:{story:`DOB/ZIP/State fields aren't shown at all in this mode — they were already collected by the Home page's own quote-entry card before the drawer opened.`}}}},h={render:()=>(0,d.jsx)(l,{collectEligibility:!0,title:`Get a quick quote`})},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  name: "collectEligibility=true (Membership page trigger)",
  render: () => <QuoteCalculatorDemo collectEligibility />
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  name: "collectEligibility=false + initialEligibility (Home page trigger)",
  render: () => <QuoteCalculatorDemo initialEligibility={{
    birthday: "1990-05-14",
    zipCode: "10001",
    state: "NY"
  }} />,
  parameters: {
    docs: {
      description: {
        story: "DOB/ZIP/State fields aren't shown at all in this mode — they were already collected by the Home page's own quote-entry card before the drawer opened."
      }
    }
  }
}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  render: () => <QuoteCalculatorDemo collectEligibility title="Get a quick quote" />
}`,...h.parameters?.docs?.source}}},g=[`CollectsEligibility`,`EligibilityAlreadyKnown`,`CustomTitle`]}))();export{p as CollectsEligibility,h as CustomTitle,m as EligibilityAlreadyKnown,g as __namedExportsOrder,f as default};