import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r}from"./esm-AWQ-KJXU.js";import{n as i,t as a}from"./RadioSelectionGroup-Cs5igWQ_.js";var o,s,c,l,u,d,f;t((()=>{o=e(n(),1),i(),s=r(),c={title:`Forms/RadioSelectionGroup`,component:a,parameters:{layout:`padded`}},l=[{value:`text`,label:`Text message`},{value:`voice`,label:`Voice call`}],u=()=>{let[e,t]=(0,o.useState)(`text`);return(0,s.jsx)(a,{name:`delivery-method`,label:`Delivery method`,options:l,value:e,onChange:t,required:!0})},d=()=>(0,s.jsx)(a,{name:`beneficiary-type`,label:`Beneficiary type`,options:[{value:`individual`,label:`Individual`},{value:`trust`,label:`Trust`}],value:`individual`,onChange:()=>{},disabled:!0}),u.__docgenInfo={description:``,methods:[],displayName:`Interactive`},d.__docgenInfo={description:``,methods:[],displayName:`Disabled`},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`() => {
  const [value, setValue] = useState("text");
  return <RadioSelectionGroup name="delivery-method" label="Delivery method" options={options} value={value} onChange={setValue} required />;
}`,...u.parameters?.docs?.source}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`() => <RadioSelectionGroup name="beneficiary-type" label="Beneficiary type" options={[{
  value: "individual",
  label: "Individual"
}, {
  value: "trust",
  label: "Trust"
}]} value="individual" onChange={() => {}} disabled />`,...d.parameters?.docs?.source}}},f=[`Interactive`,`Disabled`]}))();export{d as Disabled,u as Interactive,f as __namedExportsOrder,c as default};