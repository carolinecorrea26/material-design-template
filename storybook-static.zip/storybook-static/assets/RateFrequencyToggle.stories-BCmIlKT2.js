import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t}from"./esm-AWQ-KJXU.js";import{n,t as r}from"./RateFrequencyToggle-CRC-Oizr.js";var i,a,o,s,c;e((()=>{n(),i=t(),a={title:`Coverage & Commerce/RateFrequencyToggle`,component:r,parameters:{layout:`centered`,docs:{description:{component:`RateFrequencyToggle is a styled MUI Switch with no props of its own beyond
Switch's — the monthly/annual meaning comes entirely from how a consumer
wires \`checked\`/\`onChange\`, which is why every story below builds that
wiring. The complete labeled Monthly/Annual pattern now lives in the
adjacent RateFrequencyControl story and is what real consumers use.`}}}},o={render:()=>(0,i.jsx)(r,{inputProps:{"aria-label":`Rate frequency`}})},s={render:()=>(0,i.jsx)(r,{defaultChecked:!0,inputProps:{"aria-label":`Rate frequency`}})},o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  render: () => <RateFrequencyToggle inputProps={{
    "aria-label": "Rate frequency"
  }} />
}`,...o.parameters?.docs?.source}}},s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  render: () => <RateFrequencyToggle defaultChecked inputProps={{
    "aria-label": "Rate frequency"
  }} />
}`,...s.parameters?.docs?.source}}},c=[`Unchecked`,`Checked`]}))();export{s as Checked,o as Unchecked,c as __namedExportsOrder,a as default};