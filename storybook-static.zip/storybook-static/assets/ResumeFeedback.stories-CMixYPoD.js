import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,S as n,at as r,t as i}from"./esm-AWQ-KJXU.js";import{i as a,r as o}from"./RefreshRounded-CGBKY5dT.js";import{i as s,n as c,r as l,t as u}from"./ResendCountdownRow-B3TBMIpm.js";var d,f,p,m,h,g;e((()=>{i(),a(),s(),c(),d=t(),f={title:`Feedback/Resume Expiration`,parameters:{layout:`padded`}},p=()=>(0,d.jsxs)(n,{spacing:2,sx:{maxWidth:560},children:[(0,d.jsxs)(l,{secondsLeft:542,kind:`link`,onResend:()=>{},activeIcon:(0,d.jsx)(o,{}),children:[`A secure link has been sent to `,(0,d.jsx)(`strong`,{children:`returning.user@example.com`}),`.`]}),(0,d.jsx)(u,{secondsLeft:542,kind:`link`,onResend:()=>{}})]}),m=()=>(0,d.jsxs)(n,{spacing:2,sx:{maxWidth:560},children:[(0,d.jsx)(l,{secondsLeft:0,kind:`code`,onResend:()=>{}}),(0,d.jsx)(u,{secondsLeft:0,kind:`code`,onResend:()=>{}})]}),h=()=>(0,d.jsx)(r,{sx:{maxWidth:560},children:(0,d.jsx)(l,{secondsLeft:300,kind:`code`,onResend:()=>{},showConfirmation:!0,confirmationMessage:`A new verification code has been sent.`})}),p.__docgenInfo={description:``,methods:[],displayName:`ActiveLink`},m.__docgenInfo={description:``,methods:[],displayName:`ExpiredCode`},h.__docgenInfo={description:``,methods:[],displayName:`ResentConfirmation`},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`() => <Stack spacing={2} sx={{
  maxWidth: 560
}}>
    <ExpiringCodeAlert secondsLeft={542} kind="link" onResend={() => {}} activeIcon={<MailLockRounded />}>
      A secure link has been sent to <strong>returning.user@example.com</strong>.
    </ExpiringCodeAlert>
    <ResendCountdownRow secondsLeft={542} kind="link" onResend={() => {}} />
  </Stack>`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`() => <Stack spacing={2} sx={{
  maxWidth: 560
}}>
    <ExpiringCodeAlert secondsLeft={0} kind="code" onResend={() => {}} />
    <ResendCountdownRow secondsLeft={0} kind="code" onResend={() => {}} />
  </Stack>`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`() => <Box sx={{
  maxWidth: 560
}}>
    <ExpiringCodeAlert secondsLeft={300} kind="code" onResend={() => {}} showConfirmation confirmationMessage="A new verification code has been sent." />
  </Box>`,...h.parameters?.docs?.source}}},g=[`ActiveLink`,`ExpiredCode`,`ResentConfirmation`]}))();export{p as ActiveLink,m as ExpiredCode,h as ResentConfirmation,g as __namedExportsOrder,f as default};