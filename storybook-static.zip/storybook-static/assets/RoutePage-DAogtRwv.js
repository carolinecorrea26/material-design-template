import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r,at as i,ft as a,t as ee}from"./esm-AWQ-KJXU.js";import{a as te,o as ne,t as re}from"./dist-DRJIfgnA.js";import{a as ie,o}from"./theme-B3ct2zHf.js";import{i as ae,n as oe}from"./index.esm-DbA_UsRE.js";import{a as se,n as ce,o as le,t as s}from"./getActiveClient-DQgJg1Xd.js";import{a as ue,n as de,o as fe,t as c}from"./getClientPageFields-B3swclaK.js";import{r as l,t as u}from"./getActiveClientCoverages-DKkYn-kk.js";import{a as pe,g as me,h as he,i as ge,m as _e,o as d,r as f,v as ve}from"./ApplicationFormContext-BU7mcIce.js";import{n as p,r as ye}from"./content-CYNdyLgC.js";import{a as be,o as xe,s as Se,t as Ce}from"./pages-qGdgmj14.js";import{n as we,t as Te}from"./pageSections-CV3JNZJv.js";import{n as Ee,t as De}from"./PageShell-YUtjXUwe.js";import{n as m,t as Oe}from"./PageHeader-BIhFxM6S.js";import{n as h,t as ke}from"./FormShell-C4OXUhsM.js";import{n as g,t as Ae}from"./PageNav-rqugKBhz.js";import{a as je,n as Me,o as Ne,r as Pe,t as Fe}from"./ProgressStep-DvEa_cge.js";import{r as Ie,t as _}from"./coverageCategories-B_zBLMK-.js";import{n as Le,t as Re}from"./PageTransitionSkeleton-CVs1qDT9.js";import{n as v,t as ze}from"./ProgressSavedSnackbar-C_J7NJZl.js";import{n as y,t as Be}from"./PageAlert-BAKN4Gvd.js";function Ve(e){let t=e.productApplicants;return typeof t==`object`&&t&&!Array.isArray(t)?t:{}}function He(e){let t=b(e),n=Ve(e);for(let e of Object.values(n))if(Array.isArray(e)&&e.some(e=>e!==`member`&&t.includes(e)))return!0;return!1}function b(e){let t=e.dependents;return Array.isArray(t)?t:[]}function x(e,t){if(e===`spouse`&&!b(t).includes(`spouse`)||e===`child`&&!b(t).includes(`child`))return!1;let n=Ve(t);for(let t of Object.values(n))if(Array.isArray(t)&&t.includes(e))return!0;return!1}function S(e,t){return x(e===`self`?`member`:e,t)}function Ue(e,t){return e===`self`||e===`member`?He(t):x(e,t)}var We=t((()=>{}));function Ge(e){let{navigation:t}=p();return t.transitionMessages[e]??t.transitionDefaults}var C,Ke,w=t((()=>{ye(),C=2200,Ke=`Returning to the previous step...`}));function T(e){return O.has(e.toUpperCase())}function qe(e){return new Intl.NumberFormat(`en-US`,{style:`currency`,currency:`USD`,maximumFractionDigits:0}).format(e)}function Je(e){if(typeof e==`number`&&Number.isFinite(e)&&e>0)return e;if(typeof e==`string`){let t=Number(e.replace(/[^\d.-]/g,``));if(Number.isFinite(t)&&t>0)return t}return null}function Ye(e){if(typeof e!=`string`)return null;let t=e.trim().toLowerCase();return t===`self`?`member`:t===`member`||t===`spouse`||t===`child`?t:null}function Xe(e){let t=[];for(let n of e){let e=Ye(n);e&&!t.includes(e)&&t.push(e)}return t}function Ze(e,t,n,r){let i=e.qdDecisions;if(i&&typeof i==`object`&&!Array.isArray(i)){let e=i[`${t}:${n}`];if(e===`conditionally-approved`||e===`referred`||e===`soft-declined`||e===`database-unavailable`)return e}return rt[r%rt.length]}function E(e){let{underwritingType:t,decisionResult:n}=e,r=t.toUpperCase();if(!O.has(r))return{label:k.decisionStatuses.fullyUnderwritten.label,color:`primary.main`,activeStep:1,description:k.decisionStatuses.fullyUnderwritten.description};switch(n){case`conditionally-approved`:return{label:k.decisionStatuses.conditionallyApproved.label,color:`primary.main`,activeStep:2,description:k.decisionStatuses.conditionallyApproved.description};case`referred`:return{label:k.decisionStatuses.referred.label,color:`primary.main`,activeStep:1,description:k.decisionStatuses.referred.description};case`soft-declined`:return{label:k.decisionStatuses.softDeclined.label,color:`primary.main`,activeStep:2,description:k.decisionStatuses.softDeclined.description};case`database-unavailable`:return{label:k.decisionStatuses.databaseUnavailable.label,color:`primary.main`,activeStep:1,description:k.decisionStatuses.databaseUnavailable.description}}}function Qe(e){return Array.isArray(e.coverageSelections)?e.coverageSelections.map(String):[]}function D(e){return Array.isArray(e.dependents)?Xe(e.dependents).filter(e=>e===`spouse`||e===`child`):[]}function $e(e){return e.productApplicants!=null&&typeof e.productApplicants==`object`&&!Array.isArray(e.productApplicants)?e.productApplicants:{}}function et(e,t,n){let r=e.coverageAmounts;return!r||typeof r!=`object`||Array.isArray(r)?null:Je(r[`${t}:${n}`])}function tt(e,t){let n=Qe(e),r=D(e),i=$e(e),a=new Map(t.map(e=>[e.id,e]));return n.flatMap(e=>{let t=a.get(e);if(!t)return[];let n;if(Object.prototype.hasOwnProperty.call(i,e)){let r=Array.isArray(i[e])?i[e]:[];n=t.applicants.filter(e=>r.includes(e))}else n=r.length>0?t.applicants.filter(e=>e===`member`?!0:r.includes(e)):t.applicants.includes(`member`)?[`member`]:[];return n.map(n=>({coverageId:e,applicant:n,coverage:t}))})}function nt(e,t){let n=tt(e,t);return _.flatMap(e=>n.filter(t=>t.coverage.categoryId===e.id).sort((e,t)=>{let n=e.coverage.name.localeCompare(t.coverage.name);return n===0?j[e.applicant]-j[t.applicant]:n}))}var O,k,A,j,rt,it,at=t((()=>{Ie(),ye(),O=new Set([`SI`,`GI`,`NA`,`QD`]),k=p().receipt,A=p().shared.applicantLabels,j={member:0,spouse:1,child:2},rt=[`conditionally-approved`,`referred`,`soft-declined`,`database-unavailable`],it=k.decisionSteps}));function M(e,t){let n=e[t];return typeof n==`string`?n.trim():``}function N(e){return e.replaceAll(`&`,`&amp;`).replaceAll(`<`,`&lt;`).replaceAll(`>`,`&gt;`).replaceAll(`"`,`&quot;`).replaceAll(`'`,`&#039;`)}function ot(e){return new Intl.DateTimeFormat(`en-US`,{month:`long`,day:`numeric`,year:`numeric`}).format(e)}function P(e){return new Intl.DateTimeFormat(`en-US`,{month:`long`,day:`numeric`,year:`numeric`,hour:`numeric`,minute:`2-digit`}).format(e)}function F(e,t){let n=new Date(e);return n.setDate(n.getDate()+t),n}function I(e,t){return[e,t].filter(Boolean).join(` `).trim()||`Applicant`}function st(e){let t=`https://redesignv2--material-design-template.netlify.app`;if(!e)return t;let n=e.trim().replace(/\/$/,``);return n?n.startsWith(`http`)?n:`https://${n}`:t}function ct(e){return new URL(`/resume?client=${e}`,window.location.origin).toString()}function lt(e){return`${e.toLowerCase()}.nylinsure.com/resume`}function L(e){let t=e?se[e]:s(),n=st(t.support.website),r=t.emailSupport;return{clientId:t.id,associationName:t.branding.name,clientAcronym:t.branding.acronym,tpaName:r?.contactOverride?.name||t.branding.name,tpaAcronym:r?.contactOverride?.acronym||t.branding.acronym,tpaPhone:r?.supportOverride?.phone||t.support.phoneDisplay||t.support.phone||``,tpaEmail:r?.supportOverride?.email||t.support.email||``,tpaWebsite:r?.supportOverride?.website||t.support.website||``,hideSupportContact:!!r?.hideContactBox,clientLogo:t.branding.logo,clientLogoAlt:t.branding.logoAlt,startUrl:n,resumeUrl:ct(t.id),resumeDisplayUrl:lt(t.branding.acronym),resumeMagicLinkUrl:`${n}/resume-method`}}function ut(e,t){return{...L(t),toEmail:M(e,`email`),firstName:M(e,`first-name`),lastName:M(e,`last-name`)}}function R(e){return`Insurance Administrator`}function z(e){return`Insurance Administrator`}function dt(e){return!!M(e,`email`)}function ft(){try{let e=window.localStorage.getItem(G);if(!e)return[];let t=JSON.parse(e);return Array.isArray(t)?t:[]}catch{return[]}}function pt(){window.dispatchEvent(new Event(K))}function mt(e){let t=[e,...ft().filter(t=>t.id!==e.id)];window.localStorage.setItem(G,JSON.stringify(t)),pt()}function ht(e){return`${e}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}function B(e){return`<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>${N(e.title)}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
  </head>

  <body style="margin:0; padding:0; background-color:#eef2f7; font-family:Arial, Helvetica, sans-serif; color:#111827;">
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="font-family:Arial, Helvetica, sans-serif; background-color:#eef2f7; margin:0; padding:28px 12px;">
      <tr>
        <td align="center">
          <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="font-family:Arial, Helvetica, sans-serif; max-width:600px; background-color:#ffffff; border-radius:28px; overflow:hidden;">
            <tr>
              <td style="font-family:Arial, Helvetica, sans-serif; padding:32px 32px 0; color:#111827; font-size:16px; line-height:1.55;">
                ${e.bodyHtml}
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>`}function V(e,t){return`<table role="presentation" cellspacing="0" cellpadding="0" style="font-family:Arial, Helvetica, sans-serif; margin:28px 0;">
    <tr>
      <td align="center" style="font-family:Arial, Helvetica, sans-serif; border-radius:999px; background-color:#006fff;">
        <a href="${N(t)}" style="font-family:Arial, Helvetica, sans-serif; display:inline-block; padding:17px 28px; color:#ffffff; font-size:16px; line-height:1; font-weight:700; text-decoration:none; border-radius:999px;">
          ${N(e)}
        </a>
      </td>
    </tr>
  </table>`}function gt(e){return e.replace(/\D/g,``)}function _t(){return`<p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 16px; font-size:16px; line-height:1.55; color:#374151;">
    To access your application information, you will be asked to verify your identity using the email and phone number provided in your application.
  </p>`}function vt(e){return e===`Conditionally approved`?{background:`rgba(0, 148, 101, 0.08)`,color:`#007a53`}:e===`Sent for review`?{background:`rgba(6, 104, 255, 0.08)`,color:`#006fff`}:{background:`rgba(255, 152, 0, 0.08)`,color:`#b26a00`}}function yt(e,t,n){let r=Ze(n,e.coverageId,e.applicant,t),i=E({underwritingType:e.coverage.underwritingType,decisionResult:r}),a=vt(i.label),ee=A[e.applicant],te=et(n,e.coverageId,e.applicant);return`<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="font-family:Arial, Helvetica, sans-serif; margin:0 0 14px; border:1px solid #d1d5db; border-radius:14px;">
    <tr>
      <td style="font-family:Arial, Helvetica, sans-serif; padding:16px 18px;">
        <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td style="font-family:Arial, Helvetica, sans-serif; font-size:15px; font-weight:700; color:#111827;">
              ${N(e.coverage.name)}
            </td>
            <td align="right" style="font-family:Arial, Helvetica, sans-serif; white-space:nowrap;">
              <span style="font-family:Arial, Helvetica, sans-serif; display:inline-block; padding:3px 10px; border-radius:999px; background-color:${a.background}; color:${a.color}; font-size:12px; font-weight:700;">
                ${N(i.label)}
              </span>
            </td>
          </tr>
        </table>

        <p style="font-family:Arial, Helvetica, sans-serif; margin:8px 0 10px; font-size:13px; line-height:1.4; color:#6b7280;">
          ${N(ee)} coverage${te?` &middot; Requested: ${N(qe(te))}`:``}
        </p>

        <p style="font-family:Arial, Helvetica, sans-serif; margin:0; font-size:13px; line-height:1.5; color:#374151;">
          ${N(i.description)}
        </p>
      </td>
    </tr>
  </table>`}function bt(e){let t=nt(e,u());return t.length===0?``:`<p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 4px; font-size:18px; line-height:1.3; font-weight:700; color:#111827;">
      Coverage decisions
    </p>
    <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 16px; font-size:14px; line-height:1.5; color:#6b7280;">
      Review the current status for each coverage you applied for.
    </p>
    ${t.map((t,n)=>yt(t,n,e)).join(``)}`}function H(e,t,n,r){let i=gt(t);return`<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="font-family:Arial, Helvetica, sans-serif; margin:28px 0 0; background-color:${o.palette.support.main}; border:1px solid ${o.palette.support.border}; border-radius:16px;">
    <tr>
      <td style="font-family:Arial, Helvetica, sans-serif; padding:22px 22px 20px; color:#12233d;">
        <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 18px; color:#071b3a; font-size:18px; line-height:1.25; font-weight:700;">
          Questions? We’re here to help.
        </p>

        <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 14px; color:#12233d; font-size:16px; line-height:1.45; font-weight:400;">
          ${N(e)} Insurance Administrator
        </p>

        <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 12px; color:#12233d; font-size:16px; line-height:1.45; font-weight:700;">
          Call:
          <a href="tel:${N(i)}" style="font-family:Arial, Helvetica, sans-serif; color:#006fff; font-weight:700; text-decoration:none;">
            ${N(t)}
          </a>
        </p>

        <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 ${r?`12px`:`0`}; color:#12233d; font-size:16px; line-height:1.45; font-weight:700;">
          Email:
          <a href="mailto:${N(n)}" style="font-family:Arial, Helvetica, sans-serif; color:#006fff; font-weight:700; text-decoration:none;">
            ${N(n)}
          </a>
        </p>

        ${r?`<p style="font-family:Arial, Helvetica, sans-serif; margin:0; color:#12233d; font-size:16px; line-height:1.45; font-weight:700;">
          Website:
          <a href="${N(st(r))}" style="font-family:Arial, Helvetica, sans-serif; color:#006fff; font-weight:700; text-decoration:none;">
            ${N(r)}
          </a>
        </p>`:``}
      </td>
    </tr>
  </table>`}function xt(e,t){return`<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="font-family:Arial, Helvetica, sans-serif; margin:20px 0 0; background-color:${o.palette.notice.main}; border:1px solid ${o.palette.notice.border}; border-radius:16px;">
    <tr>
      <td style="font-family:Arial, Helvetica, sans-serif; padding:22px 22px 20px; color:#7a2e0c;">
        <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 18px; color:#7a2e0c; font-size:18px; line-height:1.25; font-weight:700;">
          ${N(e)}
        </p>

        <p style="font-family:Arial, Helvetica, sans-serif; margin:0; color:#7a2e0c; font-size:16px; line-height:1.55;">
          ${N(t)}
        </p>
      </td>
    </tr>
  </table>`}function St(){return`<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="font-family:Arial, Helvetica, sans-serif; margin:28px 0 0; border-top:1px solid #d1d5db; padding-top:18px;">
    <tr>
      <td style="font-family:Arial, Helvetica, sans-serif; padding-top:18px; vertical-align:top; width:50px;">
        <img src="/logo.svg" alt="New York Life" width="50" height="50" style="font-family:Arial, Helvetica, sans-serif; display:block; width:50px; height:50px; border:0; outline:none; text-decoration:none; border-radius:2px;" />
      </td>
      <td style="font-family:Arial, Helvetica, sans-serif; padding-top:18px; padding-left:14px; vertical-align:top;">
        <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 4px; font-size:11px; line-height:1.4; font-weight:700; color:#111827;">Underwritten By:</p>
        <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 4px; font-size:11px; line-height:1.4; color:#111827;">New York Life Insurance Company</p>
        <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 4px; font-size:11px; line-height:1.4; color:#111827;">51 Madison Avenue New York, New York 10010</p>
        <p style="font-family:Arial, Helvetica, sans-serif; margin:0; font-size:10px; line-height:1.4; color:#6b7280;">NEW YORK LIFE and the NEW YORK LIFE Box Logo are trademarks of New York Life Insurance Company.</p>
      </td>
    </tr>
  </table>`}function U(){return`${St()}
  <div style="font-family:Arial, Helvetica, sans-serif; margin:18px 0 24px; padding-top:14px;">
    <p style="font-family:Arial, Helvetica, sans-serif; margin:0; color:#6b7280; font-size:13px; line-height:1.45;">
      Please note: This is an automated message. Replies to this email are not monitored.
    </p>
  </div>`}function Ct(e){let t=e===`Submitted`||e===`Application submitted`?`#109a17`:`#0768ff`;return e===`Submitted`||e===`Application submitted`?`<svg aria-hidden="true" viewBox="0 0 24 24" width="22" height="22" style="display:block; fill:${t}; flex:0 0 auto;">
      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1.41 14.59L6.35 12.35l1.41-1.41 2.83 2.83 5.66-5.66 1.41 1.41-7.07 7.07z"></path>
    </svg>`:e===`Sent for signature`||e===`Application sent for signature`?`<svg aria-hidden="true" viewBox="0 0 24 24" width="22" height="22" style="display:block; fill:${t}; flex:0 0 auto;">
    <path d="m3.4 20.4 17.45-7.48c.81-.35.81-1.49 0-1.84L3.4 3.6c-.66-.29-1.39.2-1.39.91L2 9.12c0 .5.37.93.87.99L17 12 2.87 13.88c-.5.07-.87.5-.87 1l.01 4.61c0 .71.73 1.2 1.39.91"></path>
  </svg>`:e===`Edit requested`||e===`Application edit requested`?`<svg aria-hidden="true" viewBox="0 0 24 24" width="22" height="22" style="display:block; fill:${t}; flex:0 0 auto;">
  <path d="m17.58 6.25 1.77 1.77-4.84 4.84c-.09.09-.22.14-.35.14H13.1c-.28 0-.5-.22-.5-.5v-1.06c0-.13.05-.26.15-.35zm3.27-.44-1.06-1.06c-.2-.2-.51-.2-.71 0l-.85.85L20 7.37l.85-.85c.2-.2.2-.52 0-.71M20 18c0 .55-.45 1-1 1H5c-.55 0-1-.45-1-1s.45-1 1-1h1v-7c0-2.79 1.91-5.14 4.5-5.8v-.7c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5v.7c.82.21 1.57.59 2.21 1.09l-4.52 4.52c-.38.38-.59.88-.59 1.41V13c0 1.1.9 2 2 2h1.77c.53 0 1.04-.21 1.41-.59L18 12.2V17h1c.55 0 1 .45 1 1m-10 2h4c0 1.1-.9 2-2 2s-2-.9-2-2"></path>
</svg>`:e===`Waiting for signature`||e===`Application still pending signature`?`<svg aria-hidden="true" viewBox="0 0 24 24" width="22" height="22" style="display:block; fill:${t}; flex:0 0 auto;">
    <path d="m15.1 19.37 1 1.74c-.96.44-2.01.73-3.1.84v-2.02c.74-.09 1.44-.28 2.1-.56M4.07 13H2.05c.11 1.1.4 2.14.84 3.1l1.74-1c-.28-.66-.47-1.36-.56-2.1M15.1 4.63l1-1.74c-.96-.44-2-.73-3.1-.84v2.02c.74.09 1.44.28 2.1.56M19.93 11h2.02c-.11-1.1-.4-2.14-.84-3.1l-1.74 1c.28.66.47 1.36.56 2.1M8.9 19.37l-1 1.74c.96.44 2.01.73 3.1.84v-2.02c-.74-.09-1.44-.28-2.1-.56M11 4.07V2.05c-1.1.11-2.14.4-3.1.84l1 1.74c.66-.28 1.36-.47 2.1-.56m7.36 3.1 1.74-1.01c-.63-.87-1.4-1.64-2.27-2.27l-1.01 1.74c.59.45 1.1.96 1.54 1.54M4.63 8.9l-1.74-1c-.44.96-.73 2-.84 3.1h2.02c.09-.74.28-1.44.56-2.1m15.3 4.1c-.09.74-.28 1.44-.56 2.1l1.74 1c.44-.96.73-2.01.84-3.1zm-3.1 5.36 1.01 1.74c.87-.63 1.64-1.4 2.27-2.27l-1.74-1.01c-.45.59-.96 1.1-1.54 1.54M7.17 5.64l-1-1.75c-.88.64-1.64 1.4-2.27 2.28l1.74 1.01c.44-.59.95-1.1 1.53-1.54M5.64 16.83l-1.74 1c.63.87 1.4 1.64 2.27 2.27l1.01-1.74c-.59-.44-1.1-.95-1.54-1.53M12 7c-.55 0-1 .45-1 1v3.59c0 .53.21 1.04.59 1.41l3 3c.39.39 1.02.39 1.41 0s.39-1.02 0-1.41l-3-3V8c0-.55-.45-1-1-1"></path>
  </svg>`:`<svg aria-hidden="true" viewBox="0 0 24 24" width="22" height="22" style="display:block; fill:${t}; flex:0 0 auto;">
    <path d="M12 2C6.48 2 2 6.48 2 12h-2l3 3.01L6 12H4c0-4.42 3.58-8 8-8 2.21 0 4.21.9 5.66 2.34l1.41-1.41C17.26 3.12 14.76 2 12 2zm8.49 3.51-6.15 6.15-2.83-2.83L10.1 10.24l4.24 4.24 7.56-7.56-1.41-1.41zM20 12c0 4.42-3.58 8-8 8-2.21 0-4.21-.9-5.66-2.34l-1.41 1.41C6.74 20.88 9.24 22 12 22c5.52 0 10-4.48 10-10h2l-3-3.01L18 12h2z"></path>
  </svg>`}function wt(e){let t=N(I(q,J)),n=F(new Date,9);return B({title:`Your insurance application is being saved`,bodyHtml:`
      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 24px; font-size:16px; line-height:1.55;">
        Dear ${t},
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 20px; font-size:16px; line-height:1.55;">
        Your insurance application through <strong>${N(e.associationName)}</strong> has been automatically saved so you don’t lose your progress.
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 28px; font-size:16px; line-height:1.55;">
        You can return to complete your application within the next <strong>10 calendar days.</strong>
      </p>

      ${_t()}

      ${V(`Continue my application`,e.resumeUrl)}

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 10px; color:#374151; font-size:15px; line-height:1.5;">
        Or copy and paste this website address into your browser:
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 28px; font-size:15px; line-height:1.5; color:#006fff; word-break:break-all;">
        <a href="${N(e.resumeUrl)}" style="font-family:Arial, Helvetica, sans-serif; color:#006fff; text-decoration:none;">
          ${N(e.resumeDisplayUrl)}
        </a>
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0; font-size:16px; line-height:1.55;">
        We look forward to serving your insurance needs.
      </p>

      ${e.hideSupportContact?``:H(e.tpaName,e.tpaPhone,e.tpaEmail,e.tpaWebsite)}
      ${xt(`Your application will be saved for 10 days.`,`For your security, your saved application will be deleted on ${ot(n)} . After that, you’ll need to begin a new application.`)}
      ${U()}
    `})}function Tt(e){let t=N(I(q,J)),n=F(new Date,9),r=`advisor@${e.clientAcronym.toLowerCase()}.com`;return B({title:`Your insurance application is ready to complete and sign`,bodyHtml:`
      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 24px; font-size:16px; line-height:1.55;">
        Dear ${t},
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 20px; font-size:16px; line-height:1.55;">
        Your insurance application through <strong>${N(e.associationName)}</strong> has been prepared and is ready to complete and sign.
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 28px; font-size:16px; line-height:1.55;">
        Please complete the rest of your application within the next <strong>10 calendar days.</strong>
      </p>

      ${_t()}

      ${V(`Continue my application`,e.resumeUrl)}

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 10px; color:#374151; font-size:15px; line-height:1.5;">
        Or copy and paste this website address into your browser:
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 28px; font-size:15px; line-height:1.5; color:#006fff; word-break:break-all;">
        <a href="${N(e.resumeUrl)}" style="font-family:Arial, Helvetica, sans-serif; color:#006fff; text-decoration:none;">
          ${N(e.resumeDisplayUrl)}
        </a>
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0; font-size:16px; line-height:1.55;">
        We look forward to serving your insurance needs.
      </p>

      ${e.hideSupportContact?``:H(e.tpaName,e.tpaPhone,r,e.tpaWebsite)}
      ${xt(`Your application will be saved for 10 days.`,`For your security, your saved application will be deleted on ${ot(n)} . After that, you’ll need to begin a new application.`)}
      ${U()}
    `})}function Et(e,t,n){return B({title:`Thank you! We’ve received your insurance request`,bodyHtml:`
      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 24px; font-size:16px; line-height:1.55;">
        Dear ${N(I(q,J))},
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 20px; font-size:16px; line-height:1.55;">
        Your insurance application through <strong>${N(e.associationName)}</strong> has been received and we’ve begun processing your application.
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 24px; font-size:16px; line-height:1.55;">
        If you have any questions, please use the contact information below and refer to your confirmation number: <strong>${N(t)}</strong>
      </p>

      ${bt(n)}

      ${e.hideSupportContact?``:H(e.tpaName,e.tpaPhone,e.tpaEmail,e.tpaWebsite)}
      ${U()}
    `})}function Dt(e){let t=L(e);return B({title:`Your requested link to continue your application`,bodyHtml:`
      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 20px; font-size:16px; line-height:1.55;">
        A request has been made to return to an insurance application in progress through <strong>${N(t.associationName)}</strong>. Click the link below to continue to your application.
      </p>

      ${V(`Verify my email`,t.resumeMagicLinkUrl)}

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 20px; font-size:16px; line-height:1.55;">
        This link will expire in <strong>10 minutes.</strong>
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 8px; font-size:16px; line-height:1.55; font-weight:700;">
        Didn’t request a link?
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 20px; font-size:16px; line-height:1.55;">
        If you did not request a link, you may ignore this message. Access to application information will only be granted with verification.
      </p>

      ${U()}
    `})}function Ot(e){let t=L(e),n=F(new Date,9);return B({title:`Your insurance application is ready to be completed`,bodyHtml:`
      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 24px; font-size:16px; line-height:1.55;">
        Dear ${N(I(q,J))},
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 20px; font-size:16px; line-height:1.55;">
        We noticed you haven’t finished your <strong>${N(t.associationName)}</strong> insurance application. Good news—your progress has been saved.
      </p>

      ${_t()}

      ${V(`Continue my application`,t.resumeUrl)}

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 10px; color:#374151; font-size:15px; line-height:1.5;">
        Or copy and paste this website address into your browser:
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 28px; font-size:15px; line-height:1.5; color:#006fff; word-break:break-all;">
        <a href="${N(t.resumeUrl)}" style="font-family:Arial, Helvetica, sans-serif; color:#006fff; text-decoration:none;">
          ${N(t.resumeDisplayUrl)}
        </a>
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0; font-size:16px; line-height:1.55;">
        We look forward to serving your insurance needs.
      </p>

      ${t.hideSupportContact?``:H(t.tpaName,t.tpaPhone,t.tpaEmail,t.tpaWebsite)}
      ${xt(`Your application will be saved for 10 days.`,`For your security, your saved application will be deleted on ${ot(n)} . After that, you’ll need to begin a new application.`)}
      ${U()}
    `})}function kt(e){let t=L(e);return B({title:`Your insurance application progress`,bodyHtml:`
      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 24px; font-size:16px; line-height:1.55;">
        Dear ${N(I(q,J))},
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 20px; font-size:16px; line-height:1.55;">
        Your insurance application through <strong>${N(t.associationName)}</strong> has expired and has been securely deleted in accordance with our data retention policy. Application data is saved for you for 10 days to complete until it is deleted.
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 20px; font-size:16px; line-height:1.55;">
        If you’d still like to apply, you can start a new application.
      </p>

      ${V(`Start my application`,t.startUrl)}

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 10px; color:#374151; font-size:15px; line-height:1.5;">
        Or copy and paste this website address into your browser:
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 28px; font-size:15px; line-height:1.5; color:#006fff; word-break:break-all;">
        <a href="${N(t.startUrl)}" style="font-family:Arial, Helvetica, sans-serif; color:#006fff; text-decoration:none;">
          ${N(t.startUrl)}
        </a>
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0 0 20px; font-size:16px; line-height:1.55;">
        If you have questions about your insurance options, we’re happy to help and provide additional information.
      </p>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:0; font-size:16px; line-height:1.55;">
        We look forward to serving your insurance needs.
      </p>

      ${t.hideSupportContact?``:H(t.tpaName,t.tpaPhone,t.tpaEmail,t.tpaWebsite)}

      <div style="font-family:Arial, Helvetica, sans-serif; margin:20px 0; border-top:1px dashed #d1d5db;"></div>

      ${U()}
    `})}function W(e){let t=new Date,n=F(t,-3),r=F(n,9),i=F(t,-1),a=[[`Applicant name`,`${q} ${J}`],[`Applicant email`,Y],[`Sent for signature`,P(n)],...e.includeSubmissionDate?[[`Submitted`,P(t)]]:[[`Scheduled for deletion`,P(r)]],...e.includeEditRequested?[[`Edit requested`,P(i)]]:[]].map(([e,t])=>`<tr>
        <td style="font-family:Arial, Helvetica, sans-serif; padding:12px 14px; border-bottom:1px solid #e5e7eb; color:#4b5563; font-size:13px; font-weight:700; width:38%;">
          ${N(e)}
        </td>
        <td style="font-family:Arial, Helvetica, sans-serif; padding:12px 14px; border-bottom:1px solid #e5e7eb; color:#111827; font-size:13px;">
          ${N(t)}
        </td>
      </tr>`).join(``);return B({title:e.title,bodyHtml:`
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="font-family:Arial, Helvetica, sans-serif; border:1px solid #d1d5db; border-radius:14px; overflow:hidden;">
        <tr>
          <td colspan="2" style="font-family:Arial, Helvetica, sans-serif; padding:12px 14px; background-color:#f5f5f5; color:#111827; font-size:13px; font-weight:700; border-bottom:1px solid #d1d5db;">
            Association: ${N(e.payload.associationName)}
          </td>
        </tr>
        <tr>
          <td colspan="2" style="font-family:Arial, Helvetica, sans-serif; padding:12px 14px; background-color:#f5f5f5; color:#111827; font-size:14px; font-weight:700; border-bottom:1px solid #d1d5db;">
            <span style="font-family:Arial, Helvetica, sans-serif; display:inline-flex; align-items:center; gap:8px;">
              ${Ct(e.statusLabel)}
              <span>${N(e.statusLabel)}</span>
            </span>
          </td>
        </tr>
        ${a}
      </table>

      <p style="font-family:Arial, Helvetica, sans-serif; margin:20px 0 0; font-size:16px; line-height:1.55; color:#111827;">
        Access the ${N(e.payload.clientAcronym)} Advisor Portal to start a new application or take action on an application in progress:
        <a href="${N(e.payload.resumeUrl)}" style="font-family:Arial, Helvetica, sans-serif; color:#006fff; text-decoration:none;">
          ${N(e.payload.resumeDisplayUrl)}
        </a>
      </p>

      ${U()}
    `})}function At(e){let t=L(e),n=new Date().toISOString(),r={...t,toEmail:Y,firstName:q,lastName:J},i={coverageSelections:u().map(e=>e.id)};return[{id:`sample-autosave`,type:`autosave`,clientId:t.clientId,fromName:R(t),fromEmail:Z,toEmail:Y,subject:`Your insurance application is being saved`,createdAt:n,html:wt(r)},{id:`sample-pending-reminder`,type:`pending-reminder`,clientId:t.clientId,fromName:R(t),fromEmail:Z,toEmail:Y,subject:`Your insurance application is ready to be completed`,createdAt:n,html:Ot(e)},{id:`sample-purge-reminder`,type:`purge-reminder`,clientId:t.clientId,fromName:R(t),fromEmail:Z,toEmail:Y,subject:`Your insurance application progress`,createdAt:n,html:kt(e)},{id:`sample-receipt`,type:`receipt`,clientId:t.clientId,fromName:R(t),fromEmail:Z,toEmail:Y,subject:`Thank you! We’ve received your insurance request`,createdAt:n,html:Et(r,`CONF-2026-001234`,i)},{id:`sample-resume-magic-link`,type:`resume-magic-link`,clientId:t.clientId,fromName:R(t),fromEmail:Z,toEmail:Y,subject:`Your requested link to continue your application`,createdAt:n,html:Dt(e)},{id:`advisor-sent-for-signature`,type:`advisor-sent-for-signature`,clientId:t.clientId,fromName:z(t),fromEmail:Z,toEmail:X,subject:`Application sent for signature`,createdAt:n,html:W({title:`Application sent for signature`,message:`This application has been sent for signature:`,statusLabel:`Application sent for signature`,payload:t})},{id:`advisor-sent-to-applicant`,type:`advisor-sent-to-applicant`,clientId:t.clientId,fromName:R(t),fromEmail:Z,toEmail:Y,subject:`Your insurance application is ready to complete and sign`,createdAt:n,html:Tt(r)},{id:`advisor-pending-reminder`,type:`advisor-pending-reminder`,clientId:t.clientId,fromName:z(t),fromEmail:Z,toEmail:X,subject:`Application still pending signature`,createdAt:n,html:W({title:`Application still pending signature`,message:`This application has an update:`,statusLabel:`Application still pending signature`,payload:t})},{id:`advisor-edit-request`,type:`advisor-edit-request`,clientId:t.clientId,fromName:z(t),fromEmail:Z,toEmail:X,subject:`Application edit request`,createdAt:n,html:W({title:`Application edit request`,message:`This application has an update:`,statusLabel:`Application edit requested`,includeEditRequested:!0,payload:t})},{id:`advisor-application-complete`,type:`advisor-application-complete`,clientId:t.clientId,fromName:z(t),fromEmail:Z,toEmail:X,subject:`Application submitted`,createdAt:n,html:W({title:`Application submitted`,message:`This application has an update:`,statusLabel:`Application submitted`,includeSubmissionDate:!0,payload:t})}]}function jt(e){let t=L(e).clientId,n=ft().filter(e=>e.clientId===t),r=At(e);return[...n,...r.filter(e=>!n.some(t=>t.id===e.id))]}function Mt(e){function t(t){t.key===G&&e()}return window.addEventListener(K,e),window.addEventListener(`storage`,t),()=>{window.removeEventListener(K,e),window.removeEventListener(`storage`,t)}}async function Nt(e){if(!dt(e))return;let t=ut(e);mt({id:ht(`autosave`),type:`autosave`,clientId:t.clientId,fromName:R(t),fromEmail:Z,toEmail:t.toEmail,subject:`Your insurance application is being saved`,createdAt:new Date().toISOString(),html:wt(t)})}async function Pt(e,t){if(!dt(e))return;let n=ut(e);mt({id:ht(`receipt`),type:`receipt`,clientId:n.clientId,fromName:R(n),fromEmail:Z,toEmail:n.toEmail,subject:`Thank you! We’ve received your insurance request`,createdAt:new Date().toISOString(),html:Et(n,t,e)})}async function Ft(e){let t=e.trim();if(!t)return;let n=L();mt({id:ht(`resume-magic-link`),type:`resume-magic-link`,clientId:n.clientId,fromName:R(n),fromEmail:Z,toEmail:t,subject:`Your requested link to continue your application`,createdAt:new Date().toISOString(),html:Dt()})}var G,K,q,J,Y,X,Z,It=t((()=>{ce(),l(),le(),ie(),at(),G=`mockEmail:previews`,K=`mockEmail:previewsChanged`,q=`Caroline`,J=`Correa`,Y=`returning.user@example.com`,X=`advisor@example.com`,Z=`gmad_tpa_portal@ntlab.newyorklife.com`}));function Lt(e){return e.inputType===`checkbox`?!1:e.inputType===`checkbox-group`||e.inputType===`multi-select`?[]:``}function Rt(e){if(typeof e==`string`||typeof e==`boolean`||Array.isArray(e)&&e.every(e=>typeof e==`string`))return e}function zt(e,t,n){return[...c(e,t),...n?.(t)??[]].filter((e,t,n)=>n.findIndex(t=>t.id===e.id)===t)}function Bt(e,t){let n=me(),r=n.indexOf(`coverage`);return n.indexOf(e.pageId)>=r&&r!==-1&&e.applicant&&!S(e.applicant,t)?!1:ue(e.visibleWhen,t)}function Vt(e){return e.id===`dependents`?[]:e.id.includes(`-onset`)?`01/2020`:e.id.startsWith(`payment-method:`)?`bill-me`:e.id.startsWith(`payment-frequency:`)?`monthly`:e.id===`payment-routing-number`?`021000021`:e.id===`payment-account-number`?`123456789`:e.id===`payment-account-type`?`checking`:e.id===`bank-authorization`?!0:e.format===`currency`?`$5,000`:e.format===`percent`?`50`:e.inputType===`checkbox`?!0:e.inputType===`checkbox-group`||e.inputType===`multi-select`?e.options?.[0]?.value?[e.options[0].value]:[]:e.inputType===`radio`||e.inputType===`dropdown`||e.inputType===`searchable-select`?e.options?.[0]?.value??``:e.inputType===`date`?`1990-01-01`:e.inputType===`number`?`100`:e.format===`ssn`?`123-45-6789`:e.format===`email`||e.id.toLowerCase().includes(`email`)?`test@example.com`:e.format===`phone`||e.id.toLowerCase().includes(`phone`)?`(555) 123-4567`:e.id.toLowerCase().includes(`zip`)?`10001`:e.id.toLowerCase().includes(`state`)?`NY`:`Test`}function Ht(e){window.dispatchEvent(new CustomEvent(`form:progresssnapshot`,{detail:e}))}function Ut(e){window.dispatchEvent(new CustomEvent(`form:pendingbreadcrumbcompletion`,{detail:e}))}function Wt({pageId:e,title:t,subhead:n,formMaxWidth:r,noTitle:ee,hideActions:re,hideNextButton:ie,disableNextButton:o,help:oe,children:se,validate:ce,defaultValueOverrides:le,devFillFields:s,onDevFill:ue,onBeforeNext:de,resolveNextPageId:fe,initialTransitionMessage:c}){let l=ne(),u=te(),{values:d,setPageValues:f}=ge(),[ve,p]=(0,Q.useState)(!1);(0,Q.useEffect)(()=>{u.state?.showProgressSaved&&(p(!0),l(u.pathname,{replace:!0,state:{}}))},[u,l]);let ye=zt(e,d,s),Se=(0,Q.useRef)(le);Se.current=le;let{control:Te,handleSubmit:Ee,watch:m,getValues:h,setValue:g,trigger:Ne,reset:Pe,formState:{errors:Ie}}=ae({defaultValues:ye.reduce((e,t)=>(e[t.id]=le?.[t.id]??Rt(d[t.id])??Lt(t),e),{})}),_={...d,...m()},Le=(0,Q.useRef)(m);Le.current=m;let v=(0,Q.useRef)(f);v.current=f;let y=(0,Q.useRef)(!1);(0,Q.useEffect)(()=>()=>{y.current||v.current(Le.current())},[]);let Ve=zt(e,_,s),He=we(e);(0,Q.useEffect)(()=>{Pe(zt(e,d,s).reduce((e,t)=>(e[t.id]=Se.current?.[t.id]??Rt(d[t.id])??Lt(t),e),{}))},[s,e,Pe,d]),(0,Q.useEffect)(()=>{function t(){let t=pe(e),n={...t,...h()},r=zt(e,n,s),i=r.reduce((e,t)=>(e[t.id]=Vt(t),e),{});v.current({...t,...i}),r.forEach(e=>{g(e.id,i[e.id],{shouldDirty:!0,shouldTouch:!0,shouldValidate:!1})}),ue?.({currentValues:{...n,...i},currentFields:r,setValue:g,setPageValues:v.current})}return window.addEventListener(`devtools:fillform`,t),()=>window.removeEventListener(`devtools:fillform`,t)},[s,h,ue,e,g]);let[b,x]=(0,Q.useState)(),[S,Ue]=(0,Q.useState)(!!c),[We,w]=(0,Q.useState)(c??``),T=(0,Q.useRef)(null);(0,Q.useEffect)(()=>{c&&(T.current=setTimeout(()=>{Ue(!1),w(``)},C))},[c]),(0,Q.useEffect)(()=>()=>{T.current&&clearTimeout(T.current)},[]);let qe=(0,Q.useCallback)(()=>{requestAnimationFrame(()=>{let e=document.querySelector(`[aria-invalid="true"], .Mui-error input, .Mui-error textarea, .Mui-error .MuiSelect-select`);e?e.scrollIntoView({behavior:`smooth`,block:`center`}):window.scrollTo({top:0,behavior:`smooth`})})},[]),Je=(0,Q.useCallback)(t=>{let n=fe?.(t),r=(n===void 0?_e(e,t):n)??(e===`payment`?`receipt`:null);if(!r)return;let[i,a]=Ge(e);Ut(e),w(i),Ue(!0),window.scrollTo({top:0}),T.current=setTimeout(()=>{w(a),T.current=setTimeout(()=>{Ht(t),l(`/${r}`,{state:{showProgressSaved:!0}})},C)},C)},[l,e,fe]);function Ye(t){let n={...d,...t},r=ce?.(n);if(r){x(r),window.scrollTo({top:0,behavior:`smooth`});return}x(void 0),f(t),y.current=!0,e===`membership`&&Nt(n).catch(e=>{console.warn(`Autosave mock email failed`,e)}),e===`review`&&(window.sessionStorage.setItem(`reviewSubmitted`,`true`),window.dispatchEvent(new Event(`reviewsubmitted`))),de?.({values:n,continueNavigation:()=>Je(n)})!==!1&&Je(n)}function Xe(e){x(`Please correct the errors below before continuing.`),Object.keys(e).length>0?qe():window.scrollTo({top:0,behavior:`smooth`})}function Ze(){let t=he(e,_);if(t){let e={...d,...h()};f(e),y.current=!0,Ut(null),w(Ke),Ue(!0),window.scrollTo({top:0}),T.current=setTimeout(()=>{Ht(e),l(`/${t}`)},C)}}let E={control:Te,errors:Ie,watchedValues:_,allFields:Ve,pageSections:He,setValue:g,trigger:Ne},Qe=typeof oe==`function`?oe(E):oe,D=je(e,d)>=0,$e=t??xe(e),et=n??be(e),tt=Ce(e),nt=window.sessionStorage.getItem(`reviewSubmitted`)===`true`,O=me(),k=O.indexOf(`review`),A=O.indexOf(e),j=(0,$.jsx)(De,{title:$e,maxWidth:D?`100%`:r,noTitle:!0,actions:void 0,children:(0,$.jsx)(i,{children:(0,$.jsxs)(ke,{sx:{px:{xs:2,sm:`48px`},py:{xs:2,sm:`32px`},mb:+!!D},children:[D&&(0,$.jsx)(i,{sx:{mb:1.5},children:(0,$.jsx)(Me,{pageId:e})}),S?(0,$.jsx)(Re,{message:We}):(0,$.jsxs)($.Fragment,{children:[!ee&&(0,$.jsx)(Oe,{title:$e,subhead:et,onBack:!(nt&&k!==-1&&A>k)&&he(e,_)?Ze:void 0,help:Qe}),tt&&(0,$.jsx)(i,{sx:{mb:2},children:(0,$.jsx)(a,{severity:`info`,sx:{width:`100%`},children:tt})}),(0,$.jsx)(Be,{severity:`error`,message:b}),(0,$.jsx)(`form`,{id:`${e}-form`,noValidate:!0,onSubmit:Ee(Ye,Xe),children:typeof se==`function`?se(E):se})]}),!re&&!(typeof ie==`function`?ie(_):ie)&&(0,$.jsx)(Ae,{formId:`${e}-form`,isTransitioning:S,disabled:typeof o==`function`?o(_):!!o})]})})});return(0,$.jsxs)($.Fragment,{children:[(0,$.jsx)(ze,{open:ve,onClose:()=>p(!1)}),D?(0,$.jsx)(Fe,{pageId:e,children:j}):j]})}var Q,$,Gt=t((()=>{Q=e(n(),1),ee(),oe(),re(),de(),ve(),Se(),Te(),fe(),f(),We(),Ee(),m(),h(),g(),Pe(),Ne(),d(),w(),It(),Le(),v(),y(),$=r(),Wt.__docgenInfo={description:``,methods:[],displayName:`FormRoutePage`,props:{pageId:{required:!0,tsType:{name:`unknown[number]["id"]`,raw:`Page["id"]`},description:``},title:{required:!1,tsType:{name:`ReactNode`},description:``},subhead:{required:!1,tsType:{name:`ReactNode`},description:``},formMaxWidth:{required:!1,tsType:{name:`union`,raw:`number | string`,elements:[{name:`number`},{name:`string`}]},description:``},noTitle:{required:!1,tsType:{name:`boolean`},description:``},hideActions:{required:!1,tsType:{name:`boolean`},description:``},hideNextButton:{required:!1,tsType:{name:`union`,raw:`boolean | ((values: FormRoutePageValues) => boolean)`,elements:[{name:`boolean`},{name:`unknown`}]},description:``},disableNextButton:{required:!1,tsType:{name:`union`,raw:`boolean | ((values: FormRoutePageValues) => boolean)`,elements:[{name:`boolean`},{name:`unknown`}]},description:``},help:{required:!1,tsType:{name:`union`,raw:`ReactNode | ((props: FormRouteRenderProps) => ReactNode)`,elements:[{name:`ReactNode`},{name:`unknown`}]},description:``},children:{required:!0,tsType:{name:`union`,raw:`ReactNode | ((props: FormRouteRenderProps) => ReactNode)`,elements:[{name:`ReactNode`},{name:`unknown`}]},description:``},validate:{required:!1,tsType:{name:`signature`,type:`function`,raw:`(values: FormRoutePageValues) => string | undefined`,signature:{arguments:[{type:{name:`Record`,elements:[{name:`string`},{name:`union`,raw:`| string
| boolean
| string[]
| number
| Record<string, number>
| Record<string, boolean>
| Record<string, string>
| Record<string, unknown[]>`,elements:[{name:`string`},{name:`boolean`},{name:`Array`,elements:[{name:`string`}],raw:`string[]`},{name:`number`},{name:`Record`,elements:[{name:`string`},{name:`number`}],raw:`Record<string, number>`},{name:`Record`,elements:[{name:`string`},{name:`boolean`}],raw:`Record<string, boolean>`},{name:`Record`,elements:[{name:`string`},{name:`string`}],raw:`Record<string, string>`},{name:`Record`,elements:[{name:`string`},{name:`Array`,elements:[{name:`unknown`}],raw:`unknown[]`}],raw:`Record<string, unknown[]>`}]}],raw:`Record<
  string,
  | string
  | boolean
  | string[]
  | number
  | Record<string, number>
  | Record<string, boolean>
  | Record<string, string>
  | Record<string, unknown[]>
>`},name:`values`}],return:{name:`union`,raw:`string | undefined`,elements:[{name:`string`},{name:`undefined`}]}}},description:``},defaultValueOverrides:{required:!1,tsType:{name:`Record`,elements:[{name:`string`},{name:`union`,raw:`string | boolean | string[]`,elements:[{name:`string`},{name:`boolean`},{name:`Array`,elements:[{name:`string`}],raw:`string[]`}]}],raw:`Record<string, FormRouteFieldValue>`},description:``},devFillFields:{required:!1,tsType:{name:`signature`,type:`function`,raw:`(currentValues: FormRoutePageValues) => FieldDefinition[]`,signature:{arguments:[{type:{name:`Record`,elements:[{name:`string`},{name:`union`,raw:`| string
| boolean
| string[]
| number
| Record<string, number>
| Record<string, boolean>
| Record<string, string>
| Record<string, unknown[]>`,elements:[{name:`string`},{name:`boolean`},{name:`Array`,elements:[{name:`string`}],raw:`string[]`},{name:`number`},{name:`Record`,elements:[{name:`string`},{name:`number`}],raw:`Record<string, number>`},{name:`Record`,elements:[{name:`string`},{name:`boolean`}],raw:`Record<string, boolean>`},{name:`Record`,elements:[{name:`string`},{name:`string`}],raw:`Record<string, string>`},{name:`Record`,elements:[{name:`string`},{name:`Array`,elements:[{name:`unknown`}],raw:`unknown[]`}],raw:`Record<string, unknown[]>`}]}],raw:`Record<
  string,
  | string
  | boolean
  | string[]
  | number
  | Record<string, number>
  | Record<string, boolean>
  | Record<string, string>
  | Record<string, unknown[]>
>`},name:`currentValues`}],return:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  id: string;
  label: string;
  tooltip?: string;
  inputType: FieldInputType;
  required?: boolean;
  placeholder?: string;
  helperText?: string;
  options?: FieldOption[];
  autoComplete?: string;
  inputMode?: "text" | "email" | "tel" | "numeric";
  format?: "email" | "phone" | "ssn" | "currency" | "percent" | "month-year";
  labelVariant?: "floating" | "standard";
  multiline?: boolean;
  minRows?: number;
  disabled?: boolean;
  /** Override the companion phone-type field name (default: "phone-type") */
  phoneTypeFieldId?: string;
  /** Whether to show the companion phone type selector (default: true) */
  showPhoneTypeSelector?: boolean;
}`,signature:{properties:[{key:`id`,value:{name:`string`,required:!0}},{key:`label`,value:{name:`string`,required:!0}},{key:`tooltip`,value:{name:`string`,required:!1}},{key:`inputType`,value:{name:`union`,raw:`| "text"
| "number"
| "date"
| "radio"
| "dropdown"
| "searchable-select"
| "checkbox"
| "checkbox-group"
| "multi-select"
| "percent"`,elements:[{name:`literal`,value:`"text"`},{name:`literal`,value:`"number"`},{name:`literal`,value:`"date"`},{name:`literal`,value:`"radio"`},{name:`literal`,value:`"dropdown"`},{name:`literal`,value:`"searchable-select"`},{name:`literal`,value:`"checkbox"`},{name:`literal`,value:`"checkbox-group"`},{name:`literal`,value:`"multi-select"`},{name:`literal`,value:`"percent"`}],required:!0}},{key:`required`,value:{name:`boolean`,required:!1}},{key:`placeholder`,value:{name:`string`,required:!1}},{key:`helperText`,value:{name:`string`,required:!1}},{key:`options`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  value: string;
  label: string;
}`,signature:{properties:[{key:`value`,value:{name:`string`,required:!0}},{key:`label`,value:{name:`string`,required:!0}}]}}],raw:`FieldOption[]`,required:!1}},{key:`autoComplete`,value:{name:`string`,required:!1}},{key:`inputMode`,value:{name:`union`,raw:`"text" | "email" | "tel" | "numeric"`,elements:[{name:`literal`,value:`"text"`},{name:`literal`,value:`"email"`},{name:`literal`,value:`"tel"`},{name:`literal`,value:`"numeric"`}],required:!1}},{key:`format`,value:{name:`union`,raw:`"email" | "phone" | "ssn" | "currency" | "percent" | "month-year"`,elements:[{name:`literal`,value:`"email"`},{name:`literal`,value:`"phone"`},{name:`literal`,value:`"ssn"`},{name:`literal`,value:`"currency"`},{name:`literal`,value:`"percent"`},{name:`literal`,value:`"month-year"`}],required:!1}},{key:`labelVariant`,value:{name:`union`,raw:`"floating" | "standard"`,elements:[{name:`literal`,value:`"floating"`},{name:`literal`,value:`"standard"`}],required:!1}},{key:`multiline`,value:{name:`boolean`,required:!1}},{key:`minRows`,value:{name:`number`,required:!1}},{key:`disabled`,value:{name:`boolean`,required:!1}},{key:`phoneTypeFieldId`,value:{name:`string`,required:!1},description:`Override the companion phone-type field name (default: "phone-type")`},{key:`showPhoneTypeSelector`,value:{name:`boolean`,required:!1},description:`Whether to show the companion phone type selector (default: true)`}]}}],raw:`FieldDefinition[]`}}},description:``},onDevFill:{required:!1,tsType:{name:`signature`,type:`function`,raw:`(context: DevFillContext) => void`,signature:{arguments:[{type:{name:`signature`,type:`object`,raw:`{
  currentValues: FormRoutePageValues;
  currentFields: FieldDefinition[];
  setValue: ReturnType<typeof useForm<FormRoutePageFormValues>>["setValue"];
  setPageValues: ReturnType<typeof useApplicationForm>["setPageValues"];
}`,signature:{properties:[{key:`currentValues`,value:{name:`Record`,elements:[{name:`string`},{name:`union`,raw:`| string
| boolean
| string[]
| number
| Record<string, number>
| Record<string, boolean>
| Record<string, string>
| Record<string, unknown[]>`,elements:[{name:`string`},{name:`boolean`},{name:`Array`,elements:[{name:`string`}],raw:`string[]`},{name:`number`},{name:`Record`,elements:[{name:`string`},{name:`number`}],raw:`Record<string, number>`},{name:`Record`,elements:[{name:`string`},{name:`boolean`}],raw:`Record<string, boolean>`},{name:`Record`,elements:[{name:`string`},{name:`string`}],raw:`Record<string, string>`},{name:`Record`,elements:[{name:`string`},{name:`Array`,elements:[{name:`unknown`}],raw:`unknown[]`}],raw:`Record<string, unknown[]>`}]}],raw:`Record<
  string,
  | string
  | boolean
  | string[]
  | number
  | Record<string, number>
  | Record<string, boolean>
  | Record<string, string>
  | Record<string, unknown[]>
>`,required:!0}},{key:`currentFields`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  id: string;
  label: string;
  tooltip?: string;
  inputType: FieldInputType;
  required?: boolean;
  placeholder?: string;
  helperText?: string;
  options?: FieldOption[];
  autoComplete?: string;
  inputMode?: "text" | "email" | "tel" | "numeric";
  format?: "email" | "phone" | "ssn" | "currency" | "percent" | "month-year";
  labelVariant?: "floating" | "standard";
  multiline?: boolean;
  minRows?: number;
  disabled?: boolean;
  /** Override the companion phone-type field name (default: "phone-type") */
  phoneTypeFieldId?: string;
  /** Whether to show the companion phone type selector (default: true) */
  showPhoneTypeSelector?: boolean;
}`,signature:{properties:[{key:`id`,value:{name:`string`,required:!0}},{key:`label`,value:{name:`string`,required:!0}},{key:`tooltip`,value:{name:`string`,required:!1}},{key:`inputType`,value:{name:`union`,raw:`| "text"
| "number"
| "date"
| "radio"
| "dropdown"
| "searchable-select"
| "checkbox"
| "checkbox-group"
| "multi-select"
| "percent"`,elements:[{name:`literal`,value:`"text"`},{name:`literal`,value:`"number"`},{name:`literal`,value:`"date"`},{name:`literal`,value:`"radio"`},{name:`literal`,value:`"dropdown"`},{name:`literal`,value:`"searchable-select"`},{name:`literal`,value:`"checkbox"`},{name:`literal`,value:`"checkbox-group"`},{name:`literal`,value:`"multi-select"`},{name:`literal`,value:`"percent"`}],required:!0}},{key:`required`,value:{name:`boolean`,required:!1}},{key:`placeholder`,value:{name:`string`,required:!1}},{key:`helperText`,value:{name:`string`,required:!1}},{key:`options`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  value: string;
  label: string;
}`,signature:{properties:[{key:`value`,value:{name:`string`,required:!0}},{key:`label`,value:{name:`string`,required:!0}}]}}],raw:`FieldOption[]`,required:!1}},{key:`autoComplete`,value:{name:`string`,required:!1}},{key:`inputMode`,value:{name:`union`,raw:`"text" | "email" | "tel" | "numeric"`,elements:[{name:`literal`,value:`"text"`},{name:`literal`,value:`"email"`},{name:`literal`,value:`"tel"`},{name:`literal`,value:`"numeric"`}],required:!1}},{key:`format`,value:{name:`union`,raw:`"email" | "phone" | "ssn" | "currency" | "percent" | "month-year"`,elements:[{name:`literal`,value:`"email"`},{name:`literal`,value:`"phone"`},{name:`literal`,value:`"ssn"`},{name:`literal`,value:`"currency"`},{name:`literal`,value:`"percent"`},{name:`literal`,value:`"month-year"`}],required:!1}},{key:`labelVariant`,value:{name:`union`,raw:`"floating" | "standard"`,elements:[{name:`literal`,value:`"floating"`},{name:`literal`,value:`"standard"`}],required:!1}},{key:`multiline`,value:{name:`boolean`,required:!1}},{key:`minRows`,value:{name:`number`,required:!1}},{key:`disabled`,value:{name:`boolean`,required:!1}},{key:`phoneTypeFieldId`,value:{name:`string`,required:!1},description:`Override the companion phone-type field name (default: "phone-type")`},{key:`showPhoneTypeSelector`,value:{name:`boolean`,required:!1},description:`Whether to show the companion phone type selector (default: true)`}]}}],raw:`FieldDefinition[]`,required:!0}},{key:`setValue`,value:{name:`ReturnType["setValue"]`,raw:`ReturnType<typeof useForm<FormRoutePageFormValues>>["setValue"]`,required:!0}},{key:`setPageValues`,value:{name:`ReturnType["setPageValues"]`,raw:`ReturnType<typeof useApplicationForm>["setPageValues"]`,required:!0}}]}},name:`context`}],return:{name:`void`}}},description:``},onBeforeNext:{required:!1,tsType:{name:`signature`,type:`function`,raw:`(context: BeforeNextContext) => boolean`,signature:{arguments:[{type:{name:`signature`,type:`object`,raw:`{
  values: FormRoutePageValues;
  continueNavigation: () => void;
}`,signature:{properties:[{key:`values`,value:{name:`Record`,elements:[{name:`string`},{name:`union`,raw:`| string
| boolean
| string[]
| number
| Record<string, number>
| Record<string, boolean>
| Record<string, string>
| Record<string, unknown[]>`,elements:[{name:`string`},{name:`boolean`},{name:`Array`,elements:[{name:`string`}],raw:`string[]`},{name:`number`},{name:`Record`,elements:[{name:`string`},{name:`number`}],raw:`Record<string, number>`},{name:`Record`,elements:[{name:`string`},{name:`boolean`}],raw:`Record<string, boolean>`},{name:`Record`,elements:[{name:`string`},{name:`string`}],raw:`Record<string, string>`},{name:`Record`,elements:[{name:`string`},{name:`Array`,elements:[{name:`unknown`}],raw:`unknown[]`}],raw:`Record<string, unknown[]>`}]}],raw:`Record<
  string,
  | string
  | boolean
  | string[]
  | number
  | Record<string, number>
  | Record<string, boolean>
  | Record<string, string>
  | Record<string, unknown[]>
>`,required:!0}},{key:`continueNavigation`,value:{name:`signature`,type:`function`,raw:`() => void`,signature:{arguments:[],return:{name:`void`}},required:!0}}]}},name:`context`}],return:{name:`boolean`}}},description:``},resolveNextPageId:{required:!1,tsType:{name:`signature`,type:`function`,raw:`(values: FormRoutePageValues) => PageId | null`,signature:{arguments:[{type:{name:`Record`,elements:[{name:`string`},{name:`union`,raw:`| string
| boolean
| string[]
| number
| Record<string, number>
| Record<string, boolean>
| Record<string, string>
| Record<string, unknown[]>`,elements:[{name:`string`},{name:`boolean`},{name:`Array`,elements:[{name:`string`}],raw:`string[]`},{name:`number`},{name:`Record`,elements:[{name:`string`},{name:`number`}],raw:`Record<string, number>`},{name:`Record`,elements:[{name:`string`},{name:`boolean`}],raw:`Record<string, boolean>`},{name:`Record`,elements:[{name:`string`},{name:`string`}],raw:`Record<string, string>`},{name:`Record`,elements:[{name:`string`},{name:`Array`,elements:[{name:`unknown`}],raw:`unknown[]`}],raw:`Record<string, unknown[]>`}]}],raw:`Record<
  string,
  | string
  | boolean
  | string[]
  | number
  | Record<string, number>
  | Record<string, boolean>
  | Record<string, string>
  | Record<string, unknown[]>
>`},name:`values`}],return:{name:`union`,raw:`PageId | null`,elements:[{name:`unknown[number]["id"]`,raw:`Page["id"]`},{name:`null`}]}}},description:``},initialTransitionMessage:{required:!1,tsType:{name:`string`},description:``}}}}));export{T as _,jt as a,Ue as b,Mt as c,qe as d,et as f,at as g,Ze as h,It as i,A as l,nt as m,Gt as n,Pt as o,E as p,Bt as r,Ft as s,Wt as t,it as u,We as v,S as y};