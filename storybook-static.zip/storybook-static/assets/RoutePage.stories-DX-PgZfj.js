import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,S as n,dt as r,t as i}from"./esm-AWQ-KJXU.js";import{r as a,t as o}from"./ApplicationFormContext-BU7mcIce.js";import{n as s,t as c}from"./RoutePage-DAogtRwv.js";import{n as l,t as u}from"./FieldRenderer-DRJtoa2k.js";function d(e,t){return(0,p.jsx)(o.Provider,{value:{values:e,setPageValues:()=>{},resetValues:()=>{}},children:t})}function f({control:e,errors:t,allFields:r}){return(0,p.jsx)(n,{spacing:2.5,children:r.slice(0,3).map(n=>(0,p.jsx)(u,{field:n,control:e,errors:t},n.id))})}var p,m,h,g,_,v;e((()=>{i(),s(),a(),l(),p=t(),m={title:`Application Patterns/Application Page Template`,component:c,parameters:{layout:`fullscreen`,docs:{description:{component:`FormRoutePage is the application's de-facto page template. Seventeen
routed pages use it to compose PageShell, FormShell, PageHeader, PageNav,
ProgressStep, react-hook-form state, validation feedback, transitions,
autosave persistence, and back/next routing. The individual pieces have
component stories; this page documents the real composition that binds
them together.`}}}},h={name:`Standard form page`,render:()=>d({},(0,p.jsx)(c,{pageId:`membership`,children:e=>(0,p.jsx)(f,{...e})})),parameters:{docs:{description:{story:`The real first application step with live client field configuration. It demonstrates the complete template: responsive progress navigation and breadcrumbs, page heading, react-hook-form fields, validation summary, and the shared Continue action. Submit it empty to see field-level and page-level validation together.`}}}},g={name:`Initial transition state`,render:()=>d({},(0,p.jsx)(c,{pageId:`membership`,initialTransitionMessage:`Loading your membership application...`,children:e=>(0,p.jsx)(f,{...e})})),parameters:{docs:{description:{story:`FormRoutePage temporarily replaces the heading and form with PageTransitionSkeleton, then restores the standard template. The transition is intentionally live rather than a static imitation.`}}}},_={name:`Standalone variant — no progress or actions`,render:()=>d({},(0,p.jsx)(c,{pageId:`advisor-login`,title:`Standalone form`,subhead:`The same template can omit flow navigation and provide a custom submit action.`,formMaxWidth:500,hideActions:!0,children:(0,p.jsx)(r,{variant:`body2`,color:`text.secondary`,children:`Advisor and confirmation routes use these template options when the main application stepper and shared Continue action do not apply.`})}))},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  name: "Standard form page",
  render: () => withValues({}, <FormRoutePage pageId="membership">
        {props => <DemoFields {...props} />}
      </FormRoutePage>),
  parameters: {
    docs: {
      description: {
        story: "The real first application step with live client field configuration. It demonstrates the complete template: responsive progress navigation and breadcrumbs, page heading, react-hook-form fields, validation summary, and the shared Continue action. Submit it empty to see field-level and page-level validation together."
      }
    }
  }
}`,...h.parameters?.docs?.source}}},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  name: "Initial transition state",
  render: () => withValues({}, <FormRoutePage pageId="membership" initialTransitionMessage="Loading your membership application...">
        {props => <DemoFields {...props} />}
      </FormRoutePage>),
  parameters: {
    docs: {
      description: {
        story: "FormRoutePage temporarily replaces the heading and form with PageTransitionSkeleton, then restores the standard template. The transition is intentionally live rather than a static imitation."
      }
    }
  }
}`,...g.parameters?.docs?.source}}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  name: "Standalone variant — no progress or actions",
  render: () => withValues({}, <FormRoutePage pageId="advisor-login" title="Standalone form" subhead="The same template can omit flow navigation and provide a custom submit action." formMaxWidth={500} hideActions>
        <Typography variant="body2" color="text.secondary">
          Advisor and confirmation routes use these template options when the
          main application stepper and shared Continue action do not apply.
        </Typography>
      </FormRoutePage>)
}`,..._.parameters?.docs?.source}}},v=[`StandardFormPage`,`InitialTransition`,`StandaloneVariant`]}))();export{g as InitialTransition,_ as StandaloneVariant,h as StandardFormPage,v as __namedExportsOrder,m as default};