import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,S as n,dt as r,ft as i,t as a}from"./esm-AWQ-KJXU.js";import{n as o,t as s}from"./BusinessOutlined-BMP968Mc.js";import{n as c,t as l}from"./SectionDivider-BZXqr3do.js";var u,d,f,p,m,h,g,_,v,y,b;e((()=>{a(),o(),c(),u=t(),d={title:`Layout/SectionDivider`,component:l,parameters:{layout:`padded`,docs:{description:{component:'SectionDivider is a full-width Divider with a centered label chip. Every\nreal call site in the app uses the `variant="subsection"` preset — no\npage passes `chipVariant` directly.\n\nA real bug was fixed here as part of Phase 2B: `chipVariant` used to\nrender inverted from its name (passing "filled" rendered an MUI\n`variant="outlined"` chip and vice versa), and the `variant="subsection"`\npreset itself set the wrong internal value to compensate. Both are now\ncorrect — `chipVariant="filled"` renders filled, `"outlined"` renders\noutlined — with zero visual change for any of the ~12 existing call\nsites, since they all go through the `subsection` preset either way.'}}}},f={name:`variant="subsection" (used by every real call site)`,render:()=>(0,u.jsx)(l,{label:`Business Information`,variant:`subsection`})},p={render:()=>(0,u.jsx)(l,{label:`Business Information`,icon:s,variant:`subsection`})},m={name:`chipVariant="filled" (explicit — not used by real call sites today)`,render:()=>(0,u.jsx)(l,{label:`Filled`,chipVariant:`filled`})},h={name:`chipVariant="outlined" (the raw default)`,render:()=>(0,u.jsx)(l,{label:`Outlined`,chipVariant:`outlined`})},g={name:`chipVariant="text" (no chip, plain uppercase label)`,render:()=>(0,u.jsx)(l,{label:`Plain text label`,chipVariant:`text`})},_={name:`chipColor="default" (used by the subsection preset)`,render:()=>(0,u.jsx)(l,{label:`Neutral gray`,chipVariant:`filled`,chipColor:`default`})},v={render:()=>(0,u.jsxs)(n,{spacing:3,children:[(0,u.jsx)(l,{label:`size="default" (applicant + category headers)`,size:`default`}),(0,u.jsx)(l,{label:`size="small" (sub-sections + standalone)`,size:`small`})]})},y={name:`What was fixed`,render:()=>(0,u.jsx)(u.Fragment,{children:(0,u.jsx)(i,{severity:`success`,sx:{maxWidth:700},children:(0,u.jsxs)(r,{variant:`body2`,children:[`Before this fix, `,(0,u.jsx)(`code`,{children:`chipVariant="filled"`}),` rendered an MUI`,` `,(0,u.jsx)(`em`,{children:`outlined`}),` chip. Now it renders an actual filled chip — see`,` `,(0,u.jsx)(`strong`,{children:`Chip filled`}),` above for the corrected appearance.`]})})})},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  name: 'variant="subsection" (used by every real call site)',
  render: () => <SectionDivider label="Business Information" variant="subsection" />
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: () => <SectionDivider label="Business Information" icon={BusinessOutlinedIcon} variant="subsection" />
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  name: 'chipVariant="filled" (explicit — not used by real call sites today)',
  render: () => <SectionDivider label="Filled" chipVariant="filled" />
}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  name: 'chipVariant="outlined" (the raw default)',
  render: () => <SectionDivider label="Outlined" chipVariant="outlined" />
}`,...h.parameters?.docs?.source}}},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  name: 'chipVariant="text" (no chip, plain uppercase label)',
  render: () => <SectionDivider label="Plain text label" chipVariant="text" />
}`,...g.parameters?.docs?.source}}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  name: 'chipColor="default" (used by the subsection preset)',
  render: () => <SectionDivider label="Neutral gray" chipVariant="filled" chipColor="default" />
}`,..._.parameters?.docs?.source}}},v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{
  render: () => <Stack spacing={3}>
      <SectionDivider label="size=&quot;default&quot; (applicant + category headers)" size="default" />
      <SectionDivider label="size=&quot;small&quot; (sub-sections + standalone)" size="small" />
    </Stack>
}`,...v.parameters?.docs?.source}}},y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  name: "What was fixed",
  render: () => <>
      <Alert severity="success" sx={{
      maxWidth: 700
    }}>
        <Typography variant="body2">
          Before this fix, <code>chipVariant="filled"</code> rendered an MUI{" "}
          <em>outlined</em> chip. Now it renders an actual filled chip — see{" "}
          <strong>Chip filled</strong> above for the corrected appearance.
        </Typography>
      </Alert>
    </>
}`,...y.parameters?.docs?.source}}},b=[`SubsectionPreset`,`SubsectionWithIcon`,`ChipFilled`,`ChipOutlined`,`ChipText`,`ColorDefault`,`SizeComparison`,`FixedNote`]}))();export{m as ChipFilled,h as ChipOutlined,g as ChipText,_ as ColorDefault,y as FixedNote,v as SizeComparison,f as SubsectionPreset,p as SubsectionWithIcon,b as __namedExportsOrder,d as default};