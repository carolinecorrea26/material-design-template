import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{O as r,Ot as i,Q as a,S as o,at as s,dt as c,t as l}from"./esm-AWQ-KJXU.js";import{n as u,t as d}from"./StarsRounded-DrGX3irb.js";import{n as f,t as p}from"./SelectionGroup-qsa3Rtmv.js";var m,h,g,_,v,y,b,x,S,C;t((()=>{m=e(n(),1),l(),u(),f(),h=i(),g={title:`Forms/SelectionGroup`,component:p,parameters:{layout:`padded`,docs:{description:{component:`SelectionGroup is the shared bordered, clickable row underneath every
radio, checkbox, and icon-toggle option in the app (FieldRenderer's
radio/checkbox branches, CoverageCategorySelector, ResumeMethod, and
Beneficiary's hand-rolled radiogroup all build on it). It never renders a
label itself — callers place a native input (or nothing, for icon-toggle
rows) plus a \`.SelectionGroup-label\`-classed text node as children, and
the shared theme override (see Foundations/MUI Theme Overrides) styles
that label's weight/size globally.

Selected-state styling comes from two different mechanisms depending on
whether a native input is present — see the two variants below.`}}}},_={name:`Checkbox row — unselected`,render:()=>(0,h.jsx)(s,{sx:{maxWidth:420},children:(0,h.jsxs)(p,{htmlFor:`sg-checkbox-1`,children:[(0,h.jsx)(a,{id:`sg-checkbox-1`}),(0,h.jsx)(c,{className:`SelectionGroup-label`,component:`span`,children:`I authorize this bank account for premium payments.`})]})})},v={name:`Checkbox row — selected`,render:()=>(0,h.jsxs)(s,{sx:{maxWidth:420},children:[(0,h.jsxs)(p,{htmlFor:`sg-checkbox-2`,children:[(0,h.jsx)(a,{id:`sg-checkbox-2`,defaultChecked:!0}),(0,h.jsx)(c,{className:`SelectionGroup-label`,component:`span`,children:`I authorize this bank account for premium payments.`})]}),(0,h.jsxs)(c,{variant:`caption`,color:`text.secondary`,sx:{display:`block`,mt:1},children:[`Selected via the theme's `,(0,h.jsx)(`code`,{children:`&:has(:checked)`}),` CSS — no JavaScript state needed for rows with a native input.`]})]})},y={name:`Radio row (native-input mechanism)`,render:()=>{let[e,t]=(0,m.useState)(`yes`);return(0,h.jsx)(s,{sx:{maxWidth:420},children:(0,h.jsx)(o,{spacing:1,role:`radiogroup`,"aria-label":`Do you use tobacco products?`,children:[`yes`,`no`].map(n=>(0,h.jsxs)(p,{htmlFor:`sg-radio-${n}`,children:[(0,h.jsx)(r,{id:`sg-radio-${n}`,checked:e===n,onChange:()=>t(n)}),(0,h.jsx)(c,{className:`SelectionGroup-label`,component:`span`,sx:{textTransform:`capitalize`},children:n})]},n))})})}},b={name:`Icon-toggle row (no native input) — unselected`,render:()=>(0,h.jsxs)(s,{sx:{maxWidth:420},children:[(0,h.jsxs)(p,{component:`div`,role:`checkbox`,"aria-checked":!1,tabIndex:0,checked:!1,onClick:()=>{},onKeyDown:e=>{(e.key===`Enter`||e.key===` `)&&e.preventDefault()},children:[(0,h.jsx)(d,{className:`SelectionGroup-icon`}),(0,h.jsx)(c,{className:`SelectionGroup-label`,component:`span`,children:`Life Insurance`})]}),(0,h.jsxs)(c,{variant:`caption`,color:`text.secondary`,sx:{display:`block`,mt:1},children:[`Used by `,(0,h.jsx)(`code`,{children:`CoverageCategorySelector`}),`. Selected state is driven by the explicit `,(0,h.jsx)(`code`,{children:`checked`}),` prop (rendered as`,` `,(0,h.jsx)(`code`,{children:`data-checked="true"`}),`) since there's no native input to key CSS off of — the caller owns Space/Enter activation via`,` `,(0,h.jsx)(`code`,{children:`onKeyDown`}),`.`]})]})},x={name:`Icon-toggle row (no native input) — selected`,render:()=>(0,h.jsx)(s,{sx:{maxWidth:420},children:(0,h.jsxs)(p,{component:`div`,role:`checkbox`,"aria-checked":!0,tabIndex:0,checked:!0,onClick:()=>{},children:[(0,h.jsx)(d,{className:`SelectionGroup-icon`}),(0,h.jsx)(c,{className:`SelectionGroup-label`,component:`span`,children:`Life Insurance`})]})})},S={name:`Keyboard focus`,render:()=>(0,h.jsxs)(s,{sx:{maxWidth:420},children:[(0,h.jsxs)(c,{variant:`body2`,sx:{mb:1.5},children:[`Tab to the row below to see the focus-visible outline (`,(0,h.jsx)(`code`,{children:`2px solid primary.main`}),`, offset 2px) — this applies to every SelectionGroup row, native-input or icon-toggle alike.`]}),(0,h.jsxs)(p,{component:`div`,role:`checkbox`,"aria-checked":!1,tabIndex:0,checked:!1,onClick:()=>{},children:[(0,h.jsx)(d,{className:`SelectionGroup-icon`}),(0,h.jsx)(c,{className:`SelectionGroup-label`,component:`span`,children:`Tab here`})]})]})},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  name: "Checkbox row — unselected",
  render: () => <Box sx={{
    maxWidth: 420
  }}>
      <SelectionGroup htmlFor="sg-checkbox-1">
        <Checkbox id="sg-checkbox-1" />
        <Typography className="SelectionGroup-label" component="span">
          I authorize this bank account for premium payments.
        </Typography>
      </SelectionGroup>
    </Box>
}`,..._.parameters?.docs?.source}}},v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{
  name: "Checkbox row — selected",
  render: () => <Box sx={{
    maxWidth: 420
  }}>
      <SelectionGroup htmlFor="sg-checkbox-2">
        <Checkbox id="sg-checkbox-2" defaultChecked />
        <Typography className="SelectionGroup-label" component="span">
          I authorize this bank account for premium payments.
        </Typography>
      </SelectionGroup>
      <Typography variant="caption" color="text.secondary" sx={{
      display: "block",
      mt: 1
    }}>
        Selected via the theme's <code>&:has(:checked)</code> CSS — no
        JavaScript state needed for rows with a native input.
      </Typography>
    </Box>
}`,...v.parameters?.docs?.source}}},y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  name: "Radio row (native-input mechanism)",
  render: () => {
    const [value, setValue] = useState("yes");
    return <Box sx={{
      maxWidth: 420
    }}>
        <Stack spacing={1} role="radiogroup" aria-label="Do you use tobacco products?">
          {["yes", "no"].map(option => <SelectionGroup key={option} htmlFor={\`sg-radio-\${option}\`}>
              <Radio id={\`sg-radio-\${option}\`} checked={value === option} onChange={() => setValue(option)} />
              <Typography className="SelectionGroup-label" component="span" sx={{
            textTransform: "capitalize"
          }}>
                {option}
              </Typography>
            </SelectionGroup>)}
        </Stack>
      </Box>;
  }
}`,...y.parameters?.docs?.source}}},b.parameters={...b.parameters,docs:{...b.parameters?.docs,source:{originalSource:`{
  name: "Icon-toggle row (no native input) — unselected",
  render: () => <Box sx={{
    maxWidth: 420
  }}>
      <SelectionGroup component="div" role="checkbox" aria-checked={false} tabIndex={0} checked={false} onClick={() => {}} onKeyDown={e => {
      if (e.key === "Enter" || e.key === " ") e.preventDefault();
    }}>
        <StarsRoundedIcon className="SelectionGroup-icon" />
        <Typography className="SelectionGroup-label" component="span">
          Life Insurance
        </Typography>
      </SelectionGroup>
      <Typography variant="caption" color="text.secondary" sx={{
      display: "block",
      mt: 1
    }}>
        Used by <code>CoverageCategorySelector</code>. Selected state is
        driven by the explicit <code>checked</code> prop (rendered as{" "}
        <code>data-checked="true"</code>) since there's no native input to
        key CSS off of — the caller owns Space/Enter activation via{" "}
        <code>onKeyDown</code>.
      </Typography>
    </Box>
}`,...b.parameters?.docs?.source}}},x.parameters={...x.parameters,docs:{...x.parameters?.docs,source:{originalSource:`{
  name: "Icon-toggle row (no native input) — selected",
  render: () => <Box sx={{
    maxWidth: 420
  }}>
      <SelectionGroup component="div" role="checkbox" aria-checked tabIndex={0} checked onClick={() => {}}>
        <StarsRoundedIcon className="SelectionGroup-icon" />
        <Typography className="SelectionGroup-label" component="span">
          Life Insurance
        </Typography>
      </SelectionGroup>
    </Box>
}`,...x.parameters?.docs?.source}}},S.parameters={...S.parameters,docs:{...S.parameters?.docs,source:{originalSource:`{
  name: "Keyboard focus",
  render: () => <Box sx={{
    maxWidth: 420
  }}>
      <Typography variant="body2" sx={{
      mb: 1.5
    }}>
        Tab to the row below to see the focus-visible outline (
        <code>2px solid primary.main</code>, offset 2px) — this applies to
        every SelectionGroup row, native-input or icon-toggle alike.
      </Typography>
      <SelectionGroup component="div" role="checkbox" aria-checked={false} tabIndex={0} checked={false} onClick={() => {}}>
        <StarsRoundedIcon className="SelectionGroup-icon" />
        <Typography className="SelectionGroup-label" component="span">
          Tab here
        </Typography>
      </SelectionGroup>
    </Box>
}`,...S.parameters?.docs?.source}}},C=[`CheckboxRowUnselected`,`CheckboxRowSelected`,`RadioRow`,`IconToggleRowUnselected`,`IconToggleRowSelected`,`FocusVisible`]}))();export{v as CheckboxRowSelected,_ as CheckboxRowUnselected,S as FocusVisible,x as IconToggleRowSelected,b as IconToggleRowUnselected,y as RadioRow,C as __namedExportsOrder,g as default};