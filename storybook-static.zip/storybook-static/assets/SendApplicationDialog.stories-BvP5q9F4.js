import{a as e,n as t}from"./chunk-BneVvdWh.js";import{n}from"./react-dom-BvSj50BA.js";import{Ot as r,rt as i,t as a}from"./esm-AWQ-KJXU.js";import{n as o,t as s}from"./SendApplicationDialog-CAZBLoLe.js";function c(e){let[t,n]=(0,l.useState)(!1);return(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(i,{variant:`outlined`,onClick:()=>n(!0),children:`Trigger send confirmation`}),(0,u.jsx)(s,{...e,open:t,onClose:()=>n(!1),onConfirm:()=>n(!1)})]})}var l,u,d,f,p,m,h;t((()=>{l=e(n(),1),a(),o(),u=r(),d={title:`Overlays/SendApplicationDialog`,component:s,parameters:{layout:`centered`,docs:{description:{component:`SendApplicationDialog is a second AppModal preset (alongside
ConfirmationDialog), confirming the recipient before an advisor↔applicant
handoff email is sent. Used from Profile (advisor sending to the
applicant) and Review (applicant sending an edit back to the advisor).
Missing from \`componentInventory.ts\` today — the same gap flagged in the
Phase 1 audit.`}}}},f={name:`To applicant (advisor → applicant handoff)`,render:()=>(0,u.jsx)(c,{recipientLabel:`applicant`,recipientName:`Jordan Rivera`,recipientEmail:`jordan.rivera@example.com`})},p={name:`To advisor (applicant edit return)`,render:()=>(0,u.jsx)(c,{recipientLabel:`advisor`,showRecipientName:!1,recipientEmail:`advisor@example.com`,introText:`This edited application will be sent back to your advisor:`}),parameters:{docs:{description:{story:`showRecipientName={false} hides the Name row — used when only the recipient's email is known/relevant, as in the applicant → advisor return flow.`}}}},m={name:`Missing name/email (em dash fallback)`,render:()=>(0,u.jsx)(c,{recipientEmail:``}),parameters:{docs:{description:{story:`Both the name and email rows fall back to an em dash (—) rather than rendering empty, so the dialog never shows a blank-looking row.`}}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  name: "To applicant (advisor → applicant handoff)",
  render: () => <SendDialogDemo recipientLabel="applicant" recipientName="Jordan Rivera" recipientEmail="jordan.rivera@example.com" />
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  name: "To advisor (applicant edit return)",
  render: () => <SendDialogDemo recipientLabel="advisor" showRecipientName={false} recipientEmail="advisor@example.com" introText="This edited application will be sent back to your advisor:" />,
  parameters: {
    docs: {
      description: {
        story: "showRecipientName={false} hides the Name row — used when only the recipient's email is known/relevant, as in the applicant → advisor return flow."
      }
    }
  }
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  name: "Missing name/email (em dash fallback)",
  render: () => <SendDialogDemo recipientEmail="" />,
  parameters: {
    docs: {
      description: {
        story: "Both the name and email rows fall back to an em dash (—) rather than rendering empty, so the dialog never shows a blank-looking row."
      }
    }
  }
}`,...m.parameters?.docs?.source}}},h=[`Default`,`ToAdvisor`,`MissingRecipientData`]}))();export{f as Default,m as MissingRecipientData,p as ToAdvisor,h as __namedExportsOrder,d as default};