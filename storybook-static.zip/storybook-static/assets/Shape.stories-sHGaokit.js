import{n as e}from"./chunk-BneVvdWh.js";import{$ as t,Ot as n,S as r,St as i,Tt as a,at as o,dt as s,ft as c,lt as l,nt as u,rt as d,t as f}from"./esm-AWQ-KJXU.js";import{a as p,n as m}from"./theme-B3ct2zHf.js";import{i as h,n as g,s as _,t as v}from"./DocsBlocks-BEbHO4Nl.js";var y,b,x,S;e((()=>{i(),f(),p(),_(),y=n(),b={title:`Foundations/Shape`,parameters:{layout:`padded`}},x=()=>{let e=a();return(0,y.jsxs)(v,{eyebrow:`Foundations`,title:`Shape`,intro:(0,y.jsx)(y.Fragment,{children:`Two radius conventions cover the whole app: a shared card radius for surfaces, and a fully pill-shaped radius for buttons and toggle groups. There is no third, smaller "chip" radius — chips use MUI's own default.`}),children:[(0,y.jsxs)(g,{title:`Card radius — CARD_RADIUS`,description:`Exported once (${m}) and reused by Card, CardContent's parent, Alert, OutlinedInput, ToggleButton/ToggleButtonGroup — every stacked surface shares this radius so they read as one consistent system.`,children:[(0,y.jsxs)(r,{direction:`row`,spacing:2,flexWrap:`wrap`,children:[(0,y.jsx)(u,{variant:`outlined`,sx:{width:160,height:90},children:(0,y.jsx)(t,{children:(0,y.jsx)(s,{variant:`caption`,children:`Card`})})}),(0,y.jsx)(c,{severity:`info`,sx:{width:220,alignItems:`center`},children:`Alert`}),(0,y.jsx)(o,{sx:{width:160,height:90,border:`1px solid rgba(52,59,72,0.23)`,borderRadius:m,display:`flex`,alignItems:`center`,justifyContent:`center`,bgcolor:`background.paper`},children:(0,y.jsx)(s,{variant:`caption`,color:`text.secondary`,children:`OutlinedInput`})})]}),(0,y.jsxs)(h,{children:[`src/app/theme.ts — export const CARD_RADIUS = "`,m,`"`]})]}),(0,y.jsx)(g,{title:`Pill radius — buttons & toggle groups`,description:`MuiButton and MuiToggleButton both use borderRadius: 9999, i.e. always fully rounded regardless of height.`,children:(0,y.jsxs)(r,{direction:`row`,spacing:2,alignItems:`center`,children:[(0,y.jsx)(d,{variant:`contained`,children:`Contained`}),(0,y.jsx)(d,{variant:`outlined`,children:`Outlined`}),(0,y.jsx)(l,{label:`Chip — MUI default radius, not CARD_RADIUS`,variant:`outlined`})]})}),(0,y.jsxs)(g,{title:`Base shape unit`,description:`MUI's own shape.borderRadius, used only where no override above applies (Chip, and any unstyled MUI component).`,children:[(0,y.jsxs)(s,{variant:`body2`,color:`text.secondary`,children:[`theme.shape.borderRadius = `,(0,y.jsx)(`code`,{children:e.shape.borderRadius})]}),(0,y.jsxs)(h,{children:[`src/app/theme.ts — createTheme(`,`{`,` shape: `,`{`,` borderRadius: 8 `,`}`,` `,`}`,`)`]})]})]})},x.__docgenInfo={description:``,methods:[],displayName:`Shape`},x.parameters={...x.parameters,docs:{...x.parameters?.docs,source:{originalSource:`() => {
  const theme = useTheme();
  return <DocsPage eyebrow="Foundations" title="Shape" intro={<>
          Two radius conventions cover the whole app: a shared card radius
          for surfaces, and a fully pill-shaped radius for buttons and
          toggle groups. There is no third, smaller "chip" radius — chips
          use MUI's own default.
        </>}>
      <DocsSection title="Card radius — CARD_RADIUS" description={\`Exported once (\${CARD_RADIUS}) and reused by Card, CardContent's parent, Alert, OutlinedInput, ToggleButton/ToggleButtonGroup — every stacked surface shares this radius so they read as one consistent system.\`}>
        <Stack direction="row" spacing={2} flexWrap="wrap">
          <Card variant="outlined" sx={{
          width: 160,
          height: 90
        }}>
            <CardContent>
              <Typography variant="caption">Card</Typography>
            </CardContent>
          </Card>
          <Alert severity="info" sx={{
          width: 220,
          alignItems: "center"
        }}>
            Alert
          </Alert>
          <Box sx={{
          width: 160,
          height: 90,
          border: "1px solid rgba(52,59,72,0.23)",
          borderRadius: CARD_RADIUS,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          bgcolor: "background.paper"
        }}>
            <Typography variant="caption" color="text.secondary">OutlinedInput</Typography>
          </Box>
        </Stack>
        <SourceNote>src/app/theme.ts — export const CARD_RADIUS = "{CARD_RADIUS}"</SourceNote>
      </DocsSection>

      <DocsSection title="Pill radius — buttons & toggle groups" description="MuiButton and MuiToggleButton both use borderRadius: 9999, i.e. always fully rounded regardless of height.">
        <Stack direction="row" spacing={2} alignItems="center">
          <Button variant="contained">Contained</Button>
          <Button variant="outlined">Outlined</Button>
          <Chip label="Chip — MUI default radius, not CARD_RADIUS" variant="outlined" />
        </Stack>
      </DocsSection>

      <DocsSection title="Base shape unit" description="MUI's own shape.borderRadius, used only where no override above applies (Chip, and any unstyled MUI component).">
        <Typography variant="body2" color="text.secondary">
          theme.shape.borderRadius = <code>{theme.shape.borderRadius}</code>
        </Typography>
        <SourceNote>src/app/theme.ts — createTheme({"{"} shape: {"{"} borderRadius: 8 {"}"} {"}"})</SourceNote>
      </DocsSection>
    </DocsPage>;
}`,...x.parameters?.docs?.source}}},S=[`Shape`]}))();export{x as Shape,S as __namedExportsOrder,b as default};