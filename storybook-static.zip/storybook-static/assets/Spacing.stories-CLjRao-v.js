import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,S as n,St as r,Tt as i,at as a,dt as o,t as s}from"./esm-AWQ-KJXU.js";import{i as c,n as l,s as u,t as d}from"./DocsBlocks-BEbHO4Nl.js";var f,p,m,h,g;e((()=>{r(),s(),u(),f=t(),p={title:`Foundations/Spacing`,parameters:{layout:`padded`}},m=[.5,1,1.5,2,3,4,6,8],h=()=>{let e=i();return(0,f.jsxs)(d,{eyebrow:`Foundations`,title:`Spacing`,intro:(0,f.jsxs)(f.Fragment,{children:[`Base spacing unit: `,(0,f.jsx)(`code`,{children:String(e.spacing(1))}),` per`,` `,(0,f.jsx)(`code`,{children:`theme.spacing(1)`}),`. Every `,(0,f.jsx)(`code`,{children:`sx`}),` spacing value in the app (`,(0,f.jsx)(`code`,{children:`p`}),`, `,(0,f.jsx)(`code`,{children:`m`}),`, `,(0,f.jsx)(`code`,{children:`gap`}),`,`,` `,(0,f.jsx)(`code`,{children:`spacing`}),` on `,(0,f.jsx)(`code`,{children:`Stack`}),`, etc.) is a multiple of this unit — there is no separate spacing scale to memorize.`]}),children:[(0,f.jsxs)(l,{title:`Multiplier reference`,children:[(0,f.jsx)(n,{spacing:1.5,children:m.map(t=>(0,f.jsxs)(n,{direction:`row`,spacing:2,alignItems:`center`,children:[(0,f.jsxs)(o,{variant:`caption`,sx:{width:90,fontFamily:`monospace`},children:[`theme.spacing(`,t,`)`]}),(0,f.jsx)(a,{sx:{height:20,width:e.spacing(t),bgcolor:`primary.main`,borderRadius:.5,flexShrink:0}}),(0,f.jsx)(o,{variant:`caption`,color:`text.secondary`,children:e.spacing(t)})]},t))}),(0,f.jsxs)(c,{children:[`src/app/theme.ts — createTheme(`,`{`,` spacing: 8 `,`}`,`)`]})]}),(0,f.jsx)(l,{title:`Common usage in this app`,description:`Representative, not exhaustive — do not catalog every sx spacing value in the codebase here.`,children:(0,f.jsxs)(n,{spacing:1,children:[(0,f.jsxs)(o,{variant:`body2`,children:[(0,f.jsxs)(`code`,{children:[`spacing=`,`{2}`]}),` / `,(0,f.jsx)(`code`,{children:`{3}`}),` — the most common gap between stacked fields and between a card's internal sections.`]}),(0,f.jsxs)(o,{variant:`body2`,children:[(0,f.jsxs)(`code`,{children:[`px: `,`{ xs: 2, sm: 3, md: 4 }`]}),` — AppBody's responsive page-content padding.`]}),(0,f.jsxs)(o,{variant:`body2`,children:[(0,f.jsxs)(`code`,{children:[`py: `,`{ xs: 4, sm: 6 }`]}),` — outer vertical padding on standalone pages outside the main form shell (Resume, ResumeCode, ResumeMethod).`]})]})})]})},h.__docgenInfo={description:``,methods:[],displayName:`Spacing`},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`() => {
  const theme = useTheme();
  return <DocsPage eyebrow="Foundations" title="Spacing" intro={<>
          Base spacing unit: <code>{String(theme.spacing(1))}</code> per{" "}
          <code>theme.spacing(1)</code>. Every <code>sx</code> spacing value
          in the app (<code>p</code>, <code>m</code>, <code>gap</code>,{" "}
          <code>spacing</code> on <code>Stack</code>, etc.) is a multiple of
          this unit — there is no separate spacing scale to memorize.
        </>}>
      <DocsSection title="Multiplier reference">
        <Stack spacing={1.5}>
          {MULTIPLIERS.map(m => <Stack key={m} direction="row" spacing={2} alignItems="center">
              <Typography variant="caption" sx={{
            width: 90,
            fontFamily: "monospace"
          }}>
                theme.spacing({m})
              </Typography>
              <Box sx={{
            height: 20,
            width: theme.spacing(m),
            bgcolor: "primary.main",
            borderRadius: 0.5,
            flexShrink: 0
          }} />
              <Typography variant="caption" color="text.secondary">
                {theme.spacing(m)}
              </Typography>
            </Stack>)}
        </Stack>
        <SourceNote>src/app/theme.ts — createTheme({"{"} spacing: 8 {"}"})</SourceNote>
      </DocsSection>

      <DocsSection title="Common usage in this app" description="Representative, not exhaustive — do not catalog every sx spacing value in the codebase here.">
        <Stack spacing={1}>
          <Typography variant="body2"><code>spacing={"{2}"}</code> / <code>{"{3}"}</code> — the most common gap between stacked fields and between a card's internal sections.</Typography>
          <Typography variant="body2"><code>px: {"{ xs: 2, sm: 3, md: 4 }"}</code> — AppBody's responsive page-content padding.</Typography>
          <Typography variant="body2"><code>py: {"{ xs: 4, sm: 6 }"}</code> — outer vertical padding on standalone pages outside the main form shell (Resume, ResumeCode, ResumeMethod).</Typography>
        </Stack>
      </DocsSection>
    </DocsPage>;
}`,...h.parameters?.docs?.source}}},g=[`Spacing`]}))();export{h as Spacing,g as __namedExportsOrder,p as default};