import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,at as n,dt as r,t as i}from"./esm-AWQ-KJXU.js";import{n as a,t as o}from"./TotalCostSummary-B8FSuBrA.js";var s,c,l,u,d,f,p,m,h;e((()=>{i(),a(),s=t(),c={title:`Coverage & Commerce/TotalCostSummary`,component:o,parameters:{layout:`padded`,docs:{description:{component:`TotalCostSummary is the shared "Total Estimated Cost" panel used by both
the Coverage page's estimated-cost panel and CoverageCart — already a
good single-component/multiple-consumer precedent. RateFrequencyControl is
the separate canonical owner of the labeled Monthly/Annual switch row.
\`role="status"\`/\`aria-live="polite"\` on the wrapping Box means any prop
change re-announces the whole panel to assistive tech, including
per-item recalculation spinners.`}}}},l=[{id:`li`,name:`Life Insurance`,amount:42.5},{id:`di`,name:`Disability Insurance`,amount:18.75}],u={render:()=>(0,s.jsx)(n,{sx:{maxWidth:360},children:(0,s.jsx)(o,{items:l,total:61.25})})},d={name:`totalSuffix="/yr"`,render:()=>(0,s.jsx)(n,{sx:{maxWidth:360},children:(0,s.jsx)(o,{items:l,total:735,totalSuffix:`/yr`})})},f={name:`isCalculating (recalculating spinner)`,render:()=>(0,s.jsx)(n,{sx:{maxWidth:360},children:(0,s.jsx)(o,{items:[{id:`li`,name:`Life Insurance`,amount:42.5},{id:`di`,name:`Disability Insurance`,amount:18.75,isCalculating:!0}],total:61.25,isCalculating:!0})}),parameters:{docs:{description:{story:`Per-item isCalculating swaps that row's amount for a spinner; the top-level isCalculating does the same for the Total row. A consumer can show one without the other — e.g. one product recalculating while the grand total still reflects the last-known value.`}}}},p={render:()=>(0,s.jsx)(n,{sx:{maxWidth:360},children:(0,s.jsx)(o,{items:l,total:61.25,disclaimer:(0,s.jsx)(r,{component:`span`,variant:`caption`,color:`text.secondary`,children:`1. Estimated rates are subject to underwriting review.`})})})},m={render:()=>(0,s.jsx)(n,{sx:{maxWidth:360},children:(0,s.jsx)(o,{items:[{id:`li`,name:`Life Insurance`,amount:42.5}],total:42.5})})},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  render: () => <Box sx={{
    maxWidth: 360
  }}>
      <TotalCostSummary items={sampleItems} total={61.25} />
    </Box>
}`,...u.parameters?.docs?.source}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  name: 'totalSuffix="/yr"',
  render: () => <Box sx={{
    maxWidth: 360
  }}>
      <TotalCostSummary items={sampleItems} total={735} totalSuffix="/yr" />
    </Box>
}`,...d.parameters?.docs?.source}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  name: "isCalculating (recalculating spinner)",
  render: () => <Box sx={{
    maxWidth: 360
  }}>
      <TotalCostSummary items={[{
      id: "li",
      name: "Life Insurance",
      amount: 42.5
    }, {
      id: "di",
      name: "Disability Insurance",
      amount: 18.75,
      isCalculating: true
    }]} total={61.25} isCalculating />
    </Box>,
  parameters: {
    docs: {
      description: {
        story: "Per-item isCalculating swaps that row's amount for a spinner; the top-level isCalculating does the same for the Total row. A consumer can show one without the other — e.g. one product recalculating while the grand total still reflects the last-known value."
      }
    }
  }
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: () => <Box sx={{
    maxWidth: 360
  }}>
      <TotalCostSummary items={sampleItems} total={61.25} disclaimer={<Typography component="span" variant="caption" color="text.secondary">
            1. Estimated rates are subject to underwriting review.
          </Typography>} />
    </Box>
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  render: () => <Box sx={{
    maxWidth: 360
  }}>
      <TotalCostSummary items={[{
      id: "li",
      name: "Life Insurance",
      amount: 42.5
    }]} total={42.5} />
    </Box>
}`,...m.parameters?.docs?.source}}},h=[`Default`,`AnnualSuffix`,`Calculating`,`WithDisclaimer`,`SingleItem`]}))();export{d as AnnualSuffix,f as Calculating,u as Default,m as SingleItem,p as WithDisclaimer,h as __namedExportsOrder,c as default};