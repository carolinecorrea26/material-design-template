import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,S as n,at as r,t as i,z as a}from"./esm-AWQ-KJXU.js";import{n as o,t as s}from"./FieldRenderer-DRJtoa2k.js";import{n as c,t as l}from"./DynamicList-56mOhY9W.js";function u({icon:e,children:t}){return(0,d.jsxs)(r,{component:`li`,sx:{display:`grid`,gridTemplateColumns:`auto 1fr`,columnGap:1.5,alignItems:`start`},children:[(0,d.jsx)(r,{component:`span`,sx:{fontWeight:500,textAlign:`right`},children:e}),t]})}var d,f=e((()=>{i(),d=t(),u.__docgenInfo={description:``,methods:[],displayName:`IconListItem`,props:{icon:{required:!0,tsType:{name:`ReactNode`},description:``},children:{required:!0,tsType:{name:`ReactNode`},description:``}}}}));function p({questions:e,control:t,errors:i,watchedValues:o}){return(0,m.jsx)(n,{component:`ol`,spacing:3,sx:{listStyle:`none`,pl:0},children:e.map((e,c)=>(0,m.jsx)(u,{icon:`${c+1}.`,children:(0,m.jsxs)(n,{spacing:2,children:[(0,m.jsxs)(r,{children:[(0,m.jsx)(a,{required:e.field.required,id:`${e.field.id}-label`,sx:{display:`inline-block`,mb:1},children:e.field.label}),(0,m.jsx)(s,{field:e.field,control:t,errors:i,hideLabel:!0,margin:`none`})]}),o[e.field.id]===`yes`&&(0,m.jsx)(l,{control:t,name:e.listName,label:`details`,mapping:e.mapping,renderItem:e.renderItem})]})},e.field.id))})}var m,h=e((()=>{i(),f(),c(),o(),m=t(),p.__docgenInfo={description:`Numbered yes/no questions that reveal a canonical DynamicList on “Yes”.`,methods:[],displayName:`YesNoDetailList`,props:{questions:{required:!0,tsType:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  field: FieldDefinition;
  listName: string;
  mapping: DynamicListFieldMapping<Record<string, string>>;
  renderItem: (item: Record<string, string>) => ReactNode;
}`,signature:{properties:[{key:`field`,value:{name:`signature`,type:`object`,raw:`{
  id: string;
  label: string;
  tooltip?: string;
  inputType: FieldInputType;
  required?: boolean;
  placeholder?: string;
  helperText?: string;
  options?: FieldOption[];
  autoComplete?: string;
  inputMode?: "text" | "email" | "tel" | "numeric";
  format?: "email" | "phone" | "ssn" | "currency" | "percent" | "month-year";
  labelVariant?: "floating" | "standard";
  multiline?: boolean;
  minRows?: number;
  disabled?: boolean;
  /** Override the companion phone-type field name (default: "phone-type") */
  phoneTypeFieldId?: string;
  /** Whether to show the companion phone type selector (default: true) */
  showPhoneTypeSelector?: boolean;
}`,signature:{properties:[{key:`id`,value:{name:`string`,required:!0}},{key:`label`,value:{name:`string`,required:!0}},{key:`tooltip`,value:{name:`string`,required:!1}},{key:`inputType`,value:{name:`union`,raw:`| "text"
| "number"
| "date"
| "radio"
| "dropdown"
| "searchable-select"
| "checkbox"
| "checkbox-group"
| "multi-select"
| "percent"`,elements:[{name:`literal`,value:`"text"`},{name:`literal`,value:`"number"`},{name:`literal`,value:`"date"`},{name:`literal`,value:`"radio"`},{name:`literal`,value:`"dropdown"`},{name:`literal`,value:`"searchable-select"`},{name:`literal`,value:`"checkbox"`},{name:`literal`,value:`"checkbox-group"`},{name:`literal`,value:`"multi-select"`},{name:`literal`,value:`"percent"`}],required:!0}},{key:`required`,value:{name:`boolean`,required:!1}},{key:`placeholder`,value:{name:`string`,required:!1}},{key:`helperText`,value:{name:`string`,required:!1}},{key:`options`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  value: string;
  label: string;
}`,signature:{properties:[{key:`value`,value:{name:`string`,required:!0}},{key:`label`,value:{name:`string`,required:!0}}]}}],raw:`FieldOption[]`,required:!1}},{key:`autoComplete`,value:{name:`string`,required:!1}},{key:`inputMode`,value:{name:`union`,raw:`"text" | "email" | "tel" | "numeric"`,elements:[{name:`literal`,value:`"text"`},{name:`literal`,value:`"email"`},{name:`literal`,value:`"tel"`},{name:`literal`,value:`"numeric"`}],required:!1}},{key:`format`,value:{name:`union`,raw:`"email" | "phone" | "ssn" | "currency" | "percent" | "month-year"`,elements:[{name:`literal`,value:`"email"`},{name:`literal`,value:`"phone"`},{name:`literal`,value:`"ssn"`},{name:`literal`,value:`"currency"`},{name:`literal`,value:`"percent"`},{name:`literal`,value:`"month-year"`}],required:!1}},{key:`labelVariant`,value:{name:`union`,raw:`"floating" | "standard"`,elements:[{name:`literal`,value:`"floating"`},{name:`literal`,value:`"standard"`}],required:!1}},{key:`multiline`,value:{name:`boolean`,required:!1}},{key:`minRows`,value:{name:`number`,required:!1}},{key:`disabled`,value:{name:`boolean`,required:!1}},{key:`phoneTypeFieldId`,value:{name:`string`,required:!1},description:`Override the companion phone-type field name (default: "phone-type")`},{key:`showPhoneTypeSelector`,value:{name:`boolean`,required:!1},description:`Whether to show the companion phone type selector (default: true)`}]},required:!0}},{key:`listName`,value:{name:`string`,required:!0}},{key:`mapping`,value:{name:`signature`,type:`object`,raw:`{
  fields: FieldDefinition[];
  fieldToKey: T;
  /** Field IDs to render side-by-side in a 2-column grid inside the dialog. */
  gridFields?: string[];
}`,signature:{properties:[{key:`fields`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  id: string;
  label: string;
  tooltip?: string;
  inputType: FieldInputType;
  required?: boolean;
  placeholder?: string;
  helperText?: string;
  options?: FieldOption[];
  autoComplete?: string;
  inputMode?: "text" | "email" | "tel" | "numeric";
  format?: "email" | "phone" | "ssn" | "currency" | "percent" | "month-year";
  labelVariant?: "floating" | "standard";
  multiline?: boolean;
  minRows?: number;
  disabled?: boolean;
  /** Override the companion phone-type field name (default: "phone-type") */
  phoneTypeFieldId?: string;
  /** Whether to show the companion phone type selector (default: true) */
  showPhoneTypeSelector?: boolean;
}`,signature:{properties:[{key:`id`,value:{name:`string`,required:!0}},{key:`label`,value:{name:`string`,required:!0}},{key:`tooltip`,value:{name:`string`,required:!1}},{key:`inputType`,value:{name:`union`,raw:`| "text"
| "number"
| "date"
| "radio"
| "dropdown"
| "searchable-select"
| "checkbox"
| "checkbox-group"
| "multi-select"
| "percent"`,elements:[{name:`literal`,value:`"text"`},{name:`literal`,value:`"number"`},{name:`literal`,value:`"date"`},{name:`literal`,value:`"radio"`},{name:`literal`,value:`"dropdown"`},{name:`literal`,value:`"searchable-select"`},{name:`literal`,value:`"checkbox"`},{name:`literal`,value:`"checkbox-group"`},{name:`literal`,value:`"multi-select"`},{name:`literal`,value:`"percent"`}],required:!0}},{key:`required`,value:{name:`boolean`,required:!1}},{key:`placeholder`,value:{name:`string`,required:!1}},{key:`helperText`,value:{name:`string`,required:!1}},{key:`options`,value:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  value: string;
  label: string;
}`,signature:{properties:[{key:`value`,value:{name:`string`,required:!0}},{key:`label`,value:{name:`string`,required:!0}}]}}],raw:`FieldOption[]`,required:!1}},{key:`autoComplete`,value:{name:`string`,required:!1}},{key:`inputMode`,value:{name:`union`,raw:`"text" | "email" | "tel" | "numeric"`,elements:[{name:`literal`,value:`"text"`},{name:`literal`,value:`"email"`},{name:`literal`,value:`"tel"`},{name:`literal`,value:`"numeric"`}],required:!1}},{key:`format`,value:{name:`union`,raw:`"email" | "phone" | "ssn" | "currency" | "percent" | "month-year"`,elements:[{name:`literal`,value:`"email"`},{name:`literal`,value:`"phone"`},{name:`literal`,value:`"ssn"`},{name:`literal`,value:`"currency"`},{name:`literal`,value:`"percent"`},{name:`literal`,value:`"month-year"`}],required:!1}},{key:`labelVariant`,value:{name:`union`,raw:`"floating" | "standard"`,elements:[{name:`literal`,value:`"floating"`},{name:`literal`,value:`"standard"`}],required:!1}},{key:`multiline`,value:{name:`boolean`,required:!1}},{key:`minRows`,value:{name:`number`,required:!1}},{key:`disabled`,value:{name:`boolean`,required:!1}},{key:`phoneTypeFieldId`,value:{name:`string`,required:!1},description:`Override the companion phone-type field name (default: "phone-type")`},{key:`showPhoneTypeSelector`,value:{name:`boolean`,required:!1},description:`Whether to show the companion phone type selector (default: true)`}]},required:!0}],raw:`FieldDefinition[]`,required:!0}},{key:`fieldToKey`,value:{name:`Record`,elements:[{name:`string`},{name:`string`}],raw:`Record<string, string>`,required:!0}},{key:`gridFields`,value:{name:`Array`,elements:[{name:`string`}],raw:`string[]`,required:!1},description:`Field IDs to render side-by-side in a 2-column grid inside the dialog.`}]},required:!0}},{key:`renderItem`,value:{name:`signature`,type:`function`,raw:`(item: Record<string, string>) => ReactNode`,signature:{arguments:[{type:{name:`Record`,elements:[{name:`string`},{name:`string`}],raw:`Record<string, string>`},name:`item`}],return:{name:`ReactNode`}},required:!0}}]}}],raw:`YesNoDetailQuestion[]`},description:``}}}}));export{h as n,p as t};