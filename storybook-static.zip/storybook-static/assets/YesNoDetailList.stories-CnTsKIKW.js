import{n as e}from"./chunk-BneVvdWh.js";import{Ot as t,S as n,dt as r,t as i}from"./esm-AWQ-KJXU.js";import{i as a,n as o}from"./index.esm-DbA_UsRE.js";import{n as s,t as c}from"./YesNoDetailList-CLSEk16e.js";var l,u,d,f,p,m;e((()=>{o(),i(),s(),l=t(),u={title:`Application Patterns/YesNoDetailList`,component:c,parameters:{layout:`padded`}},d={id:`medical-treatment`,label:`Have you received medical treatment during the past five years?`,inputType:`radio`,required:!0,options:[{value:`yes`,label:`Yes`},{value:`no`,label:`No`}],labelVariant:`standard`},f={id:`details`,label:`Treatment details`,inputType:`text`,required:!0,multiline:!0},p=()=>{let{control:e,watch:t,formState:{errors:i}}=a({defaultValues:{"medical-treatment":`no`}});return(0,l.jsx)(c,{control:e,errors:i,watchedValues:t(),questions:[{field:d,listName:`medical-treatment-details`,mapping:{fields:[f],fieldToKey:{details:`details`}},renderItem:e=>(0,l.jsx)(n,{spacing:.25,children:(0,l.jsx)(r,{variant:`body2`,children:e.details})})}]})},p.__docgenInfo={description:``,methods:[],displayName:`Interactive`},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`() => {
  const {
    control,
    watch,
    formState: {
      errors
    }
  } = useForm<DemoValues>({
    defaultValues: {
      "medical-treatment": "no"
    }
  });
  return <YesNoDetailList control={control} errors={errors} watchedValues={watch()} questions={[{
    field: questionField,
    listName: "medical-treatment-details",
    mapping: {
      fields: [detailField],
      fieldToKey: {
        details: "details"
      }
    },
    renderItem: item => <Stack spacing={0.25}>
              <Typography variant="body2">{item.details}</Typography>
            </Stack>
  }]} />;
}`,...p.parameters?.docs?.source}}},m=[`Interactive`]}))();export{p as Interactive,m as __namedExportsOrder,u as default};